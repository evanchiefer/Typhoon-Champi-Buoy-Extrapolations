# Refined model: storm pressure profile + atmospheric background (env. pressure, synoptic trend, S1 and S2 tides).
# Two independent profile families:
#   A: two-ring Holland (1980) pressure profile
#   B: wind profile (inner power law, outer dual exponential, Willoughby-type) integrated through gradient-wind balance
# Pc = background at 17:33Z minus total storm deficit (the actual MSLP at the centre, including the tide).
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import numpy as np, json
from scipy.optimize import least_squares
from scipy.stats import qmc
BASE=ROOT+os.sep
INP=json.load(open(os.path.join(DATA,'inputs.json')))
B_=np.array(INP['buoy']); t,lat,lon,P=B_[:,0],B_[:,1],B_[:,2],B_[:,3]
TC=17.55                                   # time of closest approach (17:33Z) at which Pc is reported
LST=t+lon/15.0                             # local solar time (h)
RHO=1.15; FCOR=2*7.292e-5*np.sin(np.radians(17.3)); KT=1/0.5144
# ---- centre tracks ----
fx=json.load(open(os.path.join(DATA,'ir_eye_fixes.json'))); th=np.array(sorted(int(k) for k in fx))
FLAT=np.array([fx[str(h)]['lat'] for h in th]); FLON=np.array([fx[str(h)]['lon'] for h in th])
IRLAT=np.polyfit(th,FLAT,2); IRLON=np.polyfit(th,FLON,2)
BT=np.array(INP['bt']); BTLAT=np.polyfit(BT[:,0],BT[:,1],3); BTLON=np.polyfit(BT[:,0],BT[:,2],3)
def _fixes(tq,c):   # hourly IR eye fixes, linear between fixes; quadratic trend outside 07Z-00Z (buoy far from the storm there)
    tq=np.asarray(tq,float); inside=(tq>=th[0])&(tq<=th[-1])
    v=np.interp(tq,th,FLAT if c=='lat' else FLON); q=np.polyval(IRLAT if c=='lat' else IRLON,tq)
    # continuous at the ends: quadratic shifted to meet the first/last fix
    lo_=np.polyval(IRLAT if c=='lat' else IRLON,th[0]); hi_=np.polyval(IRLAT if c=='lat' else IRLON,th[-1])
    e0=(FLAT if c=='lat' else FLON)[0]-lo_; e1=(FLAT if c=='lat' else FLON)[-1]-hi_
    return np.where(inside,v,np.where(tq<th[0],q+e0,q+e1))
# Surface-centre offset from the IR eye fix (km E, km N), measured relative to the hourly fixes:
#   RCM-3 SAR 09:20Z level-2 (+7.7,-8.1), ATMS 17:01Z (+6.9,-10.1), RCM-3 SAR 21:15Z level-2 (+6.8,-9.3)  ->  mean (+7.1,-9.2), +-2 km
TRACKS={'irf':(lambda tq:_fixes(tq,'lat'),lambda tq:_fixes(tq,'lon'),np.array([7.13,-9.17]),2.0),       # primary
        'ir':(lambda tq:np.polyval(IRLAT,tq),lambda tq:np.polyval(IRLON,tq),np.array([6.0,-10.2]),4.0),   # smoothed (quadratic) IR track, previous analysis
        'bt':(lambda tq:np.polyval(BTLAT,tq),lambda tq:np.polyval(BTLON,tq),np.array([0.0,0.0]),6.0)}     # JTWC best-track positions
def dist(track,sx,sy,tq=t,la=lat,lo=lon):
    fa,fo=TRACKS[track][:2]; cla=fa(tq); clo=fo(tq)
    kx=111.0*np.cos(np.radians((la+cla)/2)); return np.hypot((lo-clo)*kx-sx,(la-cla)*111.0-sy)
# ---- background ----
def background(bg,tq=t,lst=LST):
    Pn,b1,c1,s1,c2,s2=bg; w=2*np.pi/24
    return Pn+b1*(tq-TC)+c1*np.cos(w*lst)+s1*np.sin(w*lst)+c2*np.cos(2*w*lst)+s2*np.sin(2*w*lst)
LST_C=TC+131.55/15.0
# ---- family A: two-ring Holland ----
def defA(r,parts):
    return sum(dP*(1-np.exp(-(R/np.maximum(r,0.05))**Bh)) for dP,R,Bh in parts)   # deficit relative to background
def vgA(r,parts):
    g=0*r
    for dP,R,Bh in parts: x=(R/r)**Bh; g=g+dP*100*Bh*x*np.exp(-x)
    rm=r*1e3; return np.sqrt(g/RHO+(FCOR*rm/2)**2)-FCOR*rm/2
# ---- family B: wind profile + gradient balance ----
RG=np.concatenate([np.linspace(0,1,1),np.geomspace(1e-3,1,1)])  # placeholder
def windB(r,Vm,Rm,n,A,X1,X2):
    r=np.asarray(r,float); v=np.where(r<Rm,(np.maximum(r,0)/Rm)**n,(1-A)*np.exp(-(r-Rm)/X1)+A*np.exp(-(r-Rm)/X2)); return Vm*v
def defB_unit(Rm,n,A,X1,X2):
    # returns functions g(r)=rho*int_r^inf v^2/r' dr', h(r)=rho*f*int_r^inf v dr'  (per unit Vm^2 and Vm), Pa, r in km
    ro=Rm+np.concatenate([[0],np.geomspace(0.05,4000,700)])
    vo=(1-A)*np.exp(-(ro-Rm)/X1)+A*np.exp(-(ro-Rm)/X2)
    a=vo**2/ro; b=vo
    ca=np.concatenate([[0],np.cumsum((a[1:]+a[:-1])/2*np.diff(ro))]); cb=np.concatenate([[0],np.cumsum((b[1:]+b[:-1])/2*np.diff(ro))])
    Ga=ca[-1]-ca; Gb=(cb[-1]-cb)*1e3             # int_r^inf (km-> m for the f*v term; v^2/r term is scale-free)
    g_Rm=RHO*Ga[0]; h_Rm=RHO*FCOR*Gb[0]
    def gh(r):
        r=np.asarray(r,float); out_g=np.empty_like(r); out_h=np.empty_like(r); o=r>=Rm
        out_g[o]=RHO*np.interp(r[o],ro,Ga); out_h[o]=RHO*FCOR*np.interp(r[o],ro,Gb)
        x=np.maximum(r[~o],0)/Rm
        out_g[~o]=g_Rm+RHO*(1-x**(2*n))/(2*n); out_h[~o]=h_Rm+RHO*FCOR*Rm*1e3*(1-x**(n+1))/(n+1)
        return out_g,out_h
    return gh
def shapeC(r,Rm,n,A,X1,X2,a,R2,W2):
    r=np.asarray(r,float)
    v1=np.where(r<Rm,(np.maximum(r,0)/Rm)**n,(1-A)*np.exp(-(r-Rm)/X1)+A*np.exp(-(r-Rm)/X2))
    return v1+a*np.exp(-((r-R2)/W2)**2)
RGC=None
def defC_unit(Rm,n,A,X1,X2,a,R2,W2):
    rr=np.concatenate([Rm*np.geomspace(1e-4,1,320)[:-1],Rm+np.concatenate([[0],np.geomspace(0.05,4000,800)])])
    v=shapeC(rr,Rm,n,A,X1,X2,a,R2,W2); fa=v**2/rr; fb=v
    ca=np.concatenate([[0],np.cumsum((fa[1:]+fa[:-1])/2*np.diff(rr))]); cb=np.concatenate([[0],np.cumsum((fb[1:]+fb[:-1])/2*np.diff(rr))])
    Ga=RHO*(ca[-1]-ca); Gb=RHO*FCOR*(cb[-1]-cb)*1e3
    inner_a=RHO*(Rm*1e-4/Rm)**(2*n)/(2*n)          # analytic piece below the first grid point (negligible)
    def gh(r):
        r=np.asarray(r,float); return np.interp(r,rr,Ga,left=Ga[0]+inner_a), np.interp(r,rr,Gb,left=Gb[0])
    return gh
RD=287.05
# Radially varying surface air density (proposal by Evan): rho(r) = p(r) / (Rd * Tv(r)).
#   'const'  : rho = 1.15 everywhere (previous analysis)
#   'thermo' : p(r) from the fitted profile itself (iterated), Tv(r) = Tv_env + warm-eye anomaly - rain-cooled-eyewall anomaly
#   'ramp'   : rho_c + (rho_env - rho_c) * ln(1 + r/r0) / ln(1 + Rout/r0), capped at rho_env beyond Rout
DENS=dict(mode='thermo',Tv_env=305.0,dTc=2.5,dTw=1.0,rwf=0.8,r0f=1.0,Rout=400.0)
def Tv_of_r(r,Rm,d):
    return d['Tv_env']+d['dTc']*np.exp(-(np.asarray(r)/(d['rwf']*Rm))**2)-d['dTw']*np.exp(-((np.asarray(r)-Rm)/12.0)**2)
def rho_profile(r,p_hPa,Rm,d,Pc,Pn):
    r=np.asarray(r,float)
    if d['mode']=='const': return np.full_like(r,RHO)
    if d['mode']=='thermo': return p_hPa*100/(RD*Tv_of_r(r,Rm,d))
    rc=Pc*100/(RD*(d['Tv_env']+d['dTc'])); re=Pn*100/(RD*d['Tv_env']); r0=d['r0f']*Rm
    return rc+(re-rc)*np.log1p(np.minimum(r,d['Rout'])/r0)/np.log1p(d['Rout']/r0)
def wind_deficit(Rm,n,A,X1,X2,a,R2,W2,Dtot,Pc,d,iters=3):
    # gradient-wind balance with rho(r): D(r) = int_r^inf rho (V^2/r' + f V) dr'; Vm fixed so that D(0) = Dtot
    rr=np.concatenate([Rm*np.geomspace(1e-4,1,320)[:-1],Rm+np.concatenate([[0],np.geomspace(0.05,4000,800)])])
    v=shapeC(rr,Rm,n,A,X1,X2,a,R2,W2); rho=np.full_like(rr,RHO); Bc=Pc+Dtot
    for it in range(1 if d['mode']=='const' else iters):
        fa=rho*v**2/rr; fb=rho*v
        ca=np.concatenate([[0],np.cumsum((fa[1:]+fa[:-1])/2*np.diff(rr))]); cb=np.concatenate([[0],np.cumsum((fb[1:]+fb[:-1])/2*np.diff(rr))])
        Ga=ca[-1]-ca; Gb=FCOR*(cb[-1]-cb)*1e3
        Vm=vm_from_deficit(Dtot*100,Ga[0],Gb[0])
        if d['mode']!='const': rho=rho_profile(rr,Bc-(Ga*Vm**2+Gb*Vm)/100,Rm,d,Pc,Bc)
    def gh(r):
        r=np.asarray(r,float); return np.interp(r,rr,Ga,left=Ga[0]), np.interp(r,rr,Gb,left=Gb[0])
    return gh,Vm
def vgA_rho(r,parts,Pc,Dtot,d,Rm):
    r=np.asarray(r,float); g=0*r
    for dP,R,Bh in parts: x=(R/r)**Bh; g=g+dP*100*Bh*x*np.exp(-x)
    rho=rho_profile(r,Pc+Dtot-defA(r,parts),Rm,d,Pc,Pc+Dtot)
    rm=r*1e3; return np.sqrt(g/rho+(FCOR*rm/2)**2)-FCOR*rm/2
def vm_from_deficit(D,g0,h0):     # solve g0*Vm^2 + h0*Vm = D (Pa)
    return (-h0+np.sqrt(h0**2+4*g0*D))/(2*g0)
# ---- priors (centre, sd) ----
N_FLOOR=0.8             # numerical lower bound only (the 21:15Z SAR measures the eye shape directly; no floor needed)
# Peak wind: consensus 150+-10 kt 1-min (-8 kt asymmetry -> 142+-10 azimuthal-mean surface) combined with the RCM-3 azimuthal-mean surface
# maximum interpolated to 17:33Z between the 09:20Z (135 kt) and 21:15Z (146 kt) level-2 passes: 143.5 +-3 (time) +-6% (SAR calibration:
# Sentinel-1D reads 12% below RCM-3 at 21:20Z) -> 143+-7 kt surface; / (0.85+-0.05) -> 168+-13 kt gradient level
VG_PRIOR=(168.0,12.6)
# Structure at 17:33Z interpolated in time between the RCM-3 level-2 passes at 09:20Z and 21:15Z (21 Oct 09:29Z checks curvature):
#   Rm 27.75 / 25.75 -> 26.2+-1.2 km ; eye-shape integral I 0.337 / 0.376 -> 0.366+-0.03 (power-law equivalent n = 1.37+-0.11) ;
#   v(1.4Rm)/Vm 0.74 / 0.72 at the surface -> 0.75+-0.05 at gradient level ; secondary maximum 45.8 km, 0.81 / 43.3 km, 0.77 -> 44+-3 km, 0.785+-0.045
PRI=dict(Rm=(26.2,1.2), n=(1.37,0.11), I=(0.366,0.03), R2=(44.0,3.0), Pn=(1009.5,2.0), v14=(0.75,0.05), vsec=(0.785,0.045), dens=DENS)
# vsec: secondary wind maximum / eyewall maximum
SIG0=0.5; SIGPOS=1.5   # position term: eyewall non-circularity, SAR ring-fit scatter 2.6 km (09:20Z) / 1.0 km (21:15Z) -> 1.5 km at 17:33Z
_ref=json.load(open(os.path.join(DATA,'grad_ref.json'))) if os.path.exists(os.path.join(DATA,'grad_ref.json')) else None
def sig_obs(sigpos=None):
    sp=SIGPOS if sigpos is None else sigpos
    g=np.array(_ref['dPdr']) if _ref else np.zeros_like(P)
    return np.sqrt(SIG0**2+(g*sp)**2)
# ---- residual builders ----
def make_res(family,Pc,track='ir',pri=None,data=None,shape_prior=True,tide=True,sig=None,decay_prior=True):
    pri=dict(PRI if pri is None else pri); Pd=P if data is None else data; s=sig_obs() if sig is None else sig
    off0,soff=TRACKS[track][2],TRACKS[track][3]
    if 'off' in pri: off0=pri['off']
    def bgp(q): return q if tide else np.r_[q[:2],0,0,0,0]
    if family=='A':
        def unpack(q):
            fr,R1,B1,R2,B2,sx,sy=q[:7]; bg=bgp(q[7:13]); Dtot=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            return [(Dtot*fr,R1,B1),(Dtot*(1-fr),R2,B2)],sx,sy,bg,Dtot
        def res(q):
            parts,sx,sy,bg,Dtot=unpack(q)
            if Dtot<=5: return np.full(len(Pd)+7,1e3)
            r=dist(track,sx,sy); e=(background(bg)-defA(r,parts)-Pd)/s
            dd=pri.get('dens',DENS); rr=np.linspace(2,150,500); vg=vgA_rho(rr,parts,Pc,Dtot,dd,parts[0][1]); i=vg.argmax(); rm=rr[i]
            pen=[(sx-off0[0])/soff,(sy-off0[1])/soff,(rm-pri['Rm'][0])/pri['Rm'][1],(bg[0]-pri['Pn'][0])/pri['Pn'][1]]
            if shape_prior:
                ri=np.geomspace(0.05,rm,250); vi=vgA_rho(ri,parts,Pc,Dtot,dd,parts[0][1]); I=np.trapezoid((vi/vg[i])**2/ri,ri); pen.append((I-pri['I'][0])/pri['I'][1])
            else: pen.append(0.0)
            if decay_prior: pen.append((np.interp(1.4*rm,rr,vg)/vg[i]-pri['v14'][0])/pri['v14'][1])
            else: pen.append(0.0)
            pen.append(((vg[i]*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0)
            return np.r_[e,pen]
        lb=[0.05,8,0.8,40,0.5,-40,-40,1000,-1,-3,-3,-3,-3]; ub=[0.97,70,4.5,500,3,40,40,1020,1,3,3,3,3]
    else:
        def unpack(q):
            Rm,n,A,X1,X2,sx,sy=q[:7]; bg=bgp(q[7:13]); Dtot=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            gh,Vm=wind_deficit(Rm,n,A,X1,X2,0.0,120.0,30.0,Dtot,Pc,pri.get('dens',DENS)) if Dtot>5 else (None,np.nan)
            return Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm
        def res(q):
            Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(q)
            if Dtot<=5: return np.full(len(Pd)+7,1e3)
            r=dist(track,sx,sy); g,h=gh(r); D=(g*Vm**2+h*Vm)/100
            e=(background(bg)-D-Pd)/s
            pen=[(sx-off0[0])/soff,(sy-off0[1])/soff,(Rm-pri['Rm'][0])/pri['Rm'][1],(bg[0]-pri['Pn'][0])/pri['Pn'][1],
                 ((n-pri['n'][0])/pri['n'][1]) if shape_prior else 0.0,
                 (((1-A)*np.exp(-0.4*Rm/X1)+A*np.exp(-0.4*Rm/X2)-pri['v14'][0])/pri['v14'][1]) if decay_prior else 0.0,
                 ((Vm*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0]
            return np.r_[e,pen]
        lb=[10,0.4,0.0,3,40,-40,-40,1000,-1,-3,-3,-3,-3]; ub=[60,4.0,1.0,150,1500,40,40,1020,1,3,3,3,3]
    if family=='C':
        def unpack(q):
            Rm,n,A,X1,X2,a,R2,W2,sx,sy=q[:10]; bg=bgp(q[10:16]); Dtot=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            gh,Vm=wind_deficit(Rm,n,A,X1,X2,a,R2,W2,Dtot,Pc,pri.get('dens',DENS)) if Dtot>5 else (None,np.nan)
            return Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm
        def res(q):
            Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm=unpack(q)
            if Dtot<=5: return np.full(len(Pd)+9,1e3)
            r=dist(track,sx,sy); g,h=gh(r); D=(g*Vm**2+h*Vm)/100
            e=(background(bg)-D-Pd)/s
            vR=shapeC(np.array([Rm,1.4*Rm]),Rm,n,A,X1,X2,a,R2,W2)
            pen=[(sx-off0[0])/soff,(sy-off0[1])/soff,(Rm-pri['Rm'][0])/pri['Rm'][1],(bg[0]-pri['Pn'][0])/pri['Pn'][1],
                 ((n-pri['n'][0])/pri['n'][1]) if shape_prior else 0.0,
                 ((vR[1]/vR[0]-pri['v14'][0])/pri['v14'][1]) if decay_prior else 0.0,
                 ((Vm*vR[0]*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0,
                 (R2-pri['R2'][0])/pri['R2'][1],
                 (shapeC(Rm*np.linspace(1.2,3.0,60),Rm,n,A,X1,X2,a,R2,W2).max()/vR[0]-pri['vsec'][0])/pri['vsec'][1]]
            return np.r_[e,pen]
        lb=[10,N_FLOOR,0.0,3,40,0.0,30,4,-40,-40,1000,-1,-3,-3,-3,-3]; ub=[60,5.0,1.0,150,1500,0.9,120,40,40,40,1020,1,3,3,3,3]
    return res,unpack,np.array(lb,float),np.array(ub,float)
def starts(family,track,n_rand,seed,lb,ub):
    off0=TRACKS[track][2]
    if family=='C':
        base=[[Rm,n,A,X1,X2,a,R2,W2,*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0] for Rm in (24.5,28) for n in (1.2,1.7) for A in (0.4,) for X1,X2 in ((15,250),(40,500)) for a,R2,W2 in ((0.08,42,7),(0.2,48,14))]
        d=16; u=qmc.LatinHypercube(d=d,seed=seed).random(n_rand); rnd=lb+u*(ub-lb)
        rnd[:,8]=off0[0]+(u[:,8]-0.5)*10; rnd[:,9]=off0[1]+(u[:,9]-0.5)*10; rnd[:,10]=1009.5+(u[:,10]-0.5)*6
        rnd[:,11:]=(u[:,11:]-0.5)*np.array([0.2,2,2,2,2]); rnd[:,4]=np.exp(np.log(40)+u[:,4]*np.log(1500/40)); rnd[:,3]=np.exp(np.log(3)+u[:,3]*np.log(150/3))
        rnd[:,0]=22+u[:,0]*9; rnd[:,1]=0.9+u[:,1]*1.6; rnd[:,5]=u[:,5]*0.4; rnd[:,6]=34+u[:,6]*22; rnd[:,7]=4+u[:,7]*22
        return [np.array(b,float) for b in base]+list(rnd)
    if family=='A': base=[[fr,R1,B1,R2,1.45,*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0] for fr in (0.6,0.75) for R1 in (25,30) for B1 in (1.8,2.8) for R2 in (110,150)]
    else: base=[[Rm,n,A,X1,X2,*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0] for Rm in (25,29) for n in (1.2,1.8) for A in (0.3,0.6) for X1,X2 in ((15,200),(40,400))]
    u=qmc.LatinHypercube(d=13,seed=seed).random(n_rand); rnd=lb+u*(ub-lb)
    rnd[:,5]=off0[0]+(u[:,5]-0.5)*20; rnd[:,6]=off0[1]+(u[:,6]-0.5)*20; rnd[:,7]=1009.5+(u[:,7]-0.5)*6
    rnd[:,8:]=(u[:,8:]-0.5)*np.array([0.2,2,2,2,2])
    if family=='A': rnd[:,3]=np.exp(np.log(40)+u[:,3]*np.log(500/40))
    else: rnd[:,4]=np.exp(np.log(40)+u[:,4]*np.log(1500/40)); rnd[:,3]=np.exp(np.log(3)+u[:,3]*np.log(150/3))
    return [np.array(b,float) for b in base]+list(rnd)
def solve(family,Pc,track='ir',n_rand=40,seed=0,extra=(),**kw):
    res,unpack,lb,ub=make_res(family,Pc,track,**kw)
    best=None; costs=[]
    for s0 in list(extra)+starts(family,track,n_rand,seed,lb,ub):
        try: s=least_squares(res,np.clip(s0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
        except Exception: continue
        costs.append(s.cost)
        if best is None or s.cost<best.cost: best=s
    return best,np.array(costs),unpack
def summarize(family,best,unpack,Pc,track='ir',dens=None):
    if family=='A':
        parts,sx,sy,bg,Dtot=unpack(best.x); rr=np.linspace(2,150,1500); vg=vgA_rho(rr,parts,Pc,Dtot,DENS if dens is None else dens,parts[0][1]); i=vg.argmax(); rm=rr[i]
        E=Dtot-defA(np.array([rm]),parts)[0]; vmax=vg[i]
    elif family=='B':
        Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(best.x); rm=Rm; vmax=Vm; g,h=gh(np.array([Rm])); E=Dtot-(g[0]*Vm**2+h[0]*Vm)/100
    else:
        Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm=unpack(best.x); rm=Rm; vmax=Vm*shapeC(np.array([Rm]),Rm,n,A,X1,X2,a,R2,W2)[0]
        g,h=gh(np.array([Rm])); E=Dtot-(g[0]*Vm**2+h[0]*Vm)/100
    r=dist(track,sx,sy); return dict(Pc=float(Pc),chi2=float(2*best.cost),rmw=float(rm),vg=float(vmax*KT),eye=float(E),off=[float(sx),float(sy)],
                                     bg=[float(v) for v in bg],rmin=float(r.min()),x=[float(v) for v in best.x])
