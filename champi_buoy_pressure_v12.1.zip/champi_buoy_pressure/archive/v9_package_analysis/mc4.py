# Monte Carlo job list (proof run: ~6600 trials) -> mc9.json
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, time
HERE=RES
import mc
from multiprocessing import Pool
if __name__=='__main__':
    S=mc.SRC; jobs=[]
    for src in S:
        for i in range(100): jobs.append(('C','irf',(src,),2_000_000+10_000*S.index(src)+i,True))     # one source at a time (budget)
    for i in range(2000): jobs.append(('C','irf',S,3_000_000+i,True))                                 # all sources, with peak-wind constraint
    SO=tuple(x for x in S if x!='intensity')
    for i in range(1000): jobs.append(('C','irf',SO,4_000_000+i,False))                               # buoy + satellite structure only
    for i in range(500): jobs.append(('C','bt',S,5_000_000+i,True))                                   # JTWC best-track positions
    for i in range(500): jobs.append(('C','ir',S,6_000_000+i,True))                                   # smoothed IR track
    for fam in ('A','B'):
        for i in range(500): jobs.append((fam,'irf',S,7_000_000+i+100_000*(fam=='B'),True))
    for i in range(500): jobs.append(('C','irf',S,8_000_000+i,True,'ramp'))                          # log-ramp density
    t0=time.time(); res=[]
    with Pool(2) as pool:
        for j,d in enumerate(pool.imap_unordered(mc.trial,jobs,chunksize=4)):
            res.append(d)
            if j%500==0: print('%d/%d %.0f s'%(j,len(jobs),time.time()-t0),flush=True)
    json.dump(res,open(os.path.join(HERE,'mc9.json'),'w')); print('ALL DONE %.0f s'%(time.time()-t0))
