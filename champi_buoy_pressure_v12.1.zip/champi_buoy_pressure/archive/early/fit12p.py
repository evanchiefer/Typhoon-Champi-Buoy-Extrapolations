# Brute-force multistart profile likelihood over central pressure.
# For each (scenario, Pc): 16 grid starts + 300 Latin-hypercube random starts; keep the global best,
# and record how many starts converged to within 0.1 cost of it (a check that the minimum is really global).
import numpy as np, json, sys, time
from multiprocessing import Pool
from scipy.stats import qmc
exec(open('fit11.py').read().split('def run2')[0])
SCEN={'E0':dict(Eprior=None),'E1':dict(Eprior=(22,5)),'E2':dict(Eprior=(31,7))}
LB=np.array([0.05,10,0.8,50,0.5,-40,-40]); UB=np.array([0.95,70,4,400,3,40,40])
def fit_one(args):
    sc,Pc=args; Pn=1009.5; Rprior=(27,4); Vprior=(158,10); off=OFF2; soff=6.; Eprior=SCEN[sc]['Eprior']
    def unpack(q):
        fr,R1,B1,R2,B2,sx,sy=q; dP=Pn-Pc; return [(dP*fr,R1,B1),(dP*(1-fr),R2,B2)],sx,sy
    def res(q):
        parts,sx,sy=unpack(q); r,_,_=dist(t,lat,lon,(sx,sy))
        e=prof(r,Pc,parts)-P; pen=[(sx-off[0])/soff*1.5,(sy-off[1])/soff*1.5]
        vg=vgrad(rrc,parts); i=vg.argmax(); rm=rrc[i]
        pen.append((rm-Rprior[0])/Rprior[1]*1.5); pen.append((0.9*vg[i]*KT-Vprior[0])/Vprior[1]*1.5)
        if Eprior: pen.append((prof(np.array([rm]),Pc,parts)[0]-Pc-Eprior[0])/Eprior[1]*1.5)
        return np.r_[e,pen]
    grid=[[fr,R1,B1,R2,1.45,*off] for fr in (0.6,0.75) for R1 in (25,30) for B1 in (1.8,2.8) for R2 in (110,150)]
    lhs=qmc.LatinHypercube(d=7,seed=int(Pc*10)+{'E0':0,'E1':1000,'E2':2000}[sc]).random(300)
    rnd=LB+lhs*(UB-LB); rnd[:,5]=off[0]+(lhs[:,5]-0.5)*24; rnd[:,6]=off[1]+(lhs[:,6]-0.5)*24   # centers within +-12 km of prior
    rnd[:,3]=np.exp(np.log(50)+lhs[:,3]*(np.log(400)-np.log(50)))                               # outer radius log-uniform
    costs=[]; best=None; allx_store=[]
    for s0 in list(grid)+list(rnd):
        try: s=least_squares(res,np.clip(s0,LB+1e-6,UB-1e-6),bounds=(LB,UB))
        except Exception: continue
        costs.append(2*s.cost); allx_store.append(s.x)
        if best is None or s.cost<best.cost: best=s
    # refinement: re-start from 20 perturbations of each of the 10 best solutions (basin-hopping-lite)
    sols=[]
    rng=np.random.default_rng(int(Pc*10)+7)
    allx=allx_store
    order=np.argsort(costs)[:10]
    for i in order:
        for _ in range(20):
            x0=allx[i]+rng.normal(0,0.05,7)*(UB-LB)
            try: s=least_squares(res,np.clip(x0,LB+1e-6,UB-1e-6),bounds=(LB,UB))
            except Exception: continue
            costs.append(2*s.cost); allx.append(s.x)
            if s.cost<best.cost: best=s
    costs=np.array(costs); bc=2*best.cost
    parts,sx,sy=unpack(best.x); r,_,_=dist(t,lat,lon,(sx,sy)); e=prof(r,Pc,parts)-P
    vg=0.9*vgrad(rrc,parts); i=vg.argmax(); rm=rrc[i]
    return dict(sc=sc,Pc=float(Pc),cost=float(bc),rms=float(np.sqrt(np.mean(e**2))),n_starts=int(len(costs)),lhs_best=float(min(costs[:316])),
                n_at_best=int((costs<bc+0.1).sum()),grid_best=float(min(costs[:16])),params=[float(v) for v in best.x],
                rmw=float(rm),vmax=float(vg[i]*KT),eye=float(prof(np.array([rm]),Pc,parts)[0]-Pc),off=[float(sx),float(sy)])

# ---- PROOF RUN overrides: everything below comes only from the user's spreadsheet ----
import openpyxl
_wb=openpyxl.load_workbook('xl/champi.xlsx',data_only=True); _rows=[r for r in _wb.worksheets[0].iter_rows(min_row=2,values_only=True) if r[0] is not None]
t=np.array([(r[0].day-20)*24+r[0].hour+r[0].minute/60 for r in _rows]); lat=np.array([r[4] for r in _rows],float)
lon=np.array([r[5] for r in _rows],float); P=np.array([r[6] for r in _rows],float)
_bt=np.array(json.load(open('bt.json'))); plat=np.polyfit(_bt[:,0],_bt[:,1],3); plon=np.polyfit(_bt[:,0],_bt[:,2],3)
OFF2=np.array([0.0,0.0])   # no center offset assumed; prior sigma 6 km covers 0.1-degree rounding of the track
if __name__=='__main__':
    jobs=[(sc,Pc) for Pc in np.arange(838,908.1,1.0) for sc in ('E1','E2','E0')]
    done=set()
    try:
        for l in open('bf_proof.jsonl'): d=json.loads(l); done.add((d['sc'],d['Pc']))
    except FileNotFoundError: pass
    jobs=[j for j in jobs if (j[0],float(j[1])) not in done]
    print('jobs remaining',len(jobs),flush=True); t0=time.time()
    with Pool(2) as pool, open('bf_proof.jsonl','a') as fo:
        for k,d in enumerate(pool.imap_unordered(fit_one,jobs)):
            fo.write(json.dumps(d)+'\n'); fo.flush()
            if k%10==0: print('%d/%d done, %.0f s elapsed, last %s Pc %d cost %.2f (%d/%d starts at best)'%(k+1,len(jobs),time.time()-t0,d['sc'],d['Pc'],d['cost'],d['n_at_best'],d['n_starts']),flush=True)
    print('ALL DONE in %.0f s'%(time.time()-t0),flush=True)
