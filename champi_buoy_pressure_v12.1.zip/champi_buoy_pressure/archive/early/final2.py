exec(open('fit11.py').read().split('g=np.arange')[0])
import json
tt=np.linspace(15,20,3001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
out={}
for Pc in (872,886,896):
    x=run2(Pc)
    r,_,_=dist(tt,la_i,lo_i,(x['sx'],x['sy'])); p=prof(r,Pc,x['parts']); i=p.argmin(); j=r.argmin()
    r17,_,_=dist(np.array([17+4/60]),np.array([lat[17]]),np.array([lon[17]]),(x['sx'],x['sy']))
    print('Pc %d: rms %.2f | RMW %.0f km, eye drop %.0f | R2 %.0f | off(%+.1f,%+.1f) | CPA %.1f km at %.2fZ | r(17:04) %.1f | buoy min %.1f hPa at %.2fZ | Vmax %.0f kt'%(
        Pc,x['rms'],x['rvmax'],x['eye'],x['parts'][1][1],x['sx'],x['sy'],r[j],tt[j],r17[0],p[i],tt[i],x['vmax']))
    out[Pc]=dict(parts=[list(map(float,a)) for a in x['parts']],sx=float(x['sx']),sy=float(x['sy']),rvmax=float(x['rvmax']))
json.dump(out,open('final2_fits.json','w'))
