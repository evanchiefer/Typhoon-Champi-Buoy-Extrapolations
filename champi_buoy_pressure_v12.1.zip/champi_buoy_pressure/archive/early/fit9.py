exec(open('fit7.py').read().split('if __name__')[0])
g=np.arange(869,909.1,6)
import sys
which=sys.argv[1]
if which=='free':
    scan('D3 dual, offset prior only (no RMW, no wind prior)',grid=g,dual=True)
    scan('D4 dual, NO offset prior (soff=100), RMW 35+-5',grid=g,dual=True,Rprior=(35,5),soff=100.)
elif which=='sens':
    scan('D5 dual, RMW 30+-5 (sfc RMW inside 89GHz ring), wind 150+-12',grid=g,dual=True,Rprior=(30,5),Vprior=(150,12))
    scan('D6 dual, Pn 1008, RMW 35+-5, wind 150+-12',grid=g,dual=True,Rprior=(35,5),Vprior=(150,12),Pn=1008)
    scan('D7 dual, Pn 1011, RMW 35+-5, wind 150+-12',grid=g,dual=True,Rprior=(35,5),Vprior=(150,12),Pn=1011)
    scan('D8 dual, ARCHER-IR-only offset (-3.6,-8.9) & parallax -> (-0.4,-14.9), RMW 35+-5, wind 150+-12',grid=g,dual=True,Rprior=(35,5),Vprior=(150,12),off=np.array([-0.4,-14.9]))
