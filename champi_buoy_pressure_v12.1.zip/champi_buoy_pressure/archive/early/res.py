exec(open('fit7.py').read().split('if __name__')[0])
d=run(890,dual=True,Rprior=(35,5),Vprior=(150,12)); s=run(890,Rprior=(35,5))
print(' t      P     r_dual  res_dual | r_single res_single')
for i in np.argsort(t):
    print('%5.2f %6.1f  %6.1f  %+5.2f   | %6.1f  %+5.2f'%(t[i],P[i],d['r'][i],d['e'][i],s['r'][i],s['e'][i]))
inner=d['r']<80
print('rms inner(<80km) dual %.2f single %.2f; outer dual %.2f single %.2f'%(np.sqrt(np.mean(d['e'][inner]**2)),np.sqrt(np.mean(s['e'][inner]**2)),np.sqrt(np.mean(d['e'][~inner]**2)),np.sqrt(np.mean(s['e'][~inner]**2))))
