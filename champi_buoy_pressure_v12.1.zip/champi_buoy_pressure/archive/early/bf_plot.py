import numpy as np, json, re, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=[json.loads(l) for l in open('bf_results.jsonl')]
def prof_bf(sc):
    d=sorted([r for r in R if r['sc']==sc],key=lambda r:r['Pc']); return np.array([r['Pc'] for r in d]),np.array([r['cost'] for r in d])
def prof_old(fn):
    P=[];C=[]
    for l in open(fn):
        m=re.match(r'\s+Pc (\d+) rms [\d.]+ dcost\s+([\d.]+)',l)
        if m: P.append(int(m.group(1))); C.append(float(m.group(2)))
    return np.array(P),np.array(C)
g=np.arange(838,908.01,0.25); Ls={}
for sc in ('E0','E1','E2'):
    p,c=prof_bf(sc); c=c-c.min(); L=np.exp(-0.5*np.interp(g,p,c)/1.5**2); Ls[sc]=L/L.sum()
comb=(Ls['E1']+Ls['E2'])/2
cdf=np.cumsum(comb); q=[g[np.searchsorted(cdf,x)] for x in (0.025,0.16,0.5,0.84,0.975)]
print('combined E1+E2: median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | mode %.1f'%(q[2],q[1],q[3],q[0],q[4],g[comb.argmax()]))
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'; COL={'E0':'#9a9893','E1':'#2a78d6','E2':'#eb6834'}
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'xtick.color':INK2,'ytick.color':INK2,'axes.facecolor':SURF,'figure.facecolor':SURF,
                     'axes.grid':True,'grid.color':GRID,'axes.spines.top':False,'axes.spines.right':False})
fig,(a,b)=plt.subplots(1,2,figsize=(14,5.2))
names={'E0':'no eye-drop constraint','E1':'SAR eye drop at face value','E2':'SAR eye drop scaled up'}
for sc,fn in (('E0','o11_a.txt'),('E1','o11_b.txt'),('E2','o11_c.txt')):
    p,c=prof_bf(sc); a.plot(p,(c-c.min())/1.5**2,color=COL[sc],lw=2,label=names[sc]+' — 516 starts')
    po,co=prof_old(fn); a.plot(po,co/1.5**2,'o',ms=5,color=COL[sc],mfc=SURF,mew=1.3,label=names[sc]+' — earlier 16 starts')
a.axhline(1,color=INK2,lw=0.8,ls=':'); a.text(839,1.15,'1-sigma level',fontsize=8.5,color=INK2)
a.set_xlim(838,908); a.set_ylim(0,12); a.set_xlabel('central pressure (hPa)'); a.set_ylabel('misfit above the best (chi-square units)')
a.set_title('Profile curves: brute force vs earlier runs',loc='left',fontweight='bold'); a.legend(fontsize=7.8,frameon=False,loc='upper center',ncol=2)
for sc in ('E1','E2'): b.plot(g,Ls[sc]/0.25,color=COL[sc],lw=1.5,label=names[sc])
b.fill_between(g,comb/0.25,color='#0f3f7a',alpha=0.18,lw=0); b.plot(g,comb/0.25,color='#0f3f7a',lw=2.2,label='combined (equal weight)')
b.axvspan(q[1],q[3],color='#0f3f7a',alpha=0.08,lw=0)
b.text(q[2],comb.max()/0.25*1.06,'median %.0f, 68%%: %.0f–%.0f'%(q[2],q[1],q[3]),ha='center',fontsize=9)
b.axvline(909.4,color='#d0312d',ls='--',lw=1.3); b.text(908.6,0.005,'buoy 909.4',rotation=90,fontsize=8.5,ha='right',va='bottom')
b.set_xlim(845,912); b.set_ylim(0,None); b.set_xlabel('central pressure (hPa)'); b.set_ylabel('relative likelihood (per hPa)')
b.set_title('Central pressure, brute-force result',loc='left',fontweight='bold'); b.legend(fontsize=8.5,frameon=False,loc='upper left')
fig.tight_layout(); fig.savefig('bruteforce_profiles.png',dpi=130)
