import numpy as np, json
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx))
la=np.array([fx[str(h)]['lat'] for h in th]); lo=np.array([fx[str(h)]['lon'] for h in th])
pla=np.polyfit(th,la,2); plo=np.polyfit(th,lo,2)
def ir(tt): return np.polyval(pla,tt),np.polyval(plo,tt)
def vel(tt):
    vn=np.polyval(np.polyder(pla),tt)*111; ve=np.polyval(np.polyder(plo),tt)*111*np.cos(np.radians(17.3)); s=np.hypot(ve,vn); return ve/s,vn/s,s
# wind-radii table (JTWC-style) hourly positions for comparison
wr={7:(16.5,134.2),8:(16.6,134.0),9:(16.7,133.8),10:(16.8,133.6),11:(16.9,133.3),12:(17.0,133.0),13:(17.0,132.8),14:(17.1,132.5),15:(17.1,132.3),16:(17.3,132.0),17:(17.4,131.8),18:(17.4,131.5),19:(17.5,131.3),20:(17.6,131.1),21:(17.7,130.9),22:(17.8,130.7),23:(17.9,130.4),24:(18.0,130.2)}
fixes=[('GI 09Z',9,16.62,133.91),('GI 12Z',12,16.86,133.15),('GI 15Z',15,17.08,132.34),('GI 18Z',18,17.35,131.61),('GI 21Z',21,17.57,131.02),('GI 00Z',24,17.92,130.28),
       ('MW F18 07:23',7+23/60,16.45,134.13),('MW TMS09 11:34',11+34/60,16.91,133.09),('MW MHS 11:42',11+42/60,17.07,133.06),('MW TMS06 13:36',13.6,17.04,132.60),('MW F18 19:56',19+56/60,17.59,131.05),('MW MHS 00:12',24.2,17.92,130.08)]
print('offset of each ARCHER fix from my IR track at its true time: along-track (+ahead) / cross-track (+right of motion), km; lag in hours')
for n,tt,fla,flo in fixes:
    cla,clo=ir(tt); dx=(flo-clo)*111*np.cos(np.radians(cla)); dy=(fla-cla)*111; ue,un,s=vel(tt)
    al=dx*ue+dy*un; cr=dx*un-dy*ue
    h=int(round(tt)); w=wr.get(h)
    wtxt=''
    if w and abs(tt-h)<0.01:
        wdx=(flo-w[1])*111*np.cos(np.radians(fla)); wdy=(fla-w[0])*111; wtxt='| vs wind-table pos: %+5.1f E %+5.1f N'%(wdx,wdy)
    print('%-16s along %+6.1f  cross %+6.1f  (= %+.2f h)  %s'%(n,al,cr,al/s,wtxt))
print('\nSAR surface centers vs my IR track:')
for n,tt,fla,flo in [('SAR S1D 09:09',9+9/60,16.668,133.739),('SAR RCM3 09:20',9+20/60,16.698,133.693)]:
    cla,clo=ir(tt); dx=(flo-clo)*111*np.cos(np.radians(cla)); dy=(fla-cla)*111; ue,un,s=vel(tt)
    print('%-16s dE %+5.1f dN %+5.1f | along %+5.1f cross %+5.1f km'%(n,dx,dy,dx*ue+dy*un,dx*un-dy*ue))
print('\nATMS 165/183 17:00-17:01Z vs my IR track:')
for n,tt,fla,flo in [('ATMS 17:01',17+1/60,17.335,131.719)]:
    cla,clo=ir(tt); dx=(flo-clo)*111*np.cos(np.radians(cla)); dy=(fla-cla)*111
    print('%-12s dE %+5.1f dN %+5.1f'%(n,dx,dy))
