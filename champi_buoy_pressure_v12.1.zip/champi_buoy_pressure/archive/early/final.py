exec(open('fit7.py').read().split('if __name__')[0])
import json
kw=dict(dual=True,Rprior=(32,5),Vprior=(150,12))
grid=np.arange(869,909.1,2)
rows=[(Pc,run(Pc,**kw)) for Pc in grid]; c=np.array([x['cost'] for _,x in rows]); c-=c.min()
L=np.exp(-0.5*c/1.5**2); L/=L.sum(); cdf=np.cumsum(L)
q=[float(grid[min(np.searchsorted(cdf,p),len(grid)-1)]) for p in (0.16,0.5,0.84,0.025,0.975)]
print('FINAL dual, RMW 32+-5, wind 150+-12: best %d  median %d  68%% %d-%d  95%% %d-%d'%(grid[c.argmin()],q[1],q[0],q[2],q[3],q[4]))
tt=np.linspace(15,20,3001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
out={}
for Pc,x in rows:
    if Pc in (875,889,905):
        r,_,_=dist(tt,la_i,lo_i,(x['sx'],x['sy'])); p=prof(r,Pc,x['parts']); i=p.argmin()
        print('Pc %d: buoy min %.1f at %.2fZ r=%.1f km | RMW %.1f km, Vmax %.0f kt, rms %.2f, off(%+.1f,%+.1f) | %s'%(Pc,p[i],tt[i],r[i],x['rvmax'],x['vmax'],x['rms'],x['sx'],x['sy'],x['parts']))
        out[int(Pc)]=dict(parts=[list(map(float,a)) for a in x['parts']],sx=float(x['sx']),sy=float(x['sy']))
print('dcost:',' '.join('%d:%.1f'%(g_,c_) for g_,c_ in zip(grid,c)))
s=run(889,Rprior=(32,5)); out['single']=dict(parts=[list(map(float,a)) for a in s['parts']],sx=float(s['sx']),sy=float(s['sy']),Pc=889)
json.dump(out,open('final_fits.json','w'))
