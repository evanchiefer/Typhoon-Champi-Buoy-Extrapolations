import numpy as np, sys
from PIL import Image
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
def groups(v,gap=3):
    g=[]
    for x in v:
        if g and x-g[-1][-1]<=gap: g[-1].append(x)
        else: g.append([x])
    return g
for f in sys.argv[1:]:
    a=np.array(Image.open(U+f).convert('RGB')).astype(int)
    # x labels: rows 921-930, find label clusters
    d=(a[921:931,:,:].max(2)<120).any(0); xs=np.where(d)[0]
    gx=[(q[0],q[-1]) for q in groups(xs,gap=12)]
    yl=(a[:, 0:40,:].max(2)<120).any(1); ys=np.where(yl)[0]
    gy=[(q[0],q[-1]) for q in groups(ys,gap=3)]
    print(f); print('  xlabel spans',[(s,e,(s+e)/2) for s,e in gx]); print('  ylabel spans',[(s,e,(s+e)/2) for s,e in gy])
