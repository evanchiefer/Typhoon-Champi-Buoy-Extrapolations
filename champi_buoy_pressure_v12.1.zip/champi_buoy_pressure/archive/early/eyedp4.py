exec(open('fit7.py').read().split('if __name__')[0])
for Pc in (871,889,898):
    x=run(Pc,dual=True,off=np.array([8.0,-10.3]),soff=3.,Rprior=(27,4),Vprior=(150,12)); rm=x['rvmax']
    a,b=prof(np.array([rm,87.0]),Pc,x['parts']); v=0.9*vgrad(np.array([rm,50.,87.]),x['parts'])*KT
    print('Pc %d: model rise RMW->87 km %.1f hPa; 0.9Vg at RMW/50/87 km = %.0f/%.0f/%.0f kt (ratio87 %.2f)'%(Pc,b-a,*v,v[2]/v[0]))
