import numpy as np, json
from PIL import Image, ImageDraw
from collections import deque
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
files=dict(zip([7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24],
 ['566b1dd2','0f642994','ce6eddbf','30a1f42c','4e29569e','f07e17f0','93e16b22','ad8bc327','b6f0cfb3','07017dfc','3594791c','cbb64e94','e73c7714','477f2bcd','f3c1b67a','f20c9962','5aaf9839','a374352e']))
cal={'A':((117,129),(1108,139),(106,20),(800,13)),'B':((65,127),(1056,137),(56,21),(750,14)),
     'C':((122,126),(1113,136),(91,21),(785,14)),'D':((62,124),(1053,134),(66,22),(760,15))}
crop={7:'A',8:'A',**{h:'B' for h in range(9,15)},**{h:'C' for h in range(15,22)},22:'D',23:'D',24:'D'}
seed={7:(628,447),8:(607,432),9:(729,478),10:(707,467),11:(683,460),12:(654,450),13:(628,446),14:(598,440),
      15:(735,462),16:(709,450),17:(682,447),18:(659,433),19:(640,433),20:(621,424),21:(601,410),22:(712,465),23:(691,458),24:(665,453)}
def px2ll(x,y,c):
    (x1,l1),(x2,l2),(y1,a1),(y2,a2)=cal[c]
    return a1+(y-y1)*(a2-a1)/(y2-y1), l1+(x-x1)*(l2-l1)/(x2-x1)
out={}; tiles=[]
for h,f in files.items():
    img=Image.open(U+f+'-image.jpg').convert('RGB'); a=np.array(img).astype(int)
    r,g,b=a[...,0],a[...,1],a[...,2]
    gray=(np.maximum(np.maximum(abs(r-g),abs(g-b)),abs(r-b))<28)&(r>40)
    sx,sy=seed[h]
    # nudge seed to nearest gray pixel
    best=None
    for dy in range(-12,13):
        for dx in range(-12,13):
            if gray[sy+dy,sx+dx]:
                d=dx*dx+dy*dy
                if best is None or d<best[0]: best=(d,sx+dx,sy+dy)
    _,sx,sy=best
    seen=np.zeros(gray.shape,bool); q=deque([(sy,sx)]); pts=[]
    while q:
        y,x=q.popleft()
        if seen[y,x] or not gray[y,x]: continue
        seen[y,x]=True; pts.append((y,x))
        if len(pts)>20000: break
        for yy,xx in ((y+1,x),(y-1,x),(y,x+1),(y,x-1)):
            if not seen[yy,xx]: q.append((yy,xx))
    pts=np.array(pts); cy,cx=pts.mean(0); n=len(pts)
    lat,lon=px2ll(cx,cy,crop[h])
    out[h]=dict(lat=lat,lon=lon,npx=n,rad_px=(n/np.pi)**.5)
    print('%02dZ crop %s px(%.1f,%.1f) n=%d r=%.1fpx  %.4fN %.4fE'%(h%24,crop[h],cx,cy,n,(n/np.pi)**.5,lat,lon))
    t=img.crop((int(cx)-60,int(cy)-60,int(cx)+60,int(cy)+60)).resize((240,240),Image.NEAREST)
    d=ImageDraw.Draw(t); d.line((114,120,126,120),fill=(255,0,0),width=2); d.line((120,114,120,126),fill=(255,0,0),width=2)
    d.text((4,4),'%02dZ'%(h%24),fill=(255,0,0)); tiles.append(t)
json.dump(out,open('fixes.json','w'))
M=Image.new('RGB',(240*6,240*3),'white')
for i,t in enumerate(tiles): M.paste(t,((i%6)*240,(i//6)*240))
M.save('montage.png')
