exec(open('fit7.py').read().split('if __name__')[0])
import json, openpyxl, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
Pn=1009.5
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'; BL=['#8bb8ea','#2a78d6','#0f3f7a']; OR='#eb6834'; GR='#1baf7a'; RED='#d0312d'; GY='#9a9893'
plt.rcParams.update({'font.size':9.5,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.facecolor':SURF,'figure.facecolor':SURF,
                     'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False})
def load(fn):
    try: return [json.loads(l) for l in open(fn)]
    except FileNotFoundError: return []
MAIN=load('bf_results.jsonl'); PROOF=load('bf_proof.jsonl')
def curve(R,sc):
    d=sorted([r for r in R if r['sc']==sc],key=lambda r:r['Pc']); return np.array([r['Pc'] for r in d]),np.array([r['cost'] for r in d]),d
G_=np.arange(838,908.01,0.25)
def like(R):
    out={}
    for sc in ('E0','E1','E2'):
        p,c,_=curve(R,sc)
        if len(p)<5: continue
        L=np.exp(-0.5*np.interp(G_,p,c-c.min())/1.5**2); out[sc]=L/L.sum()
    if 'E1' in out and 'E2' in out: out['comb']=(out['E1']+out['E2'])/2
    return out
def quant(L): cdf=np.cumsum(L); return [G_[np.searchsorted(cdf,x)] for x in (0.025,0.16,0.5,0.84,0.975)]
LM=like(MAIN); LP=like(PROOF); qM=quant(LM['comb']); qP=quant(LP['comb']) if 'comb' in LP else None
def parts_of(r): fr,R1,B1,R2,B2,sx,sy=r['params']; dP=Pn-r['Pc']; return [(dP*fr,R1,B1),(dP*(1-fr),R2,B2)],sx,sy
def at(R,sc,Pc): _,_,d=curve(R,sc); return min(d,key=lambda r:abs(r['Pc']-Pc))
# tracks
_wb=openpyxl.load_workbook('xl/champi.xlsx',data_only=True); bt=np.array(json.load(open('bt.json')))
bpla=np.polyfit(bt[:,0],bt[:,1],3); bplo=np.polyfit(bt[:,0],bt[:,2],3)
def dist2(tq,la,lo,shift,pa,po):
    clat=np.polyval(pa,tq); clon=np.polyval(po,tq); kx=111*np.cos(np.radians((la+clat)/2))
    return np.hypot((lo-clon)*kx-shift[0],(la-clat)*111-shift[1])
tt=np.linspace(12,23,4001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
reps=[round(qM[1]),round(qM[2]),round(qM[3])]
fig,ax=plt.subplots(3,3,figsize=(20,17.5)); (A,B,C),(D,E,F),(G1,G2,H)=ax
# (A) pressure trace
for Pc,c in zip(reps,BL):
    r_=at(MAIN,'E0',Pc); pp,sx,sy=parts_of(r_); A.plot(tt,prof(dist2(tt,la_i,lo_i,(sx,sy),plat,plon),r_['Pc'],pp),color=c,lw=2,label='main run, center %d hPa'%r_['Pc'])
if qP:
    r_=at(PROOF,'E0',round(qP[2])); pp,sx,sy=parts_of(r_); A.plot(tt,prof(dist2(tt,la_i,lo_i,(sx,sy),bpla,bplo),r_['Pc'],pp),color=OR,lw=1.6,ls='--',label='proof run (spreadsheet only), %d hPa'%r_['Pc'])
m=(t>=12)&(t<=23); A.plot(t[m],P[m],'o',ms=8,color=INK,mec=SURF,mew=1.5,label='buoy readings',zorder=5)
A.annotate('909.4 hPa at 17:04Z',(17.07,909.4),(17.8,928),fontsize=9,arrowprops=dict(arrowstyle='-',color=INK2))
A.set_xlim(12,23); A.set_ylim(890,1000); A.set_xlabel('Oct 20, UTC hour'); A.set_ylabel('pressure (hPa)')
A.set_title('A  Buoy pressure vs fits',loc='left',fontweight='bold'); A.legend(loc='upper center',fontsize=8.3,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (B) map
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx)); flat=np.array([fx[str(h)]['lat'] for h in th]); flon=np.array([fx[str(h)]['lon'] for h in th])
th2=np.linspace(11,24,300); B.plot(np.polyval(plon,th2),np.polyval(plat,th2),color=GY,lw=1.2)
B.plot(flon,flat,'o',ms=6,color=SURF,mec=INK2,mew=1.3,label='IR eye, my hourly fixes')
B.plot(np.polyval(bplo,th2),np.polyval(bpla,th2),color=OR,lw=1.4,ls='-.',label='spreadsheet track (smoothed)')
B.plot(bt[:,2],bt[:,1],'*',ms=14,color=OR,mec=SURF,label='spreadsheet track point (18Z)')
B.plot(133.36-0.0,17.0,alpha=0)  # spacer
rM=at(MAIN,'E0',round(qM[2])); _,sx,sy=parts_of(rM); k=111*np.cos(np.radians(17.4))
B.plot(np.polyval(plon,th2)+sx/k,np.polyval(plat,th2)+sy/111,color=INK,lw=2,ls='--',label='fitted surface center (main run)')
tc=17.55; cla=np.polyval(plat,tc)+sy/111; clo=np.polyval(plon,tc)+sx/k; th_=np.linspace(0,2*np.pi,200)
B.plot(clo+rM['rmw']*np.sin(th_)/k,cla+rM['rmw']*np.cos(th_)/111,color=INK,lw=1,ls=':'); B.plot(clo,cla,'+',ms=12,mew=2,color=INK)
B.plot(clo+16*np.sin(th_)/k,cla+16*np.cos(th_)/111,color=INK2,lw=0.8,ls='-',alpha=0.6)
B.text(clo+0.17,cla-0.22,'dotted: max-wind ring ~%.0f km\nsolid: calm eye ~16 km\n(at 17:33Z)'%rM['rmw'],fontsize=8.3,color=INK2,va='top')
B.plot(lon,lat,'-',color=INK,lw=1.2); B.plot(lon[17],lat[17],'^',ms=12,color=RED,mec=SURF,label='buoy at 17:04Z (909.4 hPa)')
B.set_xlim(131.05,132.25); B.set_ylim(16.95,17.75); B.set_aspect(1/np.cos(np.radians(17.3)))
B.set_xlabel('longitude (°E)'); B.set_ylabel('latitude (°N)'); B.set_title('B  Tracks and the buoy pass',loc='left',fontweight='bold')
B.legend(loc='upper right',fontsize=7.8,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (C) buoy distance vs time
r=dist2(tt,la_i,lo_i,(sx,sy),plat,plon)
C.axhspan(0,16,color=GRID,lw=0); C.text(12.2,8,'calm eye (SAR, winds < 47 kt)',fontsize=8.3,color=INK2,va='center')
C.axhspan(24,33,color=BL[0],alpha=0.35,lw=0); C.text(19.2,28.5,'radius of max wind\n(SAR 24–28, fits 27–33 km)',fontsize=7.8,color=INK2,va='center')
C.axhspan(110,135,color=GR,alpha=0.15,lw=0); C.text(13.9,122,'outer ring forming (fit 110–135; MW ~125 km by 21Z)',fontsize=8.3,color=INK2,va='center')
C.plot(tt,r,color=INK,lw=2,label='main run center')
if qP:
    rP_=at(PROOF,'E0',round(qP[2])); _,psx,psy=parts_of(rP_); C.plot(tt,dist2(tt,la_i,lo_i,(psx,psy),bpla,bplo),color=OR,lw=1.5,ls='--',label='proof run center')
j=r.argmin(); C.annotate('closest ~%.0f km at %02d:%02dZ'%(r[j],int(tt[j]),round(tt[j]%1*60)),(tt[j],r[j]),(12.4,62),fontsize=9,arrowprops=dict(arrowstyle='-',color=INK2))
C.set_xlim(12,23); C.set_ylim(0,160); C.set_xlabel('Oct 20, UTC hour'); C.set_ylabel('distance from center (km)')
C.set_title('C  Where the buoy was relative to the eyewall',loc='left',fontweight='bold'); C.legend(loc='lower right',fontsize=8.3,frameon=False)
# (D) radial profile
rr2=np.linspace(0.5,200,1500); D.axvspan(0,16,color=GRID,lw=0); D.axvspan(24,33,color=BL[0],alpha=0.35,lw=0); D.axvspan(110,135,color=GR,alpha=0.15,lw=0)
for Pc,c in zip(reps,BL):
    r_=at(MAIN,'E0',Pc); pp,_,_=parts_of(r_); D.plot(rr2,prof(rr2,r_['Pc'],pp),color=c,lw=2); D.text(1.5,r_['Pc']+1.3,'%d'%r_['Pc'],color=c if c!=BL[0] else '#3d7fc4',fontsize=9,fontweight='bold')
rb=np.array(dist2(t,lat,lon,(sx,sy),plat,plon)); bf=t<17.55
D.plot(rb[bf],P[bf],'o',ms=7,color=INK,mec=SURF,label='buoy, storm approaching'); D.plot(rb[~bf],P[~bf],'s',ms=7,color=SURF,mec=INK,mew=1.4,label='buoy, storm departing')
D.text(2,1002,'calm\neye',fontsize=8.3,color=INK2,va='top'); D.text(34,876,'RMW',fontsize=8.3,color=INK2); D.text(112,1002,'outer ring',fontsize=8.3,color=INK2,va='top')
D.set_xlim(0,200); D.set_ylim(864,1005); D.set_xlabel('distance from center (km)'); D.set_ylabel('pressure (hPa)')
D.set_title('D  Pressure profile: inside ~24 km is extrapolated',loc='left',fontweight='bold'); D.legend(loc='lower right',fontsize=8.3,frameon=False)
# (E) SAR winds
S=json.load(open('sar/sar_profiles.json'))
for (n,d),c in zip(S.items(),(BL[1],OR)): E.plot(d['r'],d['v'],color=c,lw=2,label='SAR %s (azimuthal mean)'%n)
pp,_,_=parts_of(rM); rp=np.linspace(1,95,400); E.plot(rp,0.9*vgrad(rp,pp)*KT,color=INK,lw=1.5,ls='--',label='main fit (%d hPa), 0.9 × gradient wind, 17:33Z'%rM['Pc'])
E.axvspan(0,16,color=GRID,lw=0); E.axvline(r[j],color=RED,lw=1.5,ls=':'); E.text(r[j]+1,12,'buoy closest\napproach',fontsize=8.3)
E.set_xlim(0,95); E.set_ylim(0,190); E.set_xlabel('distance from center (km)'); E.set_ylabel('wind speed (kt)')
E.set_title('E  SAR surface winds, 09Z (8 h before the pass)',loc='left',fontweight='bold'); E.legend(loc='upper right',fontsize=8.3,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (F) center offsets vs IR eye
F.axhline(0,color=INK2,lw=0.8); F.axvline(0,color=INK2,lw=0.8)
F.plot(0,0,'o',ms=9,color=SURF,mec=INK2,mew=1.5,label='my IR eye track (reference)')
F.annotate('',xy=(3.2,-6.0),xytext=(0,0),arrowprops=dict(arrowstyle='->',color=INK2,lw=1.5)); F.text(3.6,-5.0,'viewing-angle\nshift',fontsize=8,color=INK2)
mw=np.array([(0.7,-20.6),(6.5,-5.5),(6.9,11.0),(8.6,-9.7),(3.3,-11.7),(-0.2,-21.9)]); F.plot(mw[:,0],mw[:,1],'D',ms=8,color=GR,mec=SURF,label='ARCHER microwave fixes')
F.plot([9.4,9.5],[-10.4,-9.5],'s',ms=10,color=BL[1],mec=SURF,label='SAR surface center (09:09, 09:20Z)')
F.plot(2.7,-10.0,'^',ms=11,color=INK2,mec=SURF,label='ATMS 165/183 GHz, 17:01Z')
for h,bla,blo,_v in bt:
    if 7<=h<=24:
        cla_=np.polyval(plat,h); clo_=np.polyval(plon,h); F.plot((blo-clo_)*111*np.cos(np.radians(cla_)),(bla-cla_)*111,'*',ms=15,color=OR,mec=SURF)
F.plot([],[],'*',ms=15,color=OR,mec=SURF,label='spreadsheet track (12Z, 18Z)')
F.plot(sx,sy,'P',ms=13,color=INK,mec=SURF,label='center found by the main fit')
F.set_xlim(-12,16); F.set_ylim(-26,27); F.set_aspect('equal'); F.set_xlabel('km east of IR eye'); F.set_ylabel('km north of IR eye')
F.set_title('F  Surface center vs the IR eye',loc='left',fontweight='bold'); F.legend(loc='upper left',fontsize=7.8,frameon=True,facecolor=SURF,edgecolor=GRID)
# (G1) misfit curves
names={'E0':'no eye-drop constraint','E1':'SAR eye drop, face value','E2':'SAR eye drop, scaled up'}; COL={'E0':GY,'E1':BL[1],'E2':BL[2]}
for sc in ('E0','E1','E2'):
    p,c,_=curve(MAIN,sc); G1.plot(p,(c-c.min())/1.5**2,color=COL[sc],lw=2,label='main: '+names[sc])
    p,c,_=curve(PROOF,sc)
    if len(p)>3: G1.plot(p,(c-c.min())/1.5**2,color=COL[sc],lw=1.4,ls='--',label='proof: '+names[sc])
G1.axhline(1,color=INK2,lw=0.8,ls=':'); G1.text(839,1.15,'1-sigma level',fontsize=8,color=INK2)
G1.set_xlim(838,908); G1.set_ylim(0,12); G1.set_xlabel('central pressure (hPa)'); G1.set_ylabel('misfit above best (chi-square units)')
G1.set_title('G  Brute-force profile curves (516 starts per value)',loc='left',fontweight='bold'); G1.legend(fontsize=7.8,frameon=False,loc='upper center',ncol=2)
# (G2) combined likelihood
G2.fill_between(G_,LM['comb']/0.25,color=BL[2],alpha=0.18,lw=0); G2.plot(G_,LM['comb']/0.25,color=BL[2],lw=2.2,label='main run: median %.0f, 68%% %.0f–%.0f'%(qM[2],qM[1],qM[3]))
if qP: G2.plot(G_,LP['comb']/0.25,color=OR,lw=2,ls='--',label='proof run: median %.0f, 68%% %.0f–%.0f'%(qP[2],qP[1],qP[3]))
G2.axvline(909.4,color=RED,ls='--',lw=1.3); G2.text(908.6,0.002,'buoy 909.4',rotation=90,fontsize=8.3,ha='right',va='bottom')
G2.set_xlim(845,912); G2.set_ylim(0,None); G2.set_xlabel('central pressure (hPa)'); G2.set_ylabel('relative likelihood (per hPa)')
G2.set_title('H  Central pressure: main run vs proof run',loc='left',fontweight='bold'); G2.legend(fontsize=8.5,frameon=False,loc='upper left')
# (H) estimates
est=[('Main run (buoy + SAR + MW + fixes)',qM[2],qM[1],qM[3],BL[1])]
if qP: est.append(('Proof run (spreadsheet + SAR eyewall)',qP[2],qP[1],qP[3],OR))
est+= [('JTWC best track (~17Z)',895,None,None,INK2),('D-PRINT (16:30–17:30Z)',903,902,904,INK2),('ATMS (SATCON plot, ~17Z)',903,None,None,INK2),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,INK2),('SATCON (~17Z)',910,None,None,INK2)]
n=len(est)
for i,(nm,v,lo_,hi_,col) in enumerate(est):
    y=n-1-i; ours=col!=INK2
    if lo_ is not None: H.plot([lo_,hi_],[y,y],color=col,lw=7 if ours else 4,alpha=0.35 if ours else 0.5,solid_capstyle='round')
    H.plot(v,y,'o',ms=10 if ours else 8,color=col,mec=SURF,mew=1.5)
    txt=('~%.0f (68%%: %.0f–%.0f)'%(v,lo_,hi_)) if ours else ('%g'%v if lo_ is None else '%g–%g'%(lo_,hi_))
    H.text(v if ours else v+1.2,y+0.28,txt,fontsize=8.5,ha='center' if ours else 'left')
H.axvline(909.4,color=RED,lw=1.5,ls='--'); H.text(910.2,n-1.25,'buoy reading\n909.4 hPa,\n~28 km from\ncenter',fontsize=8.3,va='top')
H.set_yticks(range(n)); H.set_yticklabels([e[0] for e in est][::-1],fontsize=8.8); H.set_xlim(850,925); H.set_ylim(-0.6,n-0.3); H.grid(axis='y',visible=False)
H.set_xlabel('central pressure (hPa)'); H.set_title('I  Central pressure near 17Z, Oct 20',loc='left',fontweight='bold')
fig.suptitle('Champi (29W): central pressure from the drifting-buoy pass — main run and independent proof run',x=0.01,y=0.993,ha='left',fontsize=15,fontweight='bold')
sub='Main: hourly IR eye + SAR/ATMS center, SAR eyewall, brute-force multistart. Proof: only the spreadsheet (buoy + 6-hourly track + intensity) plus SAR eyewall size and eye drop.'
fig.text(0.01,0.972,sub,fontsize=10,color=INK2)
fig.tight_layout(rect=(0,0,1,0.955)); fig.savefig('champi_combined.png',dpi=110)
print('main',qM,'proof',qP,'reps',reps)
