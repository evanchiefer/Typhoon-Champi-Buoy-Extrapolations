import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import least_squares
exec(open('fit5.py').read().split('grid=np.arange')[0])
Pn=1009; cases=[860,885,905]; cols=['#2a78d6','#eb6834','#1baf7a']
INK='#0b0b0b'; INK2='#52514e'; GRID='#e6e5e1'; SURF='#fcfcfb'
sol={Pc:solve(Pc,Pn) for Pc in cases}
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,
                     'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':SURF,'axes.facecolor':SURF})
fig,ax=plt.subplots(1,3,figsize=(16,5.2),gridspec_kw=dict(width_ratios=[1.25,1,1.05]))
# 1: time series
a=ax[0]; tt=np.linspace(0,37,600)
la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
for Pc,c in zip(cases,cols):
    s=sol[Pc]; r,_,_=dist(tt,la_i,lo_i,(s['sx'],s['sy']))
    a.plot(tt,holland([Pc,Pn,s['Rm'],s['B']],r),color=c,lw=2,label='Holland fit, Pc = %d hPa (rms %.1f)'%(Pc,s['rms']))
a.plot(t,P,'o',ms=6,color=INK,mec=SURF,mew=1.5,label='Buoy 2802285 (hourly)',zorder=5)
a.set_xlabel('Hours since 00Z Oct 20'); a.set_ylabel('Sea-level pressure (hPa)')
a.set_title('All three fits trace the buoy record equally well',loc='left',color=INK,fontsize=11)
a.grid(color=GRID,lw=0.8); a.legend(frameon=False,fontsize=8.5,loc='lower left')
# 2: radial profile
a=ax[1]; rr=np.linspace(0.5,150,600)
for Pc,c in zip(cases,cols):
    s=sol[Pc]; a.plot(rr,holland([Pc,Pn,s['Rm'],s['B']],rr),color=c,lw=2)
    a.text(1.5,Pc-1,'%d'%Pc,color=INK2,fontsize=8.5,va='top')
rmins=[sol[Pc]['rmin'] for Pc in cases]
a.axvspan(0,min(rmins),color='#ecebe7',zorder=0)
a.text(min(rmins)/2,1004,'never\nsampled',ha='center',va='top',color=INK2,fontsize=8.5)
s=sol[885]; r,_,_=dist(t,lat,lon,(s['sx'],s['sy']))
a.plot(r,P,'o',ms=5,color=INK,mec=SURF,mew=1.2,zorder=5)
a.set_xlim(0,150); a.set_ylim(850,1012)
a.set_xlabel('Distance from storm center (km)'); a.set_ylabel('hPa')
a.set_title('They differ only where the buoy never went',loc='left',color=INK,fontsize=11)
a.grid(color=GRID,lw=0.8)
# 3: track map
a=ax[2]
a.plot(flon,flat,'o',ms=5,color=INK2,mec=SURF,mew=1,label='IR eye fixes (07Z-00Z)')
tg=np.linspace(7,24,100); a.plot(np.polyval(plon,tg),np.polyval(plat,tg),color=INK2,lw=1.5)
kx=111*np.cos(np.radians(17.4))
a.plot(np.polyval(plon,tg)+s['sx']/kx,np.polyval(plat,tg)+s['sy']/111,color=cols[1],lw=2,ls='--',label='Implied surface center (Pc 885 fit)')
a.plot(lon,lat,'-',color=INK,lw=1.2); a.plot(lon,lat,'o',ms=3,color=INK,label='Buoy drift track')
a.plot(131.52603,17.19114,'^',ms=11,color='#e34948',mec=INK,label='Buoy at 17:04Z (909.4 hPa)',zorder=6)
a.set_xlim(130.7,132.7); a.set_ylim(16.75,17.75); a.set_aspect(1/np.cos(np.radians(17.4)))
a.set_xlabel('Longitude (°E)'); a.set_ylabel('Latitude (°N)')
a.set_title('Track: IR eye vs. pressure-implied center',loc='left',color=INK,fontsize=11)
a.grid(color=GRID,lw=0.8); a.legend(frameon=False,fontsize=8,loc='lower left')
fig.tight_layout(); fig.savefig('holland_analysis.png',dpi=150,facecolor=SURF)
for Pc in cases: print(Pc,{k:round(v,1) for k,v in sol[Pc].items() if v is not None})
