import numpy as np, json, sys
from PIL import Image
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
CB=[((143,131,215),144.5),((56,49,127),125),((92,62,169),104.5),((164,74,193),89.5),((239,102,226),73.5),((205,41,41),62),
    ((221,143,60),57.5),((242,225,76),52.5),((116,217,71),45),((48,143,47),37),((77,158,214),32),((146,203,235),25),((204,231,245),15)]
cols=np.array([c for c,_ in CB],float); vals=np.array([v for _,v in CB])
def wind(path,frame=(42,69,1133,918)):
    a=np.array(Image.open(U+path).convert('RGB')).astype(float)
    x0,y0,x1,y1=frame; sub=a[y0:y1,x0:x1]
    d=((sub[:,:,None,:]-cols[None,None])**2).sum(-1); k=d.argmin(-1); dm=np.sqrt(d.min(-1))
    w=vals[k].astype(float); w[dm>45]=np.nan
    return w,x0,y0
def geo(lab_x,lab_y,lons,lats):
    px=np.polyfit(lons,lab_x,1); py=np.polyfit(np.log(np.tan(np.pi/4+np.radians(lats)/2)),lab_y,1)
    def ll(x,y):
        lon=(x-px[1])/px[0]; m=(y-py[1])/py[0]; lat=np.degrees(2*np.arctan(np.exp(m))-np.pi/2); return lon,lat
    return ll
cases={
 'S1D 09:09Z':dict(f='d9f06e8e-image.webp',lx=[158.5,310.5,461.5,613.5,765.5,916.5,1068.5],ly=[97.5,229.5,360.5,491.5,623.5,753.5,884.5]),
 'RCM-3 09:20Z':dict(f='a566c9d6-image.webp',lx=[180.5,332.5,483.5,635.5,787.5,938.5,1090.5],ly=[105.5,237.5,368.5,500.5,631.5,762.5,892.5]),
}
lons=np.array([132.9,133.2,133.5,133.8,134.1,134.4,134.7]); lats=np.array([17.5,17.25,17.0,16.75,16.5,16.25,16.0])
out={}
for name,c in cases.items():
    w,x0,y0=wind(c['f']); ll=geo(np.array(c['lx']),np.array(c['ly']),lons,lats)
    H,W=w.shape; yy,xx=np.mgrid[0:H,0:W]; LON,LAT=ll(xx+x0,yy+y0)
    # eye: pixels < 47 kt near image middle region
    m=(w<47)&(abs(xx-W/2)<250)&(abs(yy-H/2)<250)
    # iterate centroid with shrinking window
    cx,cy=xx[m].mean(),yy[m].mean()
    for it in range(5):
        r=np.hypot(xx-cx,yy-cy); mm=m&(r<120); cx,cy=xx[mm].mean(),yy[mm].mean()
    clon,clat=ll(cx+x0,cy+y0)
    kx=111*np.cos(np.radians(clat)); dx=(LON-clon)*kx; dy=(LAT-clat)*111; R=np.hypot(dx,dy); AZ=np.degrees(np.arctan2(dx,dy))%360
    rb=np.arange(0,96,1.0); prof=[];prof_q={q:[] for q in ('NE','SE','SW','NW')}
    for r0 in rb:
        s=(R>=r0)&(R<r0+1)&~np.isnan(w); prof.append((np.nanmean(w[s]) if s.sum()>20 else np.nan, s.sum(), np.nanmean(np.isnan(w[(R>=r0)&(R<r0+1)]))))
        for q,(a0,a1) in zip(('NE','SE','SW','NW'),((0,90),(90,180),(180,270),(270,360))):
            sq=s&(AZ>=a0)&(AZ<a1); prof_q[q].append(np.nanmean(w[sq]) if sq.sum()>10 else np.nan)
    pm=np.array([p[0] for p in prof]); i=np.nanargmax(pm)
    # max extent of the plotted area in radius (full azimuth coverage)
    print('\n==',name,' eye center %.3fN %.3fE'%(clat,clon),' eye (<47kt) equiv radius %.1f km'%np.sqrt(mm.sum()/(4.75**2)/np.pi))
    print('  azimuthal-mean wind: RMW %.0f km, Vmax(mean) %.0f kt'%(rb[i]+0.5,pm[i]))
    print('  r(km): '+' '.join('%d:%.0f'%(rb[j]+.5,pm[j]) for j in range(0,90,3)))
    for q in prof_q:
        v=np.array(prof_q[q]); j=np.nanargmax(v); print('  %s RMW %.0f km Vmax %.0f kt'%(q,rb[j]+.5,v[j]))
    # radius where mean wind first exceeds 64 kt and the inner edge of >=96 kt
    out[name]=dict(clat=float(clat),clon=float(clon),r=(rb+0.5).tolist(),v=[float(x) for x in pm],q={q:[float(x) for x in v] for q,v in prof_q.items()})
json.dump(out,open('sar/sar_profiles.json','w'))
