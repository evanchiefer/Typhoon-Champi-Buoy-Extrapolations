import numpy as np, json
from PIL import Image
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
def cbar(a,ly,lv):
    p=np.polyfit(ly,lv,1); ys=np.arange(70,920); c=a[ys,1146:1158].mean(1); return c, np.polyval(p,ys)
def tbfield(a,c,v,maxd=28):
    sub=a.astype(float); H,W,_=sub.shape; out=np.full((H,W),np.nan)
    flat=sub.reshape(-1,3)
    # chunked nearest-color lookup
    res=np.full(flat.shape[0],np.nan)
    for i in range(0,flat.shape[0],200000):
        d=((flat[i:i+200000,None,:]-c[None])**2).sum(-1); k=d.argmin(1); dm=np.sqrt(d.min(1))
        r=v[k]; r[dm>maxd]=np.nan; res[i:i+200000]=r
    return res.reshape(H,W)
def geo(lx,ly,lons,lats):
    px=np.polyfit(lons,lx,1); py=np.polyfit(np.log(np.tan(np.pi/4+np.radians(lats)/2)),ly,1)
    def toxy(lon,lat): return np.polyval(px,lon), np.polyval(py,np.log(np.tan(np.pi/4+np.radians(lat)/2)))
    def toll(x,y):
        lon=(x-px[1])/px[0]; m=(y-py[1])/py[0]; return lon,np.degrees(2*np.arctan(np.exp(m))-np.pi/2)
    return toxy,toll
L17=dict(lx=[142,293,445,597,748,899.5,1052],lons=[123,126,129,132,135,138,141],ly=[92.5,230.5,364.5,497.5,628.5,757.5,885.5],lats=[25,22.5,20,17.5,15,12.5,10])
L17b=dict(lx=[146,298,448.5,601,752.5,904,1056],lons=[123,126,129,132,135,138,141],ly=[88.5,225.5,360.5,493.5,623.5,753.5,881.5],lats=[25,22.5,20,17.5,15,12.5,10])
L21=dict(lx=[51,202,354,506,657,809,961,1112],lons=[120,123,126,129,132,135,138,141],ly=[104.5,241.5,376.5,508.5,639.5,769.5,897.5],lats=[25,22.5,20,17.5,15,12.5,10])
cases=[
 ('ATMS-N20 165.5 GHz 17:01Z','260d204c-image.webp',L17,[123.5,237.5,351.5,465.5,579.5,693.5,807.5,921.5],[280,260,240,220,200,180,160,140],+1,17+1/60,(17.43,131.66)),
 ('ATMS-N20 183.3+-7 17:01Z','4b591ec1-image.webp',L17,[116.5,216.5,317.5,418.5,518.5,619.5,719.5,820.5,921.5],[280,260,240,220,200,180,160,140,120],+1,17+1/60,(17.43,131.66)),
 ('ATMS-N20 183.3+-7 17:00Z','e0fb742b-image.webp',L17b,[116.5,216.5,317.5,418.5,518.5,619.5,719.5,820.5,921.5],[280,260,240,220,200,180,160,140,120],+1,17.0,(17.43,131.66)),
 ('WSF-M 89 PCT 21:25Z','9614b70a-image.webp',L21,[87.5,197.5,307.5,416.5,526.5,635.5,745.5,855.5],[300,275,250,225,200,175,150,125],+1,21+25/60,(17.80,130.75)),
 ('WSF-M 37 PCT 21:25Z','9b6228e0-image.webp',L21,[127.5,249.5,371.5,493.5,615.5,737.5,859.5],[280,260,240,220,200,180,160],+1,21+25/60,(17.80,130.75)),
 ('WSF-M 36.5 GHz 21:25Z','971264c5-image.webp',L21,[127.5,249.5,371.5,493.5,615.5,737.5,859.5],[280,260,240,220,200,180,160],-1,21+25/60,(17.80,130.75)),
 ('WSF-M 18.85H 21:25Z','ee8165ce-image.webp',L21,[137.5,315.5,493.5,671.5,849.5],[300,250,200,150,100],-1,21+25/60,(17.80,130.75)),
]
res={}
for name,f,L,cy,cv,sign,tt,g in cases:
    a=np.array(Image.open(U+f).convert('RGB')).astype(int)
    c,v=cbar(a,cy,cv); toxy,toll=geo(np.array(L['lx']),np.array(L['ly']),np.array(L['lons']),np.array(L['lats']))
    gx,gy=toxy(g[1],g[0]); x0,x1,y0,y1=int(gx-140),int(gx+140),int(gy-140),int(gy+140)
    T=tbfield(a[y0:y1,x0:x1],c,v)
    yy,xx=np.mgrid[y0:y1,x0:x1]; LON,LAT=toll(xx,yy)
    best=None
    for cyy in np.arange(gy-25,gy+26,1.0):
        for cxx in np.arange(gx-25,gx+26,1.0):
            clon,clat=toll(cxx,cyy); kx=111*np.cos(np.radians(clat))
            R=np.hypot((LON-clon)*kx,(LAT-clat)*111)
            prof=np.array([np.nanmean(T[(R>=r)&(R<r+4)]) for r in range(0,100,4)])
            eye=prof[0]; ring=np.nanmin(prof[1:15]) if sign>0 else np.nanmax(prof[1:15])
            sc=sign*(eye-ring)
            if best is None or sc>best[0]: best=(sc,clon,clat)
    sc,clon,clat=best; kx=111*np.cos(np.radians(clat)); R=np.hypot((LON-clon)*kx,(LAT-clat)*111)
    rb=np.arange(0,200,3); prof=np.array([np.nanmean(T[(R>=r)&(R<r+3)]) for r in rb])
    j=np.nanargmin(prof[:30]) if sign>0 else np.nanargmax(prof[:30])
    # half-way radius between eye value and ring extreme on the inner side = eye edge
    half=(prof[0]+prof[j])/2; k=np.where((sign*(prof[:j+1]-half))<0)[0]; edge=rb[k[0]]+1.5 if len(k) else np.nan
    res[name]=dict(t=tt,lat=float(clat),lon=float(clon),ring=float(rb[j]+1.5),edge=float(edge),prof=[float(x) for x in prof])
    print('%-28s center %.3fN %.3fE | eye edge (half-contrast) ~%.0f km | ring extreme at ~%.0f km (Tb %.0f vs eye %.0f K)'%(name,clat,clon,edge,rb[j]+1.5,prof[j],prof[0]))
    print('   T(r) every 6 km:',' '.join('%d:%.0f'%(rb[i]+1.5,prof[i]) for i in range(0,len(rb),2)))
json.dump(res,open('mw_rings.json','w'))
