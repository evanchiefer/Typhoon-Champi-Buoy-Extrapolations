import numpy as np, json
from scipy.optimize import least_squares
exec(open('fit2.py').read().split('win=(t>=6.5)')[0].replace('print(','(lambda *a,**k:None)('))
win=(t>=6.5)&(t<=24.5)
# symmetry check on the raw trace: time of closest approach from matched pressures
for lo_,hi_ in ((15.0,20.07),(16.07,19.07),(14.0,21.07)):
    pass
def run(Pn,Pc,shiftmode,mask=win):
    # shiftmode: 'free', 'parallax' (fixed 6 km toward 152) , 'para+along' (parallax fixed + free along-track lag)
    az=np.radians(152); par=np.array([6*np.sin(az),6*np.cos(az)])
    mv=np.radians(292); al=np.array([np.sin(mv),np.cos(mv)])
    def unpack(q):
        Rm,B=q[0],q[1]
        if shiftmode=='free': s=q[2:4]
        elif shiftmode=='parallax': s=par
        else: s=par - q[2]*al   # positive q[2] = true center behind IR center
        return Rm,B,s
    def f(q):
        Rm,B,s=unpack(q); r,_,_=dist(t[mask],lat[mask],lon[mask],tuple(s))
        return holland([Pc,Pn,Rm,B],r)-P[mask]
    n={'free':4,'parallax':2,'para+along':3}[shiftmode]
    lb=[2,0.5,-40,-40][:n]; ub=[90,3,40,40][:n]
    if shiftmode=='para+along': lb=[2,0.5,-30]; ub=[90,3,40]
    best=None
    for Rm0 in (10,20,30,45):
        for B0 in (0.8,1.3,2.0):
            for s0 in ((0,0),(10,-10),(-5,-20)):
                x0=[Rm0,B0,*s0][:n] if shiftmode!='para+along' else [Rm0,B0,8]
                s=least_squares(f,x0,bounds=(lb,ub))
                if best is None or s.cost<best.cost: best=s
    Rm,B,sv=unpack(best.x); r,_,_=dist(t[mask],lat[mask],lon[mask],tuple(sv))
    return np.sqrt(np.mean(f(best.x)**2)),Rm,B,sv,r.min(),best.x
for mode in ('free','para+along','parallax'):
    print('\n### center offset mode:',mode)
    for Pn in (1007,1009,1011):
        row=[]
        for Pc in (860,875,885,895,900,905,908):
            rms,Rm,B,sv,rmin,x=run(Pn,Pc,mode)
            row.append('Pc%d:rms%.2f Rm%.0f B%.2f rmin%.0f'%(Pc,rms,Rm,B,rmin) + ('' if mode=='parallax' else ' lag%.0f'%(x[2] if mode=='para+along' else 0)))
        print('Pn',Pn); [print('   ',x) for x in row]
