# Model eye pressure drop (center -> RMW) in the M-series dual fits, for comparison
exec(open('fit7.py').read().split('if __name__')[0])
for Pc in (853,862,871,880,889,898):
    x=run(Pc,dual=True,off=np.array([8.0,-10.3]),soff=3.,Rprior=(27,4),Vprior=(150,12))
    rm=x['rvmax']; p_rm=prof(np.array([rm]),Pc,x['parts'])[0]
    print('Pc %d: RMW %.0f km, P(RMW) %.1f, eye drop center->RMW %.1f hPa'%(Pc,rm,p_rm,p_rm-Pc))
