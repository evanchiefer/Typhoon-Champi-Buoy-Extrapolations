import sys
from PIL import Image
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
files=dict(zip([7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24],
 ['566b1dd2','0f642994','ce6eddbf','30a1f42c','4e29569e','f07e17f0','93e16b22','ad8bc327','b6f0cfb3','07017dfc','3594791c','cbb64e94','e73c7714','477f2bcd','f3c1b67a','f20c9962','5aaf9839','a374352e']))
for h,f in files.items():
    im=Image.open(U+f+'-image.jpg').convert('L'); W,H=im.size
    # bottom frame row
    rows=[y for y in range(H-60,H) if sum(1 for x in range(60,1100) if im.getpixel((x,y))<80)>600]
    yb=max(rows)
    cols=[x for x in range(0,80) if sum(1 for y in range(60,780) if im.getpixel((x,y))<80)>500]
    xl=min(cols)
    tx=[x for x in range(xl,1160) if im.getpixel((x,yb+3))<110]
    ty=[y for y in range(20,yb) if im.getpixel((xl-3,y))<110]
    # collapse runs
    def runs(v):
        out=[];
        for a in v:
            if out and a-out[-1][-1]<=1: out[-1].append(a)
            else: out.append([a])
        return [sum(r)/len(r) for r in out]
    print(h,(W,H),'yb',yb,'xl',xl,'tx',runs(tx),'ty',runs(ty))
