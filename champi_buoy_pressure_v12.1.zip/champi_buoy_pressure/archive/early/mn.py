import numpy as np
exec(open('plot.py').read().split('plt.rcParams')[0])
tt=np.linspace(16.5,18.5,2001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
for Pc in cases:
    s=sol[Pc]; r,_,_=dist(tt,la_i,lo_i,(s['sx'],s['sy'])); p=holland([Pc,Pn,s['Rm'],s['B']],r)
    i=p.argmin(); print(Pc,'buoy min %.1f hPa at %.2fZ, r=%.1f km, Rmax %.1f'%(p[i],tt[i],r[i],s['Rm']))
