exec(open('fit7.py').read().split('if __name__')[0])
import sys
OFF2=np.array([8.0,-10.3])   # SAR 09:09/09:20 (+9.4,-10.4) and ATMS 17:01 (+6.5,-10.0)
g=np.arange(850,909.1,3)
which=sys.argv[1]
if which=='main':
    scan('M1 dual, center (+8.0,-10.3)+-3, RMW 27+-4 (SAR), Vmax 150+-12',grid=g,dual=True,off=OFF2,soff=3.,Rprior=(27,4),Vprior=(150,12))
elif which=='s1':
    scan('M2 dual, center +-3, RMW 30+-4, Vmax 150+-12',grid=g,dual=True,off=OFF2,soff=3.,Rprior=(30,4),Vprior=(150,12))
    scan('M3 dual, center +-3, RMW 24+-4 (contraction), Vmax 150+-12',grid=g,dual=True,off=OFF2,soff=3.,Rprior=(24,4),Vprior=(150,12))
elif which=='s2':
    scan('M4 dual, center +-3, no RMW prior, Vmax 150+-12',grid=g,dual=True,off=OFF2,soff=3.,Vprior=(150,12))
    scan('M5 single, center +-3, RMW 27+-4',grid=g,off=OFF2,soff=3.,Rprior=(27,4))
