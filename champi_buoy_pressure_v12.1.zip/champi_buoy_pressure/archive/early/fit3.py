import numpy as np, json
from scipy.optimize import least_squares
exec(open('fit2.py').read().split('win=(t>=6.5)')[0].replace('print(','(lambda *a,**k:None)('))
# parallax estimate for Himawari-9 (140.7E) viewing 17.4N 131.66E
R=6371.; H=42164.
la,lo=np.radians(17.4),np.radians(131.66); sl=np.radians(140.7)
P_=R*np.array([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]); S=H*np.array([np.cos(sl),np.sin(sl),0])
v=S-P_; up=P_/R; zen=np.degrees(np.arccos(v@up/np.linalg.norm(v)))
east=np.array([-np.sin(lo),np.cos(lo),0]); north=np.cross(up,east)
az=np.degrees(np.arctan2(v@east,v@north))%360
print('satellite zenith %.1f deg, satellite azimuth from storm %.0f deg'%(zen,az))
for h in (8,12,16): print('  parallax for %d km tops: %.1f km, true center lies toward az %.0f'%(h,h*np.tan(np.radians(zen)),az))
win=(t>=6.5)&(t<=24.5); allm=np.ones_like(t,bool)
def fitshift(mask,fixPc=None,fixshift=None):
    def model(q):
        if fixPc is None: Pc,Pn,Rm,B,sx,sy=q
        else: Pn,Rm,B,sx,sy=q; Pc=fixPc
        if fixshift is not None: sx,sy=fixshift
        r,_,_=dist(t[mask],lat[mask],lon[mask],(sx,sy))
        return holland([Pc,Pn,Rm,B],r)-P[mask]
    best=None
    for Pc0 in ((860,890,905) if fixPc is None else (None,)):
      for Rm0 in (10,20,30):
        for B0 in (0.9,1.5):
          for s0 in ((0,0),(8,-3),(15,-5),(5,5)):
            if fixPc is None: x0=[Pc0,1009,Rm0,B0,*s0]; lb=[780,1002,2,0.4,-40,-40]; ub=[909,1025,90,3,40,40]
            else: x0=[1009,Rm0,B0,*s0]; lb=[1002,2,0.4,-40,-40]; ub=[1025,90,3,40,40]
            s=least_squares(model,x0,bounds=(lb,ub))
            if best is None or s.cost<best.cost: best=s
    q=best.x; e=model(q); 
    full=q if fixPc is None else np.r_[fixPc,q]
    return full,np.sqrt(np.mean(e**2)),e
for name,m in (('window',win),('all',allm)):
    q,rms,e=fitshift(m)
    Pc,Pn,Rm,B,sx,sy=q
    r,_,_=dist(t[m],lat[m],lon[m],(sx,sy))
    print('\n== %s: Pc %.1f Pn %.1f Rmax %.1f km B %.2f | center shift %.1f km E, %.1f km N (%.1f km toward %.0f deg) | rms %.2f | min r %.1f km'%(name,Pc,Pn,Rm,B,sx,sy,np.hypot(sx,sy),np.degrees(np.arctan2(sx,sy))%360,rms,r.min()))
    if name=='window':
        for ti,ri,Pi,ei in zip(t[m],r,P[m],e): print('  %5.2f r=%6.1f obs %7.1f mod %7.1f res %5.1f'%(ti,ri,Pi,Pi+ei,ei))
print('\nPc profile scan (window, shift free):')
for Pc in (850,860,870,880,885,890,895,900,903,906,908.5):
    q,rms,e=fitshift(win,fixPc=Pc); print('  Pc %5.1f rms %.2f  Pn %.1f Rmax %.1f B %.2f shift(%.1f,%.1f)'%(Pc,rms,*q[1:]))
