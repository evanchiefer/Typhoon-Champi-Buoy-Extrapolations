import numpy as np
from PIL import Image
exec(open('mwring.py').read().split('L17=')[0])   # reuse geo()
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
L09=dict(lx=[192.5,345,497,648,800,952,1103],lons=[126,129,132,135,138,141,144],ly=[197.5,331.5,464.5,595.5,724.5,852.5],lats=[22.5,20,17.5,15,12.5,10])
L21=dict(lx=[51,202,354,506,657,809,961,1112],lons=[120,123,126,129,132,135,138,141],ly=[104.5,241.5,376.5,508.5,639.5,769.5,897.5],lats=[25,22.5,20,17.5,15,12.5,10])
for name,f,L,g in [('WSF-M 89 RGB(PCT) 08:55Z','71adb74b-image.webp',L09,(16.65,133.78)),('WSF-M 89 RGB(PCT) 21:25Z','36ec1af8-image.webp',L21,(17.68,130.75))]:
    a=np.array(Image.open(U+f).convert('RGB')).astype(float)
    toxy,toll=geo(np.array(L['lx']),np.array(L['ly']),np.array(L['lons']),np.array(L['lats']))
    gx,gy=toxy(g[1],g[0]); x0,x1,y0,y1=int(gx-140),int(gx+140),int(gy-140),int(gy+140)
    s=a[y0:y1,x0:x1]; P=s[:,:,0]-s[:,:,1]          # "pinkness": deep convection / ice scattering
    yy,xx=np.mgrid[y0:y1,x0:x1]; LON,LAT=toll(xx,yy)
    best=None
    for cyy in np.arange(gy-20,gy+21,1.0):
        for cxx in np.arange(gx-20,gx+21,1.0):
            clon,clat=toll(cxx,cyy); R=np.hypot((LON-clon)*111*np.cos(np.radians(clat)),(LAT-clat)*111)
            prof=np.array([P[(R>=r)&(R<r+4)].mean() for r in range(0,80,4)])
            sc=prof[1:].max()-prof[0]
            if best is None or sc>best[0]: best=(sc,clon,clat)
    _,clon,clat=best; R=np.hypot((LON-clon)*111*np.cos(np.radians(clat)),(LAT-clat)*111)
    rb=np.arange(0,180,3); prof=np.array([P[(R>=r)&(R<r+3)].mean() for r in rb]); j=np.argmax(prof[:25])
    half=(prof[0]+prof[j])/2; k=np.where(prof[:j+1]>half)[0][0]
    print('%-26s center %.3fN %.3fE | eye edge (half) ~%.0f km | ring peak ~%.0f km'%(name,clat,clon,rb[k]+1.5,rb[j]+1.5))
    print('   P(r):',' '.join('%d:%.0f'%(rb[i]+1.5,prof[i]) for i in range(0,len(rb),2)))
