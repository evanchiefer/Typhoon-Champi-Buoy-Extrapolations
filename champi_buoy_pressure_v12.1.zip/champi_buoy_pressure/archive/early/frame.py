import numpy as np, sys
from PIL import Image
U='/root/.claude/uploads/aff9a93d-a48d-5fdf-9b61-0f18a743f164/'
for f in sys.argv[1:]:
    a=np.array(Image.open(U+f).convert('RGB')).astype(int); H,W,_=a.shape
    dark=a.max(2)<60
    # plot frame: long dark horizontal/vertical lines
    rows=[y for y in range(H) if dark[y,:].sum()>0.6*W]; cols=[x for x in range(W) if dark[:,x].sum()>0.6*H]
    print(f,'frame rows',rows[:3],rows[-3:],'cols',cols[:3],cols[-3:])
    # tick marks: just outside the frame bottom (below last frame row) and left
    if rows and cols:
        yb=max(r for r in rows if r>H/2); xl=min(c for c in cols if c<W/2)
        tb=[x for x in range(W) if dark[yb+1:yb+6,x].sum()>=4]
        tl=[y for y in range(H) if dark[y,xl-6:xl].sum()>=4]
        def groups(v):
            g=[];
            for x in v:
                if g and x-g[-1][-1]<=1: g[-1].append(x)
                else: g.append([x])
            return [round(np.mean(q),1) for q in g]
        print('  bottom ticks x:',groups(tb)); print('  left ticks y:',groups(tl))
