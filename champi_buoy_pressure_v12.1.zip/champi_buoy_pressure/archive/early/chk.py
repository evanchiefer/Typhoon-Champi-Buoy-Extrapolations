exec(open('fit7.py').read().split('if __name__')[0])
NM=1.852
tt=np.linspace(15,20,3001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
def cpa(off):
    r,_,_=dist(tt,la_i,lo_i,off); i=r.argmin(); r17,_,_=dist(np.array([17+4/60]),np.array([lat[17]]),np.array([lon[17]]),off)
    return r[i],tt[i],r17[0]
for name,off in [('my IR track, no shift',(0,0)),('IR + parallax',(3.2,-6.0)),('fix consensus',(2.4,-8.8)),('dual-fit center',(8.4,-10.1))]:
    a,b,c=cpa(off); print('%-22s CPA %.1f km at %.2fZ; r at 17:04 = %.1f km'%(name,a,b,c))
def radii(parts):
    v=0.9*vgrad(rr,parts)*KT; i=v.argmax(); out=[]
    for thr in (64,50,34):
        j=np.where(v[i:]<thr)[0]; out.append(rr[i+j[0]]/NM if len(j) else np.nan)
    return out
print('\nwind-radii table @17Z (nmi): R64 NE85 SE65 SW45 NW80 (mean 69) | R50 130/115/100/130 (119) | R34 235/200/165/230 (208); RMW 18.9')
for lab,kw in [('dual D1',dict(dual=True,Rprior=(35,5),Vprior=(150,12))),('single B',dict(Rprior=(35,5)))]:
    for Pc in (875,890,905):
        x=run(Pc,**kw); r64,r50,r34=radii(x['parts'])
        print('%s Pc %d: model symmetric R64 %.0f  R50 %.0f  R34 %.0f nmi; RMW %.1f nmi; Vmax %.0f kt'%(lab,Pc,r64,r50,r34,x['rvmax']/NM,x['vmax']))
