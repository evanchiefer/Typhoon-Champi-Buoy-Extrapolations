import numpy as np, json
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx))
la=np.array([fx[str(h)]['lat'] for h in th]); lo=np.array([fx[str(h)]['lon'] for h in th])
pla=np.polyfit(th,la,2); plo=np.polyfit(th,lo,2)
# parallax: true center ~6.8 km toward az 152 from IR position
az=np.radians(152); px,py=6.8*np.sin(az),6.8*np.cos(az)
def ir(tt): return np.polyval(pla,tt),np.polyval(plo,tt)
def off(tt,fla,flo):
    cla,clo=ir(tt); k=111*np.cos(np.radians(cla))
    return (flo-clo)*k,(fla-cla)*111
# ARCHER microwave fixes with D-MINT pass times
mw=[('F18 89GHz',7+22/60,16.45,134.13),('TMS09 183',11+34/60,16.91,133.09),('MHS 183',11+42/60,17.07,133.06),
    ('TMS06 183',13+36/60,17.04,132.60),('F18 89GHz*',19+56/60,17.59,131.05),('MHS 183',24+12/60,17.92,130.08)]
print('IR-track extrapolation ok within 7-24Z; offsets in km (E,N) of fix relative to IR eye track')
for n,tt,fla,flo in mw:
    dx,dy=off(tt,fla,flo); print('%-11s %5.2fZ  dE %+6.1f dN %+6.1f  |d| %5.1f'%(n,tt,dx,dy,np.hypot(dx,dy)))
print('parallax-implied surface offset: dE %+.1f dN %+.1f'%(px,py))
# ARCHER IR fixes: infer time by nearest approach to IR track, report cross-track offset
print('\nARCHER H9 IR fixes vs my IR track (time inferred by along-track match):')
for fla,flo in [(16.62,133.91),(16.86,133.15),(17.08,132.34),(17.35,131.61),(17.57,131.02),(17.92,130.28),(18.28,129.60)]:
    tt=np.linspace(6,27,4201); cla,clo=ir(tt); d=np.hypot((flo-clo)*106,(fla-cla)*111); i=d.argmin()
    print('  %.2fN %.2fE -> ~%5.2fZ, min dist %.1f km'%(fla,flo,tt[i]%24,d[i]))
# D-PRINT / wind-radii table positions vs IR track
dp=[(16,17.39,132.19),(16.5,17.30,131.88),(17,17.48,131.98),(17.5,17.39,131.63),(18,17.57,131.77),(18.5,17.46,131.37),(19,17.66,131.55),(19.5,17.50,131.21),(20,17.60,131.10),(21,17.70,130.90)]
print('\nD-PRINT table positions vs IR track:')
for tt,fla,flo in dp:
    dx,dy=off(tt,fla,flo); print('  %5.1fZ dE %+6.1f dN %+6.1f'%(tt,dx,dy))
wr=[(16,17.3,132.0),(16.5,17.3,131.9),(17,17.4,131.8),(17.5,17.4,131.6),(18,17.4,131.5),(18.5,17.5,131.4),(19,17.5,131.3)]
print('\nWind-radii table positions vs IR track:')
for tt,fla,flo in wr:
    dx,dy=off(tt,fla,flo); print('  %5.1fZ dE %+6.1f dN %+6.1f'%(tt,dx,dy))
print('\nSigned offsets of ARCHER H9 IR fixes relative to my IR track (E,N km):')
for fla,flo in [(16.62,133.91),(16.86,133.15),(17.08,132.34),(17.35,131.61),(17.57,131.02),(17.92,130.28),(18.28,129.60)]:
    tt=np.linspace(6,27,4201); cla,clo=ir(tt); d=np.hypot((flo-clo)*106,(fla-cla)*111); i=d.argmin()
    dx,dy=off(tt[i],fla,flo); print('  %+6.1f %+6.1f'%(dx,dy))
