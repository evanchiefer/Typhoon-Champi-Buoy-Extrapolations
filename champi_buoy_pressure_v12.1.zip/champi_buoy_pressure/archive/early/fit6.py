import numpy as np
from scipy.optimize import least_squares
exec(open('fit5.py').read().split('grid=np.arange')[0])
def solveB(Pc,Pn,B):
    def f(q):
        Rm,sx,sy=q; r,_,_=dist(t,lat,lon,(sx,sy))
        e=holland([Pc,Pn,Rm,B],r)-P
        return np.r_[e,[(sx-par[0])/SIG_OFF*1.5,(sy-par[1])/SIG_OFF*1.5]]
    best=None
    for Rm0 in (15,25,35,45):
        for s0 in ((0,0),(2,-20),(5,-10)):
            s=least_squares(f,[Rm0,*s0],bounds=([3,-40,-40],[90,40,40]))
            if best is None or s.cost<best.cost: best=s
    Rm,sx,sy=best.x; r,_,_=dist(t,lat,lon,(sx,sy)); e=holland([Pc,Pn,Rm,B],r)-P
    return np.sqrt(np.mean(e**2)),Rm,r.min(),e
for B in (1.0,1.3,1.6,2.0):
    out=[]
    for Pc in range(850,909,6):
        rms,Rm,rmin,e=solveB(Pc,1009,B); out.append((rms,Pc,Rm,rmin))
    best=min(out)
    print('B=%.1f: best Pc %d (rms %.2f, Rm %.0f, rmin %.0f) | rms at Pc 860/880/900: %s'%(B,best[1],best[0],best[2],best[3],
          ' / '.join('%.2f'%o[0] for o in out if o[1] in (862,880,898))))
