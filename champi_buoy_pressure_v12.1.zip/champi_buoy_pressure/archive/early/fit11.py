exec(open('fit7.py').read().split('if __name__')[0])
import sys
rrc=np.linspace(5,120,300)
OFF2=np.array([6.0,-10.2])   # mean of SAR 09Z (+9.4,-10.4) and ATMS 17:01Z (+2.7,-10.0)
def run2(Pc,Pn=1009.5,Rprior=(27,4),Vprior=(150,12),Eprior=None,off=OFF2,soff=4.):
    def unpack(q):
        fr,R1,B1,R2,B2,sx,sy=q; dP=Pn-Pc; return [(dP*fr,R1,B1),(dP*(1-fr),R2,B2)],sx,sy
    def res(q):
        parts,sx,sy=unpack(q); r,_,_=dist(t,lat,lon,(sx,sy))
        e=prof(r,Pc,parts)-P; pen=[(sx-off[0])/soff*1.5,(sy-off[1])/soff*1.5]
        vg=vgrad(rrc,parts); i=vg.argmax(); rm=rrc[i]
        if Rprior: pen.append((rm-Rprior[0])/Rprior[1]*1.5)
        if Vprior: pen.append((0.9*vg[i]*KT-Vprior[0])/Vprior[1]*1.5)
        if Eprior: pen.append((prof(np.array([rm]),Pc,parts)[0]-Pc-Eprior[0])/Eprior[1]*1.5)
        return np.r_[e,pen]
    best=None
    for s0 in [[fr,R1,B1,R2,1.45,*off] for fr in (0.6,0.75) for R1 in (25,30) for B1 in (1.8,2.8) for R2 in (110,150)]:
        s=least_squares(res,s0,bounds=([0.05,10,0.8,50,0.5,-40,-40],[0.95,70,4,400,3,40,40]))
        if best is None or s.cost<best.cost: best=s
    parts,sx,sy=unpack(best.x); r,_,_=dist(t,lat,lon,(sx,sy)); e=prof(r,Pc,parts)-P
    vg=0.9*vgrad(rrc,parts); i=vg.argmax(); rm=rrc[i]
    return dict(cost=2*best.cost,rms=np.sqrt(np.mean(e**2)),parts=parts,sx=sx,sy=sy,rmin=r.min(),vmax=vg[i]*KT,rvmax=rm,
                eye=prof(np.array([rm]),Pc,parts)[0]-Pc,e=e,r=r)
def scan2(label,grid,**kw):
    rows=[(Pc,run2(Pc,**kw)) for Pc in grid]; c=np.array([x['cost'] for _,x in rows]); c-=c.min()
    L=np.exp(-0.5*c/1.5**2); L/=L.sum(); cdf=np.cumsum(L)
    q=[grid[min(np.searchsorted(cdf,p),len(grid)-1)] for p in (0.025,0.16,0.5,0.84,0.975)]
    print('\n== %s: best %d | median %d | 68%% %d-%d | 95%% %d-%d'%(label,grid[c.argmin()],q[2],q[1],q[3],q[0],q[4]))
    for (Pc,x),cc in zip(rows,c):
        print('  Pc %d rms %.2f dcost %5.1f | RMW %.0f eye-drop %.0f | R2 %.0f | off(%+.1f,%+.1f) rmin %.1f | Vmax %.0f'%(Pc,x['rms'],cc,x['rvmax'],x['eye'],x['parts'][1][1],x['sx'],x['sy'],x['rmin'],x['vmax']))
    return rows,L
g=np.arange(838,909.1,4)
w=sys.argv[1]
if w=='a': scan2('E0 center prior (+6.0,-10.2)+-4, RMW 27+-4, Vmax 150+-12, no eye-drop prior',g)
if w=='b': scan2('E1 + eye drop 22+-5 hPa (SAR face value)',g,Eprior=(22,5))
if w=='c': scan2('E2 + eye drop 31+-7 hPa (SAR scaled to match buoy outer gradient)',g,Eprior=(31,7))
