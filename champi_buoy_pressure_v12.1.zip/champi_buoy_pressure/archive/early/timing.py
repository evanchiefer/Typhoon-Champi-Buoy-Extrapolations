exec(open('fit11.py').read().split('g=np.arange')[0])
import time
t0=time.time(); x=run2(886,Eprior=(22,5)); print('one Pc, 16 starts: %.1f s'%(time.time()-t0))
