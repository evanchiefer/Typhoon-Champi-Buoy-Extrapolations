exec(open('fit7.py').read().split('if __name__')[0])
import json, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
F=json.load(open('final_fits.json'))
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'
BL=['#8bb8ea','#2a78d6','#0f3f7a']; OR='#eb6834'; GR='#1baf7a'; RED='#d0312d'
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,
                     'axes.facecolor':SURF,'figure.facecolor':SURF,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,
                     'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(2,2,figsize=(14,11),gridspec_kw=dict(height_ratios=[1,1.1])); (a,b),(c,d)=ax
tt=np.linspace(12,23,4001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
keys=['875','889','905']
# (a) time series
for k,col in zip(keys,BL):
    x=F[k]; r,_,_=dist(tt,la_i,lo_i,(x['sx'],x['sy'])); a.plot(tt,prof(r,int(k),[tuple(p) for p in x['parts']]),color=col,lw=2,label='two-ring fit, center %s hPa'%k)
s=F['single']; r,_,_=dist(tt,la_i,lo_i,(s['sx'],s['sy'])); a.plot(tt,prof(r,889,[tuple(p) for p in s['parts']]),color=INK2,lw=1.5,ls='--',label='single-ring Holland (poorer fit)')
m=(t>=12)&(t<=23); a.plot(t[m],P[m],'o',ms=8,color=INK,mec=SURF,mew=1.5,label='buoy readings',zorder=5)
a.annotate('909.4 hPa at 17:04Z',(17+4/60,909.4),(17.6,925),fontsize=9,color=INK,arrowprops=dict(arrowstyle='-',color=INK2))
a.annotate('fits: ~899–906 hPa\naround 17:33Z\n(between readings)',(17.55,900),(19.2,905),fontsize=9,color=INK,arrowprops=dict(arrowstyle='-',color=INK2))
a.set_xlim(12,23); a.set_ylim(890,1000); a.set_xlabel('Oct 20, UTC hour'); a.set_ylabel('pressure (hPa)')
a.set_title('Buoy pressure trace vs constrained fits',loc='left',fontweight='bold',color=INK)
a.legend(loc='lower left',fontsize=8.5,frameon=False)
# (b) radial profile
rp=np.linspace(0.5,220,1500)
b.axvspan(0,25,color=GRID,alpha=0.9,lw=0); b.text(1.5,1003,'never sampled\n(closest pass\n~25 km)',fontsize=8.5,color=INK2,va='top')
b.axvspan(29,35,color=BL[0],alpha=0.25,lw=0); b.text(36,893,'RMW 29–35 km\n(fit, wind table,\n89 GHz ring)',fontsize=8.5,color=INK2)
b.axvspan(104,140,color=GR,alpha=0.12,lw=0); b.text(106,1003,'secondary ring\n104–140 km\n(ERC ring plot)',fontsize=8.5,color=INK2,va='top')
for k,col in zip(keys,BL):
    x=F[k]; b.plot(rp,prof(rp,int(k),[tuple(p) for p in x['parts']]),color=col,lw=2)
    b.text(1.5,int(k)+1.2,'%s'%k,color=col if k!='875' else '#3d7fc4',fontsize=9,fontweight='bold')
x=F['889']; r,_,_=dist(t,lat,lon,(x['sx'],x['sy'])); before=t<17.55
b.plot(r[before],P[before],'o',ms=7,color=INK,mec=SURF,mew=1.2,label='buoy, storm approaching')
b.plot(r[~before],P[~before],'s',ms=7,color=SURF,mec=INK,mew=1.4,label='buoy, storm departing')
b.set_xlim(0,220); b.set_ylim(870,1005); b.set_xlabel('distance from fitted surface center (km)'); b.set_ylabel('pressure (hPa)')
b.set_title('Radial profile: center is an extrapolation inside ~25 km',loc='left',fontweight='bold',color=INK)
b.legend(loc='lower right',fontsize=8.5,frameon=False)
# (c) map
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx))
flat=np.array([fx[str(h)]['lat'] for h in th]); flon=np.array([fx[str(h)]['lon'] for h in th])
th2=np.linspace(12,23,200); c.plot(np.polyval(plon,th2),np.polyval(plat,th2),color=INK2,lw=1.2,alpha=0.7)
c.plot(flon,flat,'o',ms=6,color=SURF,mec=INK2,mew=1.3,label='IR eye, my fixes (hourly)')
ai=np.array([(17.08,132.34),(17.35,131.61),(17.57,131.02)]); c.plot(ai[:,1],ai[:,0],'s',ms=9,color=BL[1],mec=SURF,mew=1.2,label='ARCHER IR fixes')
mw=np.array([(17.04,132.60),(17.59,131.05)]); c.plot(mw[:,1],mw[:,0],'D',ms=9,color=OR,mec=SURF,mew=1.2,label='ARCHER microwave (13:36Z, ~19:56Z)')
wr=np.array([(17.3,132.0),(17.3,131.9),(17.4,131.8),(17.4,131.6),(17.4,131.5),(17.5,131.4),(17.5,131.3)]); c.plot(wr[:,1],wr[:,0],'^',ms=8,color=GR,mec=SURF,mew=1.0,label='wind-radii table positions (16–19Z)')
k=111*np.cos(np.radians(17.4)); sx,sy=x['sx'],x['sy']
cl=np.polyval(plat,th2)+sy/111; co=np.polyval(plon,th2)+sx/k; c.plot(co,cl,color=INK,lw=2,ls='--',label='fitted surface center')
tc=17.55; ccl=np.polyval(plat,tc)+sy/111; cco=np.polyval(plon,tc)+sx/k
th_=np.linspace(0,2*np.pi,200); Rm=x['parts'][0][1]
c.plot(cco+Rm*np.sin(th_)/k,ccl+Rm*np.cos(th_)/111,color=INK,lw=1,ls=':')
c.text(cco+0.30,ccl-0.22,'RMW ~%.0f km\n(17:33Z)'%Rm,fontsize=8.5,color=INK2,ha='left',va='top')
c.plot(cco,ccl,'+',ms=12,mew=2,color=INK)
c.plot(lon,lat,'-',color=INK,lw=1.2); c.plot(lon[17],lat[17],'^',ms=12,color=RED,mec=SURF,label='buoy at 17:04Z (909.4 hPa)')
c.set_xlim(130.95,132.7); c.set_ylim(16.95,17.78); c.set_aspect(1/np.cos(np.radians(17.35)))
c.set_xlabel('longitude (°E)'); c.set_ylabel('latitude (°N)')
c.set_title('Center fixes and the buoy pass',loc='left',fontweight='bold',color=INK)
c.legend(loc='upper right',fontsize=8,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (d) estimates
est=[('This analysis (buoy + constraints)',887,875,901),('JTWC best track (~17Z)',895,None,None),('D-PRINT (16:30–17:30Z)',903,902,904),
     ('ATMS in SATCON plot (~17Z)',903,None,None),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907),('SATCON (~17Z)',910,None,None)]
for i,(n,v,lo_,hi_) in enumerate(est[::-1]):
    yv=i; col=BL[1] if n.startswith('This') else INK2
    if lo_ is not None: d.plot([lo_,hi_],[yv,yv],color=col,lw=6 if n.startswith('This') else 3,alpha=0.35 if n.startswith('This') else 0.6,solid_capstyle='round')
    d.plot(v,yv,'o',ms=10,color=col,mec=SURF,mew=1.5)
    d.text(v+(1.2 if not n.startswith('This') else -1.2),yv+0.22,('%g'%v if lo_ is None else '%g–%g'%(lo_,hi_)) if not n.startswith('This') else '~%d (68%%: %d–%d)'%(v,lo_,hi_),fontsize=9,color=INK,ha='left' if not n.startswith('This') else 'right')
d.axvline(909.4,color=RED,lw=1.5,ls='--'); d.text(910.2,3.5,'buoy reading\n909.4 hPa,\ntaken ~26–30 km\nfrom center',fontsize=8.5,color=INK,ha='left',va='center')
d.set_yticks(range(len(est))); d.set_yticklabels([e[0] for e in est[::-1]],fontsize=9.5); d.set_xlim(866,924); d.set_ylim(-0.6,len(est)-0.2)
d.set_xlabel('central pressure (hPa)'); d.grid(axis='y',visible=False)
d.set_title('Estimates near 17Z, Oct 20',loc='left',fontweight='bold',color=INK)
fig.suptitle('Champi (29W): central pressure from the drifting-buoy pass, constrained by center fixes and eyewall structure',x=0.01,ha='left',fontsize=13,fontweight='bold',color=INK)
fig.tight_layout(rect=(0,0,1,0.96)); fig.savefig('champi_center_pressure.png',dpi=130)
