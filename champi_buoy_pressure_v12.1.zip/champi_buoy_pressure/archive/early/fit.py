import numpy as np
from scipy.optimize import least_squares
d=[l.split() for l in open('data.txt')]
lat=np.array([float(a[0]) for a in d]); lon=np.array([float(a[1]) for a in d])
t=np.array([int(a[2].split(':')[0])+int(a[2].split(':')[1])/60 for a in d]); P=np.array([float(a[3]) for a in d])
c_lat,c_lon,tc=17.40627,131.64598,17.0
kmlat=111.0; kmlon=111.0*np.cos(np.radians(17.3))
def r_of(p):
    vx,vy,dx,dy=p[4:8]  # km/h east,north ; offset km
    cx=dx+vx*(t-tc); cy=dy+vy*(t-tc)
    bx=(lon-c_lon)*kmlon; by=(lat-c_lat)*kmlat
    return np.hypot(bx-cx,by-cy)
def model(p):
    Pc,Pn,Rm,B=p[:4]; r=np.maximum(r_of(p),0.1)
    return Pc+(Pn-Pc)*np.exp(-(Rm/r)**B)
def res(p,wo=1.0):
    e=model(p)-P
    return np.concatenate([e,[p[6]/5*wo,p[7]/5*wo]])  # weak prior: center near IR fix (±5 km)
best=None
for vx0 in (-25,-15,-5,5):
  for vy0 in (-10,0,10):
    for Rm0 in (15,25,35):
      p0=[880,1010,Rm0,1.2,vx0,vy0,0,0]
      s=least_squares(res,p0,bounds=([800,1003,3,0.5,-60,-60,-40,-40],[930,1020,80,2.5,60,60,40,40]))
      if best is None or s.cost<best.cost: best=s
p=best.x; e=model(p)-P
print('Pc %.1f Pn %.1f Rmax %.1f km B %.2f v=(%.1f,%.1f) km/h off=(%.1f,%.1f) km'%tuple(p))
print('rms %.2f hPa'%np.sqrt(np.mean(e**2)))
print('min r %.1f km at t=%.2f'%(r_of(p).min(), t[r_of(p).argmin()]))
for ti,ri,Pi,mi in zip(t,r_of(p),P,model(p)): print('%5.1f %6.1f %7.1f %7.1f'%(ti,ri,Pi,mi))
# sensitivity: profile likelihood on Pc
import itertools
for Pcf in (870,880,890,895,900,905):
    def r2(q): return res(np.r_[Pcf,q])
    s=least_squares(r2,p[1:],bounds=([1003,3,0.5,-60,-60,-40,-40],[1020,80,2.5,60,60,40,40]))
    print('Pc fixed',Pcf,'rms',round(np.sqrt(np.mean(s.fun[:-2]**2)),2), 'Rmax',round(s.x[1],1),'B',round(s.x[2],2))
