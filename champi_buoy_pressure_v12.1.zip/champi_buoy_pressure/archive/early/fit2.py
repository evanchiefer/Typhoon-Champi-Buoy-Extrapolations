import numpy as np, json
from scipy.optimize import least_squares
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx))
flat=np.array([fx[str(h)]['lat'] for h in th]); flon=np.array([fx[str(h)]['lon'] for h in th])
d=[l.split() for l in open('data.txt')]
lat=np.array([float(a[0]) for a in d]); lon=np.array([float(a[1]) for a in d])
t=np.array([int(a[2].split(':')[0])+int(a[2].split(':')[1])/60 for a in d]); P=np.array([float(a[3]) for a in d])
# smooth track: quadratic fit in time
deg=2
plat=np.polyfit(th,flat,deg); plon=np.polyfit(th,flon,deg)
res_lat=(flat-np.polyval(plat,th))*111; res_lon=(flon-np.polyval(plon,th))*111*np.cos(np.radians(17.4))
print('track fit residual rms km: %.2f'%np.sqrt(np.mean(res_lat**2+res_lon**2)))
v_n=np.polyval(np.polyder(plat),17)*111; v_e=np.polyval(np.polyder(plon),17)*111*np.cos(np.radians(17.4))
print('motion at 17Z: %.1f km/h toward %.0f deg'%(np.hypot(v_n,v_e),np.degrees(np.arctan2(v_e,v_n))%360))
def dist(t_,la,lo,shift=(0,0)):
    clat=np.polyval(plat,t_); clon=np.polyval(plon,t_)
    kx=111*np.cos(np.radians((la+clat)/2))
    dx=(lo-clon)*kx - shift[0]; dy=(la-clat)*111 - shift[1]
    return np.hypot(dx,dy), dx, dy
def holland(p,r): Pc,Pn,Rm,B=p; return Pc+(Pn-Pc)*np.exp(-(Rm/np.maximum(r,0.05))**B)
def fit(mask,shift=(0,0),fixPc=None,verbose=False):
    r,_,_=dist(t[mask],lat[mask],lon[mask],shift)
    if fixPc is None:
        f=lambda p: holland(p,r)-P[mask]
        best=None
        for Pc0 in (860,880,900):
          for Rm0 in (10,20,30,40):
            for B0 in (0.8,1.2,1.8):
              s=least_squares(f,[Pc0,1009,Rm0,B0],bounds=([780,1002,2,0.4],[909,1025,90,3]))
              if best is None or s.cost<best.cost: best=s
        p=best.x
    else:
        f=lambda q: holland([fixPc,*q],r)-P[mask]
        best=None
        for Rm0 in (10,20,30,40):
            for B0 in (0.8,1.2,1.8):
              s=least_squares(f,[1009,Rm0,B0],bounds=([1002,2,0.4],[1025,90,3]))
              if best is None or s.cost<best.cost: best=s
        p=np.r_[fixPc,best.x]
    e=holland(p,r)-P[mask]
    return p,np.sqrt(np.mean(e**2)),r,e
win=(t>=6.5)&(t<=24.5); allm=np.ones_like(t,bool)
for name,m in (('within fix window 07-00Z',win),('all obs (track extrapolated)',allm)):
    p,rms,r,e=fit(m)
    print('\n== %s: Pc %.1f  Pn %.1f  Rmax %.1f km  B %.2f  rms %.2f hPa  min r %.1f km'%(name,*p,rms,r.min()))
p,rms,r,e=fit(win)
print('\n t     r_km   obs    model   resid')
for ti,ri,Pi,ei in zip(t[win],r,P[win],e): print('%5.2f %6.1f %7.1f %7.1f %6.1f'%(ti,ri,Pi,Pi+ei,ei))
print('\nprofile scan on Pc (window):')
for Pc in (860,870,880,890,895,900,905,908):
    p,rms,r,e=fit(win,fixPc=Pc); print(' Pc %d -> rms %.2f  Pn %.1f Rmax %.1f B %.2f'%(Pc,rms,p[1],p[2],p[3]))
