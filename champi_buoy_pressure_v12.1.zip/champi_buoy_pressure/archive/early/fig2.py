exec(open('fit7.py').read().split('if __name__')[0])
import json, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
F={int(k):v for k,v in json.load(open('final2_fits.json')).items()}; S=json.load(open('sar/sar_profiles.json'))
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'; BL=['#8bb8ea','#2a78d6','#0f3f7a']; OR='#eb6834'; GR='#1baf7a'; RED='#d0312d'; PU='#7b5bd6'
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.facecolor':SURF,'figure.facecolor':SURF,
                     'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(2,3,figsize=(19,11.5)); (A,B,C),(D,E,G)=ax
keys=[872,886,896]; lab={872:'872 hPa (68% low)',886:'886 hPa (median)',896:'896 hPa (68% high)'}
P_=lambda k,r: prof(r,k,[tuple(p) for p in F[k]['parts']])
tt=np.linspace(12,23,4001); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
# (A) pressure trace
for k,c in zip(keys,BL):
    r,_,_=dist(tt,la_i,lo_i,(F[k]['sx'],F[k]['sy'])); A.plot(tt,P_(k,r),color=c,lw=2,label='fit, center '+lab[k])
m=(t>=12)&(t<=23); A.plot(t[m],P[m],'o',ms=8,color=INK,mec=SURF,mew=1.5,label='buoy readings',zorder=5)
A.annotate('909.4 hPa at 17:04Z',(17.07,909.4),(17.7,926),fontsize=9,arrowprops=dict(arrowstyle='-',color=INK2))
A.annotate('likely low ~898–902 hPa\nnear 17:33Z, between readings',(17.55,899.5),(18.9,905),fontsize=9,arrowprops=dict(arrowstyle='-',color=INK2))
A.set_xlim(12,23); A.set_ylim(890,1000); A.set_xlabel('Oct 20, UTC hour'); A.set_ylabel('pressure (hPa)')
A.set_title('Buoy pressure vs two-ring fits',loc='left',fontweight='bold'); A.legend(loc='upper center',fontsize=8.5,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (B) buoy distance from fitted center vs time, with structure bands
k=886; r,_,_=dist(tt,la_i,lo_i,(F[k]['sx'],F[k]['sy']))
B.axhspan(0,16,color=GRID,lw=0); B.text(12.2,8,'calm eye (SAR, winds < 47 kt)',fontsize=8.5,color=INK2,va='center')
B.axhspan(24,33,color=BL[0],alpha=0.35,lw=0); B.text(19.2,28.5,'radius of max wind\n(SAR 24–28, fits 28–33 km)',fontsize=8,color=INK2,va='center')
B.axhspan(110,135,color=GR,alpha=0.15,lw=0); B.text(13.9,122,'outer ring forming (fit 110–135 km; MW 120–130 km by 21Z)',fontsize=8.5,color=INK2,va='center')
B.plot(tt,r,color=INK,lw=2,label='buoy distance from surface center')
mm=(t>=12)&(t<=23); rr_,_,_=dist(t[mm],lat[mm],lon[mm],(F[k]['sx'],F[k]['sy'])); B.plot(t[mm],rr_,'o',ms=6,color=INK,mec=SURF)
j=r.argmin(); B.annotate('closest ~%.0f km at %02d:%02dZ'%(r[j],int(tt[j]),round(tt[j]%1*60)),(tt[j],r[j]),(12.4,62),fontsize=9,arrowprops=dict(arrowstyle='-',color=INK2))
B.set_xlim(12,23); B.set_ylim(0,160); B.set_xlabel('Oct 20, UTC hour'); B.set_ylabel('distance from center (km)')
B.set_title('Where the buoy was relative to the eyewall',loc='left',fontweight='bold')
# (C) SAR wind profiles
for (n,d),c in zip(S.items(),(BL[1],OR)):
    C.plot(d['r'],d['v'],color=c,lw=2,label='SAR %s (azimuthal mean)'%n)
rp=np.linspace(1,95,400); vg=0.9*vgrad(rp,[tuple(p) for p in F[886]['parts']])*KT
C.plot(rp,vg,color=INK,lw=1.5,ls='--',label='fit (886 hPa), 0.9 × gradient wind, 17:33Z')
C.axvspan(0,16,color=GRID,lw=0); C.axvline(24.5,color=RED,lw=1.5,ls=':'); C.text(25.5,15,'buoy closest\napproach',fontsize=8.5,color=INK)
C.set_xlim(0,95); C.set_ylim(0,190); C.set_xlabel('distance from center (km)'); C.set_ylabel('wind speed (kt)')
C.set_title('SAR surface winds, 09Z (8 h before the pass)',loc='left',fontweight='bold'); C.legend(loc='upper right',fontsize=8.5,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (D) center offsets
D.axhline(0,color=INK2,lw=0.8); D.axvline(0,color=INK2,lw=0.8)
D.plot(0,0,'o',ms=9,color=SURF,mec=INK2,mew=1.5,label='my IR eye track (reference)')
D.annotate('',xy=(3.2,-6.0),xytext=(0,0),arrowprops=dict(arrowstyle='->',color=INK2,lw=1.5)); D.text(3.6,-5.2,'viewing-angle\nshift',fontsize=8,color=INK2)
mw=np.array([(0.7,-20.6),(6.5,-5.5),(6.9,11.0),(8.6,-9.7),(3.3,-11.7),(-0.2,-21.9)])
D.plot(mw[:,0],mw[:,1],'D',ms=8,color=GR,mec=SURF,label='ARCHER microwave fixes (real times)')
D.plot([9.4,9.5],[-10.4,-9.5],'s',ms=10,color=BL[1],mec=SURF,label='SAR surface center (09:09, 09:20Z)')
D.plot(2.7,-10.0,'^',ms=11,color=OR,mec=SURF,label='ATMS 165/183 GHz, 17:01Z')
D.plot(7.5,-11.6,'P',ms=13,color=INK,mec=SURF,label='center found by the buoy fit')
D.set_xlim(-12,16); D.set_ylim(-26,27); D.set_aspect('equal'); D.set_xlabel('km east of IR eye'); D.set_ylabel('km north of IR eye')
D.set_title('Surface center vs the IR eye',loc='left',fontweight='bold'); D.legend(loc='upper left',fontsize=8,frameon=True,facecolor=SURF,edgecolor=GRID)
# (E) radial pressure profile
rr2=np.linspace(0.5,200,1500)
E.axvspan(0,16,color=GRID,lw=0); E.axvspan(24,33,color=BL[0],alpha=0.35,lw=0); E.axvspan(110,135,color=GR,alpha=0.15,lw=0)
for k,c in zip(keys,BL): E.plot(rr2,P_(k,rr2),color=c,lw=2); E.text(1.5,k+1.2,str(k),color=c if k!=872 else '#3d7fc4',fontsize=9,fontweight='bold')
x=F[886]; r,_,_=dist(t,lat,lon,(x['sx'],x['sy'])); bf=t<17.55
E.plot(r[bf],P[bf],'o',ms=7,color=INK,mec=SURF,label='buoy, storm approaching'); E.plot(r[~bf],P[~bf],'s',ms=7,color=SURF,mec=INK,mew=1.4,label='buoy, storm departing')
E.text(2,1002,'calm\neye',fontsize=8.5,color=INK2,va='top'); E.text(34,880,'RMW',fontsize=8.5,color=INK2); E.text(112,1002,'outer ring',fontsize=8.5,color=INK2,va='top')
E.set_xlim(0,200); E.set_ylim(866,1005); E.set_xlabel('distance from center (km)'); E.set_ylabel('pressure (hPa)')
E.set_title('Pressure profile: inside ~24 km is extrapolated',loc='left',fontweight='bold'); E.legend(loc='lower right',fontsize=8.5,frameon=False)
# (G) estimates
est=[('This analysis, combined',886,872,896,True),('  if SAR eye winds taken at face value',890,882,898,False),('  if scaled to match buoy gradient',878,866,890,False),
     ('JTWC best track (~17Z)',895,None,None,False),('D-PRINT (16:30–17:30Z)',903,902,904,False),('ATMS (SATCON plot, ~17Z)',903,None,None,False),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,False),('SATCON (~17Z)',910,None,None,False)]
n=len(est)
for i,(nm,v,lo_,hi_,main) in enumerate(est):
    y=n-1-i; col=BL[1] if (main or nm.startswith('  ')) else INK2
    if lo_ is not None: G.plot([lo_,hi_],[y,y],color=col,lw=7 if main else 4,alpha=0.35 if main else 0.5,solid_capstyle='round')
    G.plot(v,y,'o',ms=10 if main else 8,color=col,mec=SURF,mew=1.5)
    txt=('~%d (68%%: %d–%d)'%(v,lo_,hi_)) if (main or nm.startswith('  ')) else ('%g'%v if lo_ is None else '%g–%g'%(lo_,hi_))
    G.text(v if (main or nm.startswith('  ')) else v+1.2, y+0.28, txt, fontsize=8.5, ha='center' if (main or nm.startswith('  ')) else 'left')
G.axvline(909.4,color=RED,lw=1.5,ls='--'); G.text(910.2,n-1.3,'buoy reading\n909.4 hPa,\n~28 km from\ncenter',fontsize=8.5,va='top')
G.set_yticks(range(n)); G.set_yticklabels([e[0] for e in est][::-1],fontsize=9); G.set_xlim(850,925); G.set_ylim(-0.6,n-0.3); G.grid(axis='y',visible=False)
G.set_xlabel('central pressure (hPa)'); G.set_title('Central pressure near 17Z, Oct 20',loc='left',fontweight='bold')
fig.suptitle('Champi (29W): buoy pass refit with SAR, microwave and center-fix constraints',x=0.01,ha='left',fontsize=13.5,fontweight='bold')
fig.tight_layout(rect=(0,0,1,0.96)); fig.savefig('champi_center_pressure_v2.png',dpi=120)
