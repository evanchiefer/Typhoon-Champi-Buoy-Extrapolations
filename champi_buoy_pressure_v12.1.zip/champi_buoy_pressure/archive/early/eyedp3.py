import numpy as np, json
S=json.load(open('sar/sar_profiles.json')); rho=1.15; f=2*7.292e-5*np.sin(np.radians(16.7)); KT=0.5144
for name,d in S.items():
    r=np.array(d['r'])*1e3; v=np.array(d['v'])*KT/0.9; i=np.nanargmax(v); j=np.argmin(abs(r-87e3))
    dp=np.trapezoid(rho*(v[i:j+1]**2/r[i:j+1]+f*v[i:j+1]),r[i:j+1])/100
    print('%s: SAR-implied rise RMW(%.0f km)->87 km = %.1f hPa'%(name,r[i]/1e3,dp))
