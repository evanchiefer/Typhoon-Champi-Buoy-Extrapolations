import numpy as np, json
from scipy.optimize import least_squares
exec(open('fit2.py').read().split('win=(t>=6.5)')[0].replace('print(','(lambda *a,**k:None)('))
az=np.radians(152); par=np.array([6*np.sin(az),6*np.cos(az)])  # parallax: true center ~6 km toward 152 deg
SIG_OFF=12.0  # km, prior spread on (tilt + fix error) beyond parallax
mask=np.ones_like(t,bool)  # all 38 readings (track extrapolated outside 07-00Z)
def solve(Pc,Pn,rm_prior=None):
    def f(q):
        Rm,B,sx,sy=q; r,_,_=dist(t,lat,lon,(sx,sy))
        e=holland([Pc,Pn,Rm,B],r)-P
        pen=[(sx-par[0])/SIG_OFF*1.5,(sy-par[1])/SIG_OFF*1.5]   # 1.5 ~ obs sigma scale
        if rm_prior: pen.append((Rm-rm_prior[0])/rm_prior[1]*1.5)
        return np.r_[e,pen]
    best=None
    for Rm0 in (15,25,35,45):
        for B0 in (0.9,1.4,2.0):
            for s0 in ((0,0),(2,-20),(5,-10)):
                s=least_squares(f,[Rm0,B0,*s0],bounds=([3,0.6,-40,-40],[90,3,40,40]))
                if best is None or s.cost<best.cost: best=s
    Rm,B,sx,sy=best.x; r,_,_=dist(t,lat,lon,(sx,sy)); e=holland([Pc,Pn,Rm,B],r)-P
    return dict(cost=2*best.cost,rms=np.sqrt(np.mean(e**2)),Rm=Rm,B=B,sx=sx,sy=sy,rmin=r.min(),
                tmin=t[r.argmin()],P17=None)
grid=np.arange(850,909.01,3.0)
for Pn in (1008,1010):
    print('\nPn',Pn)
    for rmp,label in ((None,'no Rmax prior'),((32,8),'Rmax prior 32+-8 km (IR eye radius)')):
        rows=[(Pc,solve(Pc,Pn,rmp)) for Pc in grid]
        c=np.array([r['cost'] for _,r in rows]); c-=c.min()
        # convert to approx likelihood assuming sigma=1.5 hPa already folded in scale
        L=np.exp(-0.5*c/ (1.5**2)); L/=L.sum()
        cdf=np.cumsum(L); lo=grid[np.searchsorted(cdf,0.16)]; md=grid[np.searchsorted(cdf,0.5)]; hi=grid[np.searchsorted(cdf,0.84)]
        print('  %s: median Pc ~%d, ~68%% range %d-%d hPa'%(label,md,lo,hi))
        for Pc,r in rows[::3]:
            print('     Pc %d rms %.2f Rm %.0f B %.2f offset(%.0f E,%.0f N) rmin %.0f km'%(Pc,r['rms'],r['Rm'],r['B'],r['sx'],r['sy'],r['rmin']))
