import numpy as np, json
S=json.load(open('sar/sar_profiles.json'))
rho=1.15; f=2*7.292e-5*np.sin(np.radians(16.7)); KT=0.5144
for name,d in S.items():
    r=np.array(d['r'])*1e3; v=np.array(d['v'])*KT
    i=np.nanargmax(v); 
    for red,lab in ((1.0,'surface winds as-is'),(1/0.9,'surface/0.9 -> gradient level')):
        V=v[:i+1]*red; R=r[:i+1]
        # remove storm-motion contamination near center: subtract ~translation speed in quadrature-ish (cap at 0)
        Vc=np.sqrt(np.maximum(V**2-(7.0)**2,0))   # translation ~13-14 kt = 7 m/s
        for VV,l2 in ((V,'raw'),(Vc,'motion-removed')):
            dPdr=rho*(VV**2/R+f*VV); dp=np.trapezoid(dPdr,R)/100
            print('%-13s RMW %.0f km  %-30s %-15s eye dP (center->RMW) = %.1f hPa'%(name,r[i]/1e3,lab,l2,dp))
