import numpy as np, json
R=[json.loads(l) for l in open('bf_proof.jsonl')]
for sc,lab in (('E0','no eye-drop constraint'),('E1','SAR eye drop at face value (22+-5)'),('E2','SAR eye drop scaled (31+-7)')):
    d=sorted([r for r in R if r['sc']==sc],key=lambda r:r['Pc'])
    if not d: continue
    Pc=np.array([r['Pc'] for r in d]); c=np.array([r['cost'] for r in d]); c-=c.min()
    L=np.exp(-0.5*c/1.5**2); L/=L.sum(); cdf=np.cumsum(L); q=[Pc[np.searchsorted(cdf,x)] for x in (0.025,0.16,0.5,0.84,0.975)]
    imp=np.array([r['grid_best']-r['cost'] for r in d]); conv=np.array([r['n_at_best'] for r in d])
    print('%s (%s): n=%d | best %.0f | median %.0f | 68%% %.0f-%.0f | 95%% %.0f-%.0f'%(sc,lab,len(d),Pc[c.argmin()],q[2],q[1],q[3],q[0],q[4]))
    print('    multistart beat the 16 grid starts by median %.2f, max %.2f cost units; starts reaching best: median %d of %d'%(np.median(imp),imp.max(),np.median(conv),d[0]['n_starts']))
    # smoothness check: count local bumps in the profile
    bumps=int(((c[1:-1]>c[:-2]+0.3)&(c[1:-1]>c[2:]+0.3)).sum()); print('    profile bumps > 0.3 (sign of missed minima):',bumps)
    best=d[int(c.argmin())]; print('    at best: RMW %.0f km, eye drop %.0f hPa, Vmax %.0f kt, center offset (%+.1f,%+.1f), rms %.2f'%(best['rmw'],best['eye'],best['vmax'],*best['off'],best['rms']))
