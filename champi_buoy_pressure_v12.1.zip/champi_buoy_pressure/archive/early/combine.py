import numpy as np, re
def load(fn):
    P=[];C=[]
    for l in open(fn):
        m=re.match(r'\s+Pc (\d+) rms [\d.]+ dcost\s+([\d.]+)',l)
        if m: P.append(int(m.group(1))); C.append(float(m.group(2)))
    return np.array(P),np.array(C)
g=np.arange(838,906.1,0.5)
Ls=[]
for fn in ('o11_b.txt','o11_c.txt'):
    p,c=load(fn); L=np.exp(-0.5*np.interp(g,p,c)/1.5**2); Ls.append(L/L.sum())
for name,L in (('E1 face',Ls[0]),('E2 scaled',Ls[1]),('combined (equal weight)',(Ls[0]+Ls[1])/2)):
    cdf=np.cumsum(L); q=[g[np.searchsorted(cdf,x)] for x in (0.025,0.16,0.5,0.84,0.975)]
    print('%-24s median %.0f | 68%% %.0f-%.0f | 95%% %.0f-%.0f | mode %.0f'%(name,q[2],q[1],q[3],q[0],q[4],g[L.argmax()]))
