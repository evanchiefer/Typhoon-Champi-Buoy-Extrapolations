import openpyxl, numpy as np, json
wb=openpyxl.load_workbook('xl/champi.xlsx',data_only=True); ws=wb.worksheets[0]
rows=[r for r in ws.iter_rows(min_row=2,values_only=True) if r[0] is not None]
d=[l.split() for l in open('data.txt')]
print('buoy rows: sheet %d, data.txt %d'%(len(rows),len(d)))
diffs=0
for i,r in enumerate(rows):
    dt=r[0]; h=(dt.day-20)*24+dt.hour+dt.minute/60
    a=d[i]; ha=int(a[2].split(':')[0])+int(a[2].split(':')[1])/60
    dl=[r[4]-float(a[0]),r[5]-float(a[1]),r[6]-float(a[3]),h-ha]
    if any(abs(x)>1e-6 for x in dl): diffs+=1; print('  row %d %s: dlat %+.5f dlon %+.5f dP %+.1f dt %+.2f h'%(i+1,dt,*dl))
print('rows differing:',diffs)
bt=[((r[0].day-20)*24+r[0].hour+r[0].minute/60,r[1],r[2],r[3]) for r in rows if r[1] is not None]
print('track points:',bt)
json.dump(bt,open('bt.json','w'))
# compare with fitted surface center = my IR track + offset from brute-force best (E1/E2 ~ (+7.3,-12.0))
fx=json.load(open('fixes.json')); th=np.array(sorted(int(k) for k in fx))
la=np.array([fx[str(h)]['lat'] for h in th]); lo=np.array([fx[str(h)]['lon'] for h in th])
pla=np.polyfit(th,la,2); plo=np.polyfit(th,lo,2)
for h,bla,blo,v in bt:
    cla=np.polyval(pla,h); clo=np.polyval(plo,h); k=111*np.cos(np.radians(cla))
    sla=cla-12.0/111; slo=clo+7.3/k
    inrange = 7<=h<=24
    print('  %5.1fh track %.1fN %.1fE %3d kt | my IR eye %.2fN %.2fE | fitted sfc center %.2fN %.2fE | track minus fitted: dE %+5.1f dN %+5.1f km %s'%(
        h,bla,blo,v,cla,clo,sla,slo,(blo-slo)*k,(bla-sla)*111,'' if inrange else '(IR track extrapolated)'))
