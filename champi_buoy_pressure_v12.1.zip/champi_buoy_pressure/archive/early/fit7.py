import numpy as np, json
from scipy.optimize import least_squares
exec(open('fit2.py').read().split('win=(t>=6.5)')[0].replace('print(','(lambda *a,**k:None)('))
OFF=np.array([2.4,-8.8]); SOFF=6.0      # fix-consensus offset of center from my IR track (km E, km N)
rho=1.15; f=2*7.292e-5*np.sin(np.radians(17.3)); KT=1/0.5144
def prof(r,Pc,parts):            # parts: list of (dP,R,B); r km
    p=Pc+0*r
    for dP,R,B in parts: p=p+dP*np.exp(-(R/np.maximum(r,0.05))**B)
    return p
def vgrad(r,parts):              # gradient wind m/s
    rm=r*1e3; g=0*r
    for dP,R,B in parts: x=(R/r)**B; g=g+dP*100*B*x*np.exp(-x)    # r dP/dr in Pa
    return np.sqrt(g/rho+(f*rm/2)**2)-f*rm/2
rr=np.linspace(2,400,2000)
def run(Pc,Pn=1009.5,Rprior=None,Vprior=None,dual=False,soff=SOFF,off=OFF,Bfix=None):
    def unpack(q):
        if dual:
            fr,R1,B1,R2,B2,sx,sy=q; dP=Pn-Pc; return [(dP*fr,R1,B1),(dP*(1-fr),R2,B2)],sx,sy
        R1,B1,sx,sy=q; return [(Pn-Pc,R1,Bfix if Bfix else B1)],sx,sy
    def res(q):
        parts,sx,sy=unpack(q); r,_,_=dist(t,lat,lon,(sx,sy))
        e=prof(r,Pc,parts)-P; pen=[(sx-off[0])/soff*1.5,(sy-off[1])/soff*1.5]
        if Rprior: pen.append((parts[0][1]-Rprior[0])/Rprior[1]*1.5)
        if Vprior: pen.append((0.9*vgrad(rr,parts).max()*KT-Vprior[0])/Vprior[1]*1.5)
        return np.r_[e,pen]
    best=None
    if dual: starts=[[fr,R1,B1,R2,B2,*off] for fr in (0.4,0.6) for R1 in (30,38) for B1 in (1.5,2.5) for R2 in (90,150) for B2 in (1.0,)]
    else: starts=[[R1,B1,*s] for R1 in (20,30,40) for B1 in (0.9,1.5,2.2) for s in (off,(0,0))]
    lb=[0.05,10,0.8,50,0.5,-40,-40] if dual else [5,0.6,-40,-40]; ub=[0.95,70,4,400,3,40,40] if dual else [90,4,40,40]
    for s0 in starts:
        s=least_squares(res,s0,bounds=(lb,ub))
        if best is None or s.cost<best.cost: best=s
    parts,sx,sy=unpack(best.x); r,_,_=dist(t,lat,lon,(sx,sy)); e=prof(r,Pc,parts)-P
    v=0.9*vgrad(rr,parts); 
    return dict(cost=2*best.cost,rms=np.sqrt(np.mean(e**2)),parts=parts,sx=sx,sy=sy,rmin=r.min(),
                vmax=v.max()*KT,rvmax=rr[v.argmax()],r=r,e=e)
def scan(label,grid=np.arange(860,909.1,3),**kw):
    rows=[(Pc,run(Pc,**kw)) for Pc in grid]; c=np.array([x['cost'] for _,x in rows]); c-=c.min()
    L=np.exp(-0.5*c/1.5**2); L/=L.sum(); cdf=np.cumsum(L)
    q=[grid[min(np.searchsorted(cdf,p),len(grid)-1)] for p in (0.16,0.5,0.84)]
    print('\n== %s: best Pc %d, ~68%% %d-%d'%(label,grid[c.argmin()],q[0],q[2]))
    for Pc,x in rows:
        pp=' + '.join('dP%.0f R%.0f B%.2f'%p for p in x['parts'])
        print('  Pc %d rms %.2f dcost %5.1f | %s | off(%+.1f,%+.1f) rmin %.1f | 0.9Vg max %.0f kt @%.0f km'%(Pc,x['rms'],c[list(grid).index(Pc)],pp,x['sx'],x['sy'],x['rmin'],x['vmax'],x['rvmax']))
    return rows
if __name__=='__main__':
    scan('A single Holland, offset prior from fixes')
    scan('B single Holland, offset prior + RMW 35+-5 km',Rprior=(35,5))
    scan('C single Holland, offset prior + RMW 19+-4 km (if table RMW were km)',Rprior=(19,4))
