# Typhoon Champi (29W) — central pressure from a drifting-buoy eyewall pass

Estimate of Champi's minimum sea-level pressure at **17:33 UTC, 20 October 2026**. Drifting buoy 2802285 [B7] passed through the inner part of the
south-west eyewall. It read **909.4 hPa about 26 km from the centre at 17:04Z**, near the radius of maximum wind, and 913.3 hPa at 18:04Z.

## Result (version 11)

| | Central pressure (hPa) | 68% range | 95% range |
|---|---|---|---|
| **Combined estimate: three profile models, weighted by leave-one-out prediction** | **889** | 880–894 | 872–899 |
| Two-ring Holland profile (weight 0.71) | 890 | 882–894 | 874–899 |
| SAR eye shape, no secondary ring (weight 0.13) | 889 | 883–895 | 877–901 |
| SAR eye shape + secondary ring, the "ring model" (weight 0.16) | 881 | 873–890 | 866–897 |
| Ring model, buoy + satellite structure only (no wind input) | 869 | 861–883 | 853–894 |
| Check: SAR winds integrated inward from the buoy (no profile model) | 881 | 873–888 | 863–894 |
| No interpolation: 21:15Z structure only (ring model) | 878 | 870–888 | 864–894 |
| No interpolation: 09Z structure only (ring model) | 888 | 879–896 | 871–901 |
| No interpolation: both, weighted by fit (ring model) | 879 | 871–889 | 864–897 |
| Check: flat ±4 km centre error, v10 track (ring model) | 891 | 874–899 | 865–904 |
| Check: sub-hourly trochoidal wobble up to 3 km (ring model) | 881 | 874–890 | 867–897 |
| Check: v10 geometry (circular eyewall, ±2 km offset; ring model) | 886 | 875–895 | 865–901 |
| Check: JTWC best-track positions (ring model) | 884 | 872–892 | 860–896 |
| Check: no centre wander (ring model) | 880 | 872–887 | 867–893 |
| Check: power-law eye (ring model) | 882 | 874–889 | 867–893 |
| Check: Gaussian reading errors (ring model) | 878 | 873–887 | 867–894 |
| Check: Student-t rescaled to sd σ (ring model) | 879 | 871–889 | 867–895 |
| Check: log-ramp density profile (ring model) | 881 | 873–890 | 866–896 |
| Weighting: fit + parameter penalty (AIC) | 885 | 876–893 | 868–899 |
| Weighting: BIC | 889 | 881–894 | 873–900 |
| Weighting: equal | 887 | 878–894 | 869–900 |
| Weighting: stacking (leave-one-out) | 890 | 881–894 | 873–899 |
| Weighting check: leave-one-out on buoy readings + SAR structure (`sloo.py`) | 889 | 882–895 | 875–900 |
| Weighting check: Holland removed, ring / no-ring ratio kept | 886 | 876–893 | 868–900 |
| Previous version (v10) | 884 | 876–892 | 867–899 |
| JTWC working best track, interpolated to 17:33Z (operational value; final best track not yet released) [B5] | 895 | | |

- 1σ ±6.8 hPa. 5630 Monte Carlo trials (ring model 800, two-ring Holland 800, no-ring 400).
- **91% of the combined distribution lies below JTWC's 895 hPa**, which sits between the 68% and 95% upper limits.
- Uncertainty budget (1σ, hPa; single-source runs of each profile model, weighted over the three, plus the spread between them):
  - inner-eye wind shape 3.3
  - profile-shape choice (3 models) 3.1
  - radius of maximum wind (incl. tilt) 3.1
  - reading scatter 2.2
  - centre position (track + wander) 2.0
  - peak surface wind (incl. SAR calibration ±8%) 1.9
  - 10-m to gradient conversion 1.6
  - oval eyewall 0.6
  - eyewall wind decay 0.6
  - barometer calibration 0.6
  - environmental pressure 0.5
  - secondary wind maximum 0.5
  - air density 0.3
- Model weights (leave-one-out, pseudo-BMA+): ring model 0.16, no-ring 0.13, two-ring Holland 0.71. See "Model weighting" below.

**Reading the result.** The combined 889 is set mostly by the two-ring Holland profile, which predicts held-out buoy readings best.
Holland matches the SAR eye but not the wind decay outside the eyewall, which the buoy-only score cannot see. Scoring the SAR structure
measurements as well moves the weight to the no-ring SAR-eye model (0.80) and gives 889 (882–895),
so the headline does not depend on the Holland profile (see "Model weighting"). The check that uses no profile model at all (the measured SAR winds integrated inward from the 17:04Z and 18:04Z readings) gives
881, close to the ring model alone (881). Both routes are below 895. The difference between them (~8 hPa) is the
main open question: how the winds behave between the eyewall and the secondary maximum (25–47 km), where the buoy has only the 17:04Z,
18:04Z, 16:04Z and 19:04Z readings. With no profile model, reaching 895 needs at least two adverse assumptions at once: the weaker 09Z
structure and ignoring surface friction (bounds table below).

## What changed in version 11

Reproduced first: the v10 setup run in the v11 code gives a best fit of 883.9 hPa (v10: 884).
Single best fits (ring model, peak-wind constraint, Student-t errors) as each change is added (`ladder.json`):

| Configuration | Best-fit Pc | χ² | Residual 17:04Z / 18:04Z (hPa) |
|---|---|---|---|
| v10-like geometry: hourly-fix track, offset +-2 km, circular eyewall, position sd 1.5 km | 883.9 | 31.4 | -1.5 / -9.1 |
| + track from fixes with wander (gp), circular eyewall, position sd 1.5 km | 881.5 | 20.9 | -1.5 / -8.1 |
| + elliptical eyewall (position sd 1.5 km) | 881.8 | 18.0 | -0.0 / -6.0 |
| v11 primary: + position sd 1.0 km (non-circularity left after the ellipse) | 878.9 | 21.7 | +0.7 / -4.7 |
| v11, power-law eye instead of SAR eye table | 878.9 | 21.7 | +0.7 / -4.7 |
| v11, no secondary ring (SAR eye table) | 889.3 | 29.2 | -0.3 / -6.6 |
| v11, two-ring Holland | 884.5 | 30.8 | +1.9 / -3.1 |
| v11, no wander (track fixed at its mean) | 879.2 | 22.6 | +0.4 / -6.0 |
| v11, hourly-fix track with offset +-4 km (reviewer check), elliptical | 897.9 | 33.0 | +1.8 / -2.9 |
| v11, JTWC best-track positions | 884.4 | 31.8 | -1.5 / -0.1 |
| v11, no peak-wind constraint (buoy + structure only) | 869.4 | 18.2 | +1.7 / -1.9 |
| v11, 21:15Z structure only (no interpolation) | 876.6 | 20.8 | +0.8 / -4.7 |
| v11, 09Z structure only (no interpolation) | 884.1 | 25.0 | +0.3 / -4.6 |
| v11, Gaussian reading errors | 876.7 | 20.2 | +1.4 / -3.2 |
| v11, Student-t rescaled to sd sigma | 876.4 | 33.4 | +0.9 / -3.6 |
| v11, nu = 2.5 | 881.2 | 22.2 | -0.0 / -6.3 |
| v11, nu = 8 | 877.5 | 21.0 | +1.1 / -3.7 |

1. **Centre track from the fixes, with wander** (`track_gp.py`; Gaussian process with Matérn covariance [A24], hyperparameters by restricted
   maximum likelihood [A24b]; eye wobble and trochoidal motion: Muramatsu 1986 [A11], Nolan et al. 2001 [A12]).
   - The surface centre is a smooth track plus a time-correlated wander. Its timescale, amplitude and the IR fix scatter are estimated from the
     18 hourly Himawari IR eye fixes; the four surface fixes (SAR ring centres 09:09Z, 09:20Z, 21:15Z; ATMS 17:01Z) fix the IR-to-surface offset
     on the same track: (+7.04 E, -8.81 N) km ± 0.94.
   - The fixes are smooth: hour-to-hour fix scatter 0.57 km. The three SAR centres sit within about 0.3 km of the track plus offset.
     A slow change of the offset (vortex tilt) of 1 km is allowed; the fixes bound it only loosely (0 to ~3 km).
   - Result: the surface centre at 17:04Z is known to ±1.0 km, and the change from 17:04Z to 18:04Z to ±0.7 km.
     The fit may move the centre at each reading within that covariance.
   - **This does not support the reviewer's ±4 km.** The STAR centres sit 3–4.5 km south-west of the ring-fit centres on both days, but that is
     a different centre definition; the ring-fit centres from two sensors 11 minutes apart agree to 0.5 km after storm motion. The flat ±4 km
     version is reported as a check.
   - Evan's sub-hourly trochoidal wobble is a check: wobble up to 3 km with periods of 0.5–2 h, vanishing at the hourly fixes.
2. **Oval eyewall** (elliptical eyewalls: Kuo et al. 1999 [A13]). Three SAR passes (Sentinel-1D 09:09Z, RCM-3 21:15Z, RCM-3 21 Oct 09:29Z) show the eyewall stretched along a north–south
   axis by 1.0–1.2 km (RCM-3 09:20Z, at ~50° incidence, does not). The profile is evaluated at an effective distance
   r / (1 + e cos 2(θ − θ₀)); prior e = 0.042 ± 0.015, θ₀ = 187° ± 20°. The 18:04Z reading lay on the long side, effectively ~1 km closer to
   the eyewall. This removes about a third of its misfit.
3. **Position term 1.5 → 1.0 km**: the eyewall irregularity left after the oval (SAR sector-RMW residual sd 0.8–1.0 km).
4. **09Z structure.** The ring fit is now converged from 9 first guesses; all 9 agree for RCM-3 09:20Z on RMW 27.25 km and
   eye integral 0.317 (v10 had 27.75 / 0.337, a minority convergence; the audit's value is reproduced). Over the guesses:
   RMW 27.25–27.75 km, eye integral 0.317–0.337. The 09Z endpoint uses the Sentinel-1D 09:09Z shape (weight 0.75) and
   RCM-3 09:20Z (0.25) at the RCM-3 wind level. Interpolated to 17:33Z: surface RMW 26.44 km, eye integral 0.367.
5. **SAR-measured eye shape** used directly (table of v/Vmax inside the RMW, 47-kt cut, raised to a power s ~ N(1, 0.08)). It fits exactly as
   well as the power-law eye and gives the same best fit; the power law is kept as a check.
6. **Model weighting.** Weights now come from fits with the same likelihood as the Monte Carlo (v10 used the unconstrained scan, where the ring
   model's best fit sat at 860 hPa / 196 kt). See below.
7. **Fixes and checks**:
   - `sar/extract_all.py` runs (v10's `sar_extract.py` wrote to an undefined `S`) and includes Sentinel-1D 09:09Z; file names, acquisition
     times and sha256 are recorded in `sar/sar_files.json`. `sar/crosscal09.py` regenerates the 09Z cross-calibration.
   - `sar/structure.py`: no crash on 3-km grids; a sector's secondary maximum is no longer taken as its RMW (the 43.75 km SW sector at 09:20Z).
   - Pass times: the file-name times are the scene centres (09:09:03–09:10:07 → 09:09:35, etc.), so no change.
   - Gap check: the SAR profile is now placed at the surface RMW (v10 mixed the gradient-level RMW with surface shapes). The outer pairs move from
     0.82–0.84 to 0.89–0.91.
   - Dropsonde check (Franklin, Black & Valde 2000 [A6b]; 2003 [A6]): α at the RMW 0.885 (dropsondes 0.88 at the RMW, 0.91 eyewall); 2 RMW 0.77,
     3 RMW 0.74 (outer vortex 0.78, relative to 700 hPa). Consistent; α is not recalibrated.
   - Search floor 830 → 800 hPa: 0 trials reach it.
   - Convergence: 150 ring-model trials refitted with 10 starts instead of 4: 5 found a slightly better fit that moves Pc by more than
     1 hPa (largest 9.9). Substituting them changes the ring model's percentiles by at most 0.1 hPa.
   - The +8 kt (azimuthal mean → 1-min peak) is a range of 4–20 kt (centre 10). It is used only to quote 1-minute winds, not in the pressure.
   - Student-t scale (Student-t errors: Lange et al. 1989 [A20]): the reading σ is used as the t scale (t sd = 1.41σ). Rescaled to sd σ: see the table. ν = 2.5 and 8 in `ladder.json`.
   - SAR calibration ±8% (was ±6%; C-band cross-pol calibration at extreme winds: Mouche et al. 2019 [A14], Combot et al. 2020 [A15]). A wind-speed-dependent calibration is not applied: anchored at the RCM-3 eyewall level (which the buoy
     favours), it would raise the outer winds relative to the peak by ~8–10%, the opposite of what the buoy's outer pressure rises show.

## Response to the external review of v10 (REVIEW_V10.md §5)

| # | Item | v11 |
|---|---|---|
| 1 | Centre sd ±2 → ≥4 km; time-correlated wobble | Track model from the fixes with wander (centre ±1.0 km at 17:04Z, data-derived). ±4 km not adopted; reported as a check: 891 (874–899). Trochoidal wobble check: 881. |
| 2 | Weights from constrained fits with a parameter penalty | Done. Headline: leave-one-out (pseudo-BMA+); AIC 885, BIC 889, equal 887 reported. |
| 3 | 18:04Z: keep; residual/weight table; ν; t scale | Kept. Table below. ν = 2.5 / 8 and the rescaled t in the ladder; rescaled-t Monte Carlo 879. |
| 4 | No-interpolation envelope | 21:15Z only 878, 09Z only 888, fit-weighted 879 (ring model; compare its interpolated 881). |
| 5 | Speed-dependent SAR calibration | Regenerated (`sar/crosscal09.py`); not applied, for the reason above. Calibration spread ±8%. |
| 6 | Reproducibility | `extract_all.py` fixed, 09:09Z generator, sha256 manifest, 3-km crash fixed. |
| 7 | RCM-3 09:20Z | Weight 0.25 in the 09Z endpoint; centre-convergence spread reported; SW-sector RMW pick fixed. |
| 8 | Wavenumber-2 eyewall | Done (oval eyewall; prior from three SAR passes). |
| 9 | +8 kt as a range | 4–20 kt (reporting only). |
| 10 | Tabulated SAR eye | Used in the ring and no-ring models; power law as a check (882). |
| 11 | Franklin ratio check | Consistent (see 7 above). |
| 12 | Multistart convergence; floor | 5 of 150 trials move > 1 hPa with 10 starts; floor 800 hPa. |
| 13 | Never drop 18:04Z | Kept everywhere; leave-one-out is a diagnostic and a weighting score only. |

## Model weighting

Best fits with Pc free (`weights.json`):

Profiles: ring and no-ring models use the SAR eye table with a Willoughby-type decay [A2]; two-ring Holland [A1]. Weights: AIC/BIC [A22], leave-one-out pseudo-BMA+ and stacking [A21].

| Model | Best-fit Pc | χ² | Parameters |
|---|---|---|---|
| Ring model (SAR eye + secondary ring) | 878.9 | 21.69 | 39 |
| SAR eye, no secondary ring | 889.3 | 29.21 | 36 |
| Two-ring Holland | 889.4 | 30.75 | 36 |

| Weighting | Ring / no ring / Holland | Combined median (68%) |
|---|---|---|
| **Leave-one-out, pseudo-BMA+ (headline)** | 0.16 / 0.13 / 0.71 | 889 (880–894) |
| Leave-one-out, stacking | 0.05 / 0.00 / 0.95 | 890 (881–894) |
| Leave-one-out, plain | 0.05 / 0.09 / 0.86 | 890 (882–894) |
| AIC | 0.59 / 0.28 / 0.13 | 885 (876–893) |
| BIC | 0.11 / 0.61 / 0.28 | 889 (881–894) |
| Equal | 0.33 / 0.33 / 0.33 | 887 (878–894) |
| Fit only (χ², no penalty) | 0.97 / 0.02 / 0.01 | 882 (873–890) |

- The ring model fits best in sample (lowest χ²), but predicts held-out readings worst. Leave-one-out z of each removed reading:

| Removed reading | Ring model | No ring | Two-ring Holland |
|---|---|---|---|
| 15:00Z | -1.54 (Pc 879.0) | +0.08 (Pc 889.4) | -0.23 (Pc 889.4) |
| 16:04Z | +0.82 (Pc 880.0) | +0.13 (Pc 889.3) | -0.55 (Pc 889.7) |
| 17:04Z | +1.16 (Pc 875.6) | -0.51 (Pc 890.6) | +0.99 (Pc 888.2) |
| 18:04Z | -4.76 (Pc 887.0) | -5.35 (Pc 891.6) | -4.32 (Pc 890.0) |
| 19:04Z | +3.09 (Pc 879.3) | +2.55 (Pc 886.4) | +1.33 (Pc 888.8) |
| 20:04Z | +2.37 (Pc 878.1) | +3.94 (Pc 887.8) | +3.48 (Pc 887.3) |

- The ring model's lower pressure leans on 18:04Z: without it, 878.9 → 887.0. The no-ring model moves
  +2.3 and the Holland model +0.5.
- Pseudo-BMA+ (Yao et al. 2018 [A21]; Bayesian bootstrap, Rubin 1981 [A23]) regularises the leave-one-out weights with a Bayesian bootstrap over the six held-out readings. It is used for
  the headline because it scores what matters (predicting buoy readings near the core) without a hand-chosen parameter penalty.
- Its weakness: it scores the buoy readings only. Holland's best fit matches the SAR eye (eye-integral term +0.29σ) but not the wind decay
  outside the eyewall (wind ratio at 1.4 RMW +2.00σ, at 2 RMW -2.69σ), and its lead rests mostly on one reading: without
  19:04Z in the score, the weights are ring 0.31 / no ring 0.26 / Holland 0.43.
- Check (`sloo.py`): each SAR structure measurement the three models share (RMW, wind ratio at 1.4 and 2 RMW, peak wind) is removed in turn, the
  model refitted, and the removed value scored, as for the buoy readings. The eye integral is not scored: with no buoy reading inside 23 km,
  the eye shape is unconstrained once its own measurement is removed. z of each removed measurement (Pc after refit):

| Removed measurement | Ring model | No ring | Two-ring Holland |
|---|---|---|---|
| Radius of maximum wind | -2.36 (872.6) | +1.86 (894.4) | +3.45 (897.7) |
| Wind ratio at 1.4 RMW | +3.38 (883.4) | +1.75 (889.6) | +2.00 (889.0) |
| Peak wind | +2.76 (869.4) | +0.71 (887.2) | +0.70 (886.8) |
| Wind ratio at 2 RMW | -3.49 (887.8) | -3.42 (887.6) | -3.96 (886.0) |

| Score | Ring / no ring / Holland (pseudo-BMA+) | Combined median (68%, 95%) |
|---|---|---|
| Buoy readings (headline) | 0.16 / 0.13 / 0.71 | 888.9 (880.3–893.9, 871.5–899.3) |
| SAR structure only | 0.00 / 0.98 / 0.02 | 889.3 (882.8–895.0, 876.2–900.8) |
| Buoy + SAR structure | 0.02 / 0.80 / 0.18 | 889.3 (882.4–894.8, 875.5–900.5) |
| Buoy + SAR structure, peak wind not scored | 0.07 / 0.77 / 0.16 | 888.9 (882.0–894.7, 873.3–900.5) |
| Buoy, Holland removed | 0.54 / 0.46 / 0.00 | 885.5 (876.2–893.1, 868.1–899.9) |

- The ring model fits the buoy best in sample but is the one whose fit strains against the SAR measurements: freed of the peak-wind
  measurement it moves to 869 hPa with a peak wind 2.8σ above the measured value (SAR and intensity consensus). The no-ring and Holland models stay near
  887. The headline is left on the buoy score; the buoy + SAR score gives the same median and a slightly narrower range.
  The plug-in scores are cruder for the SAR measurements than for the readings, since a removed measurement can be partly absorbed by
  parameters the buoy pins only loosely.

## The 18:04Z reading

Residuals with the models held at the combined median (888.9 hPa):

| Reading | P (hPa) | Ring model: obs − model | σ | z | Student-t weight | Two-ring Holland: obs − model |
|---|---|---|---|---|---|---|
| 15:00Z | 969.5 | -0.5 | 0.6 | -0.72 | 1.11 | -0.1 |
| 16:04Z | 949.7 | +0.6 | 1.5 | +0.40 | 1.20 | -0.4 |
| 17:04Z | 909.4 | -1.2 | 3.0 | -0.38 | 1.21 | +1.1 |
| 18:04Z | 913.3 | -8.1 | 2.1 | -3.81 | 0.27 | -4.1 |
| 19:04Z | 949.9 | +0.9 | 1.4 | +0.61 | 1.14 | +0.8 |
| 20:04Z | 965.6 | +0.6 | 0.7 | +0.97 | 1.01 | +1.4 |

- Kept in every run. The buoy position is not the issue: the track model fixes the centre to ±1 km, and the buoy GPS is precise.
- The oval eyewall explains about 1 km of effective distance. The rest is not explained by any geometry the data allow. The barometer tests
  (17:04Z and 18:04Z both raised 2 / 4 hPa) give 881.0 / 883.3 hPa (ring model).

## How far the data can be pushed (17:04Z reading + measured SAR winds, no profile model; `bounds.py`)

17:04Z reading at 25.9 km effective distance.

| Assumptions, increasingly adverse | Drop inside the buoy | Central pressure at most |
|---|---|---|
| 21:15Z structure, log-layer conversion | 28.6 hPa | 880.8 |
| 09Z structure (wider, weaker eyewall) | 17.5 hPa | 891.9 |
| ...and surface winds treated as gradient winds (friction ignored) | 13.7 hPa | 895.7 |
| ...and centre 2 km closer to the buoy | 10.3 hPa | 899.1 |
| ...and the Sentinel-1D wind level (0.83), eyewall 10% wider | 5.3 hPa | 904.1 |

## Buoy vs SAR pressure rise (`gapcheck.py`)

Measured rise ÷ rise predicted from the 17:33Z SAR winds.

| Pair | Radii (km) | Flat factor 0.85 | Log-layer α(r) |
|---|---|---|---|
| 17:04 -> 16:04 | 26 → 47 | 1.22 | 1.17 |
| 18:04 -> 19:04 | 30 → 47 | 1.61 | 1.48 |
| 17:04 -> 15:00 | 26 → 75 | 1.19 | 1.07 |
| 18:04 -> 20:04 | 30 → 69 | 1.41 | 1.23 |
| 16:04 -> 15:00 | 47 → 75 | 1.13 | 0.91 |
| 19:04 -> 20:04 | 47 → 69 | 1.10 | 0.89 |

## SAR passes (NOAA/STAR level-2, 500 m [B1]; retrieval [A26], cross-pol GMFs [A14, A27]; `sar/`)

| Pass | RMW (km) | Az.-mean max (kt) | Eye integral I47 | v(1.4 RMW)/max | Secondary max | Incidence at eyewall | Ring-fit guesses agreeing |
|---|---|---|---|---|---|---|---|
| Sentinel-1D 20 Oct 09:09Z | 28.25 | 112 | 0.363 | 0.78 | 43.2 km, 0.83 | 28–32° | 5/9 |
| RCM-3 20 Oct 09:20Z | 27.25 | 135 | 0.317 | 0.72 | 45.8 km, 0.81 | 48–52° | 9/9 |
| RCM-3 20 Oct 21:15Z | 25.75 | 146 | 0.375 | 0.72 | 43.2 km, 0.77 | 27–33° | 9/9 |
| RCM-3 21 Oct 09:29Z | 27.25 | 134 | 0.391 | 0.83 | none | 28–33° | 8/9 |
| RCM-3 21 Oct 21:23Z | 30.25 | 99 | 0.507 | 0.90 | none | — | 4/9 |
| Sentinel-1D 20 Oct 21:20Z | swath edge 46 km west of the centre | | | | | | |

**Cross-sensor calibration** (Sentinel-1D / RCM-3, each about its own centre):
- 09Z pair: eyewall 0.83 (azimuthal-mean peak), 0.80 (sector peak).
- By RCM-3 speed: 0.94 at 60 kt, 0.87 at 100 kt, 0.80 at 140 kt (-0.0173 per 10 kt).
- 21Z, outer storm only: 0.877 ± 0.022.
- The buoy favours the RCM-3 level: an S1D-level eyewall cannot produce 909.4 hPa at the measured distance. S1D is used for shape only.

## Running

`model/` holds every script with its inputs and results side by side; all paths are relative to the script folder.
- Reproduce the numbers and figures from the saved results (~3 min): `cd model && python3 analyze.py && python3 cfits.py && python3 fig1.py && python3 fig2.py && python3 make_readme.py`
- Full rerun: `./run_all.sh` (~3 h on 2 cores; the Monte Carlo resumes after an interruption). Replaying saved trials by seed reproduces them exactly.
  `gen_gradref.py` is a fixed-point step: rerunning it moves the reference gradients by < 0.01 hPa/km.
- SAR preprocessing needs the STAR level-2 files (names and sha256 in `model/sar/sar_files.json`): `python3 model/sar/extract_all.py /path/to/files`.

Directories: `model/` (scripts, inputs, results, `sar/`), `figures/`, `data_source/` (spreadsheet and the script that builds `model/inputs.json`),
`archive/` (v3–v10).

## Version history

1. Single Holland fit, IR centre only: unconstrained (~850–905).
2. Two-ring Holland plus SAR/ARCHER/MW constraints: 887 (875–901).
3. Multistart search plus JTWC-track check: 885 (872–896).
4. Tide background and two model families: 877 (864–890); superseded.
5. Synthetic smear correction, three-feature model: 889 (875–900).
6. Radially varying air density, ρ = p/(R_d·T_v), proposed by Evan: 892 (879–902).
7. RCM-3 21:15Z level-2 SAR: 880 (872–889).
8. Level-2 SAR at 09:20Z, time interpolation, Sentinel-1D cross-calibration, leave-one-out: 878 (870–887).
9. Log-layer 10-m to gradient conversion α(r), proposed by Evan; 6600-trial Monte Carlo: 879 (871–887).
10. Robust (Student-t) reading errors; gradient-level RMW; 7100 trials: 884 (876–892).
11. **Current:** centre track model with wander and oval eyewall from SAR; Sentinel-1D 09:09Z shape; SAR eye table; model weights from
    leave-one-out prediction; external-review fixes: **889 (880–894)**.

## References and data sources

Citations were checked against publisher, Crossref or agency pages on 25 Oct 2026. Items marked † were matched to standard bibliographic
records but not re-opened. Items marked ‡ could not be confirmed (see notes).

### A. Literature
- [A1] Holland, G. J., 1980: An analytic model of the wind and pressure profiles in hurricanes. *Mon. Wea. Rev.*, 108, 1212–1218. https://doi.org/10.1175/1520-0493(1980)108<1212:AAMOTW>2.0.CO;2 (two-ring Holland profile)
- [A2] Willoughby, H. E., R. W. R. Darling, and M. E. Rahn, 2006: Parametric representation of the primary hurricane vortex. Part II: A new family of sectionally continuous profiles. *Mon. Wea. Rev.*, 134, 1102–1120. https://doi.org/10.1175/MWR3106.1 (power-law eye, dual-exponential decay)
- [A3] Atkinson, G. D., and C. R. Holliday, 1977: Tropical cyclone minimum sea level pressure/maximum sustained wind relationship for the western North Pacific. *Mon. Wea. Rev.*, 105(4), 421–427. https://doi.org/10.1175/1520-0493(1977)105<0421:TCMSLP>2.0.CO;2 (context curve in Fig. 2b)
- [A4] Knaff, J. A., and R. M. Zehr, 2007: Reexamination of tropical cyclone wind–pressure relationships. *Wea. Forecasting*, 22, 71–88. https://doi.org/10.1175/WAF965.1 (context)
- [A5] Courtney, J., and J. A. Knaff, 2009: Adapting the Knaff and Zehr wind–pressure relationship for operational use in Tropical Cyclone Warning Centres. *Aust. Meteor. Oceanogr. J.*, 58(3), 167–179. https://doi.org/10.22499/2.5803.002 (context)
- [A6] Franklin, J. L., M. L. Black, and K. Valde, 2003: GPS dropwindsonde wind profiles in hurricanes and their operational implications. *Wea. Forecasting*, 18, 32–44. https://doi.org/10.1175/1520-0434(2003)018<0032:GDWPIH>2.0.CO;2
- [A6b] Franklin, J. L., M. L. Black, and K. Valde, 2000: *Eyewall Wind Profiles in Hurricanes Determined By GPS Dropwindsondes*. NOAA/NHC web report. https://www.nhc.noaa.gov/aboutwindprofile.shtml (surface/700-hPa ratios 0.78 outer vortex, 0.91 eyewall, 0.88 at the RMW)
- [A7] Powell, M. D., P. J. Vickery, and T. A. Reinhold, 2003: Reduced drag coefficient for high wind speeds in tropical cyclones. *Nature*, 422, 279–283. https://doi.org/10.1038/nature01481 (roughness range in the log-layer factor)
- [A8] Powell, M. D., E. W. Uhlhorn, and J. D. Kepert, 2009: Estimating maximum surface winds from hurricane reconnaissance measurements. *Wea. Forecasting*, 24(3), 868–883. https://doi.org/10.1175/2008WAF2007087.1 (RMW tilt)
- [A9] Stern, D. P., and D. S. Nolan, 2009: Reexamining the vertical structure of tangential winds in tropical cyclones: Observations and theory. *J. Atmos. Sci.*, 66(12), 3579–3600. https://doi.org/10.1175/2009JAS2916.1 (RMW tilt)
- [A10] Kepert, J., 2001: The dynamics of boundary layer jets within the tropical cyclone core. Part I: Linear theory. *J. Atmos. Sci.*, 58(17), 2469–2484. https://doi.org/10.1175/1520-0469(2001)058<2469:TDOBLJ>2.0.CO;2 ; Kepert, J., and Y. Wang, 2001: Part II: Nonlinear enhancement. *J. Atmos. Sci.*, 58(17), 2485–2501. https://doi.org/10.1175/1520-0469(2001)058<2485:TDOBLJ>2.0.CO;2 (supergradient boundary-layer wind in the log-layer factor)
- [A11] Muramatsu, T., 1986: Trochoidal motion of the eye of Typhoon 8019. *J. Meteor. Soc. Japan*, 64, 259–272. https://doi.org/10.2151/jmsj1965.64.2_259
- [A12] Nolan, D. S., M. T. Montgomery, and L. D. Grasso, 2001: The wavenumber-one instability and trochoidal motion of hurricane-like vortices. *J. Atmos. Sci.*, 58(21), 3243–3270. https://doi.org/10.1175/1520-0469(2001)058<3243:TWOIAT>2.0.CO;2
- [A13] Kuo, H.-C., R. T. Williams, and J.-H. Chen, 1999: A possible mechanism for the eye rotation of Typhoon Herb. *J. Atmos. Sci.*, 56(11), 1659–1673. https://doi.org/10.1175/1520-0469(1999)056<1659:APMFTE>2.0.CO;2
- [A14] Mouche, A., B. Chapron, J. Knaff, Y. Zhao, B. Zhang, and C. Combot, 2019: Copolarized and cross-polarized SAR measurements for high-resolution description of major hurricane wind structures: Application to Irma category 5 hurricane. *J. Geophys. Res. Oceans*, 124, 3905–3922. https://doi.org/10.1029/2019JC015056
- [A15] Combot, C., A. Mouche, J. Knaff, Y. Zhao, Y. Zhao, L. Vinour, Y. Quilfen, and B. Chapron, 2020: Extensive high-resolution synthetic aperture radar (SAR) data analysis of tropical cyclones: Comparisons with SFMR flights and best track. *Mon. Wea. Rev.*, 148(11), 4545–4563. https://doi.org/10.1175/MWR-D-20-0005.1
- [A16] Velden, C. S., and D. Herndon, 2020: A consensus approach for estimating tropical cyclone intensity from meteorological satellites: SATCON. *Wea. Forecasting*, 35(4), 1645–1662. https://doi.org/10.1175/WAF-D-20-0015.1
- [A17] Olander, T. L., and C. S. Velden, 2019: The Advanced Dvorak Technique (ADT) for estimating tropical cyclone intensity: Update and new capabilities. *Wea. Forecasting*, 34(4), 905–922. https://doi.org/10.1175/WAF-D-19-0007.1
- [A18] Wimmers, A. J., and C. S. Velden, 2016: Advancements in objective multisatellite tropical cyclone center fixing. *J. Appl. Meteor. Climatol.*, 55(1), 197–212. https://doi.org/10.1175/JAMC-D-15-0098.1 (ARCHER)
- [A19] Griffin, S. M., A. Wimmers, and C. S. Velden, 2024: Predicting short-term intensity change in tropical cyclones using a convolutional neural network. *Wea. Forecasting*, 39(1), 177–202. https://doi.org/10.1175/WAF-D-23-0085.1 (D-MINT and D-PRINT; the products have also been called DeepMicroIRNet, DeepMultiNet and OPEN-AIIR)
- [A19b] Olander, T., A. Wimmers, C. Velden, and J. P. Kossin, 2021: Investigation of machine learning using satellite-based advanced Dvorak technique analysis parameters to estimate tropical cyclone intensity. *Wea. Forecasting*, 36(6), 2161–2186. https://doi.org/10.1175/WAF-D-20-0234.1 (AiDT)
- [A20] Lange, K. L., R. J. A. Little, and J. M. G. Taylor, 1989: Robust statistical modeling using the t distribution. *J. Amer. Stat. Assoc.*, 84(408), 881–896. https://doi.org/10.1080/01621459.1989.10478852 †
- [A21] Yao, Y., A. Vehtari, D. Simpson, and A. Gelman, 2018: Using stacking to average Bayesian predictive distributions (with discussion). *Bayesian Analysis*, 13(3), 917–1007. https://doi.org/10.1214/17-BA1091 † (pseudo-BMA+ and stacking weights)
- [A22] Akaike, H., 1974: A new look at the statistical model identification. *IEEE Trans. Autom. Control*, 19(6), 716–723. https://doi.org/10.1109/TAC.1974.1100705 † ; Schwarz, G., 1978: Estimating the dimension of a model. *Ann. Statist.*, 6(2), 461–464. https://doi.org/10.1214/aos/1176344136 † (AIC, BIC)
- [A23] Rubin, D. B., 1981: The Bayesian bootstrap. *Ann. Statist.*, 9(1), 130–134. https://doi.org/10.1214/aos/1176345338 †
- [A24] Rasmussen, C. E., and C. K. I. Williams, 2006: *Gaussian Processes for Machine Learning*. MIT Press. http://www.gaussianprocess.org/gpml/ † (Matérn covariance)
- [A24b] Patterson, H. D., and R. Thompson, 1971: Recovery of inter-block information when block sizes are unequal. *Biometrika*, 58(3), 545–554. https://doi.org/10.1093/biomet/58.3.545 † (restricted maximum likelihood)
- [A25] Alet, F., et al., 2026: Operational tropical cyclone forecasting with AI. *Nature*, 657, 680–688. https://doi.org/10.1038/s41586-026-10953-2 (WeatherNext-Cyclones; its GenCast baseline converts pressure to wind with v_max = 6.70·max(0, 1010 − p_min)^0.644, constants refitted to ERA5 and IBTrACS in the Atkinson–Holliday form; discussed, not used in the fit)
- [A26] Monaldo, F. M., 2005: *ANSWRS: APL/NOAA SAR Wind Retrieval System Software Documentation*. JHU/APL Report SRO-05-13. Listed at https://www.star.nesdis.noaa.gov/socd/mecb/sar/publications.php ; Monaldo, F., C. Jackson, W. Pichel, and X. Li, 2015: Early validation of operational SAR wind retrievals from Sentinel-1A. *IGARSS 2015*, 1223–1226. https://doi.org/10.1109/IGARSS.2015.7325993 ; Monaldo, F., C. Jackson, and W. Pichel, 2013: Seasat to RADARSAT-2: Research to operations. *Oceanography*, 26(2). https://doi.org/10.5670/oceanog.2013.29
- [A27] NOAA/NESDIS/STAR: *Tropical SAR Winds Technical Document* (cross-polarisation GMFs for Sentinel-1, RADARSAT-2 and RCM, July 2023). https://www.star.nesdis.noaa.gov/socd/mecb/sar/tropical_gmf_tech_doc.php ‡ The GMF labels in the file metadata ("S1A_V2", "RCM_V1") are not documented publicly; STAR documents its cross-pol GMFs as C-10 (Sentinel-1) and C-12 (RCM), matching the "C-10"/"C-12" in the file names.

### B. Data and products
- [B1] NOAA/NESDIS/STAR SAR tropical-cyclone winds, Champi (WP292026): level-2 500-m NetCDF and 3-km "MERGED_FIX" files for the six passes in `sar/sar_files.json` (names, acquisition times, sha256). https://www.star.nesdis.noaa.gov/socd/mecb/sar/sarwinds_tropical.php . Credit: "Synthetic Aperture Radar (SAR) based tropical wind products were generated and provided through the STAR Water Surface Conditions Science Team's tropical cyclone winds program." STAR products are for experimental use. RADARSAT Constellation Mission imagery © Government of Canada 2026; RADARSAT is an official mark of the Canadian Space Agency. Contains modified Copernicus Sentinel data (2026).
- [B2] NOAA/NCEP Global Forecast System 0.25° (wind directions used by ANSWRS; file metadata "gfs025"). https://nomads.ncep.noaa.gov/ † The cross-polarisation retrievals used here are close to direction-independent.
- [B3] Japan Meteorological Agency, Himawari-9 infrared imagery (hourly eye fixes, `ir_eye_fixes.json`). https://www.data.jma.go.jp/mscweb/en/himawari89/ † ; imagery viewer RAMMB/CIRA SLIDER https://rammb-slider.cira.colostate.edu/ †
- [B4] ATMS 165/183-GHz imagery (NOAA/NASA JPSS), eye fix at 17:01Z. https://www.nesdis.noaa.gov/our-satellites/currently-flying/joint-polar-satellite-system † (the satellite and the imagery page used are not recorded here)
- [B5] Joint Typhoon Warning Center, WP29 2026 (ATCF working best track; positions and 895 hPa). https://www.metoc.navy.mil/jtwc/jtwc.html ‡ JTWC releases final best tracks after the season, so 895 hPa is provisional. RSMC Tokyo (JMA) lists 900 hPa (not checked here).
- [B6] CIMSS Tropical Cyclones, University of Wisconsin–Madison SSEC (ADT, AiDT, SATCON, D-MINT, D-PRINT, ARCHER values in Fig. 2). https://tropic.ssec.wisc.edu/
- [B7] Drifting buoy WMO 2802285, hourly sea-level pressure and position (spreadsheet `data_source/champi_revised.xlsx`, supplied by Evan; NOAA source page shared by Evan). ‡ The originating platform record was not found in public GDP/OSMC/NDBC listings from here. Drifting-buoy data of this kind are distributed via the GTS (WMO buoy identifiers: https://community.wmo.int/en/buoy-wmo-identification-numbers), the NOAA Global Drifter Program (https://www.aoml.noaa.gov/phod/gdp/) and NOAA NDBC.
- [B8] Independent review of v9/v10 by a separately run analysis ("champi_v11guidance_for_claude": `AUDIT.md`, `REVIEW_V10.md`, `WRITEUP.md`), supplied by Evan, 24–25 Oct 2026. Unpublished.

### C. Software
- Harris, C. R., et al., 2020: Array programming with NumPy. *Nature*, 585, 357–362. https://doi.org/10.1038/s41586-020-2649-2 †
- Virtanen, P., et al., 2020: SciPy 1.0: fundamental algorithms for scientific computing in Python. *Nature Methods*, 17, 261–272. https://doi.org/10.1038/s41592-019-0686-2 †
- Hunter, J. D., 2007: Matplotlib: A 2D graphics environment. *Computing in Science & Engineering*, 9(3), 90–95. https://doi.org/10.1109/MCSE.2007.55 †
