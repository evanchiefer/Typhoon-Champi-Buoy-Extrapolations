# Independent check: central pressure from the buoy's eyewall readings plus the SAR wind profile integrated inward in gradient balance.
# No storm-profile model and no wind consensus are used. The 17:33Z surface profile (sar/endpoint.py: 09Z endpoint from Sentinel-1D 0.75 +
# RCM-3 09:20Z 0.25, and RCM-3 21:15Z, interpolated in time in normalized coordinates) is placed at the surface RMW and scaled to the RCM-3
# peak wind; 10-m winds are converted to gradient level with the log-layer factor alpha(r) (logwind.py).
#   Pc = P_buoy(r_b) - int_0^{r_b} rho(r) [Vg(r)^2/r + f Vg(r)] dr
# Buoy distance: v11 track (fixes + wander draw), elliptical eyewall (effective radius), non-circularity 1.0 km.
# Usage: sarcheck.py [variant]   variant = interp (default), nat2115, nat09
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import t,lat,lon,P,geom,r_eff,FCOR,RD,PRIS,LWIN,NW,WIN,ST
import logwind as LW
SD=os.path.join(HERE,'sar'); KT=1.94384; KTMS=0.514444
VAR=sys.argv[1] if len(sys.argv)>1 else 'interp'
def norm(key):
    d=np.load(os.path.join(SD,key+'_prof.npz')); s=json.load(open(os.path.join(SD,key+'_struct.json')))
    return d['rc']/s['Rm'], d['v']*KT/s['Vm_kt'], d['v2']*KT**2/s['Vm_kt']**2
xg=np.linspace(0.005,3.0,1200)
def shp(key): x,s,q=norm(key); return np.interp(xg,x,s),np.interp(xg,x,q)
a,qa=shp('S1D_20_0909'); b,qb=shp('R3_20_0920'); S1=0.75*a+0.25*b; Q1=0.75*qa+0.25*qb; S2,Q2=shp('R3_20_2115')
pri=PRIS[VAR]; s=ST[VAR]; w0={'interp':ST['interp']['w2115'],'nat2115':1.0,'nat09':0.0}[VAR]; wsd=0.10 if VAR=='interp' else 0.0
tsd=3.0 if VAR=='interp' else 0.94*s['hours_from_nearest_pass']
rng=np.random.default_rng(11); N=20000; out={17:[],18:[]}; k17,k18=list(WIN).index(17),list(WIN).index(18)
for k in range(N):
    w=np.clip(rng.normal(w0,wsd),0,1) if wsd>0 else w0
    sh=(1-w)*S1+w*S2; q=(1-w)*Q1+w*Q2
    pbl=LW.draw(rng)
    Vm=s['Vm_rcm']*rng.normal(1,0.08)+rng.normal(0,tsd)          # RCM-3 azimuthal-mean surface max: SAR calibration +-8%, time
    Rs=rng.normal(s['Rm'],1.2)                                     # surface RMW at 17:33Z
    dl=np.c_[LWIN@rng.normal(size=NW),LWIN@rng.normal(size=NW)]   # centre: track posterior (offset + wander)
    e0=max(0.0,rng.normal(*pri['e0'])); th0=rng.normal(*pri['th0'])
    dTc=rng.uniform(0.5,4.5); bias=rng.normal(0,0.5); re_kt=rng.choice([47,55])
    xe=xg[np.argmax(sh*Vm>=re_kt)]
    for idx,kk in ((17,k17),(18,k18)):
        dx,dy=geom('gp',dl[kk,0],dl[kk,1],t[idx:idx+1],lat[idx:idx+1],lon[idx:idx+1]); re,_=r_eff(dx,dy,e0,th0)
        rb=float(re[0])+rng.normal(0,1.0)                          # eyewall non-circularity left after the ellipse
        xx=np.linspace(xe,rb/Rs,500); rr=xx*Rs
        al=LW.alpha_x(xx,pbl); vg=np.interp(xx,xg,sh)*Vm*KTMS/al; vq=np.interp(xx,xg,q)*(Vm*KTMS/al)**2
        ve=np.interp(xe,xg,sh)*Vm*KTMS/LW.alpha_x(xe,pbl)
        p=np.full_like(rr,P[idx]+bias)
        for it in range(2):
            Tv=305.0+dTc*np.exp(-(rr/(0.8*Rs))**2); rho=p*100/(RD*Tv)
            dp=(rho*(vq/(rr*1e3)+FCOR*vg))*1e3
            cum=np.concatenate([[0],np.cumsum((dp[1:]+dp[:-1])/2*np.diff(rr))])
            p=(P[idx]+bias)-(cum[-1]-cum)/100
        out[idx].append(P[idx]+bias-cum[-1]/100-rho[0]*ve**2/2/100)
res={}
for key in (17,18):
    a_=np.array(out[key]); qq=np.percentile(a_,[2.5,16,50,84,97.5]); res[key]=qq.tolist()
    print('%s from the %02d:04 reading (P=%.1f): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(VAR,key,P[key],qq[2],qq[1],qq[3],qq[0],qq[4]))
both=np.concatenate([out[17],out[18]]); qq=np.percentile(both,[2.5,16,50,84,97.5]); res['both']=qq.tolist()
print('%s pooled: median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(VAR,qq[2],qq[1],qq[3],qq[0],qq[4]))
fn=os.path.join(HERE,'sarcheck.json'); allr=json.load(open(fn)) if os.path.exists(fn) else {}
if not isinstance(allr.get('interp',None),dict) and 'both' in allr: allr={}
allr[VAR]=res; json.dump(allr,open(fn,'w'))
