# Profile likelihood over central pressure (v11): at each Pc, multistart least squares plus continuation sweeps up and down the grid.
# Names: T/U/A on the v11 track with the peak-wind constraint (the Monte Carlo likelihood), T with JTWC positions, and T without the
# peak-wind constraint (buoy + satellite structure only).
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import *
CFG={'T_gp':('T','gp',True),'U_gp':('U','gp',True),'A_gp':('A','gp',True),'T_bt':('T','bt',True),'T_gp_novg':('T','gp',False)}
GRID=np.arange(838,911.1,3.0)
def pri_of(vg):
    p=dict(PRI)
    if vg: p['Vg']=VG_PRIOR
    return p
CB=json.load(open(os.path.join(HERE,'cbest.json')))
CBK={'T_gp':'T|gp|interp|vg','U_gp':'U|gp|interp|vg','A_gp':'A|gp|interp|vg','T_bt':'T|bt|interp|vg','T_gp_novg':'T|gp|interp|novg'}
def job(a):
    name,Pc=a; fam,tr,vg=CFG[name]; pri=pri_of(vg)
    extra=[np.array(r['x']) for r in CB[CBK[name]]]
    best,costs,unpack=solve(fam,Pc,tr,n_rand=4,seed=int(Pc)*7+len(name),extra=extra,pri=pri)
    d=summarize(fam,best,unpack,Pc,tr,pri=pri); d.update(name=name,n_starts=int(len(costs))); return d
def sweep(name,rows):
    fam,tr,vg=CFG[name]; pri=pri_of(vg); byP={r['Pc']:r for r in rows}
    for order in (GRID,GRID[::-1]):
        prev=None
        for Pc in order:
            if prev is not None:
                res,unpack,lb,ub=make_res(fam,Pc,tr,pri=pri)
                s=least_squares(res,np.clip(prev,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
                if 2*s.cost<byP[Pc]['chi2']-1e-6:
                    d=summarize(fam,s,unpack,Pc,tr,pri=pri); d.update(name=name,n_starts=byP[Pc]['n_starts'],improved_by_sweep=True); byP[Pc]=d
            prev=np.array(byP[Pc]['x'])
    return [byP[p] for p in GRID]
if __name__=='__main__':
    names=sys.argv[1].split(','); out=sys.argv[2]; t0=time.time()
    with Pool(2) as pool: rows=pool.map(job,[(n,float(p)) for n in names for p in GRID],chunksize=2)
    print('multistart done %.0f s'%(time.time()-t0),flush=True)
    final=[]
    for n in names:
        final+=sweep(n,[r for r in rows if r['name']==n]); print(n,'sweep done %.0f s'%(time.time()-t0),flush=True)
    json.dump(final,open(out,'w')); print('ALL DONE %.0f s'%(time.time()-t0))
