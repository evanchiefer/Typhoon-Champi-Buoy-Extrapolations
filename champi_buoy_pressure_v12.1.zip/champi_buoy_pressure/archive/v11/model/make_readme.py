# Writes README.md from the saved results (no number is typed by hand).
import os, json, numpy as np
H=os.path.dirname(os.path.abspath(__file__)); J=lambda f: json.load(open(os.path.join(H,f)))
F=J('final.json'); W=J('weights.json'); L=J('ladder.json'); BD=J('bounds.json'); GC=J('gapcheck.json'); RW=J('reading_weights.json'); CF=J('fits_constrained.json')
TG=J('track_gp.json'); LWP=J('logwind_priors.json'); CC=J('sar/crosscal_0909.json'); CC21=J('sar/crosscal.json'); ST=J('sar/structure_1733.json'); SC=J('sarcheck.json')
SF=J('sar/sar_files.json'); SL=J('sloo.json'); SLS=SL['schemes']
def sli(f,it): return [o for o in SL['items'] if o['fam']==f and o['item']==it][0]
fits_pen={f:sli(f,None)['z_all'] for f in 'TUA'}; nb19=SLS['buoy_without_1904']['pbma']
R=F['runs']; A=F['alt_weights']; JT=F['jtwc_1733']; w=F['weights']
def q(tg): x=R[tg]['q']; return x
def row(lab,x,bold=False):
    m='**%.0f**'%x[2] if bold else '%.0f'%x[2]; return '| %s | %s | %.0f–%.0f | %.0f–%.0f |'%(lab,m,x[1],x[3],x[0],x[4])
fin=[F['lo95'],F['lo68'],F['median'],F['hi68'],F['hi95']]
lad={o['label'].split(':')[0] if o['label'].startswith('v10-like') else o['label']:o for o in L}
def L_(prefix): return [o for o in L if o['label'].startswith(prefix)][0]
med=[c for c in CF if c['name']=='T_con_gp' and c['tag']=='median'][0]
fits={o['fam']:o for o in W['fits'] if o['kind']=='full'}
loo=lambda f,i: [o for o in W['fits'] if o['kind']=='loo' and o['fam']==f and o['drop'][0]==i][0]
st={k:J('sar/%s_struct.json'%k) for k in ('S1D_20_0909','R3_20_0920','R3_20_2115','R3_21_0929','R3_21_2123')}
B=F['budget']; lab={'family':'profile-shape choice (3 models)','Rm':'radius of maximum wind (incl. tilt)','intensity':'peak surface wind (incl. SAR calibration ±8%)',
   'noise':'reading scatter','center':'centre position (track + wander)','alpha':'10-m to gradient conversion','shape':'inner-eye wind shape','ring':'secondary wind maximum',
   'ellipse':'oval eyewall','decay':'eyewall wind decay','bias':'barometer calibration','density':'air density','Pn':'environmental pressure'}
budget='\n'.join('  - %s %.1f'%(lab[k],v) for k,v in sorted(B.items(),key=lambda kv:-kv[1]))
cc=CC['ratio_vs_rcm_speed']; h=TG['hyper']; csd=float(np.sqrt(np.array(TG['cov_win'])[4,4]))
C=np.array(TG['cov_win']); d1718=float(np.sqrt(C[4,4]+C[5,5]-2*C[4,5]))
cv=F['conv_check']
gap='\n'.join('| %s | %.0f → %.0f | %.2f | %.2f |'%(g[0],g[1],g[2],g[3]/g[4],g[3]/g[5]) for g in GC)
medA=[c for c in CF if c['name']=='A_con_gp' and c['tag']=='median'][0]
rws='\n'.join('| %s | %.1f | %+.1f | %.1f | %+.2f | %.2f | %+.1f |'%('%02d:%02dZ'%(int(r['t']),round(r['t']%1*60)),r['p'],r['resid'],r['sigma'],r['z'],r['weight'],medA['resid'][int(round(r['t']))]) for r in RW if 15<=r['t']<=20.1)
bnd='\n'.join('| %s | %.1f hPa | %.1f |'%(r[0],r[1],r[2]) for r in BD['rows'])
lt='\n'.join('| %s | %.1f | %.1f | %+.1f / %+.1f |'%(o['label'],o['Pc'],o['chi2'],o['summary']['resid'][17],o['summary']['resid'][18]) for o in L)
def sp(k,name,inc):
    s=st[k]; return '| %s | %.2f | %.0f | %.3f | %.2f | %s | %s | %d/9 |'%(name,s['Rm'],s['Vm_kt'],s['I47'],s['v14'],('%.1f km, %.2f'%(s['R2'],s['vsec'])) if s['R2'] else 'none',inc,s['centre_guesses_agreeing'])
sar='\n'.join([sp('S1D_20_0909','Sentinel-1D 20 Oct 09:09Z','28–32°'),sp('R3_20_0920','RCM-3 20 Oct 09:20Z','48–52°'),sp('R3_20_2115','RCM-3 20 Oct 21:15Z','27–33°'),
               sp('R3_21_0929','RCM-3 21 Oct 09:29Z','28–33°'),sp('R3_21_2123','RCM-3 21 Oct 21:23Z','—')])
cvR=st['R3_20_0920']['centre_convergence']; rmR=[c[2] for c in cvR]; iR=[c[4] for c in cvR]
fw=LWP['franklin_check']
REFS=r'''
## References and data sources

Citations were checked against publisher, Crossref or agency pages on 25 Oct 2026. Items marked † were matched to standard bibliographic
records but not re-opened. Items marked ‡ could not be confirmed (see notes).

### A. Literature
- [A1] Holland, G. J., 1980: An analytic model of the wind and pressure profiles in hurricanes. *Mon. Wea. Rev.*, 108, 1212–1218. https://doi.org/10.1175/1520-0493(1980)108<1212:AAMOTW>2.0.CO;2 (two-ring Holland profile)
- [A2] Willoughby, H. E., R. W. R. Darling, and M. E. Rahn, 2006: Parametric representation of the primary hurricane vortex. Part II: A new family of sectionally continuous profiles. *Mon. Wea. Rev.*, 134, 1102–1120. https://doi.org/10.1175/MWR3106.1 (power-law eye, dual-exponential decay)
- [A3] Atkinson, G. D., and C. R. Holliday, 1977: Tropical cyclone minimum sea level pressure/maximum sustained wind relationship for the western North Pacific. *Mon. Wea. Rev.*, 105(4), 421–427. https://doi.org/10.1175/1520-0493(1977)105<0421:TCMSLP>2.0.CO;2 (context curve in Fig. 2b)
- [A4] Knaff, J. A., and R. M. Zehr, 2007: Reexamination of tropical cyclone wind–pressure relationships. *Wea. Forecasting*, 22, 71–88. https://doi.org/10.1175/WAF965.1 (context)
- [A5] Courtney, J., and J. A. Knaff, 2009: Adapting the Knaff and Zehr wind–pressure relationship for operational use in Tropical Cyclone Warning Centres. *Aust. Meteor. Oceanogr. J.*, 58(3), 167–179. https://doi.org/10.22499/2.5803.002 (context)
- [A6] Franklin, J. L., M. L. Black, and K. Valde, 2003: GPS dropwindsonde wind profiles in hurricanes and their operational implications. *Wea. Forecasting*, 18, 32–44. https://doi.org/10.1175/1520-0434(2003)018<0032:GDWPIH>2.0.CO;2
- [A6b] Franklin, J. L., M. L. Black, and K. Valde, 2000: *Eyewall Wind Profiles in Hurricanes Determined By GPS Dropwindsondes*. NOAA/NHC web report. https://www.nhc.noaa.gov/aboutwindprofile.shtml (surface/700-hPa ratios 0.78 outer vortex, 0.91 eyewall, 0.88 at the RMW)
- [A7] Powell, M. D., P. J. Vickery, and T. A. Reinhold, 2003: Reduced drag coefficient for high wind speeds in tropical cyclones. *Nature*, 422, 279–283. https://doi.org/10.1038/nature01481 (roughness range in the log-layer factor)
- [A8] Powell, M. D., E. W. Uhlhorn, and J. D. Kepert, 2009: Estimating maximum surface winds from hurricane reconnaissance measurements. *Wea. Forecasting*, 24(3), 868–883. https://doi.org/10.1175/2008WAF2007087.1 (RMW tilt)
- [A9] Stern, D. P., and D. S. Nolan, 2009: Reexamining the vertical structure of tangential winds in tropical cyclones: Observations and theory. *J. Atmos. Sci.*, 66(12), 3579–3600. https://doi.org/10.1175/2009JAS2916.1 (RMW tilt)
- [A10] Kepert, J., 2001: The dynamics of boundary layer jets within the tropical cyclone core. Part I: Linear theory. *J. Atmos. Sci.*, 58(17), 2469–2484. https://doi.org/10.1175/1520-0469(2001)058<2469:TDOBLJ>2.0.CO;2 ; Kepert, J., and Y. Wang, 2001: Part II: Nonlinear enhancement. *J. Atmos. Sci.*, 58(17), 2485–2501. https://doi.org/10.1175/1520-0469(2001)058<2485:TDOBLJ>2.0.CO;2 (supergradient boundary-layer wind in the log-layer factor)
- [A11] Muramatsu, T., 1986: Trochoidal motion of the eye of Typhoon 8019. *J. Meteor. Soc. Japan*, 64, 259–272. https://doi.org/10.2151/jmsj1965.64.2_259
- [A12] Nolan, D. S., M. T. Montgomery, and L. D. Grasso, 2001: The wavenumber-one instability and trochoidal motion of hurricane-like vortices. *J. Atmos. Sci.*, 58(21), 3243–3270. https://doi.org/10.1175/1520-0469(2001)058<3243:TWOIAT>2.0.CO;2
- [A13] Kuo, H.-C., R. T. Williams, and J.-H. Chen, 1999: A possible mechanism for the eye rotation of Typhoon Herb. *J. Atmos. Sci.*, 56(11), 1659–1673. https://doi.org/10.1175/1520-0469(1999)056<1659:APMFTE>2.0.CO;2
- [A14] Mouche, A., B. Chapron, J. Knaff, Y. Zhao, B. Zhang, and C. Combot, 2019: Copolarized and cross-polarized SAR measurements for high-resolution description of major hurricane wind structures: Application to Irma category 5 hurricane. *J. Geophys. Res. Oceans*, 124, 3905–3922. https://doi.org/10.1029/2019JC015056
- [A15] Combot, C., A. Mouche, J. Knaff, Y. Zhao, Y. Zhao, L. Vinour, Y. Quilfen, and B. Chapron, 2020: Extensive high-resolution synthetic aperture radar (SAR) data analysis of tropical cyclones: Comparisons with SFMR flights and best track. *Mon. Wea. Rev.*, 148(11), 4545–4563. https://doi.org/10.1175/MWR-D-20-0005.1
- [A16] Velden, C. S., and D. Herndon, 2020: A consensus approach for estimating tropical cyclone intensity from meteorological satellites: SATCON. *Wea. Forecasting*, 35(4), 1645–1662. https://doi.org/10.1175/WAF-D-20-0015.1
- [A17] Olander, T. L., and C. S. Velden, 2019: The Advanced Dvorak Technique (ADT) for estimating tropical cyclone intensity: Update and new capabilities. *Wea. Forecasting*, 34(4), 905–922. https://doi.org/10.1175/WAF-D-19-0007.1
- [A18] Wimmers, A. J., and C. S. Velden, 2016: Advancements in objective multisatellite tropical cyclone center fixing. *J. Appl. Meteor. Climatol.*, 55(1), 197–212. https://doi.org/10.1175/JAMC-D-15-0098.1 (ARCHER)
- [A19] Griffin, S. M., A. Wimmers, and C. S. Velden, 2024: Predicting short-term intensity change in tropical cyclones using a convolutional neural network. *Wea. Forecasting*, 39(1), 177–202. https://doi.org/10.1175/WAF-D-23-0085.1 (D-MINT and D-PRINT; the products have also been called DeepMicroIRNet, DeepMultiNet and OPEN-AIIR)
- [A19b] Olander, T., A. Wimmers, C. Velden, and J. P. Kossin, 2021: Investigation of machine learning using satellite-based advanced Dvorak technique analysis parameters to estimate tropical cyclone intensity. *Wea. Forecasting*, 36(6), 2161–2186. https://doi.org/10.1175/WAF-D-20-0234.1 (AiDT)
- [A20] Lange, K. L., R. J. A. Little, and J. M. G. Taylor, 1989: Robust statistical modeling using the t distribution. *J. Amer. Stat. Assoc.*, 84(408), 881–896. https://doi.org/10.1080/01621459.1989.10478852 †
- [A21] Yao, Y., A. Vehtari, D. Simpson, and A. Gelman, 2018: Using stacking to average Bayesian predictive distributions (with discussion). *Bayesian Analysis*, 13(3), 917–1007. https://doi.org/10.1214/17-BA1091 † (pseudo-BMA+ and stacking weights)
- [A22] Akaike, H., 1974: A new look at the statistical model identification. *IEEE Trans. Autom. Control*, 19(6), 716–723. https://doi.org/10.1109/TAC.1974.1100705 † ; Schwarz, G., 1978: Estimating the dimension of a model. *Ann. Statist.*, 6(2), 461–464. https://doi.org/10.1214/aos/1176344136 † (AIC, BIC)
- [A23] Rubin, D. B., 1981: The Bayesian bootstrap. *Ann. Statist.*, 9(1), 130–134. https://doi.org/10.1214/aos/1176345338 †
- [A24] Rasmussen, C. E., and C. K. I. Williams, 2006: *Gaussian Processes for Machine Learning*. MIT Press. http://www.gaussianprocess.org/gpml/ † (Matérn covariance)
- [A24b] Patterson, H. D., and R. Thompson, 1971: Recovery of inter-block information when block sizes are unequal. *Biometrika*, 58(3), 545–554. https://doi.org/10.1093/biomet/58.3.545 † (restricted maximum likelihood)
- [A25] Alet, F., et al., 2026: Operational tropical cyclone forecasting with AI. *Nature*, 657, 680–688. https://doi.org/10.1038/s41586-026-10953-2 (WeatherNext-Cyclones; its GenCast baseline converts pressure to wind with v_max = 6.70·max(0, 1010 − p_min)^0.644, constants refitted to ERA5 and IBTrACS in the Atkinson–Holliday form; discussed, not used in the fit)
- [A26] Monaldo, F. M., 2005: *ANSWRS: APL/NOAA SAR Wind Retrieval System Software Documentation*. JHU/APL Report SRO-05-13. Listed at https://www.star.nesdis.noaa.gov/socd/mecb/sar/publications.php ; Monaldo, F., C. Jackson, W. Pichel, and X. Li, 2015: Early validation of operational SAR wind retrievals from Sentinel-1A. *IGARSS 2015*, 1223–1226. https://doi.org/10.1109/IGARSS.2015.7325993 ; Monaldo, F., C. Jackson, and W. Pichel, 2013: Seasat to RADARSAT-2: Research to operations. *Oceanography*, 26(2). https://doi.org/10.5670/oceanog.2013.29
- [A27] NOAA/NESDIS/STAR: *Tropical SAR Winds Technical Document* (cross-polarisation GMFs for Sentinel-1, RADARSAT-2 and RCM, July 2023). https://www.star.nesdis.noaa.gov/socd/mecb/sar/tropical_gmf_tech_doc.php ‡ The GMF labels in the file metadata ("S1A_V2", "RCM_V1") are not documented publicly; STAR documents its cross-pol GMFs as C-10 (Sentinel-1) and C-12 (RCM), matching the "C-10"/"C-12" in the file names.

### B. Data and products
- [B1] NOAA/NESDIS/STAR SAR tropical-cyclone winds, Champi (WP292026): level-2 500-m NetCDF and 3-km "MERGED_FIX" files for the six passes in `sar/sar_files.json` (names, acquisition times, sha256). https://www.star.nesdis.noaa.gov/socd/mecb/sar/sarwinds_tropical.php . Credit: "Synthetic Aperture Radar (SAR) based tropical wind products were generated and provided through the STAR Water Surface Conditions Science Team's tropical cyclone winds program." STAR products are for experimental use. RADARSAT Constellation Mission imagery © Government of Canada 2026; RADARSAT is an official mark of the Canadian Space Agency. Contains modified Copernicus Sentinel data (2026).
- [B2] NOAA/NCEP Global Forecast System 0.25° (wind directions used by ANSWRS; file metadata "gfs025"). https://nomads.ncep.noaa.gov/ † The cross-polarisation retrievals used here are close to direction-independent.
- [B3] Japan Meteorological Agency, Himawari-9 infrared imagery (hourly eye fixes, `ir_eye_fixes.json`). https://www.data.jma.go.jp/mscweb/en/himawari89/ † ; imagery viewer RAMMB/CIRA SLIDER https://rammb-slider.cira.colostate.edu/ †
- [B4] ATMS 165/183-GHz imagery (NOAA/NASA JPSS), eye fix at 17:01Z. https://www.nesdis.noaa.gov/our-satellites/currently-flying/joint-polar-satellite-system † (the satellite and the imagery page used are not recorded here)
- [B5] Joint Typhoon Warning Center, WP29 2026 (ATCF working best track; positions and 895 hPa). https://www.metoc.navy.mil/jtwc/jtwc.html ‡ JTWC releases final best tracks after the season, so 895 hPa is provisional. RSMC Tokyo (JMA) lists 900 hPa (not checked here).
- [B6] CIMSS Tropical Cyclones, University of Wisconsin–Madison SSEC (ADT, AiDT, SATCON, D-MINT, D-PRINT, ARCHER values in Fig. 2). https://tropic.ssec.wisc.edu/
- [B7] Drifting buoy WMO 2802285, hourly sea-level pressure and position (spreadsheet `data_source/champi_revised.xlsx`, supplied by Evan; NOAA source page shared by Evan). ‡ The originating platform record was not found in public GDP/OSMC/NDBC listings from here. Drifting-buoy data of this kind are distributed via the GTS (WMO buoy identifiers: https://community.wmo.int/en/buoy-wmo-identification-numbers), the NOAA Global Drifter Program (https://www.aoml.noaa.gov/phod/gdp/) and NOAA NDBC.
- [B8] Independent review of v9/v10 by a separately run analysis ("champi_v11guidance_for_claude": `AUDIT.md`, `REVIEW_V10.md`, `WRITEUP.md`), supplied by Evan, 24–25 Oct 2026. Unpublished.

### C. Software
- Harris, C. R., et al., 2020: Array programming with NumPy. *Nature*, 585, 357–362. https://doi.org/10.1038/s41586-020-2649-2 †
- Virtanen, P., et al., 2020: SciPy 1.0: fundamental algorithms for scientific computing in Python. *Nature Methods*, 17, 261–272. https://doi.org/10.1038/s41592-019-0686-2 †
- Hunter, J. D., 2007: Matplotlib: A 2D graphics environment. *Computing in Science & Engineering*, 9(3), 90–95. https://doi.org/10.1109/MCSE.2007.55 †
'''
txt=f"""# Typhoon Champi (29W) — central pressure from a drifting-buoy eyewall pass

Estimate of Champi's minimum sea-level pressure at **17:33 UTC, 20 October 2026**. Drifting buoy 2802285 [B7] passed through the inner part of the
south-west eyewall. It read **909.4 hPa about {med['r17']:.0f} km from the centre at 17:04Z**, near the radius of maximum wind, and 913.3 hPa at 18:04Z.

## Result (version 11)

| | Central pressure (hPa) | 68% range | 95% range |
|---|---|---|---|
{row('**Combined estimate: three profile models, weighted by leave-one-out prediction**',fin,True)}
{row('Two-ring Holland profile (weight %.2f)'%w['A'],q('alt_A'))}
{row('SAR eye shape, no secondary ring (weight %.2f)'%w['U'],q('alt_U'))}
{row('SAR eye shape + secondary ring, the "ring model" (weight %.2f)'%w['T'],q('primary'))}
{row('Ring model, buoy + satellite structure only (no wind input)',q('structure_only'))}
{row('Check: SAR winds integrated inward from the buoy (no profile model)',SC['interp']['both'])}
{row('No interpolation: 21:15Z structure only (ring model)',q('nat2115'))}
{row('No interpolation: 09Z structure only (ring model)',q('nat09'))}
{row('No interpolation: both, weighted by fit (ring model)',R['nat_fitweighted']['q'])}
{row('Check: flat ±4 km centre error, v10 track (ring model)',q('offset4'))}
{row('Check: sub-hourly trochoidal wobble up to 3 km (ring model)',q('trochoid'))}
{row('Check: v10 geometry (circular eyewall, ±2 km offset; ring model)',q('v10_geometry'))}
{row('Check: JTWC best-track positions (ring model)',q('bt'))}
{row('Check: no centre wander (ring model)',q('no_wander'))}
{row('Check: power-law eye (ring model)',q('powerlaw_eye'))}
{row('Check: Gaussian reading errors (ring model)',q('gauss'))}
{row('Check: Student-t rescaled to sd σ (ring model)',q('tscaled'))}
{row('Check: log-ramp density profile (ring model)',q('ramp'))}
{row('Weighting: fit + parameter penalty (AIC)',A['aic']['q'])}
{row('Weighting: BIC',A['bic']['q'])}
{row('Weighting: equal',A['equal']['q'])}
{row('Weighting: stacking (leave-one-out)',A['stacking']['q'])}
{row('Weighting check: leave-one-out on buoy readings + SAR structure (`sloo.py`)',SLS['buoy+structure']['q'])}
{row('Weighting check: Holland removed, ring / no-ring ratio kept',SLS['buoy_no_holland']['q'])}
| Previous version (v10) | 884 | 876–892 | 867–899 |
| JTWC working best track, interpolated to 17:33Z (operational value; final best track not yet released) [B5] | {JT:.0f} | | |

- 1σ ±{F['total_sd']:.1f} hPa. {F['n_trials']} Monte Carlo trials (ring model {R['primary']['n']}, two-ring Holland {R['alt_A']['n']}, no-ring {R['alt_U']['n']}).
- **{100*F['p_below_jtwc']:.0f}% of the combined distribution lies below JTWC's {JT:.0f} hPa**, which sits {'inside the 68% range' if JT<fin[3] else 'between the 68% and 95% upper limits' if JT<fin[4] else 'above the 95% range'}.
- Uncertainty budget (1σ, hPa; single-source runs of each profile model, weighted over the three, plus the spread between them):
{budget}
- Model weights (leave-one-out, pseudo-BMA+): ring model {w['T']:.2f}, no-ring {w['U']:.2f}, two-ring Holland {w['A']:.2f}. See "Model weighting" below.

**Reading the result.** The combined {fin[2]:.0f} is set mostly by the two-ring Holland profile, which predicts held-out buoy readings best.
Holland matches the SAR eye but not the wind decay outside the eyewall, which the buoy-only score cannot see. Scoring the SAR structure
measurements as well moves the weight to the no-ring SAR-eye model ({SLS['buoy+structure']['pbma']['U']:.2f}) and gives {SLS['buoy+structure']['q'][2]:.0f} ({SLS['buoy+structure']['q'][1]:.0f}–{SLS['buoy+structure']['q'][3]:.0f}),
so the headline does not depend on the Holland profile (see "Model weighting"). The check that uses no profile model at all (the measured SAR winds integrated inward from the 17:04Z and 18:04Z readings) gives
{SC['interp']['both'][2]:.0f}, close to the ring model alone ({q('primary')[2]:.0f}). Both routes are below {JT:.0f}. The difference between them (~{fin[2]-SC['interp']['both'][2]:.0f} hPa) is the
main open question: how the winds behave between the eyewall and the secondary maximum (25–47 km), where the buoy has only the 17:04Z,
18:04Z, 16:04Z and 19:04Z readings. With no profile model, reaching {JT:.0f} needs at least two adverse assumptions at once: the weaker 09Z
structure and ignoring surface friction (bounds table below).

## What changed in version 11

Reproduced first: the v10 setup run in the v11 code gives a best fit of {L_('v10-like')['Pc']:.1f} hPa (v10: 884).
Single best fits (ring model, peak-wind constraint, Student-t errors) as each change is added (`ladder.json`):

| Configuration | Best-fit Pc | χ² | Residual 17:04Z / 18:04Z (hPa) |
|---|---|---|---|
{lt}

1. **Centre track from the fixes, with wander** (`track_gp.py`; Gaussian process with Matérn covariance [A24], hyperparameters by restricted
   maximum likelihood [A24b]; eye wobble and trochoidal motion: Muramatsu 1986 [A11], Nolan et al. 2001 [A12]).
   - The surface centre is a smooth track plus a time-correlated wander. Its timescale, amplitude and the IR fix scatter are estimated from the
     18 hourly Himawari IR eye fixes; the four surface fixes (SAR ring centres 09:09Z, 09:20Z, 21:15Z; ATMS 17:01Z) fix the IR-to-surface offset
     on the same track: (+{TG['offset'][0]:.2f} E, {TG['offset'][1]:+.2f} N) km ± {TG['offset_sd']:.2f}.
   - The fixes are smooth: hour-to-hour fix scatter {h["sn"]:.2f} km. The three SAR centres sit within about 0.3 km of the track plus offset.
     A slow change of the offset (vortex tilt) of 1 km is allowed; the fixes bound it only loosely (0 to ~3 km).
   - Result: the surface centre at 17:04Z is known to ±{csd:.1f} km, and the change from 17:04Z to 18:04Z to ±{d1718:.1f} km.
     The fit may move the centre at each reading within that covariance.
   - **This does not support the reviewer's ±4 km.** The STAR centres sit 3–4.5 km south-west of the ring-fit centres on both days, but that is
     a different centre definition; the ring-fit centres from two sensors 11 minutes apart agree to 0.5 km after storm motion. The flat ±4 km
     version is reported as a check.
   - Evan's sub-hourly trochoidal wobble is a check: wobble up to 3 km with periods of 0.5–2 h, vanishing at the hourly fixes.
2. **Oval eyewall** (elliptical eyewalls: Kuo et al. 1999 [A13]). Three SAR passes (Sentinel-1D 09:09Z, RCM-3 21:15Z, RCM-3 21 Oct 09:29Z) show the eyewall stretched along a north–south
   axis by 1.0–1.2 km (RCM-3 09:20Z, at ~50° incidence, does not). The profile is evaluated at an effective distance
   r / (1 + e cos 2(θ − θ₀)); prior e = 0.042 ± 0.015, θ₀ = 187° ± 20°. The 18:04Z reading lay on the long side, effectively ~1 km closer to
   the eyewall. This removes about a third of its misfit.
3. **Position term 1.5 → 1.0 km**: the eyewall irregularity left after the oval (SAR sector-RMW residual sd 0.8–1.0 km).
4. **09Z structure.** The ring fit is now converged from 9 first guesses; all 9 agree for RCM-3 09:20Z on RMW {st['R3_20_0920']['Rm']:.2f} km and
   eye integral {st['R3_20_0920']['I47']:.3f} (v10 had 27.75 / 0.337, a minority convergence; the audit's value is reproduced). Over the guesses:
   RMW {min(rmR):.2f}–{max(rmR):.2f} km, eye integral {min(iR):.3f}–{max(iR):.3f}. The 09Z endpoint uses the Sentinel-1D 09:09Z shape (weight 0.75) and
   RCM-3 09:20Z (0.25) at the RCM-3 wind level. Interpolated to 17:33Z: surface RMW {ST['interp']['Rm']:.2f} km, eye integral {ST['interp']['I47']:.3f}.
5. **SAR-measured eye shape** used directly (table of v/Vmax inside the RMW, 47-kt cut, raised to a power s ~ N(1, 0.08)). It fits exactly as
   well as the power-law eye and gives the same best fit; the power law is kept as a check.
6. **Model weighting.** Weights now come from fits with the same likelihood as the Monte Carlo (v10 used the unconstrained scan, where the ring
   model's best fit sat at 860 hPa / 196 kt). See below.
7. **Fixes and checks**:
   - `sar/extract_all.py` runs (v10's `sar_extract.py` wrote to an undefined `S`) and includes Sentinel-1D 09:09Z; file names, acquisition
     times and sha256 are recorded in `sar/sar_files.json`. `sar/crosscal09.py` regenerates the 09Z cross-calibration.
   - `sar/structure.py`: no crash on 3-km grids; a sector's secondary maximum is no longer taken as its RMW (the 43.75 km SW sector at 09:20Z).
   - Pass times: the file-name times are the scene centres (09:09:03–09:10:07 → 09:09:35, etc.), so no change.
   - Gap check: the SAR profile is now placed at the surface RMW (v10 mixed the gradient-level RMW with surface shapes). The outer pairs move from
     0.82–0.84 to {min(GC[4][3]/GC[4][5],GC[5][3]/GC[5][5]):.2f}–{max(GC[4][3]/GC[4][5],GC[5][3]/GC[5][5]):.2f}.
   - Dropsonde check (Franklin, Black & Valde 2000 [A6b]; 2003 [A6]): α at the RMW {fw['alpha_rm'][0]:.3f} (dropsondes 0.88 at the RMW, 0.91 eyewall); 2 RMW {fw['alpha_20'][0]:.2f},
     3 RMW {fw['alpha_30'][0]:.2f} (outer vortex 0.78, relative to 700 hPa). Consistent; α is not recalibrated.
   - Search floor 830 → 800 hPa: {sum(R[k]['at_floor'] for k in R if 'at_floor' in R[k])} trials reach it.
   - Convergence: {cv['n']} ring-model trials refitted with 10 starts instead of 4: {cv['moved_over_1hPa']} found a slightly better fit that moves Pc by more than
     1 hPa (largest {cv['max_abs']:.1f}). Substituting them changes the ring model's percentiles by at most {max(abs(a-b) for a,b in zip(cv['q4'],cv['q10'])):.1f} hPa.
   - The +8 kt (azimuthal mean → 1-min peak) is a range of 4–20 kt (centre 10). It is used only to quote 1-minute winds, not in the pressure.
   - Student-t scale (Student-t errors: Lange et al. 1989 [A20]): the reading σ is used as the t scale (t sd = 1.41σ). Rescaled to sd σ: see the table. ν = 2.5 and 8 in `ladder.json`.
   - SAR calibration ±8% (was ±6%; C-band cross-pol calibration at extreme winds: Mouche et al. 2019 [A14], Combot et al. 2020 [A15]). A wind-speed-dependent calibration is not applied: anchored at the RCM-3 eyewall level (which the buoy
     favours), it would raise the outer winds relative to the peak by ~8–10%, the opposite of what the buoy's outer pressure rises show.

## Response to the external review of v10 (REVIEW_V10.md §5)

| # | Item | v11 |
|---|---|---|
| 1 | Centre sd ±2 → ≥4 km; time-correlated wobble | Track model from the fixes with wander (centre ±{csd:.1f} km at 17:04Z, data-derived). ±4 km not adopted; reported as a check: {q('offset4')[2]:.0f} ({q('offset4')[1]:.0f}–{q('offset4')[3]:.0f}). Trochoidal wobble check: {q('trochoid')[2]:.0f}. |
| 2 | Weights from constrained fits with a parameter penalty | Done. Headline: leave-one-out (pseudo-BMA+); AIC {A['aic']['q'][2]:.0f}, BIC {A['bic']['q'][2]:.0f}, equal {A['equal']['q'][2]:.0f} reported. |
| 3 | 18:04Z: keep; residual/weight table; ν; t scale | Kept. Table below. ν = 2.5 / 8 and the rescaled t in the ladder; rescaled-t Monte Carlo {q('tscaled')[2]:.0f}. |
| 4 | No-interpolation envelope | 21:15Z only {q('nat2115')[2]:.0f}, 09Z only {q('nat09')[2]:.0f}, fit-weighted {R['nat_fitweighted']['q'][2]:.0f} (ring model; compare its interpolated {q('primary')[2]:.0f}). |
| 5 | Speed-dependent SAR calibration | Regenerated (`sar/crosscal09.py`); not applied, for the reason above. Calibration spread ±8%. |
| 6 | Reproducibility | `extract_all.py` fixed, 09:09Z generator, sha256 manifest, 3-km crash fixed. |
| 7 | RCM-3 09:20Z | Weight 0.25 in the 09Z endpoint; centre-convergence spread reported; SW-sector RMW pick fixed. |
| 8 | Wavenumber-2 eyewall | Done (oval eyewall; prior from three SAR passes). |
| 9 | +8 kt as a range | 4–20 kt (reporting only). |
| 10 | Tabulated SAR eye | Used in the ring and no-ring models; power law as a check ({q('powerlaw_eye')[2]:.0f}). |
| 11 | Franklin ratio check | Consistent (see 7 above). |
| 12 | Multistart convergence; floor | {cv['moved_over_1hPa']} of {cv['n']} trials move > 1 hPa with 10 starts; floor 800 hPa. |
| 13 | Never drop 18:04Z | Kept everywhere; leave-one-out is a diagnostic and a weighting score only. |

## Model weighting

Best fits with Pc free (`weights.json`):

Profiles: ring and no-ring models use the SAR eye table with a Willoughby-type decay [A2]; two-ring Holland [A1]. Weights: AIC/BIC [A22], leave-one-out pseudo-BMA+ and stacking [A21].

| Model | Best-fit Pc | χ² | Parameters |
|---|---|---|---|
| Ring model (SAR eye + secondary ring) | {fits['T']['Pc']:.1f} | {fits['T']['chi2']:.2f} | {fits['T']['npar']} |
| SAR eye, no secondary ring | {fits['U']['Pc']:.1f} | {fits['U']['chi2']:.2f} | {fits['U']['npar']} |
| Two-ring Holland | {fits['A']['Pc']:.1f} | {fits['A']['chi2']:.2f} | {fits['A']['npar']} |

| Weighting | Ring / no ring / Holland | Combined median (68%) |
|---|---|---|
""" + '\n'.join('| %s | %.2f / %.2f / %.2f | %.0f (%.0f–%.0f) |'%(nm,A[k]['weights']['T'],A[k]['weights']['U'],A[k]['weights']['A'],A[k]['q'][2],A[k]['q'][1],A[k]['q'][3])
      for k,nm in (('pbma','**Leave-one-out, pseudo-BMA+ (headline)**'),('stacking','Leave-one-out, stacking'),('loo','Leave-one-out, plain'),('aic','AIC'),('bic','BIC'),('equal','Equal'),('chi2','Fit only (χ², no penalty)'))) + f"""

- The ring model fits best in sample (lowest χ²), but predicts held-out readings worst. Leave-one-out z of each removed reading:

| Removed reading | Ring model | No ring | Two-ring Holland |
|---|---|---|---|
""" + '\n'.join('| %s | %+.2f (Pc %.1f) | %+.2f (Pc %.1f) | %+.2f (Pc %.1f) |'%(lb,loo('T',i)['z'],loo('T',i)['Pc'],loo('U',i)['z'],loo('U',i)['Pc'],loo('A',i)['z'],loo('A',i)['Pc'])
      for i,lb in ((15,'15:00Z'),(16,'16:04Z'),(17,'17:04Z'),(18,'18:04Z'),(19,'19:04Z'),(20,'20:04Z'))) + f"""

- The ring model's lower pressure leans on 18:04Z: without it, {fits['T']['Pc']:.1f} → {loo('T',18)['Pc']:.1f}. The no-ring model moves
  {loo('U',18)['Pc']-fits['U']['Pc']:+.1f} and the Holland model {loo('A',18)['Pc']-fits['A']['Pc']:+.1f}.
- Pseudo-BMA+ (Yao et al. 2018 [A21]; Bayesian bootstrap, Rubin 1981 [A23]) regularises the leave-one-out weights with a Bayesian bootstrap over the six held-out readings. It is used for
  the headline because it scores what matters (predicting buoy readings near the core) without a hand-chosen parameter penalty.
- Its weakness: it scores the buoy readings only. Holland's best fit matches the SAR eye (eye-integral term {fits_pen['A']['eye']:+.2f}σ) but not the wind decay
  outside the eyewall (wind ratio at 1.4 RMW {fits_pen['A']['v14']:+.2f}σ, at 2 RMW {fits_pen['A']['v20']:+.2f}σ), and its lead rests mostly on one reading: without
  19:04Z in the score, the weights are ring {nb19['T']:.2f} / no ring {nb19['U']:.2f} / Holland {nb19['A']:.2f}.
- Check (`sloo.py`): each SAR structure measurement the three models share (RMW, wind ratio at 1.4 and 2 RMW, peak wind) is removed in turn, the
  model refitted, and the removed value scored, as for the buoy readings. The eye integral is not scored: with no buoy reading inside 23 km,
  the eye shape is unconstrained once its own measurement is removed. z of each removed measurement (Pc after refit):

| Removed measurement | Ring model | No ring | Two-ring Holland |
|---|---|---|---|
""" + '\n'.join('| %s | %+.2f (%.1f) | %+.2f (%.1f) | %+.2f (%.1f) |'%(nm,sli('T',it)['z'],sli('T',it)['Pc'],sli('U',it)['z'],sli('U',it)['Pc'],sli('A',it)['z'],sli('A',it)['Pc'])
      for it,nm in (('Rm','Radius of maximum wind'),('v14','Wind ratio at 1.4 RMW'),('Vg','Peak wind'),('v20','Wind ratio at 2 RMW'))) + f"""

| Score | Ring / no ring / Holland (pseudo-BMA+) | Combined median (68%, 95%) |
|---|---|---|
""" + '\n'.join('| %s | %.2f / %.2f / %.2f | %.1f (%.1f–%.1f, %.1f–%.1f) |'%(nm,SLS[k]['pbma']['T'],SLS[k]['pbma']['U'],SLS[k]['pbma']['A'],SLS[k]['q'][2],SLS[k]['q'][1],SLS[k]['q'][3],SLS[k]['q'][0],SLS[k]['q'][4])
      for k,nm in (('buoy','Buoy readings (headline)'),('structure','SAR structure only'),('buoy+structure','Buoy + SAR structure'),('buoy+structure_no_peak_wind','Buoy + SAR structure, peak wind not scored'),('buoy_no_holland','Buoy, Holland removed'))) + f"""

- The ring model fits the buoy best in sample but is the one whose fit strains against the SAR measurements: freed of the peak-wind
  measurement it moves to {sli('T','Vg')['Pc']:.0f} hPa with a peak wind {sli('T','Vg')['z']:.1f}σ above the measured value (SAR and intensity consensus). The no-ring and Holland models stay near
  {sli('U','Vg')['Pc']:.0f}. The headline is left on the buoy score; the buoy + SAR score gives the same median and a slightly narrower range.
  The plug-in scores are cruder for the SAR measurements than for the readings, since a removed measurement can be partly absorbed by
  parameters the buoy pins only loosely.

## The 18:04Z reading

Residuals with the models held at the combined median ({med['Pc']:.1f} hPa):

| Reading | P (hPa) | Ring model: obs − model | σ | z | Student-t weight | Two-ring Holland: obs − model |
|---|---|---|---|---|---|---|
{rws}

- Kept in every run. The buoy position is not the issue: the track model fixes the centre to ±1 km, and the buoy GPS is precise.
- The oval eyewall explains about 1 km of effective distance. The rest is not explained by any geometry the data allow. The barometer tests
  (17:04Z and 18:04Z both raised 2 / 4 hPa) give {[o['Pc'] for o in W['fits'] if o['kind']=='bias'][0]:.1f} / {[o['Pc'] for o in W['fits'] if o['kind']=='bias'][1]:.1f} hPa (ring model).

## How far the data can be pushed (17:04Z reading + measured SAR winds, no profile model; `bounds.py`)

17:04Z reading at {BD['r_buoy']:.1f} km effective distance.

| Assumptions, increasingly adverse | Drop inside the buoy | Central pressure at most |
|---|---|---|
{bnd}

## Buoy vs SAR pressure rise (`gapcheck.py`)

Measured rise ÷ rise predicted from the 17:33Z SAR winds.

| Pair | Radii (km) | Flat factor 0.85 | Log-layer α(r) |
|---|---|---|---|
{gap}

## SAR passes (NOAA/STAR level-2, 500 m [B1]; retrieval [A26], cross-pol GMFs [A14, A27]; `sar/`)

| Pass | RMW (km) | Az.-mean max (kt) | Eye integral I47 | v(1.4 RMW)/max | Secondary max | Incidence at eyewall | Ring-fit guesses agreeing |
|---|---|---|---|---|---|---|---|
{sar}
| Sentinel-1D 20 Oct 21:20Z | swath edge 46 km west of the centre | | | | | | |

**Cross-sensor calibration** (Sentinel-1D / RCM-3, each about its own centre):
- 09Z pair: eyewall {CC['eyewall']['azmean_vm_ratio']:.2f} (azimuthal-mean peak), {CC['eyewall']['sector_peak_ratio']:.2f} (sector peak).
- By RCM-3 speed: {cc['at_60kt']:.2f} at 60 kt, {cc['at_100kt']:.2f} at 100 kt, {cc['at_140kt']:.2f} at 140 kt ({cc['slope_per_10kt']:+.4f} per 10 kt).
- 21Z, outer storm only: {CC21['ratio_mean']:.3f} ± {CC21['ratio_sd']:.3f}.
- The buoy favours the RCM-3 level: an S1D-level eyewall cannot produce 909.4 hPa at the measured distance. S1D is used for shape only.

## Running

`model/` holds every script with its inputs and results side by side; all paths are relative to the script folder.
- Reproduce the numbers and figures from the saved results (~3 min): `cd model && python3 analyze.py && python3 cfits.py && python3 fig1.py && python3 fig2.py && python3 make_readme.py`
- Full rerun: `./run_all.sh` (~3 h on 2 cores; the Monte Carlo resumes after an interruption). Replaying saved trials by seed reproduces them exactly.
  `gen_gradref.py` is a fixed-point step: rerunning it moves the reference gradients by < 0.01 hPa/km.
- SAR preprocessing needs the STAR level-2 files (names and sha256 in `model/sar/sar_files.json`): `python3 model/sar/extract_all.py /path/to/files`.

Directories: `model/` (scripts, inputs, results, `sar/`), `figures/`, `data_source/` (spreadsheet and the script that builds `model/inputs.json`),
`archive/` (v3–v10).

## Version history

1. Single Holland fit, IR centre only: unconstrained (~850–905).
2. Two-ring Holland plus SAR/ARCHER/MW constraints: 887 (875–901).
3. Multistart search plus JTWC-track check: 885 (872–896).
4. Tide background and two model families: 877 (864–890); superseded.
5. Synthetic smear correction, three-feature model: 889 (875–900).
6. Radially varying air density, ρ = p/(R_d·T_v), proposed by Evan: 892 (879–902).
7. RCM-3 21:15Z level-2 SAR: 880 (872–889).
8. Level-2 SAR at 09:20Z, time interpolation, Sentinel-1D cross-calibration, leave-one-out: 878 (870–887).
9. Log-layer 10-m to gradient conversion α(r), proposed by Evan; 6600-trial Monte Carlo: 879 (871–887).
10. Robust (Student-t) reading errors; gradient-level RMW; 7100 trials: 884 (876–892).
11. **Current:** centre track model with wander and oval eyewall from SAR; Sentinel-1D 09:09Z shape; SAR eye table; model weights from
    leave-one-out prediction; external-review fixes: **{fin[2]:.0f} ({fin[1]:.0f}–{fin[3]:.0f})**.
"""
txt+=REFS
open(os.path.join(H,'README.md'),'w').write(txt); print('README.md written,',len(txt),'chars')
