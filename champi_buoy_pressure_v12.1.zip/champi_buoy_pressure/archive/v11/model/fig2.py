# Figure 2: central pressure and its uncertainty (v11)
import sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
HERE=os.path.dirname(os.path.abspath(__file__))
F=json.load(open(os.path.join(HERE,'final.json'))); MC=json.load(open(os.path.join(HERE,'mc11.json'))); SC=json.load(open(os.path.join(HERE,'scan_v11.json')))
BD=json.load(open(os.path.join(HERE,'bounds.json'))); WJ=json.load(open(os.path.join(HERE,'weights.json')))
def curve(name):
    d=sorted([r for r in SC if r['name']==name],key=lambda r:r['Pc']); return np.array([r['Pc'] for r in d]),np.array([r['chi2'] for r in d]),d
fig=plt.figure(figsize=(23,23)); gs=fig.add_gridspec(3,3,width_ratios=[1,1,1.05],height_ratios=[1,1.35,0.5],hspace=0.5,wspace=0.42,top=0.9)
A1=fig.add_subplot(gs[0,0]); A2=fig.add_subplot(gs[0,1]); A3=fig.add_subplot(gs[0,2]); gb=gs[1,:].subgridspec(1,3,width_ratios=[1,0.62,1.75],wspace=0.0)
B1=fig.add_subplot(gb[0,0]); B2=fig.add_subplot(gb[0,2]); C1=fig.add_subplot(gs[2,1:])
JT=F['jtwc_1733']; R=F['runs']; w=F['weights']
# (a) profile likelihood, the Monte Carlo likelihood (peak-wind constraint, Student-t errors)
for nm,c,ls,lw,lab in (('T_gp',DBL,'-',2.8,'ring model: SAR eye shape + secondary ring (weight %.2f)'%w['T']),('T_bt',DBL,'--',1.6,'  same, JTWC best-track positions'),
                       ('U_gp',GRN,'-',1.5,'SAR eye shape, no secondary ring (weight %.2f)'%w['U']),('A_gp',ORA,'-',1.5,'two-ring Holland (weight %.2f)'%w['A']),
                       ('T_gp_novg',GRY,':',1.8,'ring model without the peak-wind constraint')):
    p,cc,_=curve(nm); A1.plot(p,cc-cc.min(),color=c,ls=ls,lw=lw,label=lab)
for lv,tx in ((1,'68%'),(3.84,'95%')): A1.axhline(lv,color=INK2,lw=0.9,ls=':'); A1.text(839,lv+0.15,tx,fontsize=10.5,color=INK2)
A1.axvline(JT,color=RED,lw=1.4,ls='--'); A1.text(JT+0.8,0.15,'JTWC\n%.0f hPa'%JT,fontsize=10.5,color=RED,va='bottom',ha='left')
A1.set_xlim(838,911); A1.set_ylim(0,10); A1.set_xlabel('central pressure at 17:33Z (hPa)'); A1.set_ylabel('misfit above each model\'s best fit (Δχ²)')
A1.set_title('a   Fit quality vs central pressure\n     (each curve relative to its own best fit)',loc='left',fontweight='bold')
A1.legend(loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=1,frameon=False,fontsize=9.6)
# (b) wind-pressure relation implied by the buoy (structure-only scan: no intensity input)
for nm,c,lab,lw in (('T_gp_novg',DBL,'buoy + satellite structure, no wind input (band: α 0.84–0.93, +4–20 kt)',2.8),('T_gp',BLU,'with the peak-wind constraint',1.6)):
    _,_,d=curve(nm); pc=np.array([r['Pc'] for r in d]); vg=np.array([r['vg'] for r in d]); vg=np.array([np.median(vg[max(0,i-1):i+2]) for i in range(len(vg))])
    if nm=='T_gp_novg': A2.fill_betweenx(pc,0.837*vg+4,0.934*vg+20,color=c,alpha=0.12,lw=0)
    A2.plot(0.885*vg+10,pc,color=c,lw=lw,label=lab)
CON=[r for r in json.load(open(os.path.join(HERE,'fits_constrained.json'))) if r['name']=='T_con_gp' and r['tag']=='median'][0]
A2.plot(0.885*CON['vg']+10,CON['Pc'],'o',ms=12,color=BLU,mec=INK,mew=1.2,zorder=7,label='final fit (median)')
A2.axvspan(144,158,color=GRY,alpha=0.12,lw=0,label='peak-wind constraint 151 ± 7 kt')
pts=[('JTWC best track 18Z',160,895,RED,'*',16),('JTWC best track 12Z',155,902,RED,'*',12),('D-MINT ATMS 17:02Z',147,906,INK2,'D',8),('D-MINT ATMS 16:41Z',150,907,INK2,'D',8)]
for lab,v,p_,c,mk,ms in pts: A2.plot(v,p_,mk,ms=ms,color=c,mec=INK,mew=0.8,label=lab,zorder=6)
vv=np.linspace(120,200,100); A2.plot(vv,1010-(vv/6.7)**(1/0.644),color=INK2,lw=1.0,ls='--',label='Atkinson–Holliday 1977 (context only)')
A2.set_xlim(120,200); A2.set_ylim(912,840); A2.set_xlabel('equivalent peak 1-min surface wind (kt)'); A2.set_ylabel('central pressure (hPa)')
A2.set_title('b   Wind–pressure relation implied by the buoy\n     (1-min ≈ 0.885 × gradient + 10 kt)',loc='left',fontweight='bold')
A2.legend(loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=2,frameon=False,fontsize=9.4)
# (c) Monte Carlo
pick=lambda tg: np.array([d['Pc'] for d in MC if d['tag']==tg])
wi=pick('primary'); so=pick('structure_only'); o4=pick('offset4'); sA=pick('alt_A'); sU=pick('alt_U')
allv=np.concatenate([wi,sU,sA]); allw=np.concatenate([np.full(len(wi),w['T']/len(wi)),np.full(len(sU),w['U']/len(sU)),np.full(len(sA),w['A']/len(sA))])
bins=np.arange(838,914,2)
A3.hist(allv,bins=bins,weights=allw,density=True,color=LBL,edgecolor=SURF,lw=0.8,label='combined: three models weighted (%d trials)'%len(allv))
A3.hist(wi,bins=bins,density=True,histtype='step',color=DBL,lw=1.8,label='ring model alone (%d)'%len(wi))
A3.hist(so,bins=bins,density=True,histtype='step',color=GRY,lw=2,label='ring model, structure only (%d)'%len(so))
A3.hist(o4,bins=bins,density=True,histtype='step',color=PUR,lw=2,ls='--',label='check: flat ±4 km centre error (%d)'%len(o4))
pq=[F['lo95'],F['lo68'],F['median'],F['hi68'],F['hi95']]; ymax=A3.get_ylim()[1]
A3.axvspan(pq[1],pq[3],color=BLU,alpha=0.10,lw=0); A3.axvline(pq[2],color=DBL,lw=2.4)
A3.text(pq[2],ymax*1.03,'combined median %.0f hPa\n68%%: %.0f–%.0f   95%%: %.0f–%.0f\n(three profile models, leave-one-out weights)'%(pq[2],pq[1],pq[3],pq[0],pq[4]),ha='center',va='bottom',fontsize=12,fontweight='bold',color=DBL,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=2))
A3.axvline(JT,color=RED,lw=1.6,ls='--'); A3.text(JT+1.0,ymax*0.62,'JTWC %.0f hPa'%JT,fontsize=10.5,color=RED,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=1.5))
A3.set_xlim(838,914); A3.set_ylim(0,ymax*1.75); A3.set_xlabel('central pressure at 17:33Z (hPa)'); A3.set_ylabel('probability density (per hPa)')
A3.set_title('c   Monte Carlo over all uncertain inputs',loc='left',fontweight='bold'); A3.legend(loc='upper left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.97,fontsize=9.3)
# (d) budget
lab={'shape':'inner-eye wind shape','decay':'wind decay outside eyewall (SAR)','ring':'secondary wind maximum (SAR)','alpha':'10-m to gradient conversion (log layer)',
     'Rm':'radius of max wind (incl. tilt)','center':'centre position (track + wander)','ellipse':'oval eyewall (size, orientation)','noise':'reading scatter',
     'bias':'barometer calibration','Pn':'environmental pressure','intensity':'peak surface wind (±8 kt, incl. SAR calibration)','family':'profile-shape choice (3 models)',
     'density':'air density profile (warm eye, cool eyewall)'}
Bd=F['budget']; items=sorted(Bd.items(),key=lambda kv:kv[1]); y=np.arange(len(items))
B1.barh(y,[v for _,v in items],color=[ORA if k=='family' else BLU for k,_ in items],height=0.62)
for yy,(k,v) in zip(y,items): B1.text(v+0.12,yy,'%.1f'%v,va='center',fontsize=11)
B1.set_yticks(y); B1.set_yticklabels([lab[k] for k,_ in items]); B1.grid(axis='y',visible=False)
B1.axvline(F['total_sd'],color=DBL,lw=1.6,ls='--'); B1.text(F['total_sd']+0.12,-0.6,'combined ±%.1f hPa (1σ)'%F['total_sd'],fontsize=11,color=DBL)
B1.set_xlim(0,max(max(v for _,v in items),F['total_sd'])*1.3); B1.set_xlabel('contribution to uncertainty (hPa, 1σ)'); B1.set_title('d   Uncertainty budget (weighted over the three models)',loc='left',fontweight='bold')
# (e) comparison
qr=lambda tg: (R[tg]['q'][2],R[tg]['q'][1],R[tg]['q'][3],R[tg]['q'][0],R[tg]['q'][4])
sq=R['sar_check_interp']['q']; nf=R['nat_fitweighted']['q']; A_=F['alt_weights']
est=[('This work: combined estimate',F['median'],F['lo68'],F['hi68'],F['lo95'],F['hi95'],BLU),
     ('Ring model alone (SAR eye + secondary ring)',*qr('primary'),BLU),
     ('Two-ring Holland alone',*qr('alt_A'),BLU),('SAR eye, no secondary ring, alone',*qr('alt_U'),BLU),
     ('Ring model, structure only (no wind input)',*qr('structure_only'),GRY),
     ('Check: SAR winds integrated inward (no profile model)',sq[2],sq[1],sq[3],sq[0],sq[4],GRN),
     ('No interpolation: 21:15Z structure only (ring model)',*qr('nat2115'),GRN),('No interpolation: 09Z structure only (ring model)',*qr('nat09'),GRN),
     ('No interpolation: both, weighted by fit (ring model)',nf[2],nf[1],nf[3],nf[0],nf[4],GRN),
     ('Check: flat ±4 km centre error (reviewer; ring model)',*qr('offset4'),PUR),('Check: sub-hourly trochoidal wobble ≤3 km',*qr('trochoid'),PUR),
     ('Check: v10 geometry (circular eyewall, ±2 km)',*qr('v10_geometry'),PUR),('Check: JTWC best-track positions',*qr('bt'),ORA),
     ('Weights: fit + parameter penalty (AIC)',A_['aic']['q'][2],A_['aic']['q'][1],A_['aic']['q'][3],A_['aic']['q'][0],A_['aic']['q'][4],GRY),
     ('Weights: BIC (strongest penalty)',A_['bic']['q'][2],A_['bic']['q'][1],A_['bic']['q'][3],A_['bic']['q'][0],A_['bic']['q'][4],GRY),
     ('Weights: equal',A_['equal']['q'][2],A_['equal']['q'][1],A_['equal']['q'][3],A_['equal']['q'][0],A_['equal']['q'][4],GRY),
     ('Check: Gaussian reading errors',*qr('gauss'),GRY),('Check: power-law eye',*qr('powerlaw_eye'),GRY),
     ('Previous version (v10)',884.1,875.8,892.1,867.2,899.1,GRY),
     ('JTWC best track (interp. 17:33Z)',JT,None,None,None,None,RED),('D-PRINT (16:30–17:30Z)',903,902,904,None,None,INK2),
     ('ATMS (SATCON plot, ~17Z)',903,None,None,None,None,INK2),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,None,None,INK2),('SATCON (~17Z)',910,None,None,None,None,INK2)]
n=len(est); NOURS=19
for i,(nm,v,l1,h1,l2,h2,col) in enumerate(est):
    yy=n-1-i; ours=i<NOURS
    if l2 is not None: B2.plot([l2,h2],[yy,yy],color=col,lw=3,alpha=0.4,solid_capstyle='round')
    if l1 is not None: B2.plot([l1,h1],[yy,yy],color=col,lw=9 if ours else 4,alpha=0.45,solid_capstyle='round')
    B2.plot(v,yy,'o',ms=11 if ours else 8,color=col,mec=SURF,mew=1.5)
    txt=('%.0f  (68%%: %.0f–%.0f, 95%%: %.0f–%.0f)'%(v,l1,h1,l2,h2)) if ours else ('%.0f'%v if l1 is None else '%g–%g'%(l1,h1))
    B2.text(v if ours else v+1.0,yy+0.3,txt,fontsize=10.6,ha='center' if ours else 'left')
B2.axvline(909.4,color=RED,lw=1.3,ls=':'); B2.text(910.0,n-1.3,'buoy reading\n909.4 hPa,\n~%.0f km from\ncentre'%CON['r17'],fontsize=10.5,va='top')
B2.set_yticks(range(n)); B2.set_yticklabels([e[0] for e in est][::-1],fontsize=10.8); B2.set_xlim(845,925); B2.set_ylim(-0.7,n-0.2); B2.grid(axis='y',visible=False)
B2.set_xlabel('central pressure near 17Z, 20 Oct (hPa)'); B2.set_title('e   Comparison with checks and operational/satellite estimates   (thick bar 68%, thin bar 95%; checks use the ring model)',loc='left',fontweight='bold')
# (f) how far the data can be pushed
rows=BD['rows']; yb=np.arange(len(rows))[::-1]
for yy,(lab_,d,pc) in zip(yb,rows):
    C1.barh(yy,pc-BD['p_buoy'],left=BD['p_buoy'],color=BLU if pc<JT else ORA,alpha=0.55,height=0.6)
    C1.text(pc-0.4,yy,'%.1f hPa'%pc,ha='left',va='center',fontsize=11.5,fontweight='bold')
C1.set_yticks(yb); C1.set_yticklabels([r_[0] for r_ in rows],fontsize=11); C1.grid(axis='y',visible=False)
C1.axvline(JT,color=RED,lw=1.6,ls='--'); C1.text(JT-0.3,-0.75,'JTWC %.0f'%JT,color=RED,fontsize=11,va='center')
C1.set_xlim(BD['p_buoy'],870); C1.set_ylim(-1.0,len(rows)-0.4)
C1.set_xlabel('highest central pressure consistent with the 17:04Z reading (909.4 hPa at %.0f km effective distance)\nand the measured SAR winds (hPa)'%BD['r_buoy'])
C1.set_title('f   How far the data can be pushed: increasingly adverse assumptions, no profile model',loc='left',fontweight='bold')
fig.suptitle('Typhoon Champi (29W) — central pressure at 17:33Z, 20 October 2026, from the drifting-buoy eyewall pass',x=0.01,y=1.0,ha='left',fontsize=17,fontweight='bold')
fig.text(0.01,0.975,'Three storm profiles in gradient balance (SAR-measured eye shape with the secondary wind ring; the same without the ring; a two-ring Holland profile), combined with weights\n'
         'from how well each predicts held-out near-core buoy readings (leave-one-out). Student-t reading errors; centre from a track model of the IR and SAR/ATMS fixes with wander; oval eyewall from SAR.\n'
         'Storm structure from 500-m SAR winds: 09Z (Sentinel-1D shape, RCM-3 wind level) and 21:15Z (RCM-3), interpolated to 17:33Z; single-pass results shown in (e).\n'
         'JTWC and satellite pressures used for comparison only.',fontsize=12,color=INK2,va='top')
fig.text(0.01,-0.005,'Sources: SAR winds NOAA/NESDIS/STAR (RCM imagery © Government of Canada 2026; contains modified Copernicus Sentinel data); best track JTWC (provisional working best track); D-PRINT, D-MINT, SATCON, ADT/AiDT: UW-Madison CIMSS; Atkinson & Holliday (1977). Full references in README.',fontsize=10.5,color=INK2)
fig.savefig(os.path.join(HERE,'fig2_central_pressure.png'),dpi=150,bbox_inches='tight'); print('saved')
