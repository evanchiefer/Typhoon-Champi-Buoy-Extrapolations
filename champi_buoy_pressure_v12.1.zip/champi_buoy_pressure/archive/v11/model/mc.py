# v11 fitting with the central pressure free, and the Monte Carlo trial.
# A trial redraws the uncertain inputs (as prior centres or data perturbations) and refits with Pc free. Sources:
#   noise (reading scatter), bias (barometer), center (track + wander: offset and wander prior centres drawn from the track covariance),
#   ellipse (eyewall ellipticity and orientation), Rm (surface RMW and tilt k ~ U(1, 1.1)), shape (eye exponent / eye-table power),
#   decay (SAR v(1.4RMW), v(2RMW)), ring (SAR secondary maximum), alpha (log-layer 10-m to gradient conversion: one draw sets v14, v20,
#   the secondary maximum and the peak-wind constraint together), Pn (environmental pressure), intensity (peak surface wind), density.
# Job = dict(fam, track, sources, seed, vg, variant, dens, nu, tscale, sigpos, wander, ell, troch, soff, tag).
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import *
import logwind as LW
SRC=('noise','bias','center','ellipse','Rm','shape','decay','ring','alpha','Pn','intensity','density')
WV={'interp':(LW.W2115,0.10),'nat2115':(1.0,0.0),'nat09':(0.0,0.0)}     # weight of the 21:15Z pass (and its spread) per structure variant
GM0={v:LW.grad_metrics(LW.DEF,WV[v][0]) for v in WV}
CB=json.load(open(os.path.join(HERE,'cbest.json'))) if os.path.exists(os.path.join(HERE,'cbest.json')) else {}
DEF=dict(track='gp',sources=SRC,seed=0,vg=True,variant='interp',dens='thermo',nu=ROBUST_NU,tscale=1.0,sigpos=None,wander=True,ell=True,troch=None,soff=None,tag='',nrand=1)
TOL=1e-6      # least-squares tolerances (ftol, xtol, gtol): central pressures agree with 1e-8 to 0.1 hPa at half the cost
def config_key(j): return '%s|%s|%s|%s'%(j['fam'],j['track'],j['variant'],'vg' if j['vg'] else 'novg')
def build(j,rng=None):
    """prior dictionary, data and reading sd for a job; rng=None gives the unperturbed (MAP) configuration"""
    S=j['sources'] if rng is not None else (); v=j['variant']; base=PRIS[v]; pri=dict(base)
    pri['wander']=j['wander']; pri['ell']=j['ell']
    if j['soff'] is not None: pri['soff']=j['soff']
    s=sig_obs(j['sigpos'],j['track']); data=P.copy()
    if 'noise' in S: data=data+rng.normal(0,s)
    if 'bias' in S: data=data+rng.normal(0,0.5)                     # drifter barometer accuracy (~+-1 hPa at 2 sigma)
    if 'center' in S:
        if has_wander(j['track'],pri): pri['dlt0']=np.c_[LWIN@rng.normal(size=NW),LWIN@rng.normal(size=NW)]
        else: pri['off']=TRACKS[j['track']][2]+rng.normal(0,pri.get('soff',TRACKS[j['track']][3]),2)
    if 'ellipse' in S: pri['e0']=(max(0.0,rng.normal(*base['e0'])),base['e0'][1]); pri['th0']=(rng.normal(*base['th0']),base['th0'][1])
    if 'Rm' in S: pri['Rm']=(rng.normal(*base['Rm_sfc'])*rng.uniform(*TILT),base['Rm'][1])
    if 'shape' in S:
        z=rng.normal(); pri['n']=(base['n'][0]+z*base['n'][1],base['n'][1]); pri['I']=(base['I'][0]-z*base['I'][1],base['I'][1]); pri['s']=(base['s'][0]+z*base['s'][1],base['s'][1])
    c=dict(v14=base['v14'][0],v20=base['v20'][0],vsec=base['vsec'][0],R2=base['R2'][0]); arm=base['alpha_rm'][0]; g0=GM0[v]
    if 'alpha' in S:
        w0,wsd=WV[v]; gm=LW.grad_metrics(LW.draw(rng),np.clip(rng.normal(w0,wsd),0,1) if wsd>0 else w0)
        for k in ('v14','v20','vsec'): c[k]+=gm[k]-g0[k]
        c['R2']=base['R2'][0]*gm['x2']/g0['x2']; arm=gm['alpha_rm']
    if 'decay' in S: c['v14']+=rng.normal(0,SIG_MEAS['v14']); c['v20']+=rng.normal(0,SIG_MEAS['v20'])
    if 'ring' in S: c['vsec']+=rng.normal(0,SIG_MEAS['vsec']); c['R2']+=rng.normal(0,SIG_MEAS['R2'])
    for k in c: pri[k]=(c[k],base[k][1])
    if j['vg']:
        vs=base['VSFC'][0]+(rng.normal(0,base['VSFC'][1]) if 'intensity' in S else 0.0); pri['Vg']=(vs/arm,base['VG'][1])
    if 'Pn' in S: pri['Pn']=(rng.normal(*base['Pn']),base['Pn'][1])
    pri['dens']=dict(DENS,mode=j['dens'])
    if 'density' in S:
        pri['dens'].update(dTc=rng.uniform(0.5,4.5),dTw=rng.uniform(0.0,2.5),Tv_env=rng.normal(305.0,1.5),rwf=rng.uniform(0.5,1.2),r0f=rng.uniform(0.5,1.5),Rout=rng.uniform(200,600))
    if j['troch'] is not None and rng is not None: pri['troch']=(rng.uniform(0,j['troch'][0]),rng.uniform(*j['troch'][1:]),rng.uniform(0,2*np.pi))
    return pri,data,s
def fit_free(j,pri,data,s,starts_x,max_nfev=6000,tol=None):
    fam,track=j['fam'],j['track']
    def res(q): return make_res(fam,q[0],track,pri=pri,data=data,sig=s,nu=j['nu'],tscale=j['tscale'])[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track,pri=pri); lb=np.r_[800.0,lb]; ub=np.r_[912.0,ub]
    best=None; sols=[]
    for q0 in starts_x:
        try: r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=max_nfev,ftol=tol or TOL,xtol=tol or TOL,gtol=tol or TOL)
        except Exception: continue
        sols.append((float(r.x[0]),float(2*r.cost)))
        if best is None or r.cost<best.cost: best=r
    return best,sols
def default_starts(j,pri,rng,nrand=3):
    """starts: constrained best fits of this configuration (several Pc), with the trial's offset/ellipse/wander prior centres, plus random"""
    fam,track=j['fam'],j['track']; _,_,lb,ub=make_res(fam,880.0,track,pri=pri); bx=np.array(base_x(fam,track,pri))
    if 'dlt0' in pri: bx[-2*NW:]=np.r_[pri['dlt0'][:,0],pri['dlt0'][:,1]]
    st=[]
    for row in CB.get(config_key(j),[]):
        x=np.array(row['x'])[:len(lb)]; nb=NBASE[fam]; x[nb-8:nb-6]=pri.get('off',x[nb-8:nb-6])
        if 'dlt0' in pri and has_wander(track,pri): x[-2*NW:]=x[-2*NW:]*0.5+bx[-2*NW:]*0.5
        st.append(np.r_[row['Pc'],np.clip(x,lb+1e-6,ub-1e-6)])
    if not st: st=[np.r_[pc,q] for pc in (870.0,886.0,900.0) for q in starts(fam,track,2,int(rng.integers(1e6)),lb,ub,pri)[:2]]
    pc0=st[0][0]
    for q in starts(fam,track,nrand*4,int(rng.integers(1e6)),lb,ub,pri)[-nrand:]: st.append(np.r_[pc0+rng.normal(0,8),q])
    return st
def trial(job):
    j=dict(DEF); j.update(job); rng=np.random.default_rng(j['seed'])
    pri,data,s=build(j,rng); best,sols=fit_free(j,pri,data,s,default_starts(j,pri,rng,nrand=j['nrand']))
    pcs=np.array([p for p,c in sols]); cs=np.array([c for p,c in sols]); near=(cs<2*best.cost+0.05)
    out=dict(fam=j['fam'],track=j['track'],sources=list(j['sources']),seed=int(j['seed']),vg=bool(j['vg']),variant=j['variant'],dens=j['dens'],nu=float(j['nu']),
             tscale=float(j['tscale']),sigpos=j['sigpos'],wander=bool(j['wander']),ell=bool(j['ell']),troch=j['troch'],soff=j['soff'],tag=j['tag'],
             Pc=float(best.x[0]),chi2=float(2*best.cost),n_starts=len(sols),sols=sols,spread_at_best=float(pcs[near].max()-pcs[near].min()) if near.sum()>1 else 0.0)
    return out
def map_fit(job,nrand=8,seed=1,with_summary=True):
    """unperturbed fit (maximum a posteriori) of a configuration"""
    j=dict(DEF); j.update(job); rng=np.random.default_rng(seed); pri,data,s=build(j,None)
    st=default_starts(j,pri,rng,nrand=nrand)
    best,sols=fit_free(j,pri,data,s,st,tol=1e-8)
    out=dict(job={k:(v if not isinstance(v,tuple) else list(v)) for k,v in j.items()},Pc=float(best.x[0]),chi2=float(2*best.cost),x=[float(v) for v in best.x])
    if with_summary:
        res,unpack,_,_=make_res(j['fam'],best.x[0],j['track'],pri=pri,sig=s,nu=j['nu'],tscale=j['tscale'])
        class Bst: pass
        b=Bst(); b.x=best.x[1:]; b.cost=best.cost; d=summarize(j['fam'],b,unpack,best.x[0],j['track'],res=res,pri=pri); out.update(summary=d)
        rv=res(best.x[1:]); out['nres']=len(rv); out['npar']=len(best.x)
    return out
