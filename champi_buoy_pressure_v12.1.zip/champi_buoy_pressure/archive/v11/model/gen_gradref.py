# Reference pressure gradient at each buoy reading (sets the position term of the observation error), from a primary-model fit
# (SAR eye table + secondary ring, 'gp' track with wander and elliptical eyewall, peak-wind constraint) at 886 hPa.
import sys, os, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from core import *
pri=dict(PRI); pri['Vg']=VG_PRIOR
best,costs,unpack=solve('T',886.0,'gp',n_rand=12,seed=5,pri=pri); res,_,_,_=make_res('T',886.0,'gp',pri=pri); u=unpack(best.x)
sx,sy=res.shift(u,t); dx,dy=geom('gp',sx,sy); re,r=r_eff(dx,dy,u['e0'],u['th0']); e=0.25
dPdr=-(res.deficit(u,re+e)-res.deficit(u,np.maximum(re-e,0.01)))/(2*e)
json.dump(dict(dPdr=[float(v) for v in dPdr],r=[float(v) for v in r],source='T gp fit at 886 hPa (v11)'),open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'grad_ref.json'),'w'))
for i in range(13,23): print('%5.2fh r=%5.1f (eff %5.1f) dP/dr=%.2f hPa/km'%(t[i],r[i],re[i],dPdr[i]))
