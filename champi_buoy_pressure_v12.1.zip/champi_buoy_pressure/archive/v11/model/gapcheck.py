# Buoy pressure rise between pairs of readings vs the rise predicted by the 17:33Z SAR wind profile in gradient balance
# ((a) flat surface factor 0.85, (b) log-layer alpha(r)). v11: the SAR surface profile is placed at the surface RMW (26.4 km), distances
# from the v11 track mean and elliptical eyewall (effective radius).
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import P,geom,r_eff,FCOR,RD,PRI,ST
import logwind as LW
s=ST['interp']; sh=LW.sfc_shape(); Vm=s['Vm_rcm']*0.514444; Rs=s['Rm']
dx,dy=geom('gp',0.0,0.0); r,_=r_eff(dx,dy,PRI['e0'][0],PRI['th0'][0])
def rise(r1,r2,alpha_fn):
    rr=np.linspace(min(r1,r2),max(r1,r2),400); x=rr/Rs; v=np.interp(x,LW.XG,sh)*Vm/alpha_fn(x); rho=930*100/(RD*305.0)
    return np.trapezoid(rho*(v**2/(rr*1e3)+FCOR*v),rr*1e3)/100
pairs=[('17:04 -> 16:04',17,16),('18:04 -> 19:04',18,19),('17:04 -> 15:00',17,15),('18:04 -> 20:04',18,20),('16:04 -> 15:00',16,15),('19:04 -> 20:04',19,20)]
print('pair              radii (km)    buoy rise   SAR flat 0.85   ratio    SAR log alpha(r)   ratio')
out=[]
for lab,i,j in pairs:
    m=P[j]-P[i]; a=rise(r[i],r[j],lambda x:0.85+0*x); b=rise(r[i],r[j],lambda x:LW.alpha_x(x,LW.DEF))
    out.append((lab,float(r[i]),float(r[j]),float(m),float(a),float(b)))
    print('%-16s %5.1f-%5.1f     %5.1f        %5.1f        %.2f        %5.1f           %.2f'%(lab,r[i],r[j],m,a,m/a,b,m/b))
json.dump(out,open(os.path.join(HERE,'gapcheck.json'),'w'),indent=1)
