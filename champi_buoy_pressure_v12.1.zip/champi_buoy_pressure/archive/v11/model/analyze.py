# v11: uncertainty budget, family weights, combined estimate (weighted mixture of Monte Carlo samples), checks -> final.json
import json, numpy as np, os
D=os.path.dirname(os.path.abspath(__file__))
MC=json.load(open(os.path.join(D,'mc11.json'))); INP=json.load(open(os.path.join(D,'inputs.json')))
WJ=json.load(open(os.path.join(D,'weights.json'))); SARC=json.load(open(os.path.join(D,'sarcheck.json'))); CB=json.load(open(os.path.join(D,'cbest.json')))
jh=np.array([x[0] for x in INP['jtwc_p']]); jp=np.array([x[1] for x in INP['jtwc_p']]); JT=float(np.interp(17.55,jh,jp))
FLOOR=800.5
def rsd(v): p=np.percentile(v,[16,84]); return float((p[1]-p[0])/2)
def tag(tg): return np.array([d['Pc'] for d in MC if d['tag']==tg])
def summ(v): pq=np.percentile(v,[2.5,16,50,84,97.5]); return dict(n=int(len(v)),q=[float(x) for x in pq],sd=rsd(v),p_below_jtwc=float((v<JT).mean()),at_floor=int((v<FLOOR).sum()))
WJ0=json.load(open(os.path.join(D,'weights.json')))['weights']['pbma']
budget={}; budget_by_family={}
for src in ('noise','bias','center','ellipse','Rm','shape','decay','ring','alpha','Pn','intensity','density'):
    sd={'T':rsd(tag('budget:'+src)),'U':rsd(tag('budgetU:'+src)),'A':rsd(tag('budgetA:'+src))}; budget_by_family[src]=sd
    budget[src]=float(np.sqrt(sum(WJ0[f]*sd[f]**2 for f in sd)))      # weighted over the three profile models
    print('  %-9s %.2f  (ring %.2f, no ring %.2f, Holland %.2f)'%(src,budget[src],sd['T'],sd['U'],sd['A']))
tags=sorted({d['tag'] for d in MC if not d['tag'].startswith('budget')})
runs={tg:summ(tag(tg)) for tg in tags}
conv={tg:int(sum(1 for d in MC if d['tag']==tg and d['spread_at_best']>1.0)) for tg in tags}
for tg in tags:
    r=runs[tg]; print('%-15s n=%4d median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | P(<%.1f)=%.3f | at floor %d | multistart disagreement >1 hPa: %d'%(tg,r['n'],r['q'][2],r['q'][1],r['q'][3],r['q'][0],r['q'][4],JT,r['p_below_jtwc'],r['at_floor'],conv[tg]))
for k in ('interp','nat2115','nat09'):
    if k in SARC: runs['sar_check_'+k]=dict(q=SARC[k]['both']); q=SARC[k]['both']; print('SAR check %-8s median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(k,q[2],q[1],q[3],q[0],q[4]))
S={'T':tag('primary'),'U':tag('alt_U'),'A':tag('alt_A')}
def wq(wt,samples=S,ps=(2.5,16,50,84,97.5)):
    ks=[k for k in samples if wt.get(k,0)>0]; v=np.concatenate([samples[k] for k in ks]); ww=np.concatenate([np.full(len(samples[k]),wt[k]/len(samples[k])) for k in ks])
    o=np.argsort(v); c=np.cumsum(ww[o]); c/=c[-1]; return [float(np.interp(p/100,c,v[o])) for p in ps], float(ww[v<JT].sum()/ww.sum())
W=WJ['weights']; w=W['pbma']          # headline: leave-one-out predictive weights (pseudo-BMA+); AIC, BIC, equal, stacking reported
meds={k:float(np.median(S[k])) for k in S}; mbar=sum(w[k]*meds[k] for k in w); budget['family']=float(np.sqrt(sum(w[k]*(meds[k]-mbar)**2 for k in w)))
print('  family weights (leave-one-out pseudo-BMA+, headline):',{k:round(v,3) for k,v in w.items()},'| structural sd %.2f'%budget['family'])
alt={}
for lab in ('pbma','aic','chi2','bic','loo','stacking','equal'):
    qq,pb=wq(W[lab]); alt[lab]=dict(weights=W[lab],q=qq,p_below_jtwc=pb); print('weights %-6s median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | P(below JTWC) %.3f'%(lab,qq[2],qq[1],qq[3],qq[0],qq[4],pb))
qq,pb=wq({'T':1.0}); alt['primary_only']=dict(q=qq,p_below_jtwc=pb)
# no-interpolation envelope: single-pass structure runs, and their combination weighted by the best-fit chi2 of each (illustrative)
c21=CB['T|gp|nat2115|vg'][0]['chi2']; c09=CB['T|gp|nat09|vg'][0]['chi2']; w21=1/(1+np.exp(-0.5*(c09-c21))); NI={'n21':tag('nat2115'),'n09':tag('nat09')}
qn,pn=wq({'n21':w21,'n09':1-w21},NI); runs['nat_fitweighted']=dict(q=qn,p_below_jtwc=pn,w2115=float(w21),chi2=[c21,c09])
print('no interpolation: 21:15Z only median %.1f, 09Z only %.1f, fit-weighted (w21 %.2f) %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(runs['nat2115']['q'][2],runs['nat09']['q'][2],w21,qn[2],qn[1],qn[3],qn[0],qn[4]))
# convergence: the first 150 ring-model trials refitted with 10 starts instead of 4 (same seeds, same perturbations)
pm={d['seed']:d['Pc'] for d in MC if d['tag']=='primary'}; cm={d['seed']:d['Pc'] for d in MC if d['tag']=='conv10'}
dd=np.array([cm[k]-pm[k] for k in cm if k in pm]); conv_check=dict(n=int(len(dd)),moved_over_1hPa=int((np.abs(dd)>1).sum()),max_abs=float(np.abs(dd).max()) if len(dd) else 0.0,
     median_shift=float(np.median(dd)) if len(dd) else 0.0)
pmd={d['seed']:d for d in MC if d['tag']=='primary'}; cmd={d['seed']:d for d in MC if d['tag']=='conv10'}
P4=np.array([pmd[k]['Pc'] for k in sorted(pmd)]); P10=np.array([cmd[k]['Pc'] if (k in cmd and cmd[k]['chi2']<pmd[k]['chi2']) else pmd[k]['Pc'] for k in sorted(pmd)])
conv_check.update(q4=[float(x) for x in np.percentile(P4,[2.5,16,50,84,97.5])],q10=[float(x) for x in np.percentile(P10,[2.5,16,50,84,97.5])])
print('convergence check (10 vs 4 starts, %d paired trials): %d moved by more than 1 hPa (largest %.2f), median shift %+.3f'%(conv_check['n'],conv_check['moved_over_1hPa'],conv_check['max_abs'],conv_check['median_shift']))
qq,pb=wq(w)
final=dict(conv_check=conv_check,budget_by_family=budget_by_family,median=qq[2],lo68=qq[1],hi68=qq[3],lo95=qq[0],hi95=qq[4],p_below_jtwc=pb,total_sd=(qq[3]-qq[1])/2,jtwc_1733=JT,budget=budget,runs=runs,
           weights=w,alt_weights=alt,multistart=conv,n_trials=len(MC))
json.dump(final,open(os.path.join(D,'final.json'),'w'),indent=1)
print('FINAL (mixture, leave-one-out weights): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | 1-sigma %.1f | P(below JTWC) %.3f'%(qq[2],qq[1],qq[3],qq[0],qq[4],final['total_sd'],pb))
