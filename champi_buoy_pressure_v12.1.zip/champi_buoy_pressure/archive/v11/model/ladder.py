# Unperturbed (MAP) fits for a ladder of configurations: shows what each v11 change does to the central pressure and to the 18:04Z misfit.
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
L=[('v10-like geometry: hourly-fix track, offset +-2 km, circular eyewall, position sd 1.5 km',dict(fam='T',track='irf',ell=False,sigpos=1.5)),
   ('+ track from fixes with wander (gp), circular eyewall, position sd 1.5 km',dict(fam='T',track='gp',ell=False,sigpos=1.5)),
   ('+ elliptical eyewall (position sd 1.5 km)',dict(fam='T',track='gp',sigpos=1.5)),
   ('v11 primary: + position sd 1.0 km (non-circularity left after the ellipse)',dict(fam='T',track='gp')),
   ('v11, power-law eye instead of SAR eye table',dict(fam='C',track='gp')),
   ('v11, no secondary ring (SAR eye table)',dict(fam='U',track='gp')),
   ('v11, two-ring Holland',dict(fam='A',track='gp')),
   ('v11, no wander (track fixed at its mean)',dict(fam='T',track='gp',wander=False)),
   ('v11, hourly-fix track with offset +-4 km (reviewer check), elliptical',dict(fam='T',track='irf',soff=4.0)),
   ('v11, JTWC best-track positions',dict(fam='T',track='bt')),
   ('v11, no peak-wind constraint (buoy + structure only)',dict(fam='T',track='gp',vg=False)),
   ('v11, 21:15Z structure only (no interpolation)',dict(fam='T',track='gp',variant='nat2115')),
   ('v11, 09Z structure only (no interpolation)',dict(fam='T',track='gp',variant='nat09')),
   ('v11, Gaussian reading errors',dict(fam='T',track='gp',nu=0.0)),
   ('v11, Student-t rescaled to sd sigma',dict(fam='T',track='gp',tscale=float(np.sqrt(0.5)))),
   ('v11, nu = 2.5',dict(fam='T',track='gp',nu=2.5)),('v11, nu = 8',dict(fam='T',track='gp',nu=8.0))]
def run(a):
    lab,j=a; t0=time.time(); o=mc.map_fit(j,nrand=8); o['label']=lab; o['secs']=time.time()-t0; return o
if __name__=='__main__':
    sel=[int(x) for x in sys.argv[1].split(',')] if len(sys.argv)>1 else range(len(L))
    with Pool(2) as pool: out=pool.map(run,[L[i] for i in sel],chunksize=1)
    for o in out:
        d=o['summary']; r=np.array(d['resid'])
        print('%-80s Pc %.1f chi2 %5.2f | Vg %3.0f RMW %.1f | r17 %.1f r18 %.1f eff %.1f/%.1f | resid 17:04 %+.1f 18:04 %+.1f | e0 %.3f th0 %.0f | %.0fs'%(
            o['label'],o['Pc'],o['chi2'],d['vg'],d['rmw'],d['r17'],d['r18'],d['re17'],d['re18'],r[17],r[18],d['e0'],d['th0'],o['secs']),flush=True)
    fn=os.path.join(HERE,'ladder.json'); old=json.load(open(fn)) if (os.path.exists(fn) and len(sys.argv)>1) else []
    json.dump(old+out,open(fn,'w'))
