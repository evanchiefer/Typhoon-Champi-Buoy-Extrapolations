# v11 Monte Carlo job list. Each finished trial is appended to mc11.jsonl immediately; a restart skips trials already done, so a run
# interrupted by a time limit resumes where it stopped. When all trials are present, mc11.json is written.
# Usage: mc4.py [ncores]
import sys, os, json, time
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from multiprocessing import Pool
def J(tag,n,seed0,**kw): return [dict(kw,tag=tag,seed=seed0+i) for i in range(n)]
def jobs_all():
    S=mc.SRC; SO=tuple(x for x in S if x!='intensity'); L=[]
    L+=J('primary',800,3_000_000,fam='T',sources=S)                                   # SAR-shaped profile: eye table + ring, v11 track, all sources
    L+=J('alt_A',800,7_000_000,fam='A',sources=S); L+=J('alt_U',400,7_100_000,fam='U',sources=S)
    for k,src in enumerate(S): L+=J('budget:'+src,40,2_000_000+10_000*k,fam='T',sources=(src,))
    for k,src in enumerate(S): L+=J('budgetA:'+src,40,2_500_000+10_000*k,fam='A',sources=(src,)); L+=J('budgetU:'+src,40,2_700_000+10_000*k,fam='U',sources=(src,))   # per-family budgets
    L+=J('structure_only',250,4_000_000,fam='T',sources=SO,vg=False)
    L+=J('nat2115',250,6_100_000,fam='T',sources=S,variant='nat2115'); L+=J('nat09',250,6_200_000,fam='T',sources=S,variant='nat09')
    L+=J('offset4',250,6_400_000,fam='T',sources=S,track='irf',soff=4.0)
    L+=J('trochoid',200,6_500_000,fam='T',sources=S,troch=(3.0,0.5,2.0))
    L+=J('conv10',150,3_000_000,fam='T',sources=S,nrand=7)                            # convergence check: primary seeds again with 10 starts
    SEEDS={'v10_geometry':6_300_000,'no_wander':6_600_000,'powerlaw_eye':7_200_000,'bt':5_000_000,'ramp':8_000_000,'gauss':9_000_000,'tscaled':9_100_000}
    for tg,kw in (('v10_geometry',dict(track='irf',ell=False,sigpos=1.5)),('no_wander',dict(wander=False)),('powerlaw_eye',dict(fam='C')),('bt',dict(track='bt')),
                  ('ramp',dict(dens='ramp')),('gauss',dict(nu=0.0)),('tscaled',dict(tscale=0.7071067811865476))):
        L+=J(tg,120,SEEDS[tg],**dict(dict(fam='T',sources=S),**kw))
    # interleave so that every group advances together (the run is resumable and may be split over several sessions)
    from itertools import zip_longest
    G={}
    for j in L: G.setdefault(j['tag'],[]).append(j)
    return [j for grp in zip_longest(*G.values()) for j in grp if j is not None]
def key(d): return (d['tag'],int(d['seed']))
if __name__=='__main__':
    nc=int(sys.argv[1]) if len(sys.argv)>1 else 2
    JL=os.path.join(HERE,'mc11.jsonl'); jobs=jobs_all(); done=set()
    if os.path.exists(JL):
        for line in open(JL):
            try: done.add(key(json.loads(line)))
            except Exception: pass
    todo=[j for j in jobs if key(j) not in done]; print('%d done, %d to run'%(len(done),len(todo)),flush=True)
    t0=time.time()
    with Pool(nc) as pool, open(JL,'a') as fo:
        for k,d in enumerate(pool.imap_unordered(mc.trial,todo,chunksize=1)):
            fo.write(json.dumps(d)+'\n'); fo.flush()
            if k%250==0: print('%d/%d %.0f s'%(k,len(todo),time.time()-t0),flush=True)
    res=[json.loads(l) for l in open(JL)]
    if len({key(d) for d in res})>=len(jobs):
        json.dump(res,open(os.path.join(HERE,'mc11.json'),'w')); print('ALL DONE %.0f s (%d trials)'%(time.time()-t0,len(res)))
