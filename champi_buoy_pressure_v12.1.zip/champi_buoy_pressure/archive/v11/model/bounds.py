# How far the data can be pushed: the 17:04Z reading plus measured SAR winds integrated inward in gradient balance (no profile model),
# under increasingly adverse assumptions. Writes bounds.json.
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import t,lat,lon,P,geom,r_eff,FCOR,RD,PRI,ST
import logwind as LW
KTMS=0.514444
dx,dy=geom('gp',0.0,0.0); REFF,_=r_eff(dx,dy,PRI['e0'][0],PRI['th0'][0]); RB=float(REFF[17])
XG=LW.XG
def drop(variant,rb,alpha=True,level=1.0,tilt=1.0,cut=47):
    s=ST[variant]; sh=np.array(s['shape']); Rs=s['Rm']*tilt; Vm=s['Vm_rcm']*level
    xe=XG[np.argmax(sh*Vm>=cut)]; xx=np.linspace(xe,rb/Rs,600); rr=xx*Rs
    al=LW.alpha_x(xx,LW.DEF) if alpha else np.ones_like(xx); vg=np.interp(xx,XG,sh)*Vm*KTMS/al
    ve=np.interp(xe,XG,sh)*Vm*KTMS/(LW.alpha_x(xe,LW.DEF) if alpha else 1.0)
    p=np.full_like(rr,P[17])
    for it in range(3):
        Tv=305.0+2.5*np.exp(-(rr/(0.8*Rs))**2); rho=p*100/(RD*Tv)
        dp=rho*(vg**2/(rr*1e3)+FCOR*vg)*1e3; cum=np.concatenate([[0],np.cumsum((dp[1:]+dp[:-1])/2*np.diff(rr))]); p=P[17]-(cum[-1]-cum)/100
    return float(cum[-1]/100+rho[0]*ve**2/2/100)
rows=[('21:15Z structure, log-layer conversion',drop('nat2115',RB)),
      ('09Z structure (wider, weaker eyewall)',drop('nat09',RB)),
      ('...and surface winds treated as gradient winds (friction ignored)',drop('nat09',RB,alpha=False)),
      ('...and centre 2 km closer to the buoy',drop('nat09',RB-2.0,alpha=False)),
      ('...and the Sentinel-1D wind level (0.83), eyewall 10% wider',drop('nat09',RB-2.0,alpha=False,level=0.83,tilt=1.10))]
print('17:04Z reading %.1f hPa at effective distance %.1f km (v11 track mean, elliptical eyewall)'%(P[17],RB))
for lab,d in rows: print('%-70s drop %5.1f hPa  -> central pressure at most %.1f'%(lab,d,P[17]-d))
json.dump(dict(r_buoy=RB,p_buoy=float(P[17]),rows=[[lab,d,float(P[17]-d)] for lab,d in rows]),open(os.path.join(HERE,'bounds.json'),'w'),indent=1)
