# Profile-family weights from the constrained fits (the likelihood the Monte Carlo uses: peak-wind constraint, Student-t errors, v11
# geometry), and leave-one-out diagnostics.
#   (1) best constrained fit per family (Pc free): chi2, number of parameters k; weights from chi2 alone, AIC (chi2 + 2k, primary) and
#       BIC (chi2 + k ln n, n = 38 readings); equal weights reported alongside.
#   (2) leave-one-out predictive score over the six near-core readings (15:00-20:04Z): each reading is removed in turn, the family refitted,
#       and the removed reading scored with the Student-t density (plug-in); weights proportional to exp(sum of log scores).
#       Primary weighting (v11 headline): pseudo-BMA+ - the leave-one-out scores with Bayesian-bootstrap regularisation (Yao et al. 2018,
#       Bayesian Analysis 13:917), suited to a small number of held-out readings and to a set of models none of which is exactly right.
#       Stacking weights are reported as well.
#   (3) primary family: central pressure with each near-core reading removed, and with 17:04/18:04Z raised 2 / 4 hPa (barometer low bias).
import sys, os, json, time, numpy as np
from multiprocessing import Pool
from scipy.stats import t as tdist
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import P, sig_obs, ROBUST_NU, NB, t as T_
FAMS=('T','U','A','C')
CORE=(15,16,17,18,19,20)
def job(a):
    kind,fam,drop,shift=a; j=dict(mc.DEF,fam=fam); pri,data,s=mc.build(j,None); s=s.copy(); data=data.copy()
    for i in drop: s[i]=1e4
    for i,dv in shift: data[i]+=dv
    rng=np.random.default_rng(3); st=mc.default_starts(j,pri,rng,nrand=8)
    best,_=mc.fit_free(j,pri,data,s,st)
    out=dict(kind=kind,fam=fam,drop=list(drop),shift=[list(x) for x in shift],Pc=float(best.x[0]),chi2=float(2*best.cost),npar=int(len(best.x)))
    if drop:
        from core import make_res
        res,unpack,_,_=make_res(fam,best.x[0],'gp',pri=pri,sig=s); u=unpack(best.x[1:]); Pm,_,_=res.pressure(u); i=drop[0]
        s0=sig_obs()[i]; z=(P[i]-Pm[i])/s0; out.update(pred=float(Pm[i]),obs=float(P[i]),z=float(z),logscore=float(tdist.logpdf(z,ROBUST_NU)-np.log(s0)))
    return out
def predictive_weights(fits,mix=('T','U','A'),nboot=4000,seed=0):
    from scipy.optimize import minimize
    E={f:np.array([o['logscore'] for o in sorted([o for o in fits if o['kind']=='loo' and o['fam']==f],key=lambda o:o['drop'][0])]) for f in mix}
    n=len(E[mix[0]]); rng=np.random.default_rng(seed); acc=np.zeros(len(mix))
    for b in range(nboot):
        a=rng.dirichlet(np.ones(n)); z=np.array([n*(a*E[f]).sum() for f in mix]); w=np.exp(z-z.max()); acc+=w/w.sum()
    L=np.array([E[f] for f in mix])
    def obj(v): w=np.exp(v)/np.exp(v).sum(); return -np.sum(np.log((w[:,None]*np.exp(L)).sum(0)))
    r=min((minimize(obj,x0) for x0 in np.eye(len(mix))),key=lambda r:r.fun); ws=np.exp(r.x)/np.exp(r.x).sum()
    return {f:float(v) for f,v in zip(mix,acc/nboot)},{f:float(v) for f,v in zip(mix,ws)}
if __name__=='__main__' and len(sys.argv)>1 and sys.argv[1]=='--post':
    WJ=json.load(open(os.path.join(HERE,'weights.json'))); WJ['weights']['pbma'],WJ['weights']['stacking']=predictive_weights(WJ['fits'])
    for k,v in WJ['weights'].items(): print('  weights %-8s'%k,{f:round(x,3) for f,x in v.items()})
    json.dump(WJ,open(os.path.join(HERE,'weights.json'),'w'),indent=1); sys.exit()
if __name__=='__main__':
    jobs=[('full',f,(),()) for f in FAMS]+[('loo',f,(i,),()) for f in ('T','U','A') for i in CORE]
    jobs+=[('bias','T',(),((17,dv),(18,dv))) for dv in (2.0,4.0)]
    t0=time.time()
    with Pool(2) as pool: out=pool.map(job,jobs,chunksize=1)
    print('done %.0f s'%(time.time()-t0))
    full={o['fam']:o for o in out if o['kind']=='full'}; n=NB
    print('best constrained fit per family (Pc free):')
    for f in FAMS: print('  %s Pc %.1f chi2 %.2f k %d'%(f,full[f]['Pc'],full[f]['chi2'],full[f]['npar']))
    def wts(score):
        m=min(score.values()); w={f:np.exp(-0.5*(v-m)) for f,v in score.items()}; s=sum(w.values()); return {f:float(v/s) for f,v in w.items()}
    mix=('T','U','A')
    W=dict(chi2=wts({f:full[f]['chi2'] for f in mix}),aic=wts({f:full[f]['chi2']+2*full[f]['npar'] for f in mix}),
           bic=wts({f:full[f]['chi2']+full[f]['npar']*np.log(n) for f in mix}),equal={f:1/3 for f in mix})
    ls={f:sum(o['logscore'] for o in out if o['kind']=='loo' and o['fam']==f) for f in mix}
    m=max(ls.values()); e={f:np.exp(v-m) for f,v in ls.items()}; W['loo']={f:float(v/sum(e.values())) for f,v in e.items()}
    W['pbma'],W['stacking']=predictive_weights(out,mix)
    for k,v in W.items(): print('  weights %-6s'%k,{f:round(x,3) for f,x in v.items()})
    print('leave-one-out (log score per removed reading):')
    for f in mix:
        print('  %s: '%f+' '.join('%5.2fh z %+.2f (Pc %.1f)'%(T_[o['drop'][0]],o['z'],o['Pc']) for o in out if o['kind']=='loo' and o['fam']==f)+' | sum log score %.2f'%ls[f])
    for o in out:
        if o['kind']=='bias': print('  T with 17:04/18:04 raised %.0f hPa: Pc %.1f'%(o['shift'][0][1],o['Pc']))
    json.dump(dict(fits=out,weights=W,loo_logscore=ls),open(os.path.join(HERE,'weights.json'),'w'),indent=1)
