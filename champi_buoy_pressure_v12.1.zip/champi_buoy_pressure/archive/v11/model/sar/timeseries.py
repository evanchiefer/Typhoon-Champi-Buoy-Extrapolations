# Structure time series from the RCM-3 level-2 passes, interpolated to the buoy time (17:33Z), and surface-centre offsets from the IR fixes.
import os, sys, json, numpy as np
D=os.path.dirname(os.path.abspath(__file__))
fx=json.load(open(sys.argv[1])); th=np.array(sorted(int(k) for k in fx)); FLA=np.array([fx[str(h)]['lat'] for h in th]); FLO=np.array([fx[str(h)]['lon'] for h in th])
T={'R3_20_0920':9+20/60+37/3600,'R3_20_2115':21+15/60+26/3600,'R3_21_0929':33+29/60+17/3600,'R3_21_2123':45+23/60+7/3600}
P={k:json.load(open(os.path.join(D,k+'_struct.json'))) for k in T}; tq=17.55
w=(tq-T['R3_20_0920'])/(T['R3_20_2115']-T['R3_20_0920']); out=dict(weight_2115=w,lin={},quad={},passes={})
for q in ('Rm','Vm_kt','I47','I55','v14','R2','vsec','Rmoat','vmoat','ring_scatter'):
    a,b=P['R3_20_0920'][q],P['R3_20_2115'][q]; out['lin'][q]=a+w*(b-a)
    ks=['R3_20_0920','R3_20_2115','R3_21_0929']
    if all(P[k][q] is not None for k in ks): out['quad'][q]=float(np.polyval(np.polyfit([T[k] for k in ks],[P[k][q] for k in ks],2),tq))
for k in T:
    d={q:P[k][q] for q in ('clon','clat','Rm','Vm_kt','I47','v14','R2','vsec','ring_scatter')}
    if th[0]<=T[k]<=th[-1]:
        la=np.interp(T[k],th,FLA); lo=np.interp(T[k],th,FLO); d['offset_from_ir_fix_km']=[(P[k]['clon']-lo)*111.0*np.cos(np.radians((la+P[k]['clat'])/2)),(P[k]['clat']-la)*111.0]
    out['passes'][k]=d
print(json.dumps(out,indent=1)); json.dump(out,open(os.path.join(D,'timeseries.json'),'w'),indent=1)
