# Storm structure from a level-2 SAR wind field: surface centre (circle fit to the eyewall wind maxima), azimuthal-mean and per-sector
# profiles, RMW, Vmax, eye-shape integral I, v(1.4 RMW)/Vmax, secondary wind maximum, smear sensitivity.
# Usage: structure.py KEY lon lat          (KEY.npz from extract_all.py in this folder; lon/lat = first guess of the centre)
# v11: the ring fit is converged from 9 first guesses and the most common converged centre is used; all converged centres, with their RMW,
#      peak wind and eye integral, are saved as the centre-convergence sensitivity.
# v11: paths relative to this folder; radial bin width follows the grid spacing (0.5 km for 500-m grids, 3 km grids no longer fail);
#      per-sector RMW searched within +-6 km of the azimuthal-mean RMW (a sector's secondary maximum is no longer taken as its RMW).
import os, sys, json, numpy as np
from scipy.ndimage import gaussian_filter, uniform_filter1d
D=os.path.dirname(os.path.abspath(__file__))+os.sep
KT=1.94384
def load(key):
    d=np.load(D+key+'.npz'); return d['W'],d['lon'],d['lat']
def xy(lon,lat,clon,clat):
    kx=111.32*np.cos(np.radians(clat)); return (lon-clon)*kx,(lat-clat)*110.57
def spacing_km(lon,lat):
    X,Y=xy(lon,lat,np.nanmean(lon),np.nanmean(lat)); return float(np.nanmedian(np.hypot(np.diff(X,axis=1),np.diff(Y,axis=1))))
def smooth(W,s=3):
    M=np.isfinite(W).astype(float); Wf=np.where(np.isfinite(W),W,0)
    return gaussian_filter(Wf,s)/np.maximum(gaussian_filter(M,s),1e-6), gaussian_filter(M,s)
def ring_points(X,Y,Ws,cov,cx,cy,nsec=72,rmin=10,rmax=45,dr=0.5):
    r=np.hypot(X-cx,Y-cy); th=np.arctan2(Y-cy,X-cx); sel=r<rmax+2
    rs,ts,ws,cs=r[sel],th[sel],Ws[sel],cov[sel]; sec=((ts+np.pi)/(2*np.pi)*nsec).astype(int)%nsec
    rb=np.arange(rmin,rmax+dr,dr); pts=[]
    for k in range(nsec):
        mk=(sec==k)&(cs>0.9)
        if mk.sum()<30*(0.5/dr)**2: continue
        idx=np.digitize(rs[mk],rb)-1; n=len(rb)-1; m=(idx>=0)&(idx<n)
        cnt=np.bincount(idx[m],None,n); prof=np.bincount(idx[m],ws[mk][m],n)/np.maximum(cnt,1); prof[cnt<(3 if dr<=0.5 else 1)]=np.nan
        if np.isfinite(prof).sum()<0.8*n: continue
        j=np.nanargmax(prof); rr=0.5*(rb[j]+rb[j+1]); a=(k+0.5)/nsec*2*np.pi-np.pi
        if 0<j<n-1: pts.append((cx+rr*np.cos(a),cy+rr*np.sin(a)))
    return np.array(pts)
def fit_circle(p):
    A=np.c_[2*p[:,0],2*p[:,1],np.ones(len(p))]; b=p[:,0]**2+p[:,1]**2; s,*_=np.linalg.lstsq(A,b,rcond=None)
    return s[0],s[1],np.sqrt(s[2]+s[0]**2+s[1]**2)
def centre(W,lon,lat,glon,glat,dr=0.5):
    X,Y=xy(lon,lat,glon,glat); sp=spacing_km(lon,lat); Ws,cov=smooth(W,max(1.0,3*0.5/sp))
    W8,_=smooth(W,max(1.5,10*0.5/sp)); r=np.hypot(X,Y); i=np.argmin(np.where((r<40)&np.isfinite(W8),W8,1e9)); cx,cy=X.flat[i],Y.flat[i]
    R=np.nan; sc=np.nan; nk=0; npnt=0
    for it in range(12):
        p=ring_points(X,Y,Ws,cov,cx,cy,dr=dr); npnt=len(p)
        if len(p)<12: break
        ncx,ncy,R=fit_circle(p); res=np.hypot(p[:,0]-ncx,p[:,1]-ncy)-R; mad=np.median(np.abs(res-np.median(res)))*1.4826
        keep=np.abs(res)<2.5*max(mad,0.5); ncx,ncy,R=fit_circle(p[keep]); sc=float(np.std(res[keep])); nk=int(keep.sum())
        done=np.hypot(ncx-cx,ncy-cy)<0.05; cx,cy=ncx,ncy
        if done: break
    if not np.isfinite(R): raise ValueError('ring fit failed: fewer than 12 sector maxima (grid too coarse or eyewall outside the swath)')
    kx=111.32*np.cos(np.radians(glat))
    return glon+cx/kx, glat+cy/110.57, R, sc, nk, npnt
def centre_multi(W,lon,lat,glon,glat,dr=0.5,rad=4.0):
    """converge the ring fit from 9 first guesses (the given one and 8 around it at rad km); return the most common converged centre and
    all converged centres (centre-convergence sensitivity)"""
    kx=111.32*np.cos(np.radians(glat)); gs=[(glon,glat)]+[(glon+rad*np.cos(a)/kx,glat+rad*np.sin(a)/110.57) for a in np.linspace(0,2*np.pi,8,endpoint=False)]
    res=[]
    for g in gs:
        try: res.append(centre(W,lon,lat,*g,dr=dr))
        except ValueError: pass
    if not res: raise ValueError('ring fit failed from every first guess')
    key=[(round(c[0]*kx/0.2),round(c[1]*110.57/0.2)) for c in res]
    best=max(set(key),key=lambda k:(key.count(k),-min(c[3] for c,kk in zip(res,key) if kk==k)))
    pick=[c for c,kk in zip(res,key) if kk==best]; pick=min(pick,key=lambda c:c[3])
    return pick,res,key.count(best)
def azprof(W,lon,lat,clon,clat,dr=0.5,rmax=300):
    X,Y=xy(lon,lat,clon,clat); r=np.hypot(X,Y); th=np.degrees(np.arctan2(X,Y))%360; ok=np.isfinite(W)
    rb=np.arange(0,rmax+dr,dr); rc=0.5*(rb[1:]+rb[:-1]); n=len(rc)
    i=np.digitize(r[ok],rb)-1; m=(i>=0)&(i<n); w=W[ok][m]; ii=i[m]; t=th[ok][m]
    cnt=np.bincount(ii,None,n); v=np.bincount(ii,w,n)/np.maximum(cnt,1); v2=np.bincount(ii,w**2,n)/np.maximum(cnt,1)
    sec=(t//10).astype(int); key=ii*36+sec; u=np.unique(key); cov=np.bincount(u//36,None,n)/36.0     # fraction of 10-deg sectors with data
    return rc,v,v2,cov,r,th
def Iint(rc,vk,re_kt=47,rwin=(0,60)):
    """eye integral I = (v47/vm)^2/2 + int_{x47}^{1} (v/vm)^2/x dx (solid body inside the 47-kt radius); RMW searched within rwin (km)"""
    win=(rc>=rwin[0])&(rc<=rwin[1])&np.isfinite(vk); i=int(np.flatnonzero(win)[np.nanargmax(vk[win])]); Rm=rc[i]; vm=vk[i]
    je=int(np.argmax(np.nan_to_num(vk)>=re_kt)); x=rc[:i+1]/Rm; vv=vk[:i+1]/vm; m=(x>=rc[je]/Rm)&np.isfinite(vv)
    return float((vk[je]/vm)**2/2+np.trapezoid(vv[m]**2/x[m],x[m])),Rm,vm
def analyze(key,glon,glat,save=True,quiet=False):
    W,lon,lat=load(key); sp=spacing_km(lon,lat); dr=max(0.5,round(sp*2)/2) if sp>0.75 else 0.5
    (clon,clat,R,sc,nk,npnt),allc,nsame=centre_multi(W,lon,lat,glon,glat,dr=dr)
    conv=[]
    for c in allc:
        rc_,v_,_,_,_,_=azprof(W,lon,lat,c[0],c[1],dr=dr,rmax=120); I_,R_,V_=Iint(rc_,v_*KT,47); conv.append([float(c[0]),float(c[1]),float(R_),float(V_),float(I_)])
    rc,v,v2,cov,r,th=azprof(W,lon,lat,clon,clat,dr=dr); vk=v*KT
    full=np.nanmin(cov[int(5/dr):int(60/dr)])
    out=dict(key=key,grid_km=sp,dr=dr,clon=clon,clat=clat,ring_R=R,ring_scatter=sc,ring_pts=[nk,npnt],min_cov_5_60km=float(full),
             centre_guesses_agreeing=int(nsame),centre_convergence=conv)
    I47,Rm,vm=Iint(rc,vk,47); I55,_,_=Iint(rc,vk,55); out.update(Rm=float(Rm),Vm_kt=float(vm),I47=I47,I55=I55)
    sh=lambda x: float(np.interp(x*Rm,rc,vk)/vm)
    out.update(v14=sh(1.4),v20=sh(2.0),v30=sh(3.0),v40=sh(4.0))
    ss=uniform_filter1d(np.nan_to_num(vk),max(1,int(round(2.5/dr)))); jm=None; j=None
    for q in range(int(1.1*Rm/dr),int(2.2*Rm/dr)):                                # first dip after the eyewall followed by a rise > 2 kt within 20 km
        w0,w1=max(q-int(2/dr),0),q+int(2/dr)+1
        if ss[q]==ss[w0:w1].min():
            k2=q+int(20/dr); jj=q+int(np.argmax(ss[q:k2]))
            if ss[jj]-ss[q]>2.0 and jj>q+2: jm,j=q,jj; break
    has2=jm is not None
    if not has2: jm=int(np.argmin(np.where((rc>1.1*Rm)&(rc<2*Rm),ss,1e9))); j=jm
    out.update(Rmoat=float(rc[jm]),vmoat=float(ss[jm]/vm),R2=float(rc[j]) if has2 else None,vsec=float(ss[j]/vm) if has2 else None,sec_rise_kt=float(ss[j]-ss[jm]))
    # per-sector (10 deg) eye shape and Rm/Vm, covered sectors only; sector RMW searched within +-6 km of the azimuthal-mean RMW
    Ik=[];Rk=[];Vk=[];az=[]
    rb=np.arange(0,80.01,dr); rcc=0.5*(rb[1:]+rb[:-1]); ok=np.isfinite(W)
    for k in range(36):
        msk=ok&(th>=k*10)&(th<(k+1)*10)&(r<80)
        if msk.sum()<400*(0.5/dr)**2: continue
        ii=np.digitize(r[msk],rb)-1; n=len(rcc); mm_=(ii>=0)&(ii<n); cnt=np.bincount(ii[mm_],None,n)
        if (cnt[int(2/dr):int(60/dr)]==0).any(): continue
        ps=uniform_filter1d(np.bincount(ii[mm_],W[msk][mm_],n)/np.maximum(cnt,1),3)*KT
        try: Ii,Ri,Vi=Iint(rcc,ps,47,rwin=(Rm-6,Rm+6))
        except Exception: continue
        Ik.append(Ii);Rk.append(Ri);Vk.append(Vi);az.append(k*10+5)
    out.update(n_sectors=len(Ik),I_sector=[float(np.mean(Ik)),float(np.std(Ik))] if Ik else None,Rm_sector=[float(np.mean(Rk)),float(np.std(Rk))] if Rk else None,
               Vm_sector=[float(np.mean(Vk)),float(np.std(Vk)),float(np.max(Vk))] if Vk else None,sector_az=az,sector_Rm=[float(x) for x in Rk],
               sector_Vm=[float(x) for x in Vk],sector_I=[float(x) for x in Ik])
    def I_off(dx,dy):
        kx=111.32*np.cos(np.radians(clat)); rc2,vv,_,_,_,_=azprof(W,lon,lat,clon+dx/kx,clat+dy/110.57,dr=dr,rmax=80); return Iint(rc2,vv*KT,47)[0]
    out['I47_2km_offset']=float(np.mean([I_off(2*np.cos(a),2*np.sin(a)) for a in np.linspace(0,2*np.pi,4,endpoint=False)]))
    if save:
        np.savez(D+key+'_prof.npz',rc=rc,v=v,v2=v2,cov=cov)
        json.dump(out,open(D+key+'_struct.json','w'),indent=1)
    if not quiet: print(json.dumps({k:(round(v,3) if isinstance(v,float) else v) for k,v in out.items() if k not in('sector_az','sector_Rm','sector_Vm','sector_I')}))
    return out
if __name__=='__main__':
    analyze(sys.argv[1],float(sys.argv[2]),float(sys.argv[3]))
