# Cross-sensor check at 09Z: Sentinel-1D (VH, 09:09:35Z) vs RCM-3 (HV, 09:20:37Z), 11 min apart, each about its own ring-fit centre.
# Radial bands x 30-degree sectors where both passes have data; ratio S1D / RCM-3 per band (means over common sectors), per cell vs wind speed,
# and at the eyewall (azimuthal-mean and sector peak winds). Needs S1D_20_0909 and R3_20_0920 npz + struct from extract_all.py / structure.py.
import os, sys, json, numpy as np
D=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,D)
from structure import load, xy
KT=1.94384
S=json.load(open(os.path.join(D,'S1D_20_0909_struct.json'))); R=json.load(open(os.path.join(D,'R3_20_0920_struct.json')))
def grid(key,c):
    W,lon,lat=load(key); X,Y=xy(lon,lat,c['clon'],c['clat']); return W,np.hypot(X,Y),np.degrees(np.arctan2(X,Y))%360
WS,rS,aS=grid('S1D_20_0909',S); WR,rR,aR=grid('R3_20_0920',R)
bands=((10,16),(16,22),(22,26),(26,30),(30,36),(36,42),(42,50),(50,70),(70,100),(100,140),(140,200))
rows=[]; cells=[]
for r0,r1 in bands:
    vr=[]; vs=[]
    for a0 in range(0,360,30):
        mR=(rR>=r0)&(rR<r1)&(aR>=a0)&(aR<a0+30)&np.isfinite(WR); mS=(rS>=r0)&(rS<r1)&(aS>=a0)&(aS<a0+30)&np.isfinite(WS)
        if mR.sum()<30 or mS.sum()<30: continue
        a,b=float(np.mean(WR[mR])*KT),float(np.mean(WS[mS])*KT); vr.append(a); vs.append(b); cells.append((r0,r1,a0,a,b))
    if vr: rows.append([r0,r1,float(np.mean(vr)),float(np.mean(vs)),float(np.mean(vs)/np.mean(vr)),len(vr)])
C=np.array([(c[3],c[4]/c[3]) for c in cells]); sl,ic=np.polyfit(C[:,0],C[:,1],1)
out=dict(rows=rows,cells=cells,ratio_vs_rcm_speed=dict(slope_per_10kt=float(sl*10),at_60kt=float(ic+sl*60),at_100kt=float(ic+sl*100),at_140kt=float(ic+sl*140)),
         eyewall=dict(azmean_vm_ratio=S['Vm_kt']/R['Vm_kt'],sector_peak_ratio=S['Vm_sector'][2]/R['Vm_sector'][2]),
         centres=dict(S1D=[S['clon'],S['clat']],R3=[R['clon'],R['clat']]))
for r in rows: print('%3d-%3d km  RCM-3 %5.1f kt  S1D %5.1f kt  ratio %.3f  (%d sectors)'%tuple(r))
print('ratio vs RCM-3 speed: %+.4f per 10 kt -> %.3f at 60 kt, %.3f at 100 kt, %.3f at 140 kt'%(sl*10,ic+sl*60,ic+sl*100,ic+sl*140))
print('eyewall: azimuthal-mean peak ratio %.3f, sector peak ratio %.3f'%(out['eyewall']['azmean_vm_ratio'],out['eyewall']['sector_peak_ratio']))
json.dump(out,open(os.path.join(D,'crosscal_0909.json'),'w'),indent=1)
