# Cross-sensor check of SAR wind calibration: Sentinel-1D (VH, 21:20:37Z) vs RCM-3 (HV, 21:15:26Z), same storm-relative positions.
# Sentinel-1D misses the eyewall (swath edge), so the comparison uses the western sectors 240-330 deg at 35-200 km.
import os, sys, json, numpy as np
D=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,D)
from structure import load, xy
fx=json.load(open(sys.argv[1] if len(sys.argv)>1 else os.path.join(D,"..","..","fixes.json")))                          # hourly IR eye fixes (storm motion between 21Z and 22Z)
c=json.load(open(os.path.join(D,'R3_20_2115_struct.json'))); f=(5+11/60)/60
cS=(c['clon']+(fx['22']['lon']-fx['21']['lon'])*f, c['clat']+(fx['22']['lat']-fx['21']['lat'])*f)
def grid(key,clon,clat):
    W,lon,lat=load(key); X,Y=xy(lon,lat,clon,clat); return W,np.hypot(X,Y),np.degrees(np.arctan2(X,Y))%360
WR,rR,aR=grid('R3_20_2115',c['clon'],c['clat']); WS,rS,aS=grid('S1D_20_2120',*cS)
rows=[]
for r0,r1 in ((35,50),(50,70),(70,100),(100,140),(140,200)):
    for a0 in range(240,330,30):
        mR=(rR>=r0)&(rR<r1)&(aR>=a0)&(aR<a0+30)&np.isfinite(WR); mS=(rS>=r0)&(rS<r1)&(aS>=a0)&(aS<a0+30)&np.isfinite(WS)
        if mR.sum()<200 or mS.sum()<200: continue
        rows.append((r0,r1,a0,float(np.mean(WR[mR])*1.94384),float(np.mean(WS[mS])*1.94384)))
rat=np.array([b/a for *_,a,b in rows])
for r in rows: print('%3d-%3d km  %3d-%3d deg  RCM-3 %5.1f kt  S1D %5.1f kt  ratio %.3f'%(r[0],r[1],r[2],r[2]+30,r[3],r[4],r[4]/r[3]))
print('S1D / RCM-3 = %.3f +- %.3f (%d cells)'%(rat.mean(),rat.std(),len(rat)))
json.dump(dict(rows=rows,ratio_mean=float(rat.mean()),ratio_sd=float(rat.std())),open(os.path.join(D,'crosscal.json'),'w'),indent=1)
