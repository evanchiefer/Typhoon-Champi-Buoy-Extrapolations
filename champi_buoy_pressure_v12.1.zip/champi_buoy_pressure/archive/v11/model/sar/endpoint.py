# Storm structure at the buoy time (17:33Z) from the level-2 SAR passes -> structure_1733.json
#   09Z endpoint: Sentinel-1D 09:09:35Z shape (weight 0.75) and RCM-3 09:20:37Z shape (weight 0.25; ~50 deg incidence at the eyewall,
#                 outlier in shape and asymmetry), in normalised coordinates (r/RMW, v/Vmax). Wind level: RCM-3 (the buoy favours it).
#   21:15Z endpoint: RCM-3 21:15:26Z.
#   Variants: 'interp' (linear in time between the endpoints, the headline), 'nat2115' (21:15Z only), 'nat09' (09Z only) - no interpolation.
#   Eye table: v/Vmax inside the RMW with winds below 47 kt replaced by solid-body rotation (the 47-kt cut used for the eye integral I).
import os, json, numpy as np
D=os.path.dirname(os.path.abspath(__file__))
KT=1.94384; W09={'S1D_20_0909':0.75,'R3_20_0920':0.25}
T={'S1D_20_0909':9+9/60+35/3600,'R3_20_0920':9+20/60+37/3600,'R3_20_2115':21+15/60+26/3600}; TQ=17.55
st={k:json.load(open(os.path.join(D,k+'_struct.json'))) for k in T}
XE=np.linspace(0,1,401); XG=np.linspace(0.005,4.0,1600)
def norm_prof(k):
    d=np.load(os.path.join(D,k+'_prof.npz')); s=st[k]; return d['rc']/s['Rm'], d['v']*KT/s['Vm_kt']
def eye_table(k):
    x,v=norm_prof(k); vk=v*st[k]['Vm_kt']; j=int(np.argmax(vk>=47)); x47=x[j]; v47=v[j]
    t=np.interp(XE,x,v); t[XE<x47]=v47*XE[XE<x47]/x47; t[-1]=1.0; return np.minimum(t,1.0)
def I_of(tab): return float(np.trapezoid(tab[1:]**2/XE[1:],XE[1:]))
def outer(k): x,v=norm_prof(k); return np.interp(XG,x,v)
t09=sum(W09[k]*T[k] for k in W09)
E09=dict(Rm=sum(W09[k]*st[k]['Rm'] for k in W09),Vm_rcm=st['R3_20_0920']['Vm_kt'],I47=sum(W09[k]*st[k]['I47'] for k in W09),
         v14=sum(W09[k]*st[k]['v14'] for k in W09),v20=sum(W09[k]*st[k]['v20'] for k in W09),R2=sum(W09[k]*st[k]['R2'] for k in W09),
         vsec=sum(W09[k]*st[k]['vsec'] for k in W09),eye=sum(W09[k]*eye_table(k) for k in W09),shape=sum(W09[k]*outer(k) for k in W09))
s2=st['R3_20_2115']
E21=dict(Rm=s2['Rm'],Vm_rcm=s2['Vm_kt'],I47=s2['I47'],v14=s2['v14'],v20=s2['v20'],R2=s2['R2'],vsec=s2['vsec'],eye=eye_table('R3_20_2115'),shape=outer('R3_20_2115'))
w_int=(TQ-t09)/(T['R3_20_2115']-t09)
out=dict(t09=t09,t2115=T['R3_20_2115'],weights_09=W09,x_eye=XE.tolist(),x_shape=XG.tolist(),
         passes={k:{q:st[k][q] for q in ('Rm','Vm_kt','I47','v14','v20','R2','vsec','clon','clat','centre_guesses_agreeing')} for k in T},
         replicate_spread_09=dict(Rm=abs(st['S1D_20_0909']['Rm']-st['R3_20_0920']['Rm']),I47=abs(st['S1D_20_0909']['I47']-st['R3_20_0920']['I47']),
                                  v14=abs(st['S1D_20_0909']['v14']-st['R3_20_0920']['v14'])))
for name,w in (('interp',w_int),('nat2115',1.0),('nat09',0.0)):
    m={q:(1-w)*E09[q]+w*E21[q] for q in ('Rm','Vm_rcm','I47','v14','v20','R2','vsec')}
    eye=(1-w)*E09['eye']+w*E21['eye']; shp=(1-w)*E09['shape']+w*E21['shape']
    m.update(w2115=w,I_table=I_of(eye),eye=eye.tolist(),shape=shp.tolist(),hours_from_nearest_pass=float(min(abs(TQ-t09),abs(T['R3_20_2115']-TQ))) if w in (0,1) else None)
    out[name]=m
    print('%-8s w(21:15)=%.3f  Rm_sfc %.2f  Vm(RCM) %.1f  I47 %.3f (table %.3f)  v14 %.3f  v20 %.3f  R2 %.2f  vsec %.3f'%(name,w,m['Rm'],m['Vm_rcm'],m['I47'],m['I_table'],m['v14'],m['v20'],m['R2'],m['vsec']))
json.dump(out,open(os.path.join(D,'structure_1733.json'),'w'))
