# Read every NOAA/STAR level-2 SAR wind file (NetCDF-3, 500 m) and save the fields the structure analysis needs, one npz per pass,
# into this folder. Records each source file name, acquisition times and sha256 in sar_files.json.
# Usage: python3 extract_all.py RAW_DIR      (RAW_DIR holds the STAR files under their original names)
import glob, os, sys, json, hashlib, numpy as np
from scipy.io import netcdf_file
D=os.path.dirname(os.path.abspath(__file__))
RAW=sys.argv[1] if len(sys.argv)>1 else os.environ.get('CHAMPI_SAR_RAW',os.path.join(D,'..','..','data','raw'))
PAT={'S1D_20_0909':'S1D_ESA_2026_10_20_09_09_35*level2*.nc','R3_20_0920':'RCM3_SHUB_2026_10_20_09_20_37*level2*.nc',
     'R3_20_2115':'RCM3_SHUB_2026_10_20_21_15_26*level2*.nc','S1D_20_2120':'S1D_ESA_2026_10_20_21_20_37*level2*.nc',
     'R3_21_0929':'RCM3_SHUB_2026_10_21_09_29_17*level2*.nc','R3_21_2123':'RCM3_SHUB_2026_10_21_21_23_07*level2*.nc'}
def att(f,k):
    v=f._attributes.get(k,b''); return v.decode('ascii','replace') if isinstance(v,bytes) else str(v)
def sha(fn):
    h=hashlib.sha256()
    with open(fn,'rb') as fh:
        for b in iter(lambda: fh.read(1<<20),b''): h.update(b)
    return h.hexdigest()
meta={}
for k,pat in PAT.items():
    hits=sorted(glob.glob(os.path.join(RAW,pat)))
    if not hits: print('missing:',k,pat); continue
    fn=hits[0]; f=netcdf_file(fn,'r',mmap=False); g=lambda v: f.variables[v].data.astype(float)
    W=g('sar_wind'); W[(W<-900)|(W<=0)]=np.nan
    lon=g('longitude'); lat=g('latitude'); inc=g('incid'); px=float(f.variables['pixel_size'].data)
    np.savez_compressed(os.path.join(D,k+'.npz'),W=W,lon=lon,lat=lat,inc=inc)
    meta[k]=dict(file=os.path.basename(fn),sha256=sha(os.path.realpath(fn)),platform=att(f,'answrs:platform_name'),pol=att(f,'answrs:polarization'),
                 gmf=att(f,'answrs:geophysical_model_function'),acq=att(f,'answrs:acquistion_time'),acq_begin=att(f,'answrs:acq_date_time_begin'),
                 acq_end=att(f,'answrs:acq_date_time_end'),pixel_m=px,max_wind_ms=float(np.nanmax(W)),valid_fraction=float(np.isfinite(W).mean()))
    print('%s: %s %s GMF %s acq %s (%s - %s) grid %s px %.0f m | max %.1f m/s | valid %.2f'%(k,meta[k]['platform'],meta[k]['pol'],meta[k]['gmf'],meta[k]['acq'],
          meta[k]['acq_begin'],meta[k]['acq_end'],W.shape,px,meta[k]['max_wind_ms'],meta[k]['valid_fraction']))
    f.close()
for fn in sorted(glob.glob(os.path.join(RAW,'STAR_SAR_*FIX_3km.nc'))):
    meta['fix3km:'+os.path.basename(fn)]=dict(file=os.path.basename(fn),sha256=sha(os.path.realpath(fn)))
json.dump(meta,open(os.path.join(D,'sar_files.json'),'w'),indent=1)
