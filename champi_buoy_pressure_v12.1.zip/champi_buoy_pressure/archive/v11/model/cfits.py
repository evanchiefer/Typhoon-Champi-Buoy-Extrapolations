# Constrained fits for the figures and tables (peak-wind constraint, Student-t errors, v11 geometry - the Monte Carlo likelihood):
# primary family at the combined 68% low / median / 68% high central pressures, the alternatives at the median, and the primary with the
# v10 geometry and JTWC positions at the median. Also the per-reading residual / effective-weight table at the median fit.
import sys, os, json, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import *
F=json.load(open(os.path.join(HERE,'final.json'))); CB=json.load(open(os.path.join(HERE,'cbest.json')))
def job(a):
    fam,tr,Pc,tag,extra_pri=a; pri=dict(PRI); pri['Vg']=VG_PRIOR; pri.update(extra_pri); key='%s|%s|interp|vg'%(fam,tr)
    sig=sig_obs(extra_pri.get('_sigpos'),tr); pri.pop('_sigpos',None)
    best,costs,unpack=solve(fam,Pc,tr,n_rand=10,seed=int(Pc*10)%1000,extra=[np.array(r['x']) for r in CB.get(key,[])],pri=pri,sig=sig)
    res,_,_,_=make_res(fam,Pc,tr,pri=pri,sig=sig); d=summarize(fam,best,unpack,Pc,tr,res=res,pri=pri); d.update(name=fam+'_con_'+tr,tag=tag); return d
if __name__=='__main__':
    jobs=[('T','gp',F['lo68'],'lo68',{}),('T','gp',F['median'],'median',{}),('T','gp',F['hi68'],'hi68',{}),('U','gp',F['median'],'median',{}),
          ('A','gp',F['median'],'median',{}),('T','irf',F['median'],'median_v10geom',{'ell':False,'_sigpos':1.5}),('T','bt',F['median'],'median',{})]
    with Pool(2) as pool: out=pool.map(job,jobs,chunksize=1)
    for d in out: print('%-12s %-15s Pc %.1f: chi2 %.2f peak %.0f kt gradient, RMW %.1f, 17:04Z %.1f km (eff %.1f), 18:04Z %.1f km (eff %.1f), closest %.1f km at %.2f h'%(
        d['name'],d['tag'],d['Pc'],d['chi2'],d['vg'],d['rmw'],d['r17'],d['re17'],d['r18'],d['re18'],d['rclose'],d['tclose']))
    json.dump(out,open(os.path.join(HERE,'fits_constrained.json'),'w'))
    m=[d for d in out if d['name']=='T_con_gp' and d['tag']=='median'][0]; s=sig_obs(); r=np.array(m['resid']); z=r/s; w=(ROBUST_NU+1)/(ROBUST_NU+z**2)
    tab=[dict(t=float(t[i]),p=float(P[i]),resid=float(r[i]),sigma=float(s[i]),z=float(z[i]),weight=float(w[i])) for i in range(13,23)]
    print('reading   P (hPa)  obs-model  sigma   z      t-weight')
    for x in tab: print('%5.2fh  %6.1f   %+5.2f    %4.2f  %+5.2f   %.2f'%(x['t'],x['p'],x['resid'],x['sigma'],x['z'],x['weight']))
    json.dump(tab,open(os.path.join(HERE,'reading_weights.json'),'w'),indent=1)
