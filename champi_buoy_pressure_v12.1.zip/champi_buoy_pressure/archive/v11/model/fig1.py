# Figure 1: observations and storm structure (v11)
import sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
import logwind as LW
HERE=os.path.dirname(os.path.abspath(__file__))
F=json.load(open(os.path.join(HERE,'final.json'))); PCm,PClo,PChi=F['median'],F['lo68'],F['hi68']
CF=os.path.join(HERE,'fits_constrained.json')   # constrained fits (peak-wind constraint, Student-t errors, v11 geometry), as in the Monte Carlo
RT=rows_of(CF,'T_con_gp'); bm=[r for r in RT if r['tag']=='median'][0]
RU=rows_of(CF,'U_con_gp')[0]; RA=rows_of(CF,'A_con_gp')[0]; RV=rows_of(CF,'T_con_irf')[0]; RJ=rows_of(CF,'T_con_bt')[0]
GPJ=json.load(open(os.path.join(HERE,'track_gp.json')))
SPk=('S1D_20_0909','R3_20_0920','R3_20_2115','R3_21_0929')
SP={k:np.load(os.path.join(HERE,'sar',k+'_prof.npz')) for k in SPk}; C2=json.load(open(os.path.join(HERE,'sar','R3_20_2115_struct.json')))
fig,ax=plt.subplots(2,3,figsize=(21,13.4)); (A1,A2,A3),(B1,B2,B3)=ax
tt=np.linspace(0,37,3000); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
# (a) full record
D,bg,_,_=model_eval(bm,'gp',tt,la_i,lo_i)
A1.plot(tt,bg,color=GRN,lw=1.6,ls='--',label='background: environment + tide + trend')
A1.plot(tt,bg-D,color=BLU,lw=2.2,label='fitted ring model (SAR eye shape + secondary ring), centre ≈%.0f hPa'%PCm)
A1.plot(t,P,'o',ms=6.5,color=INK,mec=SURF,mew=1.2,label='drifting-buoy pressure (hourly)',zorder=5)
A1.set_xlim(0,37); A1.set_ylim(870,1015); A1.set_xticks(range(0,38,6)); A1.set_xticklabels(['00Z\n20 Oct','06Z','12Z','18Z','00Z\n21 Oct','06Z','12Z'])
A1.set_ylabel('sea-level pressure (hPa)'); A1.set_title('a   Full buoy record and fit',loc='left',fontweight='bold')
A1.legend(loc='lower left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (b) zoom on pass
tz=np.linspace(13,22,2000); la_z=np.interp(tz,t,lat); lo_z=np.interp(tz,t,lon)
for tag,c,lab in (('lo68',LBL,'68% low'),('median',BLU,'median'),('hi68',DBL,'68% high')):
    r_=[r for r in RT if r['tag']==tag][0]; D,bg,_,_=model_eval(r_,'gp',tz,la_z,lo_z); A2.plot(tz,bg-D,color=c,lw=2.2,label='ring model, centre ≈%.0f hPa (%s)'%(r_['Pc'],lab))
D,bg,_,_=model_eval(RA,'gp',tz,la_z,lo_z); A2.plot(tz,bg-D,color=ORA,lw=1.6,ls='--',label='two-ring Holland, median (highest weight)')
D,bg,_,_=model_eval(RV,'irf',tz,la_z,lo_z,{'ell':False}); A2.plot(tz,bg-D,color=GRY,lw=1.4,ls=':',label='ring model, median, v10 geometry')
m=(t>=13)&(t<=22); A2.plot(t[m],P[m],'o',ms=8,color=INK,mec=SURF,mew=1.4,label='buoy',zorder=5)
A2.annotate('909.4 hPa, 17:04Z',(17.07,909.4),(13.4,925),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
A2.annotate('913.3 hPa, 18:04Z\n(model %.0f; buoy on the\nlong side of the oval eyewall)'%(P[18]-bm['resid'][18]),(18.07,913.3),(19.25,921),fontsize=10.5,arrowprops=dict(arrowstyle='-',color=INK2))
D,bg,_,_=model_eval(bm,'gp',tz,la_z,lo_z); j=np.argmin(bg-D)
A2.annotate('likely buoy low ~%.0f hPa\nat %02d:%02dZ (between readings)'%((bg-D)[j],int(tz[j]),round(tz[j]%1*60)),(tz[j],(bg-D)[j]),(19.25,897),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
A2.set_xlim(13,22); A2.set_ylim(885,990); A2.set_xlabel('20 October, UTC hour'); A2.set_ylabel('sea-level pressure (hPa)')
A2.set_title('b   The eyewall pass',loc='left',fontweight='bold'); A2.legend(loc='upper center',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95,fontsize=10)
# (c) map
fx=json.load(open(os.path.join(HERE,'ir_eye_fixes.json'))); hh=np.array(sorted(int(q) for q in fx)); th2=np.linspace(11,23,700)
A3.plot([fx[str(h)]['lon'] for h in hh],[fx[str(h)]['lat'] for h in hh],'o-',ms=6,lw=1.0,color=GRY,mfc=SURF,mec=INK2,mew=1.3,label='IR eye track (hourly fixes)')
fa,fo=TRACKS['gp'][:2]; A3.plot(fo(th2),fa(th2),color=INK,lw=1.4,ls='--',label='surface centre: fixes + offset (track model)')
cla,clo=centre_track(bm,'gp',np.linspace(16.0,19.5,400)); A3.plot(clo,cla,color=BLU,lw=2.6,label='surface centre fitted with the buoy (wander)')
A3.plot(np.polyval(BTLON,th2),np.polyval(BTLAT,th2),color=ORA,lw=1.4,ls='-.',label='JTWC best-track positions (smoothed)')
bt=np.array(INP['bt']); mm=(bt[:,0]>=11)&(bt[:,0]<=23); A3.plot(bt[mm,2],bt[mm,1],'*',ms=15,color=ORA,mec=SURF)
A3.plot(131.719,17.335,'^',ms=11,color=GRN,mec=SURF,label='ATMS 165/183 GHz eye, 17:01Z')
A3.plot(C2['clon'],C2['clat'],'s',ms=10,color=PUR,mec=SURF,label='RCM-3 SAR ring centre, 21:15Z')
cl,co=centre_track(bm,'gp',np.array([TC])); cl,co=cl[0],co[0]; k=111*np.cos(np.radians(cl)); th_=np.linspace(0,2*np.pi,300)
Rell=bm['rmw']*(1+bm['e0']*np.cos(2*(th_-np.radians(bm['th0']))))
A3.plot(co+Rell*np.sin(th_)/k,cl+Rell*np.cos(th_)/111,color=BLU,lw=1.6,ls=':')
A3.plot(co+14*np.sin(th_)/k,cl+14*np.cos(th_)/111,color=INK2,lw=1.0); A3.plot(co,cl,'+',ms=14,mew=2.2,color=INK)
A3.text(132.22,17.88,'at 17:33Z:\nmax-wind radius %.0f km, oval ±%.1f km\n(long axis %.0f°/%.0f°; dotted)\ncalm eye ~14 km (solid)'%(bm['rmw'],bm['rmw']*bm['e0'],bm['th0']%180,bm['th0']%180+180),fontsize=10.5,color=INK2,va='top',ha='right')
A3.plot(lon,lat,'-',color=INK,lw=1.3,label='buoy drift'); A3.plot(lon[17],lat[17],'v',ms=12,color=RED,mec=SURF,label='buoy at 17:04Z (909.4 hPa)')
A3.plot(lon[18],lat[18],'v',ms=10,color=SURF,mec=RED,mew=1.6,label='buoy at 18:04Z (913.3 hPa)')
A3.set_xlim(130.72,132.25); A3.set_ylim(16.95,17.9); A3.set_aspect(1/np.cos(np.radians(17.4)))
A3.set_xlabel('longitude (°E)'); A3.set_ylabel('latitude (°N)'); A3.set_title('c   Centre positions and the buoy pass',loc='left',fontweight='bold')
A3.legend(loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=2,fontsize=9.4,frameon=False)
# (d) distance vs time
_,_,r,re=model_eval(bm,'gp',tz,la_z,lo_z); _,_,rv,_=model_eval(RV,'irf',tz,la_z,lo_z,{'ell':False}); _,_,rbt,_=model_eval(RJ,'bt',tz,la_z,lo_z)
B1.axhspan(0,14,color=GRID,lw=0); B1.text(13.2,7,'calm eye (SAR 21:15Z: winds < 47 kt)',fontsize=10.5,color=INK2,va='center')
B1.axhspan(bm['rmw']-1.5,bm['rmw']+1.5,color=LBL,alpha=0.45,lw=0); B1.text(19.6,bm['rmw']-2.5,'max-wind radius\n%.0f ± 1.5 km'%bm['rmw'],fontsize=10.5,color=INK2,va='center')
B1.plot(tz,r,color=INK,lw=2.4,label='distance, fitted centre (fixes + offset + wander)')
B1.plot(tz,re,color=BLU,lw=1.8,ls='--',label='same, scaled to the oval eyewall (effective distance)')
B1.plot(tz,rv,color=GRY,lw=1.6,ls=':',label='v10 geometry (hourly fixes, offset ±2 km)'); B1.plot(tz,rbt,color=ORA,lw=1.8,ls='-.',label='JTWC best-track positions')
_,_,rp,rpe=model_eval(bm,'gp',t[m],lat[m],lon[m]); B1.plot(t[m],rp,'o',ms=6.5,color=INK,mec=SURF)
j=np.argmin(r); B1.annotate('closest approach %.0f km at %02d:%02dZ\n(%.2f × max-wind radius)'%(r[j],int(tz[j]),round(tz[j]%1*60),r[j]/bm['rmw']),(tz[j],r[j]),(13.3,62),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
B1.set_xlim(13,22); B1.set_ylim(0,130); B1.set_xlabel('20 October, UTC hour'); B1.set_ylabel('buoy distance from centre (km)')
B1.set_title('d   Where the buoy was relative to the eyewall',loc='left',fontweight='bold'); B1.legend(loc='upper right',frameon=False,fontsize=10)
# (e) radial pressure profile (storm part only: buoy minus fitted background), against effective distance
rr=np.linspace(0.3,250,2000)
B2.axvspan(0,r.min(),color=GRID,lw=0)
for tag,c in (('lo68',LBL),('median',BLU),('hi68',DBL)):
    r_=[x for x in RT if x['tag']==tag][0]; rise,_,_=radial(r_,'gp',rr); B2.plot(rr,r_['Pc']+rise,color=c,lw=2.2); B2.text(1.0,r_['Pc']+1.2,'%.0f'%r_['Pc'],color=c if c!=LBL else '#3d7fc4',fontsize=11,fontweight='bold')
rise,_,_=radial(RA,'gp',rr); B2.plot(rr,RA['Pc']+rise,color=ORA,lw=1.4,ls='--',label='alternative: two-ring Holland (same centre pressure)')
rise,_,_=radial(RU,'gp',rr); B2.plot(rr,RU['Pc']+rise,color=GRN,lw=1.4,ls=':',label='alternative: no secondary ring (same centre pressure)')
D,bg,rb,rbe=model_eval(bm,'gp',t,lat,lon); Pst=P-(bg-background(np.array(bm['bg']),np.array([TC]),np.array([LST_C]))[0])
bf=t<TC; B2.plot(rbe[bf],Pst[bf],'o',ms=7,color=INK,mec=SURF,label='buoy, storm approaching'); B2.plot(rbe[~bf],Pst[~bf],'s',ms=7,color=SURF,mec=INK,mew=1.4,label='buoy, storm departing')
B2.text(1.5,1004,'never sampled\n(inside %.0f km)'%r.min(),fontsize=10.5,color=INK2,va='top')
B2.set_xlim(0,250); B2.set_ylim(858,1010); B2.set_xlabel('effective distance from centre (km; oval eyewall)'); B2.set_ylabel('pressure, tide and trend removed (hPa)')
B2.set_title('e   Radial pressure profile at 17:33Z',loc='left',fontweight='bold'); B2.legend(loc='lower right',frameon=False)
# (f) wind structure
for k_,c,lw,lab in (('R3_21_0929',GRY,1.3,'RCM-3 21 Oct 09:29Z (after the peak)'),('S1D_20_0909',PUR,1.6,'Sentinel-1D 20 Oct 09:09Z (~17% low at eyewall)'),
                    ('R3_20_0920',GRN,1.6,'RCM-3 20 Oct 09:20Z (~50° incidence)'),('R3_20_2115',INK,2.2,'RCM-3 20 Oct 21:15Z')):
    B3.plot(SP[k_]['rc'],SP[k_]['v']*1.94384,color=c,lw=lw,label=lab)
_,V,_=radial(bm,'gp',rr); B3.plot(rr,V,color=BLU,lw=2.6,label='ring model: wind above the boundary layer')
B3.plot(rr,V*LW.alpha_x(rr/ST['interp']['Rm'],LW.DEF),color=BLU,lw=1.4,ls=':',label='same × α(r) (10-m equivalent)')
B3.axvspan(0,14,color=GRID,lw=0); B3.axvline(r.min(),color=RED,lw=1.4,ls='--'); B3.text(r.min()+1,8,'buoy closest\napproach',fontsize=10.5)
B3.set_xlim(0,100); B3.set_ylim(0,265); B3.set_xlabel('distance from centre (km)'); B3.set_ylabel('wind speed (kt)')
B3.set_title('f   Wind structure: SAR azimuthal means and fit',loc='left',fontweight='bold'); B3.legend(loc='upper right',fontsize=9.4,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
fig.suptitle('Typhoon Champi (29W), 20 October 2026 — drifting-buoy eyewall pass: observations and storm structure',x=0.01,y=0.995,ha='left',fontsize=17,fontweight='bold')
h=GPJ['hyper']
fig.text(0.01,0.968,'Buoy pressures fitted with a storm wind profile in gradient balance (radially varying air density; SAR-measured eye shape) plus atmospheric background (tides, trend).\n'
         'Centre: hourly Himawari-9 IR eye fixes and SAR/ATMS surface fixes combined in a track model (fix scatter %.1f km); the centre may wander within the track uncertainty\n'
         '(±%.1f km at 17:04Z). Eyewall oval from three SAR passes. SAR 10-m winds converted to gradient level with a log-layer factor α(r) (0.885 at the RMW).'%(h['sn'],np.sqrt(GPJ['cov_win'][4][4])),fontsize=12,color=INK2,va='top')
fig.text(0.01,0.004,'Sources: buoy WMO 2802285 (NOAA; supplied by Evan); SAR winds NOAA/NESDIS/STAR - RCM imagery © Government of Canada 2026, contains modified Copernicus Sentinel data; IR: JMA Himawari-9; ATMS: NOAA JPSS; best track: JTWC (provisional). Full references in README.',fontsize=10,color=INK2)
fig.tight_layout(rect=(0,0.015,1,0.925)); fig.savefig(os.path.join(HERE,'fig1_observations.png'),dpi=170)
print('saved')
