# Check on the family weights: leave-one-out over the SAR structure measurements as well as the buoy readings.
# The headline weights (weights.py) score only the six near-core buoy readings, so they cannot see how well each profile model matches
# the SAR wind structure. Here each SAR-derived measurement that all three models share - radius of maximum wind, wind ratio at 1.4 RMW,
# peak wind, wind ratio at 2 RMW - is removed in turn (its sd set very large), the model refitted with Pc free, and the removed measurement
# scored with its Gaussian density at the refitted value (plug-in, as for the buoy readings). The eye integral is fitted too but not
# scored: no buoy reading lies inside 23 km, so with its own measurement removed the eye shape is unconstrained and a plug-in score is
# arbitrary. The ring measurements (secondary maximum) exist only in the ring model and are not scored either.
# Weights: pseudo-BMA+ over the held-out items (weights.predictive_weights); combined distribution from the Monte Carlo samples (mc11.json).
# Writes sloo.json. Run after weights.py and mc4.py.
import sys, os, json, time, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import make_res, NB
from weights import predictive_weights
from scipy.stats import norm
from multiprocessing import Pool
ITEMS=['Rm','eye','v14','Vg','v20']; SCORED=['Rm','v14','Vg','v20']
def key(fam,it): return ('I' if fam=='A' else 's') if it=='eye' else it
def job(a):
    fam,it=a; j=dict(mc.DEF,fam=fam); pri0,data,s=mc.build(j,None); pri=dict(pri0)
    if it: k=key(fam,it); pri[k]=(pri0[k][0],1e4)
    rng=np.random.default_rng(3); st=mc.default_starts(j,pri,rng,nrand=8)
    best,_=mc.fit_free(j,pri,data,s,st)
    res,unpack,_,_=make_res(fam,best.x[0],'gp',pri=pri0,sig=s); pen=res(best.x[1:])[NB:]
    z=dict(zip(ITEMS,[float(v) for v in pen[3:8]]))          # penalty order in core.make_res: offset x, y, Pn, then these five
    out=dict(fam=fam,item=it,Pc=float(best.x[0]),chi2=float(2*best.cost),z_all=z)
    if it: out.update(z=z[it],logscore=float(norm.logpdf(z[it])))
    return out
if __name__=='__main__':
    t0=time.time()
    with Pool(2) as p: out=p.map(job,[(f,it) for f in 'TUA' for it in ITEMS+[None]],chunksize=1)          # None: full fit, for the z of each measurement
    print('refits done %.0f s'%(time.time()-t0))
    WJ=json.load(open(os.path.join(HERE,'weights.json'))); MC=json.load(open(os.path.join(HERE,'mc11.json'))); JT=json.load(open(os.path.join(HERE,'final.json')))['jtwc_1733']
    S={'T':np.array([d['Pc'] for d in MC if d['tag']=='primary']),'U':np.array([d['Pc'] for d in MC if d['tag']=='alt_U']),'A':np.array([d['Pc'] for d in MC if d['tag']=='alt_A'])}
    def wq(wt,ps=(2.5,16,50,84,97.5)):
        ks=[k for k in S if wt.get(k,0)>0]; v=np.concatenate([S[k] for k in ks]); ww=np.concatenate([np.full(len(S[k]),wt[k]/len(S[k])) for k in ks])
        o=np.argsort(v); c=np.cumsum(ww[o]); c/=c[-1]; return [float(np.interp(p/100,c,v[o])) for p in ps],float(ww[v<JT].sum()/ww.sum())
    buoy=[o for o in WJ['fits'] if o['kind']=='loo']
    def recs(items): return [dict(kind='loo',fam=o['fam'],drop=[100+ITEMS.index(o['item'])],logscore=o['logscore']) for o in out if o['item'] in items]
    print('removed item: z (Pc after refit)')
    for it in ITEMS: print('  %-4s '%it+'  '.join('%s %+.2f (%.1f)'%(f,o['z'],o['Pc']) for f in 'TUA' for o in out if o['fam']==f and o['item']==it)+('' if it in SCORED else '   [not scored]'))
    schemes={}
    for lab,r in (('buoy',buoy),('structure',recs(SCORED)),('buoy+structure',buoy+recs(SCORED)),('buoy+structure_no_peak_wind',buoy+recs(['Rm','v14','v20']))):
        pb,stk=predictive_weights(r); q,p=wq(pb); tot={f:float(sum(o['logscore'] for o in r if o['fam']==f)) for f in 'TUA'}
        schemes[lab]=dict(sum_logscore=tot,pbma=pb,q=q,p_below_jtwc=p)
        print('%-28s sum log score '%lab+' '.join('%s %.1f'%(f,tot[f]) for f in 'TUA')+' | pBMA+ '+' '.join('%s %.2f'%(f,pb[f]) for f in 'TUA')+
              ' | median %.1f, 68%% %.1f-%.1f, 95%% %.1f-%.1f, P(below JTWC) %.2f'%(q[2],q[1],q[3],q[0],q[4],p))
    i19=[o['drop'][0] for o in buoy if abs(o['drop'][0]-19)<0.5][0]
    pb,_=predictive_weights([o for o in buoy if o['drop'][0]!=i19]); q,p=wq(pb); schemes['buoy_without_1904']=dict(pbma=pb,q=q,p_below_jtwc=p)
    print('buoy readings without 19:04Z in the score: pBMA+ '+' '.join('%s %.2f'%(f,pb[f]) for f in 'TUA')+' | median %.1f'%q[2])
    print('full fits, z of each measurement: '+' | '.join(f+' '+' '.join('%s %+.2f'%(k,v) for k,v in o['z_all'].items()) for f in 'TUA' for o in out if o['fam']==f and o['item'] is None))
    hw=WJ['weights']['pbma']; q,p=wq({'T':hw['T'],'U':hw['U']}); schemes['buoy_no_holland']=dict(pbma={'T':hw['T']/(hw['T']+hw['U']),'U':hw['U']/(hw['T']+hw['U']),'A':0.0},q=q,p_below_jtwc=p)
    print('buoy weights with Holland removed (ring/no-ring ratio kept): median %.1f, 68%% %.1f-%.1f'%(q[2],q[1],q[3]))
    json.dump(dict(items=out,scored=SCORED,schemes=schemes),open(os.path.join(HERE,'sloo.json'),'w'),indent=1)
