# Radius-dependent 10-m to gradient-level wind factor alpha(r) = V10 / Vgradient from a log-layer boundary-layer model:
#   alpha(r) = [ln(10/z0) / ln(z_s/z0)] * beta(r),  z_s = 0.1 h(r) (surface-layer top; the mixed layer above it is near-uniform)
#   h(r): boundary-layer depth, shallow at the eyewall (h_ew) and deepening outward to h_out over Lh (in RMW units)
#   beta(r): boundary-layer wind / gradient wind; supergradient at the eyewall (b_ew) relaxing to sub-gradient outside (b_out) over Lb
#   Inside the RMW alpha is held at its RMW value. z0 from drag saturation at extreme winds (Cd(10 m) ~ 0.002-0.003 -> z0 ~ 1-4 mm).
import os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__))
DEF=dict(z0=0.002,h_ew=500.0,h_out=1100.0,Lh=1.2,b_ew=1.05,b_out=0.94,Lb=0.6)
def draw(rng):
    return dict(z0=10**rng.uniform(np.log10(0.001),np.log10(0.004)),h_ew=rng.uniform(350,650),h_out=rng.uniform(800,1500),
                Lh=rng.uniform(0.5,2.0),b_ew=rng.uniform(1.00,1.10),b_out=rng.uniform(0.88,1.00),Lb=rng.uniform(0.3,1.0))
def alpha_x(x,p):
    """alpha at normalized radius x = r/RMW"""
    d=np.maximum(np.asarray(x,float)-1.0,0.0)
    h=p['h_out']-(p['h_out']-p['h_ew'])*np.exp(-d/p['Lh']); zs=0.1*h
    beta=p['b_out']+(p['b_ew']-p['b_out'])*np.exp(-d/p['Lb'])
    return np.log(10.0/p['z0'])/np.log(zs/p['z0'])*beta
# SAR surface shape at 17:33Z in normalized coordinates (sar/endpoint.py): 09Z endpoint (Sentinel-1D 09:09Z shape 0.75, RCM-3 09:20Z 0.25)
# and RCM-3 21:15Z, interpolated in time (w = weight of 21:15Z). w = 1 / 0 give the single-pass (no interpolation) variants.
SD=os.path.join(HERE,'sar')
_ST=json.load(open(os.path.join(SD,'structure_1733.json')))
XG=np.array(_ST['x_shape']); S1=np.array(_ST['nat09']['shape']); S2=np.array(_ST['nat2115']['shape'])
W2115=float(_ST['interp']['w2115'])
def sfc_shape(w=W2115): return (1-w)*S1+w*S2
def grad_metrics(p,w=W2115):
    """gradient-level shape ratios implied by the SAR surface shape and alpha(r): v14, v20, v30, secondary maximum (radius in RMW, strength)"""
    s=sfc_shape(w); g=s/alpha_x(XG,p)*alpha_x(1.0,p); g1=np.interp(1.0,XG,g)
    v=lambda x: float(np.interp(x,XG,g)/g1)
    m=(XG>1.45)&(XG<2.2); j=np.argmax(np.where(m,g,-1))
    return dict(v14=v(1.4),v20=v(2.0),v30=v(3.0),vsec=float(g[j]/g1),x2=float(XG[j]),alpha_rm=float(alpha_x(1.0,p)),alpha_14=float(alpha_x(1.4,p)),alpha_20=float(alpha_x(2.0,p)),alpha_30=float(alpha_x(3.0,p)))
# Franklin, Black & Valde (NHC "GPS dropwindsonde wind profiles", 2000/2003): mean surface / 700-hPa wind 0.88 at the flight-level RMW,
# 0.91 in the eyewall, 0.78 in the outer vortex. Used as a consistency check on alpha(r), not as an input.
FRANKLIN=dict(rmw=0.88,eyewall=0.91,outer=0.78)
def priors(rng,w0,wsd,n=20000):
    M=[]
    for k in range(n):
        p=draw(rng); w=np.clip(rng.normal(w0,wsd),0,1) if wsd>0 else w0; M.append(grad_metrics(p,w))
    keys=M[0].keys(); A={k:np.array([m[k] for m in M]) for k in keys}; return {k:[float(A[k].mean()),float(A[k].std())] for k in keys}
if __name__=='__main__':
    out={}
    for name,w0,wsd in (('interp',W2115,0.10),('nat2115',1.0,0.0),('nat09',0.0,0.0)):
        out[name]=priors(np.random.default_rng(7),w0,wsd); s0=sfc_shape(w0); g=lambda x: float(np.interp(x,XG,s0)/np.interp(1.0,XG,s0))
        print('%-8s surface ratios v14 %.3f v20 %.3f | gradient: '%(name,g(1.4),g(2.0))+' '.join('%s %.3f+-%.3f'%(k,*out[name][k]) for k in ('v14','v20','vsec','x2','alpha_rm')))
    a=out['interp']; out['franklin_check']=dict(alpha_rm=a['alpha_rm'],alpha_14=a['alpha_14'],alpha_20=a['alpha_20'],alpha_30=a['alpha_30'],franklin=FRANKLIN)
    print('Franklin check: alpha at RMW %.3f (dropsondes 0.88 at RMW, 0.91 eyewall); 1.4 RMW %.3f; 2 RMW %.3f; 3 RMW %.3f (outer vortex 0.78)'%(a['alpha_rm'][0],a['alpha_14'][0],a['alpha_20'][0],a['alpha_30'][0]))
    json.dump(out,open(os.path.join(HERE,'logwind_priors.json'),'w'),indent=1)
