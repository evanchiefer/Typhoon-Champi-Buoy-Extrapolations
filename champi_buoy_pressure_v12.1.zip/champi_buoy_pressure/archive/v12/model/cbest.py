# v12. Starting points for the Monte Carlo: for each model configuration, the best constrained fit with Pc free (multistart) and fits at
# Pc = best -12 / +12 hPa (continuation from the best). Writes cbest.json.
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import make_res, least_squares
# v12: every profile model x outer-conversion case, plus the configurations the sensitivity runs use (other keys fall back to the headline one)
CONF=[dict(fam=f,a20case=c) for f in 'TUA' for c in ('prior','free','loglayer','flat','independent')]+[dict(fam=f,variant=v) for f in 'TUA' for v in ('nat2115','nat09')]+\
     [dict(fam=f,track=tr) for f in 'TUA' for tr in ('irf','bt')]+[dict(fam='C'),dict(fam='T',vg=False),dict(fam='U',vg=False),dict(fam='A',vg=False)]
def run(c):
    j=dict(mc.DEF); j.update(c); o=mc.map_fit(j,nrand=12,seed=11,with_summary=False); pri,data,s=mc.build(j,None)
    rows=[dict(Pc=o['Pc'],x=o['x'][1:],chi2=o['chi2'])]; x0=np.array(o['x'][1:])
    for dp in (-12.0,12.0):
        pc=o['Pc']+dp; res,_,lb,ub=make_res(j['fam'],pc,j['track'],pri=pri,sig=s)
        r=least_squares(res,np.clip(x0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=6000); rows.append(dict(Pc=pc,x=[float(v) for v in r.x],chi2=float(2*r.cost)))
    return mc.config_key(j),rows
if __name__=='__main__':
    t0=time.time()
    with Pool(2) as pool: out=pool.map(run,CONF,chunksize=1)
    CB={k:v for k,v in out}
    for k,v in CB.items(): print('%-26s best Pc %.1f chi2 %.2f'%(k,v[0]['Pc'],v[0]['chi2']))
    json.dump(CB,open(os.path.join(HERE,'cbest.json'),'w')); print('%.0f s'%(time.time()-t0))
