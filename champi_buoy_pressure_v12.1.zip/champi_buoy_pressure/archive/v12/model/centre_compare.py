# Centre cross-check at 17:33Z: the v12 fitted centre (ring model at the combined median, with wander) against the separately run
# centre-relocation analysis [B10] (their headline posterior and their IR-vs-STAR sensitivity centre), and the v12 track against the
# centre fixes that neither analysis fits (CIMSS ARCHER, JTWC) and the ATMS fix, at their own times (16:30-18:30Z).
# Input: ../data_source/centre_fixes_17Z.csv (from [B10]). Writes centre_compare.json.
import sys, os, csv, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import core as C
from common import centre_track
C.set_track(C._tv()['hier']['i_median']); fa,fo=C.TRACKS['gp'][:2]
def km(la1,lo1,la2,lo2): return float((lo2-lo1)*111*np.cos(np.radians((la1+la2)/2))),float((la2-la1)*111)
CF=json.load(open(os.path.join(HERE,'fits_constrained.json'))); med=[r for r in CF if r['name']=='T_con_gp' and r['tag']=='median'][0]
ml,mo=centre_track(med,'gp',np.array([17.55])); ml,mo=float(ml[0]),float(mo[0])
R=list(csv.DictReader(open(os.path.join(os.path.dirname(HERE),'data_source','centre_fixes_17Z.csv'))))
out=dict(v12_centre=[ml,mo],derived=[],fixes=[])
for r in R:
    if r['source'].startswith('DERIVED'):
        dx,dy=km(ml,mo,float(r['lat']),float(r['lon'])); out['derived'].append(dict(source=r['source'],lat=float(r['lat']),lon=float(r['lon']),dE=dx,dN=dy,dist=float(np.hypot(dx,dy)),unc=r['uncertainty_km']))
    h=float(r['hour'])
    if 16.5<=h<=18.5 and ('ARCHER' in r['source'] or 'JTWC' in r['source'] or 'ATMS microwave' in r['source']):
        la,lo=float(fa(h)),float(fo(h)); dx,dy=km(la,lo,float(r['lat']),float(r['lon']))
        out['fixes'].append(dict(hour=h,source=r['source'],sensor=r['sensor'],dE=dx,dN=dy,dist=float(np.hypot(dx,dy)),unc=r['uncertainty_km'],role=r['role']))
for d in out['derived']: print('%-60s %+.1f E %+.1f N km (%.1f km)'%(d['source'][:60],d['dE'],d['dN'],d['dist']))
for d in out['fixes']: print('%5.2fh %-40s %-16s %+6.1f E %+6.1f N (%.1f km) %s'%(d['hour'],d['source'][:40],d['sensor'][:16],d['dE'],d['dN'],d['dist'],d['unc'][:26]))
json.dump(out,open(os.path.join(HERE,'centre_compare.json'),'w'),indent=1)
