# v12: best fits, buoy-conservation diagnostics and model weights (v12 spec sections 3 and H7).
# For each profile model (T ring, U no ring, A two-ring Holland) and outer-conversion case (free, prior = headline, flat, loglayer), plus the
# buoy-only reference (no SAR outer-structure terms):
#   best fit with Pc free; chi2 of the buoy readings and of each SAR term; z of every reading (18:04Z called out); fitted alpha20 and the
#   implied alpha20 = alpha_rm x s20 / g20 (shape-flexibility test); leave-one-out refits of the six core readings (scoring only, plug-in
#   Student-t log score as in v11); effective number of parameters p_eff = sum of the hat-matrix diagonal over the measurement rows.
# Weights (headline: measurement-aware AIC):
#   chi2_meas = buoy chi2 + SAR terms shared by all models (RMW, eye integral, 1.4 RMW, peak wind, 2 RMW) + one secondary-maximum term
#               scored the same way for all models (the model's wind at the SAR secondary-maximum radius, x2 x its RMW, against the
#               SAR ratio there); measAIC = chi2_meas + 2 p_eff (p_eff includes the ring model's own ring rows).
#   also: measAIC_all (adds the SAR ellipse terms), AIC and BIC with nominal parameter counts, BIC with p_eff, pseudo-BMA+ on the buoy
#   leave-one-out scores, pseudo-BMA+ on buoy + SAR leave-one-out scores (RMW, 1.4 RMW, peak wind, 2 RMW; eye not scored), equal.
# Writes weights12.json, rescale.json (sigma scale giving buoy chi2 / dof = 1, for case S20).
import sys, os, json, time, numpy as np
from multiprocessing import Pool
from scipy.stats import t as tdist, norm
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc, logwind as LW
from core import make_res, NB, P, t as T_, ROBUST_NU, sig_obs, least_squares, shapeC, vgA_rho, NBASE
from weights import predictive_weights
FAMS='TUA'; CASES=('free','prior','flat','loglayer'); CORE=(15,16,17,18,19,20)
SARROWS={'Rm':3,'eye':4,'v14':5,'Vg':6,'v20':7}
def cfg(fam,case): return dict(fam=fam,a20case='prior' if case=='buoyonly' else case,buoyonly=(case=='buoyonly'))
def fit(fam,case,drop=(),hold=None,x0=None):
    j=dict(mc.DEF,**cfg(fam,case)); pri,data,s=mc.build(j,None); pri=dict(pri); s=s.copy()
    for i in drop: s[i]=1e4
    if hold:
        k={'Rm':'Rm','v14':'v14','Vg':'Vg','v20':'v20'}[hold]
        if k in ('v14','v20'): pri['sdm']=dict(pri['sdm'],**{k:1e4})
        else: pri[k]=(pri[k][0],1e4)
    rng=np.random.default_rng(3); st=mc.default_starts(j,pri,rng,nrand=6)
    if x0 is not None: st=[np.array(x0)]+st
    best,_=mc.fit_free(j,pri,data,s,st,tol=1e-8)
    return j,pri,data,s,best
def jac(f,x,lb,ub,rel=1e-5):
    """finite-difference Jacobian (central; one-sided next to a bound)"""
    r0=f(x); Jm=np.zeros((len(r0),len(x)))
    for k in range(len(x)):
        h=rel*max(1.0,abs(x[k])); up=x.copy(); dn=x.copy()
        if x[k]+h<=ub[k] and x[k]-h>=lb[k]: up[k]+=h; dn[k]-=h; Jm[:,k]=(f(up)-f(dn))/(2*h)
        elif x[k]+h<=ub[k]: up[k]+=h; Jm[:,k]=(f(up)-r0)/h
        else: dn[k]-=h; Jm[:,k]=(r0-f(dn))/h
    return Jm
def ring_z(fam,pri,u,Pc):
    """model wind at the SAR secondary-maximum radius (x2 x model RMW) over its peak, converted to the surface, against the SAR ratio"""
    x2=pri['x2']; arm=pri['arm_val']; fac=LW.alpha_two(x2,arm,u['a20'])/arm
    if fam=='A':
        r=np.linspace(2,150,3000); vg=vgA_rho(r,u['parts'],Pc,u['Dtot'],pri['dens'],u['parts'][0][1]); i=vg.argmax(); v=np.interp(x2*r[i],r,vg)/vg[i]
    else:
        tab=pri['tab'] if fam in 'TU' else None; rm=u['Rm']; vv=shapeC(np.array([rm,x2*rm]),rm,u['n'],u['A'],u['X1'],u['X2'],u['a'],u['R2'],u['W2'],tab); v=vv[1]/vv[0]
    return float((v*fac-pri['sfc']['ssec'])/pri['sdm']['vsec'])
def full(a):
    fam,case=a; j,pri,data,s,best=fit(fam,case); Pc=best.x[0]
    res,unpack,lb,ub=make_res(fam,Pc,'gp',pri=pri,sig=s)
    def rall(q): return make_res(fam,q[0],'gp',pri=pri,sig=s)[0](q[1:])
    r=rall(best.x); _,_,lb,ub=make_res(fam,880.0,'gp',pri=pri); lb=np.r_[800.0,lb]; ub=np.r_[912.0,ub]
    Jm=jac(rall,best.x,lb,ub); free_=(best.x>lb+1e-6)&(best.x<ub-1e-6); Jf=Jm[:,free_]           # parameters held at a bound are not free
    Hd=np.einsum('ij,jk,ik->i',Jf,np.linalg.pinv(Jf.T@Jf),Jf)
    pen=r[NB:]; names=mc.PEN_NAMES[fam]+['a20']; idx={nm:NB+k for k,nm in enumerate(names)}
    rows=list(range(NB))+[idx[k] for k in ('Rm','eye','v14','Vg','v20')]+([idx['R2'],idx['vsec']] if fam in 'CT' else [])
    rows_all=rows+[idx['e0'],idx['th0']]
    u=unpack(best.x[1:]); zr=ring_z(fam,pri,u,Pc); d=mc.detail(j,pri,data,s,best)
    chi_sar={k:float(pen[SARROWS[k]]**2) for k in SARROWS}; chi_meas=float(np.sum(r[:NB]**2))+sum(chi_sar.values())+zr**2
    s20=pri['sfc']['s20']; imp=float(pri['arm_val']*s20/d['fit']['g20'])
    return dict(fam=fam,case=case,Pc=float(Pc),chi2_total=float(2*best.cost),chi2_buoy=float(np.sum(r[:NB]**2)),chi2_sar=chi_sar,z_ring=zr,chi2_meas=chi_meas,
                chi2_ellipse=float(pen[idx['e0']-NB]**2+pen[idx['th0']-NB]**2),p_eff=float(Hd[rows].sum()),p_eff_buoy=float(Hd[:NB].sum()),p_eff_all=float(Hd[rows_all].sum()),
                k=int(len(best.x)),z=d['z'],resid=d['resid'],z_1804=float(d['z'][18]),a20_fit=d['fit']['a20'],g20=d['fit']['g20'],a20_implied=imp,
                rmw=d['fit']['rmw'],vmax_kt=d['fit']['vmax_kt'],x=[float(v) for v in best.x],chi2_parts=d['chi2_parts'])
def loo(a):
    fam,case,i,x0=a; j,pri,data,s,best=fit(fam,case,drop=(i,),x0=x0); Pc=best.x[0]
    res,unpack,_,_=make_res(fam,Pc,'gp',pri=pri,sig=s); Pm,_,_=res.pressure(unpack(best.x[1:])); s0=sig_obs()[i]; z=(P[i]-Pm[i])/s0
    return dict(kind='loo',fam=fam,case=case,drop=[i],Pc=float(Pc),pred=float(Pm[i]),z=float(z),logscore=float(tdist.logpdf(z,ROBUST_NU)-np.log(s0)))
def sloo(a):
    fam,item,x0=a; j,pri,data,s,best=fit(fam,'prior',hold=item,x0=x0); Pc=best.x[0]
    pri0,_,_=mc.build(dict(mc.DEF,fam=fam),None)
    r=make_res(fam,Pc,'gp',pri=pri0,sig=s)[0](best.x[1:]); z=float(r[NB+SARROWS[item]])
    return dict(kind='sloo',fam=fam,item=item,Pc=float(Pc),z=z,logscore=float(norm.logpdf(z)))
def wts(score):
    m=min(score.values()); w={f:np.exp(-0.5*(v-m)) for f,v in score.items()}; S=sum(w.values()); return {f:float(v/S) for f,v in w.items()}
if __name__=='__main__':
    t0=time.time(); npr=int(sys.argv[1]) if len(sys.argv)>1 else 1
    CK=os.path.join(HERE,'weights12_checkpoint.json'); ck=json.load(open(CK)) if os.path.exists(CK) else {}
    with Pool(npr) as pool:
        if 'F' not in ck: ck['F']=pool.map(full,[(f,c) for f in FAMS for c in CASES+('buoyonly',)],chunksize=1); json.dump(ck,open(CK,'w'))
        F=ck['F']; FX={(o['fam'],o['case']):o['x'] for o in F}
        if 'L' not in ck: ck['L']=pool.map(loo,[(f,c,i,FX[(f,c)]) for f in FAMS for c in CASES+('buoyonly',) for i in CORE],chunksize=1); json.dump(ck,open(CK,'w'))
        L=ck['L']
        if 'SL' not in ck: ck['SL']=pool.map(sloo,[(f,it,FX[(f,'prior')]) for f in FAMS for it in ('Rm','v14','Vg','v20')],chunksize=1); json.dump(ck,open(CK,'w'))
        SL=ck['SL']
    print('fits done %.0f s'%(time.time()-t0))
    FB={(o['fam'],o['case']):o for o in F}; n_meas=NB+6
    for o in F:
        lo=[l for l in L if l['fam']==o['fam'] and l['case']==o['case']]; o['loo']=lo; o['loo_sum']=float(sum(l['logscore'] for l in lo))
    W={}
    for case in CASES:
        G={f:FB[(f,case)] for f in FAMS}
        W[case]=dict(measAIC=wts({f:G[f]['chi2_meas']+2*G[f]['p_eff'] for f in FAMS}),
                     measAIC_all=wts({f:G[f]['chi2_meas']+G[f]['chi2_ellipse']+2*G[f]['p_eff_all'] for f in FAMS}),
                     AIC_nominal=wts({f:G[f]['chi2_meas']+2*G[f]['k'] for f in FAMS}),BIC_nominal=wts({f:G[f]['chi2_meas']+G[f]['k']*np.log(n_meas) for f in FAMS}),
                     BIC_eff=wts({f:G[f]['chi2_meas']+G[f]['p_eff']*np.log(n_meas) for f in FAMS}),equal={f:1/3 for f in FAMS})
        recs=[dict(kind='loo',fam=l['fam'],drop=l['drop'],logscore=l['logscore']) for l in L if l['case']==case]
        W[case]['pbma_buoy'],W[case]['stacking_buoy']=predictive_weights(recs)
        if case=='prior':
            srec=[dict(kind='loo',fam=o['fam'],drop=[100+['Rm','v14','Vg','v20'].index(o['item'])],logscore=o['logscore']) for o in SL]
            W[case]['pbma_buoy_sar'],_=predictive_weights(recs+srec)
    print('\nbest fits (Pc free), chi2 of buoy readings and SAR terms, effective parameters, 18:04Z z, fitted / implied alpha20:')
    for case in CASES+('buoyonly',):
        for f in FAMS:
            o=FB[(f,case)]; fr=FB[(f,'free')]
            print('  %s %-9s Pc %.1f | buoy %.2f (vs free %+.2f) | SAR '%(f,case,o['Pc'],o['chi2_buoy'],o['chi2_buoy']-fr['chi2_buoy'])+' '.join('%s %.2f'%(k,v) for k,v in o['chi2_sar'].items())+
                  ' ring z %+.2f | meas %.2f p_eff %.1f (buoy %.1f) | 18:04Z z %+.2f | a20 fit %s implied %.3f | RMW %.1f vmax %.0f | LOO sum %.2f (vs free %+.2f)'%(
                  o['z_ring'],o['chi2_meas'],o['p_eff'],o['p_eff_buoy'],o['z_1804'],('%.3f'%o['a20_fit']) if o['a20_fit'] else '-',o['a20_implied'],o['rmw'],o['vmax_kt'],o['loo_sum'],o['loo_sum']-fr['loo_sum']))
    print('\nweights by case:')
    for case in CASES:
        for k,v in W[case].items(): print('  %-9s %-14s '%(case,k)+' '.join('%s %.3f'%(f,v[f]) for f in FAMS))
    print('\nSAR leave-one-out (headline case): '+' | '.join('%s %s z %+.2f Pc %.1f'%(o['fam'],o['item'],o['z'],o['Pc']) for o in SL))
    RS={f:dict(chi2_buoy=FB[(f,'prior')]['chi2_buoy'],dof=NB-FB[(f,'prior')]['p_eff_buoy']) for f in FAMS}
    for f in FAMS: RS[f]['tscale']=float(np.sqrt(RS[f]['chi2_buoy']/RS[f]['dof']))
    print('sigma rescale to buoy chi2/dof = 1 (case S20): '+' '.join('%s %.3f (chi2 %.2f, dof %.1f)'%(f,RS[f]['tscale'],RS[f]['chi2_buoy'],RS[f]['dof']) for f in FAMS))
    json.dump(RS,open(os.path.join(HERE,'rescale.json'),'w'),indent=1)
    json.dump(dict(fits=F,loo=L,sar_loo=SL,weights=W,n_meas=n_meas),open(os.path.join(HERE,'weights12.json'),'w'),indent=1)
    print('%.0f s'%(time.time()-t0))
