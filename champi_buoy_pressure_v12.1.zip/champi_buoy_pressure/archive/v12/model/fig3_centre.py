# Figure 3: storm centre at 17:33Z (v12). Shading: ring-model best-fit central pressure with the centre held at each grid point
# (centre_map.py: whole surface track shifted by a constant offset, no centre prior, no wander, headline likelihood otherwise);
# white contours: buoy + SAR misfit above its minimum (centre12.py). Markers: fitted centre in the Monte Carlo trials of each case,
# mean ± 1 sigma (centretrials12.py), the centre fixes at their own times, and the separately run centre analysis [B10].
# Frame: km east / north of the smoothed IR eye track (track_gp, IR component, posterior-median drift model) at 17:33Z.
import sys, os, json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
import matplotlib.patheffects as pe
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Ellipse, Rectangle
from matplotlib.lines import Line2D
import track_gp as TG
HERE=os.path.dirname(os.path.abspath(__file__))
M=json.load(open(os.path.join(HERE,'centre_map.json'))); CT=json.load(open(os.path.join(HERE,'centretrials12.json'))); F=json.load(open(os.path.join(HERE,'final12.json')))
C12=json.load(open(os.path.join(HERE,'centre12.json'))); TH=json.load(open(os.path.join(HERE,'track_hier.json'))); G=TG.TrackGP(so=TH['median_flat'])
_s=G.mean([17.55],surface=True)[0]; _i=G.mean([17.55],surface=False)[0]; D=(_s[0]-_i[0],_s[1]-_i[1])      # surface track minus IR eye track at 17:33Z
E=np.array(M['ex'])+D[0]; N=np.array(M['ny'])+D[1]; gd={(round(g['ox'],2),round(g['oy'],2)):g for g in M['grid']}
PC=np.array([[gd[(round(x,2),round(y,2))]['Pc'] for x in M['ex']] for y in M['ny']]); X2=np.array([[gd[(round(x,2),round(y,2))]['chi2'] for x in M['ex']] for y in M['ny']])
_f=[o for o in C12['free'] if o['fam']=='T' and o['free']][0]; DO=dict(E=_f['ox']+D[0],N=_f['oy']+D[1],Pc=_f['Pc'],chi2=_f['chi2']); X0=min(DO['chi2'],X2.min())
def fr(t,la,lo):
    ir=G.mean([t],surface=False)[0]; return (lo-TG.LON0)*TG.KX-ir[0],(la-TG.LAT0)*TG.KY-ir[1]
Q=F['headline']['q']; CS=F['cases']
cm=LinearSegmentedColormap.from_list('pc',['#0b2a55',DBL,BLU,'#86b6ec']); lv=np.arange(860,914.1,2.0)
halo=[pe.Stroke(linewidth=3.8,foreground=INK,alpha=0.5),pe.Normal()]; thalo=[pe.withStroke(linewidth=2.6,foreground=INK,alpha=0.55)]
fig=plt.figure(figsize=(17,11.2))
A=fig.add_axes([0.05,0.255,0.235,0.60]); B=fig.add_axes([0.33,0.255,0.53,0.60]); cax=fig.add_axes([0.885,0.255,0.014,0.60])
def base(ax,lw=(2.4,1.7,1.1),isob=True):
    cf=ax.contourf(E,N,np.clip(PC,lv[0],lv[-1]),levels=lv,cmap=cm,extend='both')
    if isob:
        cs=ax.contour(E,N,PC,levels=np.arange(870,911,10),colors=INK,linewidths=0.7,alpha=0.5,linestyles=':'); ax.clabel(cs,fmt='%.0f',fontsize=9.5,inline=True)
    cc=ax.contour(E,N,X2-X0,levels=[2.3,6.2,11.8],colors=SURF,linewidths=lw)
    try: cc.set_path_effects(halo)
    except Exception: [c.set_path_effects(halo) for c in cc.collections]
    ax.plot(0,0,'+',ms=15,mew=2.4,color=SURF,zorder=7); ax.set_aspect('equal'); ax.grid(color=SURF,alpha=0.15); return cf
# (a) full view: the buoy + SAR valley
cf=base(A); ax=A
ax.errorbar(DO['E'],DO['N'],fmt='o',ms=12,color=SURF,mec=INK,mew=1.5,zorder=9)
m=(X2-X0)<=2.3; EE,NN=np.meshgrid(E,N)
ax.errorbar(DO['E'],DO['N'],xerr=[[DO['E']-EE[m].min()],[EE[m].max()-DO['E']]],yerr=[[DO['N']-NN[m].min()],[min(NN[m].max(),N.max())-DO['N']]],fmt='none',ecolor=SURF,elinewidth=2.0,capsize=4,zorder=8)
ax.annotate('buoy + SAR alone\nPc %.0f'%DO['Pc'],(DO['E'],DO['N']),(1.0,-35.5),fontsize=10.5,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.2))
o=CT['head']; ax.errorbar(*o['mean'],xerr=o['sd'][0],yerr=o['sd'][1],fmt='o',ms=9,color=ORA,mec=INK,mew=1.2,ecolor=ORA,elinewidth=2.2,capsize=3,zorder=10)
ax.annotate('v12 headline\nPc %.0f'%Q[2],tuple(o['mean']),(8.0,-3.5),fontsize=10.5,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.2))
ax.annotate('IR eye',(0,0),(-8.5,-2.6),fontsize=10,color=SURF,path_effects=thalo)
ZX=(-2.0,13.0); ZY=(-20.0,-5.0); ax.add_patch(Rectangle((ZX[0],ZY[0]),ZX[1]-ZX[0],ZY[1]-ZY[0],fill=False,ec=SURF,lw=1.3,ls='--',zorder=6))
ax.text(ZX[0]+0.3,ZY[0]-1.5,'panel b',fontsize=9.5,color=SURF,path_effects=thalo)
ax.set_xlim(E.min(),E.max()); ax.set_ylim(N.min(),N.max())
ax.set_xlabel('km east of the IR eye track'); ax.set_ylabel('km north of the smoothed IR eye track at 17:33Z')
ax.set_title('a   Full view: where the buoy alone puts the centre',loc='left',fontweight='bold',fontsize=12.5)
# (b) zoom: the centre estimates and fixes
base(B,lw=(2.8,2.0,1.3)); ax=B
def eb(c,col,mk,ms=11,z=8,lw=2.2):
    o=CT[c]; ax.errorbar(o['mean'][0],o['mean'][1],xerr=o['sd'][0],yerr=o['sd'][1],fmt=mk,ms=ms,color=col,mec=INK,mew=1.3,ecolor=col,elinewidth=lw,capsize=5,zorder=z)
ir0=G.mean([17.5],surface=False)[0]; ir1=G.mean([17.6],surface=False)[0]; ang=np.degrees(np.arctan2(ir1[1]-ir0[1],ir1[0]-ir0[0]))
for la,lo,sa,sc,ls in ((17.37776,131.58957,0.86,1.43,'-'),(17.33901,131.57247,1.10,4.17,'--')):
    x,y=fr(17.55,la,lo); ax.add_patch(Ellipse((x,y),2*sa,2*sc,angle=ang,fill=False,ec=SURF,lw=1.9,ls=ls,zorder=7)); ax.plot(x,y,'o',ms=7,mfc='none',mec=SURF,mew=1.9,zorder=7)
eb('S24_flat4km_irf',PUR,'^'); eb('v11chk_bt',RED,'v'); eb('S5_drift_fixed3','#f2c14e','D',ms=9); eb('S23_star_centre',GRN,'s'); eb('head',ORA,'o',ms=14,z=11,lw=2.8)
sf=TG.surface_fixes(); P={nm:fr(tf,la,lo) for nm,tf,lo,la,e in sf}
for nm,(x,y) in P.items(): ax.plot(x,y,'D',ms=9,color=SURF,mec=INK,mew=1.3,zorder=9)
sar=[v for k,v in P.items() if 'SAR' in k]; atms=[v for k,v in P.items() if 'ATMS' in k][0]
ax.annotate('SAR eye-ring fits\n09:09, 09:20, 21:15Z',sar[1],(2.2,-6.0),fontsize=10,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.1))
ax.annotate('ATMS 17:01Z',atms,(9.6,-8.4),fontsize=10,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.1))
for tf,la,lo,lab,xt in ((9+9/60+35/3600,16.670,133.719,'STAR 09:09Z',(-0.6,-13.6)),(21.2572,17.707,130.818,'STAR 21:15Z',(-0.6,-9.0))):
    x,y=fr(tf,la,lo); ax.plot(x,y,'P',ms=13,color=PUR,mec=SURF,mew=1.3,zorder=9)
    ax.annotate(lab,(x,y),xt,fontsize=10,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.1))
for tf,la,lo,lab,xt in ((17+2/60,17.33,131.71,'ARCHER\nATMS 17:02Z',(3.0,-17.6)),(17.5,17.35,131.61,'ARCHER\nHimawari 17:30Z',(10.6,-15.6))):
    x,y=fr(tf,la,lo); ax.plot(x,y,'^',ms=10,mfc='none',mec=SURF,mew=1.8,zorder=9)
    ax.annotate(lab,(x,y),xt,fontsize=9.5,color=SURF,path_effects=thalo,arrowprops=dict(arrowstyle='-',color=SURF,lw=1.0))
x,y=fr(18.0,17.4,131.4); ax.plot(x,y,'X',ms=11,color=SURF,mec=INK,mew=1.0,zorder=9); ax.annotate('JTWC 18Z',(x,y),(-1.75,-12.35),fontsize=10,color=SURF,path_effects=thalo)
ax.annotate('IR eye (cloud top)',(0,0),(0.3,-5.6),fontsize=10,color=SURF,path_effects=thalo) if ZY[1]>=0 else None
ax.set_xlim(*ZX); ax.set_ylim(*ZY); ax.set_xlabel('km east of the smoothed IR eye track at 17:33Z'); ax.set_ylabel('km north of the smoothed IR eye track at 17:33Z')
ax.set_title('b   The centre estimates and fixes (mean ± 1σ)',loc='left',fontweight='bold',fontsize=12.5)
ax.text(0.015,0.015,'white contours: buoy + SAR misfit Δχ² = 2.3 / 6.2 / 11.8 above its minimum\n(68 / 95 / 99.7% for two parameters; no centre fixes used)',transform=ax.transAxes,fontsize=10,color=SURF,path_effects=thalo,va='bottom')
cb=fig.colorbar(cf,cax=cax); cb.set_label('best-fit central pressure with the centre held at that point (hPa)'); cb.set_ticks(np.arange(860,915,8))
# legend (proxies with dark edges so the white symbols show)
L=lambda **k: Line2D([],[],ls='none',**k)
hs=[(L(marker='o',ms=12,color=ORA,mec=INK,mew=1.2),'v12 headline centre, ring-model trials (1000): Pc %.1f (68%% %.0f–%.0f)'%(Q[2],Q[1],Q[3])),
    (L(marker='s',ms=10,color=GRN,mec=INK),'STAR 09:09Z centre in place of the SAR ring fit: Pc %.1f'%CS['S23_star_centre']['q'][2]),
    (L(marker='D',ms=9,color='#f2c14e',mec=INK),'IR-to-surface drift fixed at 3 km: Pc %.1f'%CS['S5_drift_fixed3']['q'][2]),
    (L(marker='v',ms=10,color=RED,mec=INK),'JTWC best-track positions + fitted offset: Pc %.1f'%CS['v11chk_bt']['q'][2]),
    (L(marker='^',ms=10,color=PUR,mec=INK),'flat ±4 km centre error on the hourly IR fixes: Pc %.1f'%CS['S24_flat4km_irf']['q'][2]),
    (L(marker='o',ms=11,color=SURF,mec=INK,mew=1.4),'buoy + SAR alone, no centre information (68%% extent): Pc %.1f'%DO['Pc']),
    (L(marker='D',ms=9,color=SURF,mec=INK),'surface fixes used: SAR eye-ring fits (09:09, 09:20, 21:15Z), ATMS 17:01Z'),
    (L(marker='P',ms=12,color=PUR,mec=INK,mew=0.8),'NOAA/STAR SAR storm centres (09:09Z pass summary; 21:15Z from [B10])'),
    (L(marker='^',ms=10,mfc='none',mec=INK,mew=1.5),'CIMSS ARCHER fixes, raw (not used; 50% radius 8–10 km)'),
    (L(marker='X',ms=10,color=SURF,mec=INK),'JTWC 18Z position (0.1° rounding; not used)'),
    (Line2D([],[],color=INK,lw=1.6,ls='-'),'separately run centre analysis [B10], 1σ along / across track: Pc 883.3'),
    (Line2D([],[],color=INK,lw=1.6,ls='--'),'… its IR-vs-STAR random-effects centre: Pc 893.6')]
fig.legend([h for h,_ in hs],[l for _,l in hs],loc='upper left',bbox_to_anchor=(0.05,0.205),ncol=2,frameon=False,fontsize=10.8,columnspacing=2.5,handletextpad=0.6)
fig.text(0.02,0.985,'Typhoon Champi (29W), 20 October 2026 — where was the storm centre at 17:33Z?',fontsize=17,fontweight='bold',va='top')
fig.text(0.02,0.953,'Shading: the ring model refitted to the buoy pressures and SAR structure with the whole centre track shifted so that the 17:33Z centre sits at each point\n'
         '(1.5-km grid of refits; no centre prior, no wander). Markers: the fitted 17:33Z centre in the v12 Monte Carlo trials of each case (mean ± 1σ), the centre fixes at\n'
         'their own times, and a separately run centre analysis. The buoy alone prefers a centre well to the south-west; the surface fixes, including the near-time ATMS fix, hold it\n'
         'near the IR eye track plus its measured offset, where the headline sits.',fontsize=11.5,color=INK2,va='top')
fig.text(0.02,0.01,'Sources: buoy WMO 2802285 (NOAA; supplied by Evan); SAR winds and storm centres NOAA/NESDIS/STAR - RCM imagery © Government of Canada 2026, contains modified Copernicus\n'
         'Sentinel data; IR: JMA Himawari-9; ATMS: NOAA JPSS; ARCHER: UW-Madison CIMSS; JTWC (provisional). [B10]: separately run centre-relocation analysis (unpublished). Full references in README.',fontsize=9.5,color=INK2)
fig.savefig(os.path.join(HERE,'fig3_centre.png'),dpi=170); print('saved')
