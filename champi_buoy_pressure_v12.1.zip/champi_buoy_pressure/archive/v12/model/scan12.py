# Profile likelihood over central pressure (v12): at each Pc, multistart least squares plus continuation sweeps up and down the grid.
# Unperturbed v12 configuration (posterior-median track, outer-conversion prior, fitted alpha20). Names: T/U/A headline likelihood,
# T with JTWC positions, T without the peak-wind constraint (buoy + satellite structure only).
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import solve, summarize, make_res, least_squares
CFG={'T_gp':dict(fam='T'),'U_gp':dict(fam='U'),'A_gp':dict(fam='A'),'T_bt':dict(fam='T',track='bt'),'T_gp_novg':dict(fam='T',vg=False)}
GRID=np.arange(838,911.1,3.0)
CB=json.load(open(os.path.join(HERE,'cbest.json')))
def setup(name):
    j=dict(mc.DEF,**CFG[name]); pri,data,s=mc.build(j,None); return j,pri,s
def job(a):
    name,Pc=a; j,pri,s=setup(name); extra=[np.array(r['x']) for r in CB[mc.config_key(j)]]
    best,costs,unpack=solve(j['fam'],Pc,j['track'],n_rand=4,seed=int(Pc)*7+len(name),extra=extra,pri=pri,sig=s)
    d=summarize(j['fam'],best,unpack,Pc,j['track'],pri=pri,res=make_res(j['fam'],Pc,j['track'],pri=pri,sig=s)[0]); d.update(name=name,n_starts=int(len(costs))); return d
def sweep(name,rows):
    j,pri,s=setup(name); fam,tr=j['fam'],j['track']; byP={r['Pc']:r for r in rows}
    for order in (GRID,GRID[::-1]):
        prev=None
        for Pc in order:
            if prev is not None:
                res,unpack,lb,ub=make_res(fam,Pc,tr,pri=pri,sig=s)
                r=least_squares(res,np.clip(prev,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
                if 2*r.cost<byP[Pc]['chi2']-1e-6:
                    d=summarize(fam,r,unpack,Pc,tr,pri=pri,res=res); d.update(name=name,n_starts=byP[Pc]['n_starts'],improved_by_sweep=True); byP[Pc]=d
            prev=np.array(byP[Pc]['x'])
    return [byP[p] for p in GRID]
if __name__=='__main__':
    names=sys.argv[1].split(','); out=sys.argv[2]; npr=int(sys.argv[3]) if len(sys.argv)>3 else 2; t0=time.time()
    with Pool(npr) as pool: rows=pool.map(job,[(n,float(p)) for n in names for p in GRID],chunksize=2)
    print('multistart done %.0f s'%(time.time()-t0),flush=True)
    final=[]
    for n in names:
        final+=sweep(n,[r for r in rows if r['name']==n]); print(n,'sweep done %.0f s'%(time.time()-t0),flush=True)
    json.dump(final,open(out,'w')); print('ALL DONE %.0f s'%(time.time()-t0))
