import sys, os, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from core import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'
BLU='#2a78d6'; DBL='#0f3f7a'; LBL='#8bb8ea'; ORA='#eb6834'; GRN='#1baf7a'; RED='#d0312d'; GRY='#9a9893'; PUR='#7b5ea7'
plt.rcParams.update({'font.size':12,'axes.titlesize':13.5,'axes.labelsize':12.5,'legend.fontsize':10.5,'xtick.labelsize':11,'ytick.labelsize':11,
    'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.facecolor':SURF,'figure.facecolor':SURF,
    'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
def rows_of(fn,name,tag=None):
    d=[r for r in json.load(open(fn)) if r['name']==name and (tag is None or r.get('tag')==tag)]; return sorted(d,key=lambda r:r['Pc'])
def nearest(rows,Pc): return min(rows,key=lambda r:abs(r['Pc']-Pc))
FAM_OF=lambda name: name.split('_')[0]
def _setup(row,track,extra=None):
    fam=FAM_OF(row['name'])
    if 'job' in row:                                   # v12 rows: rebuild the unperturbed configuration (also selects the track model)
        import mc
        j=dict(mc.DEF,**row['job']); pri,_,s=mc.build(j,None); pri=dict(pri)
        if extra: pri.update(extra)
        res,unpack,_,_=make_res(fam,row['Pc'],track,pri=pri,sig=s); return fam,pri,res,unpack(np.array(row['x']))
    pri=dict(PRI); pri['Vg']=VG_PRIOR
    if extra: pri.update(extra)
    res,unpack,_,_=make_res(fam,row['Pc'],track,pri=pri); return fam,pri,res,unpack(np.array(row['x']))
def model_eval(row,track,tq,la,lo,extra=None):
    """storm deficit (hPa), background, distance and effective distance at arbitrary times/positions for a fitted row"""
    fam,pri,res,u=_setup(row,track,extra); Pm,r,re=res.pressure(u,tq,la,lo); bg=background(u['bg'],tq,tq+lo/15.0)
    return bg-Pm,bg,r,re
def centre_track(row,track,tq,extra=None):
    """fitted surface centre (lat, lon) including the wander, at times tq"""
    fam,pri,res,u=_setup(row,track,extra); sx,sy=res.shift(u,np.asarray(tq,float)); fa,fo=TRACKS[track][:2]
    cla=fa(tq)+np.asarray(sy)/111.0; clo=fo(tq)+np.asarray(sx)/(111.0*np.cos(np.radians(cla))); return cla,clo
def radial(row,track,rr,extra=None):
    """pressure rise above the centre (hPa) and gradient-level wind (kt) of a fitted row, azimuthal mean"""
    fam,pri,res,u=_setup(row,track,extra); D=res.deficit(u,rr)
    if fam=='A': V=vgA_rho(rr,u['parts'],row['Pc'],u['Dtot'],DENS,u['parts'][0][1])*KT
    else: V=u['Vm']*shapeC(rr,u['Rm'],u['n'],u['A'],u['X1'],u['X2'],u['a'],u['R2'],u['W2'],pri['tab'] if fam in 'TU' else None)*KT
    return u['Dtot']-D, V, u
