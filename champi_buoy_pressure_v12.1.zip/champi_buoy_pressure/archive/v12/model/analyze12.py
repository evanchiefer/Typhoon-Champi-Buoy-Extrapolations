# v12 combination and reporting. Reads mc12.json (or the partial mc12.jsonl), weights12.json.
# Headline: the three profile models' Monte Carlo trials mixed with the measurement-aware AIC weights of the headline case. Every other
# case is mixed with its own weights where they exist (the four outer-conversion cases) and with the headline weights otherwise (the
# sensitivity cases change one input; their per-model medians are reported too). All trials kept, no tails cut.
# Outputs: final12.json; results12/summary_<case>.json, results12/conservation_<case>.json, results12/derivatives_<case>.json,
#          results12/draws_<case>.csv (every trial, every column), results12/flag_map.json (spec flag -> v12 job setting).
import sys, os, json, csv, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); OUT=os.path.join(HERE,'results12'); os.makedirs(OUT,exist_ok=True)
INP=json.load(open(os.path.join(HERE,'inputs.json'))); jh=np.array([x[0] for x in INP['jtwc_p']]); jp=np.array([x[1] for x in INP['jtwc_p']]); JT=float(np.interp(17.55,jh,jp))
src=os.path.join(HERE,'mc12.json')
if os.path.exists(src): MC=json.load(open(src)); partial=False
else:
    MC=[]; partial=True
    for line in open(os.path.join(HERE,'mc12.jsonl')):
        try: MC.append(json.loads(line))
        except Exception: pass
WJ=json.load(open(os.path.join(HERE,'weights12.json'))); W=WJ['weights']; FAMS='TUA'; QS=(2.5,16,50,84,97.5)
G={}
for d in MC: G.setdefault((d['tag'],d['fam']),[]).append(d)
# headline ring model: every trial was also refitted with 10 starts (tag conv10, same seed and draws); the better fit (lower chi2) is used.
# The 4-start set is kept as head4 for the paired comparisons with the sensitivity cases (which use 4 starts).
_cm={d['seed']:d for d in G.get(('conv10','T'),[])}; _HT=[]; _moved=0
for d in sorted(G.get(('head','T'),[]),key=lambda d:d['seed']):
    c=_cm.get(d['seed'])
    if c is not None and c['chi2']<d['chi2']-1e-9:
        _moved+=int(abs(c['Pc']-d['Pc'])>1.0); dd=dict(c); dd['tag']='head'; dd['refit10']=True; _HT.append(dd)
    else: _HT.append(dict(d,refit10=False))
G[('head4','T')]=G.get(('head','T'),[]); G[('head','T')]=_HT
def pcs(tag,fam): return np.array([d['Pc'] for d in sorted(G.get((tag,fam),[]),key=lambda d:d['seed'])])
def rsd(v): p=np.percentile(v,[16,84]); return float((p[1]-p[0])/2)
def mix(samples,wt,ps=QS):
    ks=[k for k in samples if wt.get(k,0)>0 and len(samples[k])]; v=np.concatenate([samples[k] for k in ks]); ww=np.concatenate([np.full(len(samples[k]),wt[k]/len(samples[k])) for k in ks])
    o=np.argsort(v); c=np.cumsum(ww[o]); c/=c[-1]; q=[float(np.interp(p/100,c,v[o])) for p in ps]
    mu=float(np.sum(ww*v)/ww.sum()); sd=float(np.sqrt(np.sum(ww*(v-mu)**2)/ww.sum()))
    return dict(q=q,sd=sd,half68=(q[3]-q[1])/2,p_below_jtwc=float(ww[v<JT].sum()/ww.sum()),ess=float(ww.sum()**2/np.sum(ww**2)),n={k:int(len(samples[k])) for k in ks})
def boot(samples,wt,B=1000,seed=0):
    rng=np.random.default_rng(seed); R=[]
    for b in range(B):
        sb={k:v[rng.integers(0,len(v),len(v))] for k,v in samples.items() if len(v)}; m=mix(sb,wt); R.append(m['q']+[m['sd']])
    R=np.array(R); return dict(se_q=[float(x) for x in R[:,:5].std(0)],se_sd=float(R[:,5].std()))
CASEW={'head':'prior','a20_free':'free','a20_loglayer':'loglayer','a20_flat':'flat'}
tags=sorted({d['tag'] for d in MC if not d['tag'].startswith('budget') and d['tag']!='conv10'})
wH=W['prior']['measAIC']
summ={}
for tg in tags:
    fams=[f for f in 'TUAC' if (tg,f) in G]; S={f:pcs(tg,f) for f in fams}
    wt=W[CASEW[tg]]['measAIC'] if tg in CASEW else ({'C':1.0} if fams==['C'] else wH)
    m=mix(S,wt); m.update(weights={f:float(wt.get(f,0)) for f in fams},weights_from=(CASEW.get(tg,'prior') if fams!=['C'] else 'single model'),
                          per_model={f:dict(q=[float(x) for x in np.percentile(S[f],QS)],sd=rsd(S[f]),n=int(len(S[f])),
                                            multistart_over_1hPa=int(sum(1 for d in G[(tg,f)] if d['spread_at_best']>1.0))) for f in fams})
    if tg in ('head','a20_free','a20_loglayer','a20_flat'): m['bootstrap']=boot(S,wt,B=400)
    summ[tg]=m; json.dump(dict(case=tg,**m),open(os.path.join(OUT,'summary_%s.json'%tg),'w'),indent=1)
# paired shifts: each case against the headline trials with the same seeds (4-start fits for the ring model, as in the cases)
for tg,m in summ.items():
    if tg=='head': continue
    fams=[f for f in 'TUA' if (tg,f) in G]
    if not fams: continue
    pr={}; SB={}
    for f in fams:
        hb={d['seed']:d['Pc'] for d in G.get(('head4' if f=='T' else 'head',f),[])}; cs={d['seed']:d['Pc'] for d in G[(tg,f)]}; ks=sorted(k for k in cs if k in hb)
        if not ks: continue
        dd=np.array([cs[k]-hb[k] for k in ks]); pr[f]=dict(n=len(ks),median_diff=float(np.median(dd)),mean_diff=float(dd.mean()),se_mean=float(dd.std(ddof=1)/np.sqrt(len(ks))) if len(ks)>1 else 0.0)
        SB[f]=np.array([hb[k] for k in ks])
    if pr:
        mb=mix(SB,m['weights']); m['paired']=dict(per_model=pr,head_same_seeds_q=mb['q'],shift_median=m['q'][2]-mb['q'][2],shift_half68=m['half68']-mb['half68'])
        json.dump(dict(case=tg,**m),open(os.path.join(OUT,'summary_%s.json'%tg),'w'),indent=1)
H=summ.get('head')
# alternative weighting schemes on the headline trials
SH={f:pcs('head',f) for f in FAMS}; alt={}
for k,wt in W['prior'].items(): alt[k]=dict(weights=wt,**mix(SH,wt))
alt['ring_only']=dict(weights={'T':1.0},**mix(SH,{'T':1.0}))
# single-source budget (per model, weighted over the models with the headline weights) and the spread between models
SRC=sorted({d['tag'].split(':')[1] for d in MC if d['tag'].startswith('budget:')})
budget,budget_fam={},{}
for s_ in SRC:
    sd={f:rsd(pcs('budget:'+s_,f)) for f in FAMS if len(pcs('budget:'+s_,f))>3}; budget_fam[s_]=sd
    if sd: budget[s_]=float(np.sqrt(sum(wH[f]*sd[f]**2 for f in sd)/sum(wH[f] for f in sd)))
meds={f:float(np.median(SH[f])) for f in FAMS if len(SH[f])}; mbar=sum(wH[f]*meds[f] for f in meds)/sum(wH[f] for f in meds); budget['family']=float(np.sqrt(sum(wH[f]*(meds[f]-mbar)**2 for f in meds)))
# convergence: headline ring-model trials refitted with 10 starts instead of 4 (same seeds)
cv={}
hm={d['seed']:d for d in G.get(('head4','T'),[])}; cm={d['seed']:d for d in G.get(('conv10','T'),[])}; ks=[k for k in cm if k in hm]
if ks:
    dd=np.array([cm[k]['Pc']-hm[k]['Pc'] for k in ks]); best=np.array([cm[k]['Pc'] if cm[k]['chi2']<hm[k]['chi2'] else hm[k]['Pc'] for k in ks]); orig=np.array([hm[k]['Pc'] for k in ks])
    cv=dict(n=len(ks),moved_over_1hPa=int((np.abs(dd)>1).sum()),better_moved_over_1hPa=_moved,max_abs=float(np.abs(dd).max()),q_4starts=[float(x) for x in np.percentile(orig,QS)],q_better_of_two=[float(x) for x in np.percentile(best,QS)],
            headline_ring_uses='better of the 4-start and 10-start fits')
# conservation diagnostics (spec section 3), from the best fits + leave-one-out (weights12) and the Monte Carlo medians
FB={(o['fam'],o['case']):o for o in WJ['fits']}
cons={}
for case in ('free','prior','flat','loglayer','buoyonly'):
    tg={'prior':'head','free':'a20_free','flat':'a20_flat','loglayer':'a20_loglayer','buoyonly':'S27_buoy_only'}[case]; rows={}
    for f in FAMS:
        o=FB[(f,case)]; fr=FB[(f,'free')]; mcq=summ.get(tg,{}).get('per_model',{}).get(f,{}).get('q')
        dchi=o['chi2_buoy']-fr['chi2_buoy']; dof=38-o['p_eff_buoy']; scale=o['chi2_buoy']/dof
        rows[f]=dict(Pc_best=o['Pc'],chi2_buoy=o['chi2_buoy'],dchi2_buoy_vs_free=dchi,dlogL_buoy=-0.5*dchi,conflict=bool(abs(dchi)>1),                      # spec: |dlogL| > 0.5 per added term, i.e. |dchi2| > 1
                     
                     dchi2_after_rescale=dchi/scale,chi2_per_dof=scale,z=o['z'],z_1804=o['z_1804'],loo_sum=o['loo_sum'],dloo_vs_free=o['loo_sum']-fr['loo_sum'],
                     a20_fit=o['a20_fit'],g20=o['g20'],a20_implied=o['a20_implied'],chi2_sar=o['chi2_sar'],z_ring=o['z_ring'],Pc_mc=mcq)
    cons[case]=rows; json.dump(dict(case=case,models=rows),open(os.path.join(OUT,'conservation_%s.json'%case),'w'),indent=1)
# derivatives (spec section 7): regressions on the headline trials of each model
def ols(y,X):
    X=np.c_[np.ones(len(y)),X]; b,*_=np.linalg.lstsq(X,y,rcond=None); r=y-X@b; s2=r@r/(len(y)-X.shape[1]); se=np.sqrt(np.diag(s2*np.linalg.inv(X.T@X))); return b[1:],se[1:]
der={}
for tg in ('head','a20_free','a20_flat','a20_loglayer'):
    der[tg]={}
    for f in FAMS:
        D=G.get((tg,f),[])
        if len(D)<30: continue
        y=np.array([d['Pc'] for d in D]); vm=np.array([d['fit']['vmax_kt'] for d in D]); rm=np.array([d['fit']['rmw'] for d in D]); arm=np.array([d['inputs']['arm'] for d in D])
        a20=np.array([d['fit']['a20'] for d in D]); re17=np.array([d['r_eff'][17] for d in D]); vs=np.array([d['inputs']['vsfc'] for d in D])
        bp,sp=ols(y,np.c_[vm,rm]); b1,s1=ols(y,arm[:,None]); b2,s2=ols(y,a20[:,None]); b3,s3=ols(y,re17[:,None]); b4,s4=ols(y,rm[:,None]); b5,s5=ols(y,vs[:,None])
        der[tg][f]=dict(dPc_dVg_partial=[float(bp[0]),float(sp[0])],dPc_dVsfc_partial=[float(bp[0]/np.mean(arm)),float(sp[0]/np.mean(arm))],dPc_dRm_partial=[float(bp[1]),float(sp[1])],
                       dPc_dRm_total=[float(b4[0]),float(s4[0])],dPc_dalpha_rm=[float(b1[0]),float(s1[0])],dPc_dalpha20=[float(b2[0]),float(s2[0])],dPc_dreff1704=[float(b3[0]),float(s3[0])],
                       dPc_dVsfc_input=[float(b5[0]),float(s5[0])],corr_Pc_Rm=float(np.corrcoef(y,rm)[0,1]),corr_Pc_Vg=float(np.corrcoef(y,vm)[0,1]),
                       alpha20_fit_q=[float(x) for x in np.percentile(a20,(16,50,84))])
    json.dump(dict(case=tg,models=der[tg]),open(os.path.join(OUT,'derivatives_%s.json'%tg),'w'),indent=1)
# per-trial tables, every column
def flat(d,wt):
    row=dict(case=d['tag'],model=d['fam'],seed=d['seed'],refit10=d.get('refit10',''),a20case=d.get('a20case'),track_model=d.get('track_model'),Pc=d['Pc'],chi2=d['chi2'],n_starts=d['n_starts'],
             spread_at_best=d['spread_at_best'],mix_weight=wt)
    for k,v in d['inputs'].items():
        if isinstance(v,list): row.update({'%s_%d'%(k,i):x for i,x in enumerate(v)})
        else: row['in_'+k]=v
    for k,v in d['fit'].items():
        if k=='x': row.update({'x%02d'%i:x for i,x in enumerate(v)})
        else: row['fit_'+k]=v
    for k,v in d['chi2_parts'].items(): row['chi2_'+k]=v
    for nm in ('resid','z','r_eff'): row.update({'%s_%02d'%(nm,i):x for i,x in enumerate(d[nm])})
    return row
for tg in sorted({k[0] for k in G}):
    D=[d for (t_,f),v in G.items() if t_==tg for d in v]; fams=sorted({d['fam'] for d in D}); wt=summ.get(tg,{}).get('weights',{f:1/len(fams) for f in fams})
    rows=[flat(d,wt.get(d['fam'],0.0)/max(1,sum(1 for e in D if e['fam']==d['fam']))) for d in sorted(D,key=lambda d:(d['fam'],d['seed']))]
    cols=[]; [cols.append(k) for r in rows for k in r if k not in cols]
    with open(os.path.join(OUT,'draws_%s.csv'%tg.replace(':','_')),'w',newline='') as fo:
        w=csv.DictWriter(fo,fieldnames=cols); w.writeheader(); w.writerows(rows)
FLAGS={'v20_case':"job a20case in {prior (HEAD), free, flat, loglayer}; tags head, a20_free, a20_flat, a20_loglayer",'alpha_profile=independent':'a20case=independent (S4_independent)',
       'wander_mode=hier (flat-sigma prior)':"track_model='hier': IR-surface drift amplitude SO drawn per trial from its restricted-likelihood posterior (track_hier.py)",
       'wander_sd=3.0 / 1.5 fixed':"track_model='fixed:3.0' / 'fixed:1.5' (S5, S6)",'wander_sd=0':'wander=False (S7_no_wander: no centre wander at all)',
       'wander_prior=jeffreys':"track_model='loguniform' (S8; log-uniform from 0.1 km, Jeffreys is improper at 0 for this likelihood)",'v11 ALT wander 1 km':"track_model='v11' (S9: v11 track, SO = 1 km)",
       'rm_alpha_rho':'rho_rm_a20 (S12)','tilt_alpha_rho':'rho_tilt_a20 (S13)','w_sd':'w_sd (S14)','sar_v14v20_rho':'v1420_rho (S15)','sar_bin_corr':'not applicable: SAR enters as ratios, covered by S15',
       'marg_nuisance=analytic':'not applicable: background terms are fitted in every trial','ca_r_scale':'not applicable (their M3)','sigma_r':'sigpos 0.5 / 1.5 km (S19, position term)',
       'sigma_p_mode=rescale':'tscale from rescale.json (S20)','weights=*':'weights12.json: measAIC (HEAD), measAIC_all, AIC_nominal, BIC_nominal, BIC_eff, pbma_buoy, pbma_buoy_sar, equal',
       'track_mode=star':"track_model='star' (S23: STAR storm centre for the Sentinel-1D 09:09Z pass, the only STAR centre available)",'track_mode=flat4':"track='irf', soff=4.0 (S24)",
       'structure=s1d_only / rcm_only':"variant='nat2115' / 'nat09' (S25 21:15Z only, S26 09Z only)",'sar=False':'buoyonly=True (S27: no SAR outer-structure terms)','loo':'weights12.py leave-one-out refits (scoring only)',
       'm2_v20_mode=iw, m3_score, m1_score':'not applicable (their M1-M3)'}
json.dump(FLAGS,open(os.path.join(OUT,'flag_map.json'),'w'),indent=1)
final=dict(partial=partial,n_trials=len(MC),jtwc_1733=JT,headline=H,alt_weights=alt,cases=summ,budget=budget,budget_by_model=budget_fam,conv_check=cv,conservation=cons,derivatives=der,
           weights=W,best_fits={'%s|%s'%k:dict(Pc=v['Pc'],chi2_meas=v['chi2_meas'],p_eff=v['p_eff']) for k,v in FB.items()})
json.dump(final,open(os.path.join(HERE,'final12.json'),'w'),indent=1)
if H:
    q=H['q']; print('%sHEADLINE (measurement-aware AIC weights %s): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | sd %.2f | P(below JTWC %.1f) %.3f | n %s'%(
        'PARTIAL ' if partial else '',{k:round(v,3) for k,v in H['weights'].items()},q[2],q[1],q[3],q[0],q[4],H['sd'],JT,H['p_below_jtwc'],H['n']))
    if 'bootstrap' in H: print('   bootstrap SE of the 2.5/16/50/84/97.5 percentiles: '+' '.join('%.2f'%x for x in H['bootstrap']['se_q'])+' | sd %.2f'%H['bootstrap']['se_sd'])
for tg in tags:
    m=summ[tg]; q=m['q']; pz=m.get('paired')
    print('%-24s median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | sd %.2f | '%(tg,q[2],q[1],q[3],q[0],q[4],m['sd'])+' '.join('%s %.1f'%(f,v['q'][2]) for f,v in m['per_model'].items())+
          (' | paired shift %+.1f (ring %+.2f +- %.2f)'%(pz['shift_median'],pz['per_model'].get('T',{}).get('mean_diff',np.nan),pz['per_model'].get('T',{}).get('se_mean',np.nan)) if pz else ''))
for k,v in alt.items(): print('weights %-14s %s median %.1f 68%% %.1f-%.1f'%(k,{f:round(x,3) for f,x in v['weights'].items()},v['q'][2],v['q'][1],v['q'][3]))
print('budget (1 sigma): '+', '.join('%s %.2f'%(k,v) for k,v in sorted(budget.items(),key=lambda kv:-kv[1])))
if cv: print('convergence: %d of %d moved > 1 hPa (max %.2f); percentiles 4 starts %s, better of two %s'%(cv['moved_over_1hPa'],cv['n'],cv['max_abs'],[round(x,1) for x in cv['q_4starts']],[round(x,1) for x in cv['q_better_of_two']]))
