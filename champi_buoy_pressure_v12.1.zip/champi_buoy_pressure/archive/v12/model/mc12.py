# v12 Monte Carlo (resumable). Usage: mc12.py [ncores]
# Order: headline (all three profile models, 1000 trials each), then the other outer-conversion cases at the same size, then the
# sensitivity cases and v11 checks at 250 per model, then the single-source budget runs and the 10-start refits of the headline ring model. Seeds are shared:
# trial k of every case and every model uses seed k, and each source has its own random stream (mc.build), so cases are paired.
# Output: mc12.jsonl (one full record per trial, floats rounded to 6 significant digits); mc12.json when all are done.
import sys, os, json, time
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from multiprocessing import Pool
FAMS='TUA'; NH=1000; NS=250
def J(tag,n,fams=FAMS,seed0=1,**kw): return [dict(kw,fam=f,tag=tag,seed=seed0+i) for i in range(n) for f in fams]
SENS=[('S4_independent',dict(a20case='independent')),
      ('S5_drift_fixed3',dict(track_model='fixed:3.0')),('S6_drift_fixed1.5',dict(track_model='fixed:1.5')),('S7_no_wander',dict(wander=False)),
      ('S8_drift_loguniform',dict(track_model='loguniform')),('S9_v11_track',dict(track_model='v11')),
      ('S12_rm_a20_-0.5',dict(rho_rm_a20=-0.5)),('S12_rm_a20_-0.3',dict(rho_rm_a20=-0.3)),('S12_rm_a20_+0.3',dict(rho_rm_a20=0.3)),('S12_rm_a20_+0.5',dict(rho_rm_a20=0.5)),
      ('S13_tilt_a20_-0.5',dict(rho_tilt_a20=-0.5)),('S13_tilt_a20_+0.5',dict(rho_tilt_a20=0.5)),
      ('S14_wsd_0.05',dict(w_sd=0.05)),('S14_wsd_0.02',dict(w_sd=0.02)),
      ('S15_v14v20_rho0.3',dict(v1420_rho=0.3)),('S15_v14v20_rho0.5',dict(v1420_rho=0.5)),('S15_v14v20_rho0.7',dict(v1420_rho=0.7)),
      ('S19_sigpos0.5',dict(sigpos=0.5)),('S19_sigpos1.5',dict(sigpos=1.5)),
      ('S23_star_centre',dict(track_model='star')),('S24_flat4km_irf',dict(track='irf',soff=4.0)),
      ('S25_2115_only',dict(variant='nat2115')),('S26_09Z_only',dict(variant='nat09')),('S27_buoy_only',dict(buoyonly=True)),
      ('v11chk_trochoid',dict(troch=(3.0,0.5,2.0))),('v11chk_v10_geometry',dict(track='irf',ell=False,sigpos=1.5)),('v11chk_bt',dict(track='bt')),
      ('v11chk_ramp',dict(dens='ramp')),('v11chk_gauss',dict(nu=0.0)),('v11chk_tscaled',dict(tscale=0.7071067811865476)),
      ('v11chk_structure_only',dict(vg=False,sources=tuple(s for s in mc.SRC12 if s!='intensity')))]
def S20():
    """sigma rescaled so that the buoy chi2 per degree of freedom is 1 at each model's headline best fit (weights12.py -> rescale.json)"""
    f=os.path.join(HERE,'rescale.json')
    if not os.path.exists(f): return []
    R=json.load(open(f)); return [j for fam in FAMS for j in J('S20_sigma_rescaled',NS,fams=fam,tscale=R[fam]['tscale'])]
def jobs_all():
    L=J('head',NH)
    for c in ('free','loglayer','flat'): L+=J('a20_'+c,NH,a20case=c)
    for tg,kw in SENS: L+=J(tg,NS,**kw)
    L+=J('v11chk_powerlaw_eye',NS,fams='C'); L+=S20()
    for k,src in enumerate(mc.SRC12): L+=J('budget:'+src,40,seed0=2_000_000+10_000*k,sources=(src,))
    L+=J('conv10',1000,fams='T',nrand=7)                 # every headline ring-model trial refitted with 10 starts; the better fit is used (analyze12.py)
    return L
def key(d): return (d['tag'],d['fam'],int(d['seed']))
def r6(o):
    if isinstance(o,float): return float('%.6g'%o)
    if isinstance(o,dict): return {k:r6(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)): return [r6(v) for v in o]
    return o
if __name__=='__main__':
    nc=int(sys.argv[1]) if len(sys.argv)>1 else 2
    JL=os.path.join(HERE,'mc12.jsonl'); jobs=jobs_all(); done=set()
    if os.path.exists(JL):
        for line in open(JL):
            try: done.add(key(json.loads(line)))
            except Exception: pass
    todo=[j for j in jobs if key(j) not in done]; print('%d jobs, %d done, %d to run'%(len(jobs),len(done),len(todo)),flush=True)
    t0=time.time()
    with Pool(nc) as pool, open(JL,'a') as fo:
        for k,d in enumerate(pool.imap(mc.trial,todo,chunksize=1)):
            fo.write(json.dumps(r6(d))+'\n'); fo.flush()
            if k%250==0: print('%d/%d %.0f s'%(k,len(todo),time.time()-t0),flush=True)
    res=[]
    for line in open(JL):
        try: res.append(json.loads(line))
        except Exception: pass
    if {key(d) for d in res}>={key(j) for j in jobs}:
        json.dump(res,open(os.path.join(HERE,'mc12.json'),'w')); print('ALL DONE %.0f s (%d trials)'%(time.time()-t0,len(res)),flush=True)
