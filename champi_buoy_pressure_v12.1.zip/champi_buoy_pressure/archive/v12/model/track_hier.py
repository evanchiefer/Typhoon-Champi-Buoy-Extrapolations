# v12: hierarchical treatment of the slow IR-to-surface offset drift (amplitude SO), the one track hyperparameter the fixes bound only
# loosely (4 surface fixes). For SO on a 0.1-km grid the GP is refitted (s, tau, sn by restricted maximum likelihood at that SO) and the
# restricted likelihood kept; the posterior p(SO | fixes) ∝ L_R(SO) x prior, with a flat prior in SO (headline) or log-uniform from 0.1 km
# (sensitivity). Each Monte Carlo trial draws SO from the posterior and uses that track model (mean, window covariance) - no interpolation
# between track models. The grid runs far enough that the posterior mass beyond it is negligible (reported). Also writes a track with the
# STAR storm centre for the Sentinel-1D 09:09Z pass (the only STAR centre available) in place of the SAR ring-fit centre, at the posterior
# median SO. Outputs: track_variants.npz, track_hier.json.
import os, sys, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import track_gp as TG
from multiprocessing import Pool
SOG=np.round(np.arange(0.0,15.01,0.1),2)
INP=json.load(open(os.path.join(HERE,'inputs.json'))); TB=np.array(INP['buoy'])[:,0]; WIN=np.flatnonzero((TB>=13)&(TB<=22.2))
STAR0909=(133.719,16.670)     # STAR pass summary, Sentinel-1D 2026-10-20 09:09:35Z: "Storm Center Longitude/Latitude"
def one(so,surface=None):
    G=TG.TrackGP(so=so,surface=surface); v=TG.variant(G,TB,WIN); o,osd=G.offset()
    return dict(so=float(so),hyper=G.hyper,offset=[float(x) for x in o],offset_sd=float(osd[0]),**{k:np.asarray(a) for k,a in v.items()})
if __name__=='__main__':
    with Pool(2) as p: V=p.map(one,list(SOG),chunksize=1)
    nll=np.array([v['hyper']['reml'] for v in V]); L=np.exp(-(nll-nll.min()))
    post={'flat':L/L.sum()}; lu=np.where(SOG>=0.1,L/np.maximum(SOG,0.1),0.0); post['loguniform']=lu/lu.sum()
    def q(pw,qq): c=np.cumsum(pw); return float(np.interp(qq,c,SOG))
    med=float(SOG[np.argmin(np.abs(np.cumsum(post['flat'])-0.5))])
    print('SO grid 0-10 km: restricted -log L relative to min: '+' '.join('%.1f:%.2f'%(s,n-nll.min()) for s,n in zip(SOG[::10],nll[::10])))
    for k,pw in post.items(): print('  posterior (%s prior): median %.2f km, 16-84%% %.2f-%.2f, P(SO>3 km) %.3f, mass beyond 12 km %.5f'%(k,q(pw,0.5),q(pw,0.16),q(pw,0.84),pw[SOG>3].sum(),pw[SOG>12.0].sum()))
    im=int(np.argmin(np.abs(SOG-med)))
    sf=TG.surface_fixes(); sf_star=[(('STAR storm centre 09:09:35Z',)+tuple(f[1:2])+STAR0909+(f[4],)) if f[0].startswith('Sentinel-1D') else f for f in sf]
    VS=one(med,surface=sf_star)
    np.savez_compressed(os.path.join(HERE,'track_variants.npz'),so=SOG,grid_t=V[0]['grid_t'],grid_lat=np.array([v['grid_lat'] for v in V]),grid_lon=np.array([v['grid_lon'] for v in V]),
        cov_win=np.array([v['cov_win'] for v in V]),grid_w=np.array([v['grid_w'] for v in V]),sd_readings=np.array([v['sd_readings'] for v in V]),
        star_grid_lat=VS['grid_lat'],star_grid_lon=VS['grid_lon'],star_cov_win=VS['cov_win'],star_grid_w=VS['grid_w'],star_sd_readings=VS['sd_readings'])
    i1=int(np.argmin(np.abs(SOG-1.0)))
    out=dict(so_grid=SOG.tolist(),nll=nll.tolist(),post=dict((k,v.tolist()) for k,v in post.items()),median_flat=med,i_median=im,
             hyper=[v['hyper'] for v in V],offset=[v['offset'] for v in V],
             sd_1704=[float(np.sqrt(v['cov_win'][list(WIN).index(17),list(WIN).index(17)])) for v in V],star=dict(centre=STAR0909,so=med,offset=VS['offset']))
    json.dump(out,open(os.path.join(HERE,'track_hier.json'),'w'),indent=1)
    print('posterior-median track (SO %.1f km): centre sd at 17:04Z %.2f km per component (SO 1.0: %.2f)'%(med,out['sd_1704'][im],out['sd_1704'][i1]))
    a=V[im]['grid_lat'][int(17.55*60)],V[im]['grid_lon'][int(17.55*60)]; b=V[i1]['grid_lat'][int(17.55*60)],V[i1]['grid_lon'][int(17.55*60)]
    print('centre at 17:33Z, median-SO vs SO=1 track: %.2f km apart'%np.hypot((a[0]-b[0])*111,(a[1]-b[1])*111*np.cos(np.radians(17.3))))
    c=VS['grid_lat'][int(17.55*60)],VS['grid_lon'][int(17.55*60)]; print('STAR-centre track at 17:33Z: %.2f km from the median-SO track'%np.hypot((c[0]-a[0])*111,(c[1]-a[1])*111*np.cos(np.radians(17.3))))
