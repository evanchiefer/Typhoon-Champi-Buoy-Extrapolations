# Storm-centre track with time-correlated wander (v11).
# The surface centre S(t) = smooth track (quadratic in time) + wander w(t) + IR-to-surface offset o.
#   w(t): Gaussian process (Matern-3/2 covariance, amplitude s, timescale tau) - eye wobble and track irregularities between fixes.
#   Hourly Himawari IR eye fixes see S(t) - o - d(t) plus fix noise (sd sn); d(t) is a slow variation of the IR-to-surface offset (vortex
#   tilt changes): Matern-3/2, amplitude SO = 1.0 km, timescale TO = 6 h. The fixes bound SO only loosely (restricted likelihood changes by
#   0.4 at 1 km, 1.0 at 2 km, 2.2 at 3 km); 1.0 km is used, 0 and the flat 4-km offset are checks.
#   Surface fixes see S(t) plus their own error: SAR ring-fit centres (S1D 09:09Z, RCM-3 09:20Z, RCM-3 21:15Z; 0.7 km), ATMS 17:01Z (2.5 km).
# s, tau and sn are estimated from the fixes themselves (restricted maximum likelihood, both components share them); the quadratic
# coefficients and the offset are estimated jointly by generalised least squares, so the offset is measured on the same track.
# Output (track_gp.json): posterior mean of S(t) on a 1-min grid and the posterior covariance of S at the buoy reading times
# (includes offset and track-coefficient uncertainty). The fit lets the centre at each reading move within that covariance.
import os, sys, json, numpy as np
from scipy.optimize import minimize
HERE=os.path.dirname(os.path.abspath(__file__))
BASE=os.environ.get('CHAMPI_BASE',os.path.dirname(HERE))
LAT0,LON0=17.3,132.0; KX=111.0*np.cos(np.radians(LAT0)); KY=111.0; TREF=15.5
SO=float(os.environ.get('CHAMPI_TILT_SD','1.0')); TO=6.0
def kern(t1,t2,s,tau):
    d=np.abs(np.subtract.outer(t1,t2))*np.sqrt(3)/tau; return s**2*(1+d)*np.exp(-d)
def load_fixes():
    fx=json.load(open(os.path.join(HERE,'ir_eye_fixes.json'))); th=np.array(sorted(int(k) for k in fx),float)
    la=np.array([fx[str(int(h))]['lat'] for h in th]); lo=np.array([fx[str(int(h))]['lon'] for h in th]); return th,la,lo
def surface_fixes():
    sd=os.path.join(HERE,'sar'); st=lambda k: json.load(open(os.path.join(sd,k+'_struct.json')))
    a,b,c=st('S1D_20_0909'),st('R3_20_0920'),st('R3_20_2115')
    return [('Sentinel-1D SAR ring fit 09:09:35Z',9+9/60+35/3600,a['clon'],a['clat'],0.7),('RCM-3 SAR ring fit 09:20:37Z',9+20/60+37/3600,b['clon'],b['clat'],0.7),
            ('ATMS 165/183 GHz eye 17:01Z',17+1/60,131.719,17.335,2.5),('RCM-3 SAR ring fit 21:15:26Z',21+15/60+26/3600,c['clon'],c['clat'],0.7)]
def design(t,is_surf):
    tt=np.asarray(t)-TREF; return np.c_[np.ones_like(tt),tt,tt**2,np.asarray(is_surf,float)]
class TrackGP:
    def __init__(self,hyper=None,so=None,surface=None):
        self.so=SO if so is None else float(so)
        th,la,lo=load_fixes(); SF=surface_fixes() if surface is None else surface
        self.t=np.r_[th,[f[1] for f in SF]]; self.surf=np.r_[np.zeros(len(th)),np.ones(len(SF))]
        self.Y=np.c_[np.r_[(lo-LON0)*KX,[(f[2]-LON0)*KX for f in SF]],np.r_[(la-LAT0)*KY,[(f[3]-LAT0)*KY for f in SF]]]
        self.esd=np.r_[np.full(len(th),np.nan),[f[4] for f in SF]]; self.SF=SF; self.th=th
        self.X=design(self.t,self.surf)
        self.hyper=self.fit() if hyper is None else dict(hyper)
        self._prep()
    def _K(self,s,tau,sn):
        noise=np.where(self.surf>0,self.esd,sn)**2; ir=(self.surf==0).astype(float)
        so=self.so; return kern(self.t,self.t,s,tau)+np.diag(noise)+(kern(self.t,self.t,so,TO)*np.outer(ir,ir) if so>0 else 0.0)
    def reml(self,p):
        s,tau,sn=np.exp(p); K=self._K(s,tau,sn); L=np.linalg.cholesky(K); ld=2*np.log(np.diag(L)).sum()
        Ki=np.linalg.inv(K); A=self.X.T@Ki@self.X; _,lA=np.linalg.slogdet(A); P=Ki-Ki@self.X@np.linalg.solve(A,self.X.T@Ki)
        return 0.5*sum(float(y@P@y) for y in self.Y.T)+ld+lA      # both components share the hyperparameters
    def fit(self):
        best=None
        for s0 in (1.0,3.0,8.0):
            for t0 in (0.7,2.0,5.0):
                for n0 in (0.5,1.5):
                    r=minimize(self.reml,np.log([s0,t0,n0]),method='L-BFGS-B',bounds=[(np.log(0.1),np.log(30)),(np.log(0.3),np.log(12)),(np.log(0.2),np.log(10))])
                    if best is None or r.fun<best.fun: best=r
        s,tau,sn=np.exp(best.x); return dict(s=float(s),tau=float(tau),sn=float(sn),reml=float(best.fun))
    def _prep(self):
        h=self.hyper; K=self._K(h['s'],h['tau'],h['sn']); self.Ki=np.linalg.inv(K)
        A=self.X.T@self.Ki@self.X; self.Ai=np.linalg.inv(A); self.beta=self.Ai@self.X.T@self.Ki@self.Y       # (4,2): quadratic + offset, per component
        self.alpha=self.Ki@(self.Y-self.X@self.beta)
    def mean(self,tq,surface=True):
        tq=np.atleast_1d(np.asarray(tq,float)); Xq=design(tq,np.full(len(tq),1.0 if surface else 0.0)); kq=kern(tq,self.t,self.hyper['s'],self.hyper['tau'])
        return Xq@self.beta+kq@self.alpha                                                                # (n,2) km E, km N
    def cov(self,t1,t2=None):
        """posterior covariance of the surface centre (per component, km^2), including offset and track-coefficient uncertainty"""
        t1=np.atleast_1d(np.asarray(t1,float)); t2=t1 if t2 is None else np.atleast_1d(np.asarray(t2,float)); h=self.hyper
        k1=kern(t1,self.t,h['s'],h['tau']); k2=kern(t2,self.t,h['s'],h['tau'])
        R1=design(t1,np.ones(len(t1)))-k1@self.Ki@self.X; R2=design(t2,np.ones(len(t2)))-k2@self.Ki@self.X
        return kern(t1,t2,h['s'],h['tau'])-k1@self.Ki@k2.T+R1@self.Ai@R2.T
    def latlon(self,tq,surface=True):
        m=self.mean(tq,surface); return LAT0+m[:,1]/KY, LON0+m[:,0]/KX
    def offset(self): return self.beta[3], np.sqrt(np.diag(self.Ai)[3])*np.ones(2)
def variant(G,tb,win):
    """the arrays core.py needs for one track model: 1-min grid mean, window covariance, kriging weights, track sd at all readings"""
    tg=np.arange(0.0,38.01,1/60); la,lo=G.latlon(tg); C=G.cov(tb[win]); Cgw=G.cov(tg,tb[win]); sd_all=np.sqrt(np.diag(G.cov(tb)))
    Wg=Cgw@np.linalg.inv(C+1e-9*np.eye(len(win)))
    return dict(grid_t=tg,grid_lat=la,grid_lon=lo,cov_win=C,grid_w=Wg,sd_readings=sd_all)
if __name__=='__main__':
    G=TrackGP(); h=G.hyper
    print('wander amplitude s = %.2f km, timescale tau = %.2f h, IR fix noise sn = %.2f km (REML %.2f)'%(h['s'],h['tau'],h['sn'],h['reml']))
    o,osd=G.offset(); print('IR -> surface offset: %+.2f E, %+.2f N km (sd %.2f)'%(o[0],o[1],osd[0]))
    for nm,tf,lo_,la_,e in G.SF:
        m=G.mean([tf])[0]; print('  %-34s fix minus track %+.2f E %+.2f N km'%(nm,(lo_-LON0)*KX-m[0],(la_-LAT0)*KY-m[1]))
    INP=json.load(open(os.path.join(HERE,'inputs.json'))); B=np.array(INP['buoy']); tb=B[:,0]
    win=np.flatnonzero((tb>=13)&(tb<=22.2)); C=G.cov(tb[win])
    print('posterior sd of the surface centre at buoy readings (km, per component):'); [print('  %5.2f h  %.2f'%(tb[i],np.sqrt(C[k,k]))) for k,i in enumerate(win)]
    sd_diff=np.sqrt(C[list(win).index(17),list(win).index(17)]+C[list(win).index(18),list(win).index(18)]-2*C[list(win).index(17),list(win).index(18)])
    print('sd of the centre change between 17:04Z and 18:04Z (per component): %.2f km'%sd_diff)
    tg=np.arange(0.0,38.01,1/60); la,lo=G.latlon(tg); Cgw=G.cov(tg,tb[win]); sd_all=np.sqrt(np.diag(G.cov(tb)))
    Wg=Cgw@np.linalg.inv(C+1e-9*np.eye(len(win)))          # kriging weights: wander at any time from the wander at the window readings
    json.dump(dict(hyper=h,offset=[float(x) for x in o],offset_sd=float(osd[0]),win=[int(i) for i in win],t_win=[float(tb[i]) for i in win],cov_win=C.tolist(),
                   sd_readings=sd_all.tolist(),grid_t=tg.tolist(),grid_lat=la.tolist(),grid_lon=lo.tolist(),grid_w=Wg.tolist(),beta=G.beta.tolist(),
                   surface_fixes=[[f[0],f[1],f[2],f[3],f[4]] for f in G.SF]),open(os.path.join(HERE,'track_gp.json'),'w'))
