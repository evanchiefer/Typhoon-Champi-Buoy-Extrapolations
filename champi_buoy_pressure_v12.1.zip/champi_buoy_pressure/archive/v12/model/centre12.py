# Data-only centre check in the v12 code: the whole centre track shifted by a constant offset (east, north) with no prior on the offset
# and no wander, ring model / no-ring / Holland, headline likelihood otherwise (alpha20 prior, SAR terms, peak wind). (0, 0) = the
# fix-based track (IR fixes + SAR/ATMS surface fixes, posterior-median drift). Pc free at each point.
import sys, json, time, numpy as np
import os; V=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,V)
import mc
from multiprocessing import Pool
def fit(a):
    fam,ox,oy,free=a; j=dict(mc.DEF,fam=fam,wander=False); pri,data,s=mc.build(j,None); pri=dict(pri)
    if free: pri['soff']=1e3; pri['off']=np.array([0.0,0.0])
    else: pri['soff']=1e-3; pri['off']=np.array([ox,oy])
    rng=np.random.default_rng(3); st=mc.default_starts(j,pri,rng,nrand=4)
    from core import NBASE
    nb=NBASE[fam]
    for x in st: x[1+nb-8:1+nb-6]=pri['off']
    best,_=mc.fit_free(j,pri,data,s,st,tol=1e-8); x=best.x; return dict(fam=fam,ox=float(x[1+nb-8]),oy=float(x[1+nb-7]),Pc=float(x[0]),chi2=float(2*best.cost),free=free)
if __name__=='__main__':
    t0=time.time()
    with Pool(2) as p:
        F=p.map(fit,[(f,0,0,True) for f in 'TUA']+[(f,0,0,False) for f in 'TUA'])
        for o in F: print('%s %-9s offset E %+.1f N %+.1f km  Pc %.1f  chi2 %.2f'%(o['fam'],'data-only' if o['free'] else 'fixes',o['ox'],o['oy'],o['Pc'],o['chi2']))
        G=p.map(fit,[('T',ox,oy,False) for oy in np.arange(-14,6.1,2.0) for ox in np.arange(-8,8.1,2.0)],chunksize=2)
    json.dump(dict(free=F,grid=G),open(os.path.join(V,'centre12.json'),'w'))
    g=np.array([[o['ox'],o['oy'],o['Pc'],o['chi2']] for o in G]); c0=min(o['chi2'] for o in F if o['fam']=='T'); 
    print('ring model grid: chi2 - data-only minimum, and Pc (rows north offset, columns east offset -8..8 km)')
    for oy in np.arange(6,-14.1,-2.0):
        r=g[np.abs(g[:,1]-oy)<0.05]; r=r[np.argsort(r[:,0])]; print('N %+4.0f | '%oy+' '.join('%5.1f/%3.0f'%(c-c0,p-800) for _,_,p,c in r))
    print('%.0f s'%(time.time()-t0))
