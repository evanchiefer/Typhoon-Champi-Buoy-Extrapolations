# What each v12 change does to the best fit (Pc free, unperturbed inputs), one change at a time on top of the previous, per profile model.
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
STEPS=[('v11 (log-layer conversion, ring radius at the surface, drift fixed 1 km)',dict(a20case=None,track_model='v11',sources=mc.SRC)),
       ('+ one conversion profile, alpha20 ~ N(0.80, 0.05) fitted',dict(a20case='prior',track_model='v11',r2fix=False)),
       ('+ secondary-ring radius at gradient level (tilted)',dict(a20case='prior',track_model='v11',r2fix=True)),
       ('+ IR-surface drift from its posterior (median track) = v12 headline configuration',dict(a20case='prior',track_model='hier',r2fix=True))]
def run(a):
    k,fam=a; lab,kw=STEPS[k]; o=mc.map_fit(dict(kw,fam=fam),nrand=8,seed=11,with_summary=True)
    sm=o['summary']; return dict(step=k,label=lab,fam=fam,Pc=o['Pc'],chi2=o['chi2'],rmw=sm['rmw'],vg=sm['vg'],resid17=sm['resid'][17],resid18=sm['resid'][18])
if __name__=='__main__':
    npr=int(sys.argv[1]) if len(sys.argv)>1 else 1; t0=time.time()
    with Pool(npr) as p: out=p.map(run,[(k,f) for k in range(len(STEPS)) for f in 'TUA'],chunksize=1)
    for k,(lab,_) in enumerate(STEPS):
        print(lab); [print('   %s Pc %.1f chi2 %.2f RMW %.1f peak %.0f kt | 17:04Z %+.1f 18:04Z %+.1f'%(o['fam'],o['Pc'],o['chi2'],o['rmw'],o['vg'],o['resid17'],o['resid18'])) for o in out if o['step']==k]
    json.dump(out,open(os.path.join(HERE,'ladder12.json'),'w'),indent=1); print('%.0f s'%(time.time()-t0))
