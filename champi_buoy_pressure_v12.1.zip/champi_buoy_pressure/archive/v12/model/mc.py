# v12 fitting with the central pressure free, and the Monte Carlo trial (v11 build kept as build_v11; used when a20case is None).
# A trial redraws the uncertain inputs (as prior centres or data perturbations) and refits with Pc free. Sources:
#   noise (reading scatter), bias (barometer), center (track + wander: offset and wander prior centres drawn from the track covariance),
#   ellipse (eyewall ellipticity and orientation), Rm (surface RMW and tilt k ~ U(1, 1.1)), shape (eye exponent / eye-table power),
#   decay (SAR v(1.4RMW), v(2RMW)), ring (SAR secondary maximum), alpha (log-layer 10-m to gradient conversion: one draw sets v14, v20,
#   the secondary maximum and the peak-wind constraint together), Pn (environmental pressure), intensity (peak surface wind), density.
# Job = dict(fam, track, sources, seed, vg, variant, dens, nu, tscale, sigpos, wander, ell, troch, soff, tag).
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from core import *
import logwind as LW
import core as C
from scipy.stats import norm as _N
SRC12=('noise','bias','center','ellipse','Rm','shape','decay','ring','alpha','alpha20','Pn','intensity','density')
SID={k:i+1 for i,k in enumerate(SRC12+('troch',))}      # one random stream per source: rng([seed, source id, 4242]); variants stay paired
SRC=('noise','bias','center','ellipse','Rm','shape','decay','ring','alpha','Pn','intensity','density')
WV={'interp':(LW.W2115,0.10),'nat2115':(1.0,0.0),'nat09':(0.0,0.0)}     # weight of the 21:15Z pass (and its spread) per structure variant
GM0={v:LW.grad_metrics(LW.DEF,WV[v][0]) for v in WV}
CB=json.load(open(os.path.join(HERE,'cbest.json'))) if os.path.exists(os.path.join(HERE,'cbest.json')) else {}
DEF=dict(track='gp',sources=SRC12,seed=0,vg=True,variant='interp',dens='thermo',nu=ROBUST_NU,tscale=1.0,sigpos=None,wander=True,ell=True,troch=None,soff=None,tag='',nrand=1,
         a20case='prior',track_model='hier',w_sd=None,v1420_rho=0.0,rho_rm_a20=0.0,rho_tilt_a20=0.0,buoyonly=False,r2fix=True)
DEF11=dict(DEF,sources=SRC,a20case=None,track_model='v11')
TOL=1e-6      # least-squares tolerances (ftol, xtol, gtol): central pressures agree with 1e-8 to 0.1 hPa at half the cost
def config_key(j):
    k='%s|%s|%s|%s'%(j['fam'],j['track'],j['variant'],'vg' if j['vg'] else 'novg'); return k if j.get('a20case') is None else k+'|'+j['a20case']
def track_select(j,u=None):
    """v12 track model for a trial: 'hier' / 'loguniform' draw SO from its posterior with the uniform u (None: posterior median);
    'fixed:<km>' a fixed SO; 'star' the STAR-centre track; 'v11' the v11 track (SO = 1 km)"""
    tm=j['track_model']
    if j['track']!='gp': return None
    if tm=='v11' or tm=='star': key=tm
    elif tm.startswith('fixed:'): key=C.so_index(float(tm.split(':')[1]))
    else:
        H=C._tv()['hier']
        if u is None: key=int(H['i_median'])
        else: cdf=np.cumsum(H['post']['flat' if tm=='hier' else 'loguniform']); key=int(min(np.searchsorted(cdf,u*cdf[-1]),len(cdf)-1))
    C.set_track(key); return key
def build(j,rng=None):
    """v12 prior dictionary, data and reading sd for a job; rng=None gives the unperturbed (MAP) configuration. Each source has its own
    random stream (seed, source id), consumed the same way in every variant, so variants differ only in what they change."""
    if j.get('a20case') is None: return build_v11(j,rng)
    S=j['sources'] if rng is not None else (); v=j['variant']; base=C.get_pri(v,j['a20case']); pri=dict(base)
    RS=lambda src: np.random.default_rng([int(j['seed']),SID[src],4242])
    pri['wander']=j['wander']; pri['ell']=j['ell']; pri['buoyonly']=j['buoyonly']
    if j['soff'] is not None: pri['soff']=j['soff']
    rc=RS('center'); uc=rc.uniform(); zc=rc.normal(size=2*NW)
    tk=track_select(j,uc if 'center' in S else None); pri['track_key']=tk
    s=sig_obs(j['sigpos'],j['track']); data=P.copy()
    if 'noise' in S: data=data+RS('noise').normal(0,s)
    if 'bias' in S: data=data+RS('bias').normal(0,0.5)
    if 'center' in S:
        if has_wander(j['track'],pri): pri['dlt0']=np.c_[C.LWIN@zc[:NW],C.LWIN@zc[NW:]]
        else: pri['off']=TRACKS[j['track']][2]+zc[:2]*pri.get('soff',TRACKS[j['track']][3])
    if 'ellipse' in S: re_=RS('ellipse'); pri['e0']=(max(0.0,re_.normal(*base['e0'])),base['e0'][1]); pri['th0']=(re_.normal(*base['th0']),base['th0'][1])
    zR,uk=0.0,0.5
    if 'Rm' in S: rr=RS('Rm'); zR=rr.normal(); uk=rr.uniform(); pri['Rm']=((base['Rm_sfc'][0]+zR*base['Rm_sfc'][1])*(TILT[0]+uk*(TILT[1]-TILT[0])),base['Rm'][1])
    if 'shape' in S:
        z=RS('shape').normal(); pri['n']=(base['n'][0]+z*base['n'][1],base['n'][1]); pri['I']=(base['I'][0]-z*base['I'][1],base['I'][1]); pri['s']=(base['s'][0]+z*base['s'][1],base['s'][1])
    arm=base['arm_val']; w=base['w0']; wsd=base['wsd'] if j['w_sd'] is None else (j['w_sd'] if base['wsd']>0 else 0.0); p=LW.DEF
    if 'alpha' in S:
        ra=RS('alpha'); p=LW.draw(ra); zw=ra.normal(); arm=float(LW.alpha_x(1.0,p)); w=float(np.clip(w+zw*wsd,0,1)) if wsd>0 else w
    c=base['a20']; za=RS('alpha20').normal() if 'alpha20' in S else 0.0
    if j['rho_rm_a20']: za=j['rho_rm_a20']*zR+np.sqrt(1-j['rho_rm_a20']**2)*za
    if j['rho_tilt_a20']: za=j['rho_tilt_a20']*_N.ppf(np.clip(uk,1e-9,1-1e-9))+np.sqrt(1-j['rho_tilt_a20']**2)*za
    a20c=c[1]+c[2]*za if c[0]=='norm' else base['a20c']
    x2=LW.x2_two(w,arm,a20c); r=LW.sfc_ratios(w,x2); sfc=dict(s14=r['s14'],s20=r['s20'],ssec=r['ssec'])
    if 'decay' in S:
        e=RS('decay').normal(size=2); rho=j['v1420_rho']; sfc['s14']+=SIG_M12*e[0]; sfc['s20']+=SIG_M12*(rho*e[0]+np.sqrt(1-rho**2)*e[1])
    R2c=x2*pri['Rm'][0] if j.get('r2fix',True) else ST[v]['R2']        # r2fix False: v11 form (surface, untilted secondary-maximum radius)
    if 'ring' in S: rg=RS('ring'); sfc['ssec']+=rg.normal(0,0.035); R2c+=rg.normal(0,SIG_MEAS['R2'])
    pri.update(a20c=a20c,arm_val=arm,x2=x2,sfc=sfc,R2=(R2c,base['R2'][1]),w_trial=w,a14_ll=float(LW.alpha_x(1.4,p)),ax2_ll=float(LW.alpha_x(x2,p)))
    if j['vg']:
        vs=base['VSFC'][0]+(RS('intensity').normal(0,base['VSFC'][1]) if 'intensity' in S else 0.0); pri['Vg']=(vs/arm,base['VG'][1]); pri['vsfc_trial']=vs
    if 'Pn' in S: pri['Pn']=(RS('Pn').normal(*base['Pn']),base['Pn'][1])
    pri['dens']=dict(DENS,mode=j['dens'])
    if 'density' in S:
        rd=RS('density'); pri['dens'].update(dTc=rd.uniform(0.5,4.5),dTw=rd.uniform(0.0,2.5),Tv_env=rd.normal(305.0,1.5),rwf=rd.uniform(0.5,1.2),r0f=rd.uniform(0.5,1.5),Rout=rd.uniform(200,600))
    if j['troch'] is not None and rng is not None: rt=RS('troch'); pri['troch']=(rt.uniform(0,j['troch'][0]),rt.uniform(*j['troch'][1:]),rt.uniform(0,2*np.pi))
    return pri,data,s
SIG_M12=0.03      # SAR measurement sd of the surface wind ratios at 1.4 and 2 RMW (v12 spec)
def build_v11(j,rng=None):
    """prior dictionary, data and reading sd for a job; rng=None gives the unperturbed (MAP) configuration"""
    C.set_track('v11')
    S=j['sources'] if rng is not None else (); v=j['variant']; base=PRIS[v]; pri=dict(base)
    pri['wander']=j['wander']; pri['ell']=j['ell']
    if j['soff'] is not None: pri['soff']=j['soff']
    s=sig_obs(j['sigpos'],j['track']); data=P.copy()
    if 'noise' in S: data=data+rng.normal(0,s)
    if 'bias' in S: data=data+rng.normal(0,0.5)                     # drifter barometer accuracy (~+-1 hPa at 2 sigma)
    if 'center' in S:
        if has_wander(j['track'],pri): pri['dlt0']=np.c_[LWIN@rng.normal(size=NW),LWIN@rng.normal(size=NW)]
        else: pri['off']=TRACKS[j['track']][2]+rng.normal(0,pri.get('soff',TRACKS[j['track']][3]),2)
    if 'ellipse' in S: pri['e0']=(max(0.0,rng.normal(*base['e0'])),base['e0'][1]); pri['th0']=(rng.normal(*base['th0']),base['th0'][1])
    if 'Rm' in S: pri['Rm']=(rng.normal(*base['Rm_sfc'])*rng.uniform(*TILT),base['Rm'][1])
    if 'shape' in S:
        z=rng.normal(); pri['n']=(base['n'][0]+z*base['n'][1],base['n'][1]); pri['I']=(base['I'][0]-z*base['I'][1],base['I'][1]); pri['s']=(base['s'][0]+z*base['s'][1],base['s'][1])
    c=dict(v14=base['v14'][0],v20=base['v20'][0],vsec=base['vsec'][0],R2=base['R2'][0]); arm=base['alpha_rm'][0]; g0=GM0[v]
    if 'alpha' in S:
        w0,wsd=WV[v]; gm=LW.grad_metrics(LW.draw(rng),np.clip(rng.normal(w0,wsd),0,1) if wsd>0 else w0)
        for k in ('v14','v20','vsec'): c[k]+=gm[k]-g0[k]
        c['R2']=base['R2'][0]*gm['x2']/g0['x2']; arm=gm['alpha_rm']
    if 'decay' in S: c['v14']+=rng.normal(0,SIG_MEAS['v14']); c['v20']+=rng.normal(0,SIG_MEAS['v20'])
    if 'ring' in S: c['vsec']+=rng.normal(0,SIG_MEAS['vsec']); c['R2']+=rng.normal(0,SIG_MEAS['R2'])
    for k in c: pri[k]=(c[k],base[k][1])
    if j['vg']:
        vs=base['VSFC'][0]+(rng.normal(0,base['VSFC'][1]) if 'intensity' in S else 0.0); pri['Vg']=(vs/arm,base['VG'][1])
    if 'Pn' in S: pri['Pn']=(rng.normal(*base['Pn']),base['Pn'][1])
    pri['dens']=dict(DENS,mode=j['dens'])
    if 'density' in S:
        pri['dens'].update(dTc=rng.uniform(0.5,4.5),dTw=rng.uniform(0.0,2.5),Tv_env=rng.normal(305.0,1.5),rwf=rng.uniform(0.5,1.2),r0f=rng.uniform(0.5,1.5),Rout=rng.uniform(200,600))
    if j['troch'] is not None and rng is not None: pri['troch']=(rng.uniform(0,j['troch'][0]),rng.uniform(*j['troch'][1:]),rng.uniform(0,2*np.pi))
    return pri,data,s
def fit_free(j,pri,data,s,starts_x,max_nfev=6000,tol=None):
    fam,track=j['fam'],j['track']
    def res(q): return make_res(fam,q[0],track,pri=pri,data=data,sig=s,nu=j['nu'],tscale=j['tscale'])[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track,pri=pri); lb=np.r_[800.0,lb]; ub=np.r_[912.0,ub]
    best=None; sols=[]
    for q0 in starts_x:
        try: r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=max_nfev,ftol=tol or TOL,xtol=tol or TOL,gtol=tol or TOL)
        except Exception: continue
        sols.append((float(r.x[0]),float(2*r.cost)))
        if best is None or r.cost<best.cost: best=r
    return best,sols
def default_starts(j,pri,rng,nrand=3):
    """starts: constrained best fits of this configuration (several Pc), with the trial's offset/ellipse/wander prior centres, plus random"""
    fam,track=j['fam'],j['track']; _,_,lb,ub=make_res(fam,880.0,track,pri=pri); bx=np.array(base_x(fam,track,pri))
    if 'dlt0' in pri: bx[-2*NW:]=np.r_[pri['dlt0'][:,0],pri['dlt0'][:,1]]
    st=[]
    rows=CB.get(config_key(j)) or CB.get('%s|gp|interp|vg|prior'%fam) if j.get('a20case') else CB.get(config_key(j),[])
    for row in rows or []:
        x=np.array(row['x']); nb=NBASE[fam]
        if pri.get('a20mode') and len(x)==len(lb)-1: x=np.r_[x[:nb+2],pri['a20c'],x[nb+2:]]
        x=x[:len(lb)]; x[nb-8:nb-6]=pri.get('off',x[nb-8:nb-6])
        if pri.get('a20mode'): x[nb+2]=pri['a20c']
        if 'dlt0' in pri and has_wander(track,pri): x[-2*NW:]=x[-2*NW:]*0.5+bx[-2*NW:]*0.5
        st.append(np.r_[row['Pc'],np.clip(x,lb+1e-6,ub-1e-6)])
    if not st: st=[np.r_[pc,q] for pc in (870.0,886.0,900.0) for q in starts(fam,track,2,int(rng.integers(1e6)),lb,ub,pri)[:2]]
    pc0=st[0][0]
    for q in starts(fam,track,nrand*4,int(rng.integers(1e6)),lb,ub,pri)[-nrand:]: st.append(np.r_[pc0+rng.normal(0,8),q])
    return st
def trial(job):
    j=dict(DEF); j.update(job); rng=np.random.default_rng(j['seed'])
    if j.get('a20case') is None: j=dict(DEF11); j.update(job); rng=np.random.default_rng(j['seed'])
    pri,data,s=build(j,rng); best,sols=fit_free(j,pri,data,s,default_starts(j,pri,rng,nrand=j['nrand']))
    pcs=np.array([p for p,c in sols]); cs=np.array([c for p,c in sols]); near=(cs<2*best.cost+0.05)
    out=dict(fam=j['fam'],track=j['track'],sources=list(j['sources']),seed=int(j['seed']),vg=bool(j['vg']),variant=j['variant'],dens=j['dens'],nu=float(j['nu']),
             tscale=float(j['tscale']),sigpos=j['sigpos'],wander=bool(j['wander']),ell=bool(j['ell']),troch=j['troch'],soff=j['soff'],tag=j['tag'],
             Pc=float(best.x[0]),chi2=float(2*best.cost),n_starts=len(sols),sols=sols,spread_at_best=float(pcs[near].max()-pcs[near].min()) if near.sum()>1 else 0.0)
    if j.get('a20case') is not None: out.update(a20case=j['a20case'],track_model=j['track_model'],**detail(j,pri,data,s,best))
    return out
PEN_NAMES={'T':['sx','sy','Pn','Rm','eye','v14','Vg','v20','R2','vsec','e0','th0'],'C':['sx','sy','Pn','Rm','eye','v14','Vg','v20','R2','vsec','e0','th0'],
           'U':['sx','sy','Pn','Rm','eye','v14','Vg','v20','e0','th0'],'A':['sx','sy','Pn','Rm','eye','v14','Vg','v20','e0','th0']}
def detail(j,pri,data,s,best):
    """full per-trial record (v12 spec rule 7): drawn inputs, fitted parameters, chi2 by component, residual and z of every reading"""
    fam=j['fam']; res,unpack,_,_=make_res(fam,best.x[0],j['track'],pri=pri,data=data,sig=s,nu=j['nu'],tscale=j['tscale'])
    q=best.x[1:]; r=res(q); u=unpack(q); Pm,rr,re=res.pressure(u); names=PEN_NAMES[fam]+(['a20'] if pri.get('a20mode') else []); pen=r[NB:]
    if fam=='A':
        r_=np.linspace(2,150,1500); vg=vgA_rho(r_,u['parts'],best.x[0],u['Dtot'],pri['dens'],u['parts'][0][1]); i=int(vg.argmax()); rm,vmax=float(r_[i]),float(vg[i])
        g14,g20=float(np.interp(1.4*rm,r_,vg)/vmax),float(np.interp(2*rm,r_,vg)/vmax)
    else:
        tab=pri['tab'] if fam in 'TU' else None; rm=float(u['Rm']); vR=shapeC(np.array([rm,1.4*rm,2*rm]),rm,u['n'],u['A'],u['X1'],u['X2'],u['a'],u['R2'],u['W2'],tab)
        vmax=float(u['Vm']*vR[0]); g14,g20=float(vR[1]/vR[0]),float(vR[2]/vR[0])
    so=None
    if pri.get('track_key') not in (None,'v11','star'): so=float(C._tv()['so'][int(pri['track_key'])])
    elif pri.get('track_key')=='v11': so=1.0
    return dict(inputs=dict(so=so,track_key=(pri.get('track_key') if not isinstance(pri.get('track_key'),(np.integer,)) else int(pri['track_key'])),
                            arm=float(pri['arm_val']),a20c=float(pri['a20c']),w=float(pri['w_trial']),x2=float(pri['x2']),Rm_prior=float(pri['Rm'][0]),
                            vsfc=float(pri.get('vsfc_trial',np.nan)),Vg_prior=float(pri['Vg'][0]) if 'Vg' in pri else None,R2_prior=float(pri['R2'][0]),
                            sfc=[float(pri['sfc'][k]) for k in ('s14','s20','ssec')],e0_prior=float(pri['e0'][0]),th0_prior=float(pri['th0'][0]),Pn_prior=float(pri['Pn'][0])),
                fit=dict(x=[float(v) for v in best.x],rmw=rm,vmax_kt=vmax*KT,g14=g14,g20=g20,a20=(float(u['a20']) if u['a20'] is not None else None),e0=float(u['e0']),th0=float(u['th0'])),
                chi2_parts=dict(buoy=float(np.sum(r[:NB]**2)),**{nm:float(pen[k]**2) for k,nm in enumerate(names)},wander=float(np.sum(pen[len(names):]**2))),
                resid=[float(v) for v in (data-Pm)],z=[float(v) for v in (data-Pm)/s],r_eff=[float(v) for v in re])
def map_fit(job,nrand=8,seed=1,with_summary=True):
    """unperturbed fit (maximum a posteriori) of a configuration"""
    j=dict(DEF); j.update(job); rng=np.random.default_rng(seed); pri,data,s=build(j,None)
    st=default_starts(j,pri,rng,nrand=nrand)
    best,sols=fit_free(j,pri,data,s,st,tol=1e-8)
    out=dict(job={k:(v if not isinstance(v,tuple) else list(v)) for k,v in j.items()},Pc=float(best.x[0]),chi2=float(2*best.cost),x=[float(v) for v in best.x])
    if with_summary:
        res,unpack,_,_=make_res(j['fam'],best.x[0],j['track'],pri=pri,sig=s,nu=j['nu'],tscale=j['tscale'])
        class Bst: pass
        b=Bst(); b.x=best.x[1:]; b.cost=best.cost; d=summarize(j['fam'],b,unpack,best.x[0],j['track'],res=res,pri=pri); out.update(summary=d)
        rv=res(best.x[1:]); out['nres']=len(rv); out['npar']=len(best.x)
    return out
