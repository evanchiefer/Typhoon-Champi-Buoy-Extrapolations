# Writes README.md for v12 from the saved results (no number is typed by hand).
import os, json, numpy as np
H=os.path.dirname(os.path.abspath(__file__)); J=lambda f: json.load(open(os.path.join(H,f)))
F=J('final12.json'); WJ=J('weights12.json'); LD=J('ladder12.json'); TH=J('track_hier.json'); GC=J('gapcheck.json'); BD=J('bounds.json'); SCK=J('sarcheck.json')
CF=J('fits_constrained.json'); RW=J('reading_weights.json'); LWP=J('logwind_priors.json'); SF=J('sar/sar_files.json'); RS=J('rescale.json'); C12=J('centre12.json'); CC=J('centre_compare.json'); CTR=J('centretrials12.json')
st={k:J('sar/%s_struct.json'%k) for k in ('S1D_20_0909','R3_20_0920','R3_20_2115','R3_21_0929','R3_21_2123')}
Hd=F['headline']; HQ=Hd['q']; CS=F['cases']; W=F['weights']; JT=F['jtwc_1733']; AW=F['alt_weights']; CON=F['conservation']; DER=F['derivatives']; w=Hd['weights']
FB={(o['fam'],o['case']):o for o in WJ['fits']}
NAME={'T':'ring model','U':'no-ring model','A':'two-ring Holland'}
def row(lab,q,bold=False):
    m='**%.0f**'%q[2] if bold else '%.0f'%q[2]; return '| %s | %s | %.0f–%.0f | %.0f–%.0f |'%(lab,m,q[1],q[3],q[0],q[4])
def pmq(tg,f): return CS[tg]['per_model'][f]['q']
def case_row(lab,tg):
    m=CS[tg]; pz=m.get('paired')
    sh=('%+.1f'%pz['shift_median']) if pz else '—'; rt=('%+.2f ± %.2f'%(pz['per_model']['T']['mean_diff'],pz['per_model']['T']['se_mean'])) if pz and 'T' in pz['per_model'] else '—'
    return '| %s | %.1f | %.1f–%.1f | %.1f–%.1f | %s | %s | %s |'%(lab,m['q'][2],m['q'][1],m['q'][3],m['q'][0],m['q'][4],sh,rt,' / '.join('%.1f'%m['per_model'][f]['q'][2] for f in 'TUAC' if f in m['per_model']))
med=[c for c in CF if c['name']=='T_con_gp' and c['tag']=='median'][0]
im=TH['i_median']
B=F['budget']; lab={'family':'profile-shape choice (3 models)','Rm':'radius of maximum wind (incl. tilt)','intensity':'peak surface wind (incl. SAR calibration ±8%)',
   'noise':'reading scatter','center':'centre position (track, drift, wander)','alpha':'10-m to gradient conversion at the RMW','alpha20':'conversion at 2× radius (α20)','shape':'inner-eye wind shape',
   'ring':'secondary wind maximum','ellipse':'oval eyewall','decay':'wind ratios at 1.4× and 2× radius','bias':'barometer calibration','density':'air density','Pn':'environmental pressure'}
budget='\n'.join('  - %s %.1f'%(lab.get(k,k),v) for k,v in sorted(B.items(),key=lambda kv:-kv[1]))
cv=F['conv_check']; bs=Hd.get('bootstrap',{})
lad='\n'.join('| %s | %s |'%(s,' | '.join('%.1f'%[o for o in LD if o['step']==k and o['fam']==f][0]['Pc'] for f in 'TUA'))
             for k,s in sorted({(o['step'],o['label']) for o in LD}))
cons='\n'.join('| %s | %s | %.1f | %.2f | %+.2f | %.2f | %+.2f | %s | %+.2f | %s | %.3f | %s |'%(c,NAME[f],FB[(f,c)]['Pc'],FB[(f,c)]['chi2_buoy'],CON[c][f]['dchi2_buoy_vs_free'],CON[c][f]['chi2_per_dof'],
    CON[c][f]['dchi2_after_rescale'],('—' if c=='buoyonly' else 'yes' if CON[c][f]['conflict'] else 'no'),CON[c][f]['z_1804'],('%+.2f'%CON[c][f]['dloo_vs_free']),CON[c][f]['a20_implied'],
    ('%.1f (%.1f–%.1f)'%(CON[c][f]['Pc_mc'][2],CON[c][f]['Pc_mc'][1],CON[c][f]['Pc_mc'][3])) if CON[c][f]['Pc_mc'] else '—') for c in ('free','prior','flat','loglayer','buoyonly') for f in 'TUA')
wrow=lambda k,nm: '| %s | %.2f / %.2f / %.2f | %.1f (%.1f–%.1f) |'%(nm,AW[k]['weights'].get('T',0),AW[k]['weights'].get('U',0),AW[k]['weights'].get('A',0),AW[k]['q'][2],AW[k]['q'][1],AW[k]['q'][3])
wtab='\n'.join(wrow(k,nm) for k,nm in (('measAIC','**Measurement-aware AIC, effective parameters (headline)**'),('measAIC_all','… adding the SAR ellipse terms'),('AIC_nominal','AIC, nominal parameter counts'),
      ('BIC_nominal','BIC, nominal'),('BIC_eff','BIC, effective parameters'),('pbma_buoy','Leave-one-out on buoy readings, pseudo-BMA+ (v11 headline method)'),('stacking_buoy','… stacking'),
      ('pbma_buoy_sar','Leave-one-out on buoy readings + SAR measurements, pseudo-BMA+'),('equal','Equal'),('ring_only','Ring model only')))
fits='\n'.join('| %s | %.1f | %.2f | %.2f | %s | %.2f | %.1f | %.1f | %.3f |'%(NAME[f],FB[(f,'prior')]['Pc'],FB[(f,'prior')]['chi2_buoy'],sum(FB[(f,'prior')]['chi2_sar'].values()),
      '%+.2f'%FB[(f,'prior')]['z_ring'],FB[(f,'prior')]['chi2_meas'],FB[(f,'prior')]['p_eff'],FB[(f,'prior')]['chi2_meas']+2*FB[(f,'prior')]['p_eff'],FB[(f,'prior')]['a20_fit']) for f in 'TUA')
sarterms='\n'.join('| %s | %s |'%(NAME[f],' | '.join('%.2f'%FB[(f,'prior')]['chi2_sar'][k] for k in ('Rm','eye','v14','Vg','v20'))) for f in 'TUA')
SENS=[('S4_independent','S4 α20 for the 2× ratio only (1.4× and ring keep the log-layer α; v11 form)'),('S5_drift_fixed3','S5 IR-surface drift fixed at 3 km'),('S6_drift_fixed1.5','S6 drift fixed at 1.5 km'),
      ('S7_no_wander','S7 no centre wander'),('S8_drift_loguniform','S8 drift posterior with a log-uniform prior'),('S9_v11_track','S9 v11 track (drift 1 km)'),
      ('S12_rm_a20_-0.5','S12 RMW–α20 correlation −0.5'),('S12_rm_a20_-0.3','S12 … −0.3'),('S12_rm_a20_+0.3','S12 … +0.3'),('S12_rm_a20_+0.5','S12 … +0.5'),
      ('S13_tilt_a20_-0.5','S13 tilt–α20 correlation −0.5'),('S13_tilt_a20_+0.5','S13 … +0.5'),('S14_wsd_0.05','S14 21:15Z weight sd 0.05'),('S14_wsd_0.02','S14 … 0.02'),
      ('S15_v14v20_rho0.3','S15 SAR 1.4×/2× error correlation 0.3'),('S15_v14v20_rho0.5','S15 … 0.5'),('S15_v14v20_rho0.7','S15 … 0.7'),
      ('S19_sigpos0.5','S19 position term 0.5 km'),('S19_sigpos1.5','S19 position term 1.5 km'),('S20_sigma_rescaled','S20 reading σ rescaled to buoy χ²/dof = 1'),
      ('S23_star_centre','S23 STAR storm centre at 09:09Z'),('S24_flat4km_irf','S24 flat ±4 km centre error, v10 track'),('S25_2115_only','S25 21:15Z structure only'),
      ('S26_09Z_only','S26 09Z structure only'),('S27_buoy_only','S27 buoy only (no SAR outer-structure terms)'),
      ('v11chk_trochoid','v11 check: trochoidal wobble ≤ 3 km'),('v11chk_v10_geometry','v11 check: v10 geometry'),('v11chk_bt','v11 check: JTWC best-track positions'),
      ('v11chk_ramp','v11 check: log-ramp density'),('v11chk_gauss','v11 check: Gaussian reading errors'),('v11chk_tscaled','v11 check: Student-t scaled to sd σ'),
      ('v11chk_structure_only','v11 check: structure only (no wind input)'),('v11chk_powerlaw_eye','v11 check: power-law eye (ring model)')]
sens='\n'.join(case_row(nm,tg) for tg,nm in SENS if tg in CS)
def d_(tg,f,k): x=DER[tg][f][k]; return '%.2f ± %.2f'%(x[0],x[1])
der='\n'.join('| %s | %s | %s | %s | %s | %s | %s |'%(NAME[f],d_('head',f,'dPc_dVsfc_partial'),d_('head',f,'dPc_dRm_total'),d_('head',f,'dPc_dRm_partial'),d_('head',f,'dPc_dalpha_rm'),d_('head',f,'dPc_dalpha20'),d_('head',f,'dPc_dreff1704')) for f in 'TUA')
a20q='; '.join('%s %.3f (%.3f–%.3f)'%(NAME[f],DER['head'][f]['alpha20_fit_q'][1],DER['head'][f]['alpha20_fit_q'][0],DER['head'][f]['alpha20_fit_q'][2]) for f in 'TUA')
gap='\n'.join('| %s | %.0f → %.0f | %.2f | %.2f | %.2f |'%(g[0],g[1],g[2],g[3]/g[4],g[3]/g[5],g[3]/g[6]) for g in GC)
bnd='\n'.join('| %s | %.1f hPa | %.1f |'%(r[0],r[1],r[2]) for r in BD['rows'])
rws='\n'.join('| %s | %.1f | %+.1f | %.1f | %+.2f | %.2f |'%('%02d:%02dZ'%(int(r['t']),round(r['t']%1*60)),r['p'],r['resid'],r['sigma'],r['z'],r['weight']) for r in RW if 15<=r['t']<=20.1)
def sp(k,name,inc):
    s=st[k]; return '| %s | %.2f | %.0f | %.3f | %.2f | %s | %s |'%(name,s['Rm'],s['Vm_kt'],s['I47'],s['v14'],('%.1f km, %.2f'%(s['R2'],s['vsec'])) if s['R2'] else 'none',inc)
sar='\n'.join([sp('S1D_20_0909','Sentinel-1D 20 Oct 09:09Z','28–32°'),sp('R3_20_0920','RCM-3 20 Oct 09:20Z','48–52°'),sp('R3_20_2115','RCM-3 20 Oct 21:15Z','27–33°'),
               sp('R3_21_0929','RCM-3 21 Oct 09:29Z','28–33°'),sp('R3_21_2123','RCM-3 21 Oct 21:23Z','—')])
post=np.array(TH['post']['flat']); sog=np.array(TH['so_grid']); cdf=np.cumsum(post); qso=lambda q: float(np.interp(q,cdf,sog))
pl=np.array(TH['post']['loguniform']); cdl=np.cumsum(pl); qsl=lambda q: float(np.interp(q,cdl,sog))
nH=sum(Hd['n'].values()); ntot=F['n_trials']; sq=SCK['interp']['both']
cT=[o for o in C12['free'] if o['fam']=='T' and o['free']][0]; cTf=[o for o in C12['free'] if o['fam']=='T' and not o['free']][0]
cU=[o for o in C12['free'] if o['fam']=='U' and o['free']][0]; cA=[o for o in C12['free'] if o['fam']=='A' and o['free']][0]
dh=[d for d in CC['derived'] if 'headline' in d['source']][0]; dr=[d for d in CC['derived'] if 'IR-vs-STAR' in d['source']][0]
fx='\n'.join('| %02d:%02dZ | %s (%s) | %+.1f | %+.1f | %.1f | %s |'%(int(d['hour']),round(d['hour']%1*60),d['source'].replace('CIMSS ARCHER centre fix','ARCHER').replace(' (derived from 183 GHz image)',''),d['sensor'],d['dE'],d['dN'],d['dist'],d['unc']) for d in CC['fixes'])
cen=f'''- **Data only.** With the centre fixes removed (the whole track shifted by a free constant offset, no wander), the buoy readings and SAR terms pull the
  centre south-west along a long, weakly bound valley: best fit {abs(cT['ox']):.1f} km west and {abs(cT['oy']):.1f} km south of the fix-based track, Pc {cT['Pc']:.1f}; the
  fix-based centre is Δχ² {cTf['chi2']-cT['chi2']:.1f} worse (about 3σ for two parameters). The no-ring and Holland models do the same (Pc {cU['Pc']:.0f} and {cA['Pc']:.0f} at their own optima).
  Near the fix-based centre, Pc rises about 2.4 hPa per km as the centre slides south-west (Figure 3).
- **Not independent evidence of position.** A symmetric profile can absorb the 18:04Z misfit and any wavenumber-1 asymmetry only by moving
  the centre. The fixes nearest the pass that neither this analysis nor [B10] fits agree with the fix-based track, measured at their own times:

| Time | Fix | East (km) | North (km) | Distance (km) | Stated uncertainty |
|---|---|---|---|---|---|
'''+fx+f'''

  None points 10 km or more south-west. The ARCHER geo-referenced positions lie 11–26 km west and disagree with ARCHER's own raw positions for the same images.
- **Separate centre analysis.** A separately run centre-relocation analysis [B10] (IR-fix track plus an offset prior times a buoy + SAR likelihood;
  different code, mostly the same fixes) puts the 17:33Z centre {dh['dist']:.1f} km from the v12 fitted centre ({dh['dE']:+.1f} km east, {dh['dN']:+.1f} km north), within both
  analyses' 1σ (theirs {dh['unc']}; v12 ±{TH['sd_1704'][im]:.1f} km per component). Their IR-vs-STAR sensitivity centre lies {dr['dist']:.1f} km away, to the south ({dr['dE']:+.1f} E, {dr['dN']:+.1f} N).
  The two analyses share most of their inputs, so this is a check on method, not independent data.
- In the headline the centre is carried by the track model (±{TH['sd_1704'][im]:.1f} km); wider centre assumptions are sensitivity cases: flat ±4 km
  {CS['S24_flat4km_irf']['paired']['shift_median']:+.0f}, v10 geometry {CS['v11chk_v10_geometry']['paired']['shift_median']:+.0f}, JTWC positions {CS['v11chk_bt']['paired']['shift_median']:+.0f}, STAR centre {CS['S23_star_centre']['paired']['shift_median']:+.0f} hPa (paired shifts).'''
REFS=r'''
## References and data sources

Citations were checked against publisher, Crossref or agency pages on 25–26 Oct 2026. Items marked † were matched to standard bibliographic
records but not re-opened. Items marked ‡ could not be confirmed (see notes).

### A. Literature
- [A1] Holland, G. J., 1980: An analytic model of the wind and pressure profiles in hurricanes. *Mon. Wea. Rev.*, 108, 1212–1218. https://doi.org/10.1175/1520-0493(1980)108<1212:AAMOTW>2.0.CO;2 (two-ring Holland profile)
- [A2] Willoughby, H. E., R. W. R. Darling, and M. E. Rahn, 2006: Parametric representation of the primary hurricane vortex. Part II: A new family of sectionally continuous profiles. *Mon. Wea. Rev.*, 134, 1102–1120. https://doi.org/10.1175/MWR3106.1 (power-law eye, dual-exponential decay)
- [A3] Atkinson, G. D., and C. R. Holliday, 1977: Tropical cyclone minimum sea level pressure/maximum sustained wind relationship for the western North Pacific. *Mon. Wea. Rev.*, 105(4), 421–427. https://doi.org/10.1175/1520-0493(1977)105<0421:TCMSLP>2.0.CO;2 (context curve in Fig. 2b)
- [A4] Knaff, J. A., and R. M. Zehr, 2007: Reexamination of tropical cyclone wind–pressure relationships. *Wea. Forecasting*, 22, 71–88. https://doi.org/10.1175/WAF965.1 (context)
- [A5] Courtney, J., and J. A. Knaff, 2009: Adapting the Knaff and Zehr wind–pressure relationship for operational use in Tropical Cyclone Warning Centres. *Aust. Meteor. Oceanogr. J.*, 58(3), 167–179. https://doi.org/10.22499/2.5803.002 (context)
- [A6] Franklin, J. L., M. L. Black, and K. Valde, 2003: GPS dropwindsonde wind profiles in hurricanes and their operational implications. *Wea. Forecasting*, 18, 32–44. https://doi.org/10.1175/1520-0434(2003)018<0032:GDWPIH>2.0.CO;2
- [A6b] Franklin, J. L., M. L. Black, and K. Valde, 2000: *Eyewall Wind Profiles in Hurricanes Determined By GPS Dropwindsondes*. NOAA/NHC web report. https://www.nhc.noaa.gov/aboutwindprofile.shtml (357 eyewall dropsonde profiles from NOAA and Air Force Reserve aircraft in 17 Atlantic and eastern-Pacific hurricanes, 1997–1999; 10-m wind / 700-hPa flight-level wind: 0.91 eyewall, 0.88 at the RMW (a lower bound), 0.78 outer vortex. Not Champi data, and the reference level is 700 hPa (~3 km), not the top of the boundary layer: used as a consistency check on the shape of α(r) only)
- [A7] Powell, M. D., P. J. Vickery, and T. A. Reinhold, 2003: Reduced drag coefficient for high wind speeds in tropical cyclones. *Nature*, 422, 279–283. https://doi.org/10.1038/nature01481 (roughness range in the log-layer factor)
- [A8] Powell, M. D., E. W. Uhlhorn, and J. D. Kepert, 2009: Estimating maximum surface winds from hurricane reconnaissance measurements. *Wea. Forecasting*, 24(3), 868–883. https://doi.org/10.1175/2008WAF2007087.1 (RMW tilt; mean slant reduction factor, maximum surface wind / maximum 2–4 km flight-level wind on the same leg, 0.84 ± 0.09 (SFMR, 15 hurricanes) - an eyewall value with no eyewall/outer split, so it does not constrain α at 2 RMW)
- [A9] Stern, D. P., and D. S. Nolan, 2009: Reexamining the vertical structure of tangential winds in tropical cyclones: Observations and theory. *J. Atmos. Sci.*, 66(12), 3579–3600. https://doi.org/10.1175/2009JAS2916.1 (RMW tilt)
- [A10] Kepert, J., 2001: The dynamics of boundary layer jets within the tropical cyclone core. Part I: Linear theory. *J. Atmos. Sci.*, 58(17), 2469–2484. https://doi.org/10.1175/1520-0469(2001)058<2469:TDOBLJ>2.0.CO;2 ; Kepert, J., and Y. Wang, 2001: Part II: Nonlinear enhancement. *J. Atmos. Sci.*, 58(17), 2485–2501. https://doi.org/10.1175/1520-0469(2001)058<2485:TDOBLJ>2.0.CO;2 (supergradient boundary-layer wind in the log-layer factor)
- [A11] Muramatsu, T., 1986: Trochoidal motion of the eye of Typhoon 8019. *J. Meteor. Soc. Japan*, 64, 259–272. https://doi.org/10.2151/jmsj1965.64.2_259
- [A12] Nolan, D. S., M. T. Montgomery, and L. D. Grasso, 2001: The wavenumber-one instability and trochoidal motion of hurricane-like vortices. *J. Atmos. Sci.*, 58(21), 3243–3270. https://doi.org/10.1175/1520-0469(2001)058<3243:TWOIAT>2.0.CO;2
- [A13] Kuo, H.-C., R. T. Williams, and J.-H. Chen, 1999: A possible mechanism for the eye rotation of Typhoon Herb. *J. Atmos. Sci.*, 56(11), 1659–1673. https://doi.org/10.1175/1520-0469(1999)056<1659:APMFTE>2.0.CO;2
- [A14] Mouche, A., B. Chapron, J. Knaff, Y. Zhao, B. Zhang, and C. Combot, 2019: Copolarized and cross-polarized SAR measurements for high-resolution description of major hurricane wind structures: Application to Irma category 5 hurricane. *J. Geophys. Res. Oceans*, 124, 3905–3922. https://doi.org/10.1029/2019JC015056
- [A15] Combot, C., A. Mouche, J. Knaff, Y. Zhao, Y. Zhao, L. Vinour, Y. Quilfen, and B. Chapron, 2020: Extensive high-resolution synthetic aperture radar (SAR) data analysis of tropical cyclones: Comparisons with SFMR flights and best track. *Mon. Wea. Rev.*, 148(11), 4545–4563. https://doi.org/10.1175/MWR-D-20-0005.1
- [A16] Velden, C. S., and D. Herndon, 2020: A consensus approach for estimating tropical cyclone intensity from meteorological satellites: SATCON. *Wea. Forecasting*, 35(4), 1645–1662. https://doi.org/10.1175/WAF-D-20-0015.1
- [A17] Olander, T. L., and C. S. Velden, 2019: The Advanced Dvorak Technique (ADT) for estimating tropical cyclone intensity: Update and new capabilities. *Wea. Forecasting*, 34(4), 905–922. https://doi.org/10.1175/WAF-D-19-0007.1
- [A18] Wimmers, A. J., and C. S. Velden, 2016: Advancements in objective multisatellite tropical cyclone center fixing. *J. Appl. Meteor. Climatol.*, 55(1), 197–212. https://doi.org/10.1175/JAMC-D-15-0098.1 (ARCHER)
- [A19] Griffin, S. M., A. Wimmers, and C. S. Velden, 2024: Predicting short-term intensity change in tropical cyclones using a convolutional neural network. *Wea. Forecasting*, 39(1), 177–202. https://doi.org/10.1175/WAF-D-23-0085.1 (D-MINT and D-PRINT; the products have also been called DeepMicroIRNet, DeepMultiNet and OPEN-AIIR)
- [A19b] Olander, T., A. Wimmers, C. Velden, and J. P. Kossin, 2021: Investigation of machine learning using satellite-based advanced Dvorak technique analysis parameters to estimate tropical cyclone intensity. *Wea. Forecasting*, 36(6), 2161–2186. https://doi.org/10.1175/WAF-D-20-0234.1 (AiDT)
- [A20] Lange, K. L., R. J. A. Little, and J. M. G. Taylor, 1989: Robust statistical modeling using the t distribution. *J. Amer. Stat. Assoc.*, 84(408), 881–896. https://doi.org/10.1080/01621459.1989.10478852 †
- [A21] Yao, Y., A. Vehtari, D. Simpson, and A. Gelman, 2018: Using stacking to average Bayesian predictive distributions (with discussion). *Bayesian Analysis*, 13(3), 917–1007. https://doi.org/10.1214/17-BA1091 † (pseudo-BMA+ and stacking weights)
- [A22] Akaike, H., 1974: A new look at the statistical model identification. *IEEE Trans. Autom. Control*, 19(6), 716–723. https://doi.org/10.1109/TAC.1974.1100705 † ; Schwarz, G., 1978: Estimating the dimension of a model. *Ann. Statist.*, 6(2), 461–464. https://doi.org/10.1214/aos/1176344136 † (AIC, BIC)
- [A23] Rubin, D. B., 1981: The Bayesian bootstrap. *Ann. Statist.*, 9(1), 130–134. https://doi.org/10.1214/aos/1176345338 †
- [A24] Rasmussen, C. E., and C. K. I. Williams, 2006: *Gaussian Processes for Machine Learning*. MIT Press. http://www.gaussianprocess.org/gpml/ † (Matérn covariance)
- [A24b] Patterson, H. D., and R. Thompson, 1971: Recovery of inter-block information when block sizes are unequal. *Biometrika*, 58(3), 545–554. https://doi.org/10.1093/biomet/58.3.545 † (restricted maximum likelihood)
- [A25] Alet, F., et al., 2026: Operational tropical cyclone forecasting with AI. *Nature*, 657, 680–688. https://doi.org/10.1038/s41586-026-10953-2 (WeatherNext-Cyclones; its GenCast baseline converts pressure to wind with v_max = 6.70·max(0, 1010 − p_min)^0.644, constants refitted to ERA5 and IBTrACS in the Atkinson–Holliday form; discussed, not used in the fit)
- [A26] Monaldo, F. M., 2005: *ANSWRS: APL/NOAA SAR Wind Retrieval System Software Documentation*. JHU/APL Report SRO-05-13. Listed at https://www.star.nesdis.noaa.gov/socd/mecb/sar/publications.php ; Monaldo, F., C. Jackson, W. Pichel, and X. Li, 2015: Early validation of operational SAR wind retrievals from Sentinel-1A. *IGARSS 2015*, 1223–1226. https://doi.org/10.1109/IGARSS.2015.7325993 ; Monaldo, F., C. Jackson, and W. Pichel, 2013: Seasat to RADARSAT-2: Research to operations. *Oceanography*, 26(2). https://doi.org/10.5670/oceanog.2013.29
- [A27] NOAA/NESDIS/STAR: *Tropical SAR Winds Technical Document* (cross-polarisation GMFs for Sentinel-1, RADARSAT-2 and RCM, July 2023). https://www.star.nesdis.noaa.gov/socd/mecb/sar/tropical_gmf_tech_doc.php ‡ The GMF labels in the file metadata ("S1A_V2", "RCM_V1") are not documented publicly; STAR documents its cross-pol GMFs as C-10 (Sentinel-1) and C-12 (RCM), matching the "C-10"/"C-12" in the file names.
- [A28] Chavas, D. R., J. A. Knaff, and P. Klotzbach, 2025: A simple model for predicting tropical cyclone minimum central pressure from intensity and size. *Wea. Forecasting*, 40(2), 333–346. https://doi.org/10.1175/WAF-D-24-0031.1 † (title, volume and pages checked at https://purr.purdue.edu/projects/chavasetal2024 ; DOI as given in [B9]; context for the wind-pressure sensitivity)

### B. Data and products
- [B1] NOAA/NESDIS/STAR SAR tropical-cyclone winds, Champi (WP292026): level-2 500-m NetCDF and 3-km "MERGED_FIX" files for the six passes in `sar/sar_files.json` (names, acquisition times, sha256). https://www.star.nesdis.noaa.gov/socd/mecb/sar/sarwinds_tropical.php . Credit: "Synthetic Aperture Radar (SAR) based tropical wind products were generated and provided through the STAR Water Surface Conditions Science Team's tropical cyclone winds program." STAR products are for experimental use. RADARSAT Constellation Mission imagery © Government of Canada 2026; RADARSAT is an official mark of the Canadian Space Agency. Contains modified Copernicus Sentinel data (2026).
- [B2] NOAA/NCEP Global Forecast System 0.25° (wind directions used by ANSWRS; file metadata "gfs025"). https://nomads.ncep.noaa.gov/ † The cross-polarisation retrievals used here are close to direction-independent.
- [B3] Japan Meteorological Agency, Himawari-9 infrared imagery (hourly eye fixes, `ir_eye_fixes.json`). https://www.data.jma.go.jp/mscweb/en/himawari89/ † ; imagery viewer RAMMB/CIRA SLIDER https://rammb-slider.cira.colostate.edu/ †
- [B4] ATMS 165/183-GHz imagery (NOAA/NASA JPSS), eye fix at 17:01Z. https://www.nesdis.noaa.gov/our-satellites/currently-flying/joint-polar-satellite-system † (the satellite and the imagery page used are not recorded here)
- [B5] Joint Typhoon Warning Center, WP29 2026 (ATCF working best track; positions and 895 hPa). https://www.metoc.navy.mil/jtwc/jtwc.html ‡ JTWC releases final best tracks after the season, so 895 hPa is provisional. RSMC Tokyo (JMA) lists 900 hPa (not checked here).
- [B6] CIMSS Tropical Cyclones, University of Wisconsin–Madison SSEC (ADT, AiDT, SATCON, D-MINT, D-PRINT, ARCHER values in Fig. 2). https://tropic.ssec.wisc.edu/
- [B7] Drifting buoy WMO 2802285, hourly sea-level pressure and position (spreadsheet `data_source/champi_revised.xlsx`, supplied by Evan; NOAA source page shared by Evan). ‡ The originating platform record was not found in public GDP/OSMC/NDBC listings from here. Drifting-buoy data of this kind are distributed via the GTS (WMO buoy identifiers: https://community.wmo.int/en/buoy-wmo-identification-numbers), the NOAA Global Drifter Program (https://www.aoml.noaa.gov/phod/gdp/) and NOAA NDBC.
- [B8] Independent review of v9/v10 by a separately run analysis ("champi_v11guidance_for_claude": `AUDIT.md`, `REVIEW_V10.md`, `WRITEUP.md`), supplied by Evan, 24–25 Oct 2026. Unpublished.
- [B9] The same group's review of v11 (`review_claude_v11.md`) and v12 specification (`v12_spec_for_claude.md`), supplied by Evan, 25–26 Oct 2026. Unpublished. Literature values quoted from [B9] and not re-derived here are marked as such.
- [B10] The same group's centre-relocation and Holland-shape study ("v12-CR"), with the centre-fix table `data_source/centre_fixes_17Z.csv`
  (Himawari-9 IR fixes, SAR ring-fit and STAR centres, ATMS, CIMSS ARCHER and JTWC positions), supplied by Evan, 26 Oct 2026. Unpublished.

### C. Software
- Harris, C. R., et al., 2020: Array programming with NumPy. *Nature*, 585, 357–362. https://doi.org/10.1038/s41586-020-2649-2 †
- Virtanen, P., et al., 2020: SciPy 1.0: fundamental algorithms for scientific computing in Python. *Nature Methods*, 17, 261–272. https://doi.org/10.1038/s41592-019-0686-2 †
- Hunter, J. D., 2007: Matplotlib: A 2D graphics environment. *Computing in Science & Engineering*, 9(3), 90–95. https://doi.org/10.1109/MCSE.2007.55 †
'''
txt=f"""# Typhoon Champi (29W) — central pressure from a drifting-buoy eyewall pass

Estimate of Champi's minimum sea-level pressure at **17:33 UTC, 20 October 2026**. Drifting buoy 2802285 [B7] passed through the inner part of the
south-west eyewall. It read **909.4 hPa about {med['r17']:.0f} km from the centre at 17:04Z**, near the radius of maximum wind, and 913.3 hPa at 18:04Z.

## Result (version 12)

| | Central pressure (hPa) | 68% range | 95% range |
|---|---|---|---|
{row('**Combined estimate: three profile models weighted by fit to the buoy and SAR together**',HQ,True)}
{row('Ring model: SAR eye shape + secondary ring (weight %.2f)'%w['T'],pmq('head','T'))}
{row('SAR eye shape, no secondary ring (weight %.2f)'%w['U'],pmq('head','U'))}
{row('Two-ring Holland profile (weight %.2f)'%w['A'],pmq('head','A'))}
{row('Sensitivity: no constraint on the wind ratio at 2× the max-wind radius',CS['a20_free']['q'])}
{row('Sensitivity: conversion at 2× radius flat 0.77–0.91',CS['a20_flat']['q'])}
{row('Sensitivity: conversion at 2× radius from the log-layer model, 0.769 ± 0.029',CS['a20_loglayer']['q'])}
{row('Sensitivity: buoy only (no SAR outer-structure terms)',CS['S27_buoy_only']['q'])}
{row('Check: SAR winds integrated inward from the buoy (no profile model)',sq)}
{row('Weighting: buoy leave-one-out only (v11 headline method)',AW['pbma_buoy']['q'])}
{row('Weighting: BIC with effective parameters',AW['BIC_eff']['q'])}
{row('Weighting: equal',AW['equal']['q'])}
| Previous version (v11) | 889 | 880–894 | 872–899 |
| Previous version (v10) | 884 | 876–892 | 867–899 |
| JTWC working best track, interpolated to 17:33Z (operational value; final best track not yet released) [B5] | {JT:.0f} | | |

- Half-width of the 68% range ±{Hd['half68']:.1f} hPa (sd {Hd['sd']:.1f}). {nH} headline trials ({', '.join('%s %d'%(NAME[f],n) for f,n in Hd['n'].items())}); {ntot} trials in all cases.
- **{100*Hd['p_below_jtwc']:.0f}% of the combined distribution lies below JTWC's {JT:.0f} hPa**, which sits {'inside the 68% range' if JT<HQ[3] else 'between the 68% and 95% upper limits' if JT<HQ[4] else 'above the 95% range'}.
- Monte Carlo precision (bootstrap standard error of the 2.5 / 16 / 50 / 84 / 97.5 percentiles): {' / '.join('%.2f'%x for x in bs.get('se_q',[]))} hPa.
- Uncertainty budget (1σ, hPa; single-source runs of each profile model, weighted over the three, plus the spread between the models):
{budget}

**Reading the result.** The change from v11 comes from treating the SAR wind ratios properly. One 10-m-to-gradient conversion profile now feeds
the wind ratios at 1.4× and 2× the max-wind radius and the secondary maximum, with the value at 2× the radius fitted (prior 0.80 ± 0.05). The
ring model can match those ratios and the buoy together; the no-ring and Holland profiles cannot (they miss the 1.4× and 2× ratios by 2σ or more), so a
weighting that counts the SAR measurements puts {w['T']:.2f} on the ring model. The v11 headline (889) leaned on the Holland profile through a
buoy-only score that could not see this. The answer still depends on the weighting: {AW['measAIC']['q'][2]:.0f} with the measurement-aware AIC,
{AW['BIC_eff']['q'][2]:.0f} with BIC, {AW['pbma_buoy']['q'][2]:.0f} with the buoy-only leave-one-out score. The fork in the physics is the conversion at 2× the radius:
{CS['a20_loglayer']['q'][2]:.0f} with the log-layer value, {CS['head']['q'][2]:.0f} with the 0.80 prior, {CS['a20_flat']['q'][2]:.0f} with a flat 0.77–0.91 range, {CS['a20_free']['q'][2]:.0f} with no constraint.
The 68% range is wider than v11's (±{Hd['half68']:.1f} against ±6.8 hPa). v11's narrower range came from the Holland profile, whose fixed shape
cannot follow the SAR structure; the ring model carries the buoy fit's full trade-off between the radius of maximum wind and the peak wind
(the two largest items in the budget).

## What changed in version 12

Best fits (Pc free, unperturbed inputs), one change at a time on top of the previous (`ladder12.py`):

| Step | Ring | No ring | Holland |
|---|---|---|---|
{lad}

1. **One conversion profile, α20 fitted** (v12 spec H1–H3). α(r) = α_rm inside the RMW and varies linearly in ln(r/RMW) to α20 at 2 RMW.
   α_rm = 0.885 ± 0.030 from the log-layer model (drawn per trial); α20 is a fitted parameter with prior N(0.80, 0.05). The SAR terms are surface-ratio
   residuals, (model gradient ratio × α(x)/α_rm − measured surface ratio)/σ with σ = 0.03 (0.035 at the secondary maximum) combined with the spread
   from the 21:15Z interpolation weight. In v11 the 1.4× and 2× ratios each carried their own share of the log-layer uncertainty, which counted it twice.
   Posterior α20 (16–84%): {a20q}.
2. **Secondary-ring radius at gradient level** (found by the v11 review [B9]). v11 used the surface, untilted radius ({st['R3_20_2115']['R2']:.1f} km at 21:15Z) while
   everything else was tilted to gradient level. v12 uses x2 × RMW at gradient level (x2 from the converted SAR shape).
3. **IR-to-surface drift drawn from its posterior** (spec H4, adapted). The track model already estimates the wander from the fixes; the one loosely
   bound hyperparameter is the amplitude of the slow drift of the IR-to-surface offset (fixed at 1 km in v11; only four surface fixes constrain it).
   v12 refits the track on a 0.1-km grid of that amplitude (0–15 km, `track_hier.py`) and each trial draws it from the restricted-likelihood
   posterior with a flat prior: median {qso(0.5):.2f} km (16–84% {qso(0.16):.2f}–{qso(0.84):.2f}), P(> 3 km) {post[sog>3].sum():.2f}; the mass beyond the grid is below 10⁻⁴.
   Centre sd at 17:04Z on the median track ±{TH['sd_1704'][im]:.2f} km per component (v11 ±{TH['sd_1704'][int(np.argmin(np.abs(sog-1.0)))]:.2f}).
4. **Weights that count the SAR measurements** (spec H7): AIC on the buoy readings plus the SAR terms shared by all three models plus one
   secondary-maximum term scored the same way for all, with effective parameter counts (hat-matrix trace). See "Model weighting".
5. **Paired random streams.** Each uncertain input has its own random stream (seed, source), so trial k of every case and every model shares
   every draw except the one the case changes. Every trial is written in full (`results12/draws_<case>.csv`).

## Response to the v12 specification [B9]

| Item | v12 | Note |
|---|---|---|
| H1–H3 α20 prior in the fit, one α(r) | Done | As specified; α_rm drawn from the log-layer ensemble, independent of α20. |
| H4 hierarchical wander | Adapted | Applied to the IR-to-surface drift amplitude (the v12 track model already estimates the wander itself). Posterior median {qso(0.5):.2f} km here vs their 1.55 km. Their Jeffreys prior is improper at 0 for this likelihood; S8 uses log-uniform from 0.1 km (median {qsl(0.5):.2f} km). |
| H5 paired streams | Done | Per-source streams, `rng([seed, source, 4242])`. |
| H6, H8, S29, S30 (their M1/M3 scoring) | Not applicable | The Holland model here is scored on the eye integral, which sets the pressure drop inside the closest approach; its eye shape is wrong but that costs ~1 hPa there. |
| H7 measurement-aware weights | Done | measAIC headline; measAIC_all, AIC/BIC nominal, BIC_eff, buoy and buoy+SAR leave-one-out, equal reported. |
| H9 item #12 | Done, larger than rated | Every headline ring-model trial was refitted with 10 starts: {cv.get('moved_over_1hPa','–')} of {cv.get('n','–')} move by more than 1 hPa (largest {cv.get('max_abs',0):.1f}). The headline uses the better fit of the two for every ring-model trial; ring-model percentiles (2.5/16/50/84/97.5) {', '.join('%.1f'%x for x in cv.get('q_better_of_two',[]))} vs 4 starts only {', '.join('%.1f'%x for x in cv.get('q_4starts',[]))}. The sensitivity cases use 4 starts and are compared with the 4-start headline trials. |
| H10 sample sizes | Adapted | 1000 trials per model for the headline and the three other α20 cases; 250 per model, paired, for the other cases (Evan's choice). |
| Sensitivity cases S1–S31 | Done where applicable | Flag mapping in `results12/flag_map.json`; S11, S16–S18 not applicable (see the file). S23 uses the only STAR storm centre available (Sentinel-1D 09:09Z pass summary); the STAR "MERGED_FIX" files carry scene centres, not storm centres. |
| Literature (§7) | Partly | Powell et al. 2009 [A8] reports 0.84 ± 0.09 as a slant reduction at the maximum wind (2–4 km flight level), with no eyewall/outer split: it does not support a value at 2 RMW. Franklin [A6b] is a 10-m/700-hPa climatology from other storms. The dPc/dVm literature values in [B9] were not re-derived here. |
| Pre-check shifts for T/U/A | Differ | Their pre-check moved the v12 ring model −8 hPa under the prior; with the shared profile and the ring-radius fix the ring model's best fit is {FB[('T','prior')]['Pc']:.1f} under the prior vs {FB[('T','free')]['Pc']:.1f} free ({FB[('T','prior')]['Pc']-FB[('T','free')]['Pc']:+.1f}). |

## The conversion at 2× the max-wind radius (α20)

Buoy-conservation diagnostics (best fits; Δ relative to the free case; spec §3). Conflict criterion: |Δχ²_buoy| > 1. "Rescaled" divides Δχ² by the
buoy χ²/dof of that fit. Implied α20 = α_rm × s20 / g20 (shape-flexibility test).

| Case | Model | Pc best | χ² buoy | Δχ² vs free | χ²/dof | Δχ² rescaled | conflict | 18:04Z z | ΔLOO vs free | implied α20 | Monte Carlo median (68%) |
|---|---|---|---|---|---|---|---|---|---|---|---|
{cons}

- Every model's buoy fit pays for the 2× constraint (Δχ² {', '.join('%s %+.1f'%(NAME[f],CON['prior'][f]['dchi2_buoy_vs_free']) for f in 'TUA')} under the prior): a mild conflict (1–2σ), in all
  three models. Freed of it, all three fits settle on a gradient-wind ratio at 2× the radius of 0.63–0.66, which would need α20 ≈ 0.9–1.0 - more
  than "no radial change". That value is partly an artefact of the fitted peak wind (pulled about 1.5σ above the measured value when freed) and of
  the profile shapes between 1 and 2 RMW; the profile-free check below gives 0.81–0.82 at 1.8–2.8 RMW.
- The direction of the shift differs by model: the ring model moves down under the constraint, the no-ring and Holland models barely move or move up.
- The buoy-only rows remove the SAR outer terms rather than add one, so the conflict test does not apply to them.
- Holland's best fit has several near-equal minima (about 886–888 hPa); each table shows the best found in its own run.

## Model weighting

Best fits under the headline case (`weights12.json`); χ²_meas = buoy + SAR terms (RMW, eye integral, 1.4×, peak wind, 2×) + one ring term:

| Model | Pc best | χ² buoy | χ² SAR (5 terms) | ring z | χ²_meas | p_eff | measAIC | α20 fitted |
|---|---|---|---|---|---|---|---|---|
{fits}

SAR terms (χ² each: RMW, eye integral, 1.4×, peak wind, 2×):

| Model | RMW | eye | 1.4× | peak wind | 2× |
|---|---|---|---|---|---|
{sarterms}

| Weighting (headline trials) | Ring / no ring / Holland | Combined median (68%) |
|---|---|---|
{wtab}

- The buoy-only leave-one-out score still prefers Holland, as in v11; once the SAR measurements count, the ring model leads. Leave-one-out on
  buoy + SAR measurements prefers the no-ring model: the ring model honours the SAR ratios in the fit but mispredicts several of them when each
  is held out (peak wind z {[o for o in WJ['sar_loo'] if o['fam']=='T' and o['item']=='Vg'][0]['z']:+.1f}, RMW z {[o for o in WJ['sar_loo'] if o['fam']=='T' and o['item']=='Rm'][0]['z']:+.1f}), the same pattern as in v11.

## Sensitivity cases (paired seeds; headline weights unless the case has its own)

"Shift vs headline" compares each case with the headline trials that have the same seeds (1000 for the four α20 cases, the first 250
otherwise); the ring model's mean paired shift has its standard error. Sampling noise between a 250-trial case and the full headline is
about ±0.6 hPa on the median, so read the shift columns, not the raw medians.

| Case | Combined median | 68% | 95% | shift vs headline, same seeds | ring model: mean paired shift | ring / no ring / Holland medians |
|---|---|---|---|---|---|---|
{case_row('Headline','head')}
{case_row('S1 no 2× constraint (own weights)','a20_free')}
{case_row('S2 α20 flat 0.77–0.91 (own weights)','a20_flat')}
{case_row('S3 α20 log-layer (own weights)','a20_loglayer')}
{sens}

## Derivatives (headline trials; regression slope ± standard error)

| Model | dPc/dV (hPa per kt, surface peak, with RMW held) | dPc/dRMW total (hPa/km) | dPc/dRMW with peak held | dPc/dα_rm (hPa per unit) | dPc/dα20 (fitted) | dPc/d(effective distance at 17:04Z) (hPa/km) |
|---|---|---|---|---|---|---|
{der}

- [B9] quotes −0.97 to −1.03 hPa/kt from Knaff & Zehr [A4] and Chavas et al. [A28] for the wind-pressure sensitivity without a buoy anchor
  (not re-derived here). With the buoy reading fixing the pressure near the RMW, the sensitivity to the peak wind is smaller.

## Centre position at 17:33Z (`centre12.py`, `centre_map.py`, `centre_compare.py`, `centretrials12.py`; Figure 3)

![Centre at 17:33Z](figures/fig3_centre.png)

Figure 3: shading is the ring model's best-fit central pressure with the 17:33Z centre held at each point of a 1.5-km grid (the whole centre
track shifted by a constant offset; no centre prior, no wander); white contours are the buoy + SAR misfit above its minimum (Δχ² 2.3 / 6.2 / 11.8,
68 / 95 / 99.7% for two parameters). Markers are the fitted 17:33Z centre in the Monte Carlo trials of each case (mean ± 1σ), the centre fixes at
their own times and the separately run analysis [B10]. Positions are km from the smoothed IR eye track at 17:33Z.

{cen}

Fitted 17:33Z centre in the ring-model trials (km from the smoothed IR eye track; mean ± 1σ):

| Case | Trials | East | North | Case Pc (hPa) |
|---|---|---|---|---|
{chr(10).join('| %s | %d | %+.1f ± %.1f | %+.1f ± %.1f | %.1f |'%(CTR[k]['label'],CTR[k]['n'],CTR[k]['mean'][0],CTR[k]['sd'][0],CTR[k]['mean'][1],CTR[k]['sd'][1],(Hd['q'][2] if k=='head' else CS[k]['q'][2])) for k in ('head','S7_no_wander','S5_drift_fixed3','S23_star_centre','v11chk_bt','S24_flat4km_irf'))}

## The 18:04Z reading

Residuals of the ring model held at the combined median ({med['Pc']:.1f} hPa):

| Reading | P (hPa) | obs − model | σ | z | Student-t weight |
|---|---|---|---|---|---|
{rws}

- Kept in every run. With the outer constraint the ring model's z at 18:04Z is {FB[('T','prior')]['z_1804']:+.2f} (free {FB[('T','free')]['z_1804']:+.2f}).

## How far the data can be pushed (17:04Z reading + measured SAR winds, no profile model; `bounds.py`)

17:04Z reading at {BD['r_buoy']:.1f} km effective distance (posterior-median track).

| Assumptions | Pressure drop to the centre | Central pressure at most |
|---|---|---|
{bnd}

## Buoy vs SAR pressure rise (`gapcheck.py`)

Measured rise ÷ rise predicted from the 17:33Z SAR winds in gradient balance (no profile model):

| Pair | Radii (km) | Flat factor 0.85 | Log-layer α(r) | Two-point, α20 = 0.80 |
|---|---|---|---|---|
{gap}

The two outer pairs (1.8–2.8 RMW) are matched with a constant factor of about 0.81–0.82 (±0.065 for the ±8% SAR wind level), between the
dropsonde climatology (0.78 at 700 hPa [A6b]) and no radial change (0.885). The inner pairs (1–1.8 RMW) need a lower factor (0.77; 0.67 with
18:04Z), where the centre position, the RMW and the 18:04Z reading are all uncertain.

## SAR passes (NOAA/STAR level-2, 500 m [B1]; retrieval [A26], cross-pol GMFs [A14, A27]; `sar/`)

| Pass | RMW (km) | Az.-mean max (kt) | Eye integral I47 | v(1.4 RMW)/max | Secondary max | Incidence at eyewall |
|---|---|---|---|---|---|---|
{sar}

## Files

- `model/`: scripts, inputs and results side by side (all paths relative to the script folder). v12 additions: `track_hier.py` (track models over the
  drift amplitude, `track_variants.npz`, `track_hier.json`), `mc12.py` (Monte Carlo), `weights12.py` (best fits, diagnostics, weights),
  `analyze12.py` (combination), `ladder12.py`, `scan12.py`, `cfits12.py`, `centre12.py` / `centre_map.py` / `centre_compare.py` / `centretrials12.py` (centre checks) and `fig3_centre.py` (Figure 3).
- `model/results12/`: `summary_<case>.json` (quantiles, sd, weights, per-model results, bootstrap SE), `conservation_<case>.json` (spec §3),
  `derivatives_<case>.json` (spec §7), `draws_<case>.csv` (every trial: drawn inputs, fitted parameters, χ² by component, residual, z and effective
  distance of every reading, mixture weight), `flag_map.json` (spec flag → v12 setting).
- `model/mc12.json`: every trial record. `archive/`: versions 3–11.
- The per-trial records (`model/mc12.json`, `model/results12/draws_*.csv`) ship as a second zip, `champi_buoy_pressure_v12_trials.zip`; unzip both into the
  same place. Everything else, including every summary, diagnostic and figure, is in the main zip.

## Running

`./run_all.sh` reproduces everything from the shipped inputs (Python 3 with numpy, scipy, matplotlib). The track models (`model/track_variants.npz`, 31 MB)
are not shipped: `python3 track_hier.py` in `model/` rebuilds the identical file in about 3 minutes (run_all.sh does this first); run it before
using any script on its own. The Monte Carlo ({ntot} trials) takes about
17 hours on two cores and is resumable: rerun the same command after an interruption.

## Version history

1–7. Earlier hand fits and single-profile models (see `archive/`).
8. Level-2 SAR at 09:20Z, time interpolation, Sentinel-1D cross-calibration, leave-one-out: 878 (870–887).
9–10. SAR-measured eye, secondary ring, Student-t errors, external review: 884 (876–892).
11. Track model with wander, oval eyewall, three profile models weighted by buoy-only leave-one-out: 889 (880–894).
12. One conversion profile with α20 fitted, ring-radius fix, IR-surface drift from its posterior, weights that count the SAR measurements:
    **{HQ[2]:.0f} ({HQ[1]:.0f}–{HQ[3]:.0f})**.
"""
open(os.path.join(H,'README.md'),'w').write(txt+REFS); print('README.md written, %d chars'%len(txt+REFS))
