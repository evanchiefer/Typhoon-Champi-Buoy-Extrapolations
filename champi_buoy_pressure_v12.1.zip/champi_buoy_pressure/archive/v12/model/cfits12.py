# v12 constrained fits for the figures and tables (the Monte Carlo likelihood, unperturbed inputs): ring model at the combined 68% low /
# median / 68% high central pressures, no-ring and Holland at the median, ring model with the v10 geometry and with JTWC positions at the
# median. Also the per-reading residual / effective-weight table at the median fit.
import sys, os, json, numpy as np
from multiprocessing import Pool
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import solve, summarize, make_res, sig_obs, ROBUST_NU, t, P
F=json.load(open(os.path.join(HERE,'final12.json'))); CB=json.load(open(os.path.join(HERE,'cbest.json'))); Q=F['headline']['q']
def job(a):
    name,tag,Pc,jb=a; j=dict(mc.DEF,**jb); pri,data,s=mc.build(j,None)
    best,costs,unpack=solve(j['fam'],Pc,j['track'],n_rand=10,seed=int(Pc*10)%1000,extra=[np.array(r['x']) for r in CB.get(mc.config_key(j),[])],pri=pri,sig=s)
    res,_,_,_=make_res(j['fam'],Pc,j['track'],pri=pri,sig=s); d=summarize(j['fam'],best,unpack,Pc,j['track'],res=res,pri=pri)
    d.update(name=name,tag=tag,job=jb,a20=float(unpack(best.x)['a20']),arm=float(pri['arm_val'])); return d
if __name__=='__main__':
    jobs=[('T_con_gp','lo68',Q[1],dict(fam='T')),('T_con_gp','median',Q[2],dict(fam='T')),('T_con_gp','hi68',Q[3],dict(fam='T')),
          ('U_con_gp','median',Q[2],dict(fam='U')),('A_con_gp','median',Q[2],dict(fam='A')),
          ('T_con_irf','median_v10geom',Q[2],dict(fam='T',track='irf',ell=False,sigpos=1.5)),('T_con_bt','median',Q[2],dict(fam='T',track='bt'))]
    npr=int(sys.argv[1]) if len(sys.argv)>1 else 2
    with Pool(npr) as pool: out=pool.map(job,jobs,chunksize=1)
    for d in out: print('%-12s %-15s Pc %.1f: chi2 %.2f peak %.0f kt gradient, RMW %.1f, alpha20 %.3f, 17:04Z %.1f km (eff %.1f), 18:04Z %.1f km (eff %.1f), closest %.1f km at %.2f h'%(
        d['name'],d['tag'],d['Pc'],d['chi2'],d['vg'],d['rmw'],d['a20'],d['r17'],d['re17'],d['r18'],d['re18'],d['rclose'],d['tclose']))
    json.dump(out,open(os.path.join(HERE,'fits_constrained.json'),'w'))
    m=[d for d in out if d['name']=='T_con_gp' and d['tag']=='median'][0]; mc.build(dict(mc.DEF,fam='T'),None); s=sig_obs(); r=np.array(m['resid']); z=r/s; w=(ROBUST_NU+1)/(ROBUST_NU+z**2)
    tab=[dict(t=float(t[i]),p=float(P[i]),resid=float(r[i]),sigma=float(s[i]),z=float(z[i]),weight=float(w[i])) for i in range(13,23)]
    for x in tab: print('%5.2fh  %6.1f   %+5.2f    %4.2f  %+5.2f   %.2f'%(x['t'],x['p'],x['resid'],x['sigma'],x['z'],x['weight']))
    json.dump(tab,open(os.path.join(HERE,'reading_weights.json'),'w'),indent=1)
