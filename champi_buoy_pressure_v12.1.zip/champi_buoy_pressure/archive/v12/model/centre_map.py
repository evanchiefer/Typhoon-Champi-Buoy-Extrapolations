# Centre-likelihood map at 17:33Z (Figure 3): the whole centre track shifted by a constant offset (east, north) relative to the v12
# fix-based track (posterior-median drift), no wander, ring model, headline likelihood otherwise (buoy readings, SAR terms, peak wind,
# alpha20 prior); Pc free at each offset. 1.5-km grid, E -16..+8 km, N -36..+7.5 km. Writes centre_map.json.
import sys, os, json, time, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc
from core import NBASE
from multiprocessing import Pool
EX=np.round(np.arange(-16,8.01,1.5),2); NY=np.round(np.arange(-36,7.51,1.5),2)
def fit(a):
    ox,oy=a; j=dict(mc.DEF,fam='T',wander=False); pri,data,s=mc.build(j,None); pri=dict(pri,soff=1e-3,off=np.array([ox,oy]))
    nb=NBASE['T']; st=mc.default_starts(j,pri,np.random.default_rng(3),nrand=4)
    for x in st: x[1+nb-8:1+nb-6]=pri['off']
    best,_=mc.fit_free(j,pri,data,s,st,tol=1e-8); return dict(ox=float(ox),oy=float(oy),Pc=float(best.x[0]),chi2=float(2*best.cost))
if __name__=='__main__':
    t0=time.time(); jobs=[(x,y) for y in NY for x in EX]
    with Pool(int(sys.argv[1]) if len(sys.argv)>1 else 2) as p: G=p.map(fit,jobs,chunksize=4)
    json.dump(dict(ex=EX.tolist(),ny=NY.tolist(),grid=G),open(os.path.join(HERE,'centre_map.json'),'w'))
    c=np.array([g['chi2'] for g in G]); i=int(c.argmin()); print('grid minimum at E %+.1f N %+.1f: Pc %.1f (%.0f s)'%(G[i]['ox'],G[i]['oy'],G[i]['Pc'],time.time()-t0))
