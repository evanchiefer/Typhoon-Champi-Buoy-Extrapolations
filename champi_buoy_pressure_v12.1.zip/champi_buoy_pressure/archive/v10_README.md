# Typhoon Champi (29W) — central pressure from a drifting-buoy eyewall pass

Estimate of Champi's minimum sea-level pressure at **17:33 UTC, 20 October 2026**. A drifting buoy passed through the inner part of the
south-west eyewall: it read **909.4 hPa about 25 km from the centre at 17:04Z**, just inside the radius of maximum wind (~26 km).

## Result (version 10)

| | Central pressure (hPa) | 68% range | 95% range |
|---|---|---|---|
| **Combined estimate (primary model; alternatives weighted by fit)** | **884** | 876–892 | 867–899 |
| Primary model, buoy + satellite structure only | 864 | 850–886 | 838–899 |
| Check: SAR winds integrated inward from the buoy (no profile model, no wind consensus) | 882 | 873–891 | 864–898 |
| Check: JTWC best-track positions | 884 | 874–892 | 866–900 |
| Check: smoothed IR track | 885 | 875–893 | 868–899 |
| Check: log-ramp density profile | 885 | 877–892 | 868–900 |
| Check: Gaussian reading errors (v9 error model) | 881 | 872–891 | 864–898 |
| Sensitivity: two-ring Holland profile | 890 | 883–897 | 874–902 |
| Sensitivity: no secondary wind ring | 891 | 884–897 | 877–903 |
| Sensitivity: the three profile models weighted equally | 889 | 880–896 | 871–902 |
| Previous version (v9) | 879 | 871–887 | 863–895 |
| JTWC best track (interpolated to 17:33Z) | 895 | | |

- 1σ ±8.1 hPa, from 7100 Monte Carlo trials (2000 for the primary estimate).
- About 93% of trials fall below JTWC's 895 hPa, which lies inside the 95% range near its upper edge.
- Uncertainty budget (1σ, hPa):
  - peak surface wind 4.5
  - 10-m-to-gradient conversion 3.4
  - radius of maximum wind 3.0
  - centre position 3.0
  - reading scatter 2.7
  - inner-eye wind shape 2.5
  - secondary wind maximum 2.3
  - eyewall wind decay 0.9
  - profile-shape choice 0.8
  - barometer calibration 0.5
  - density 0.3
  - environmental pressure 0.1
- Model weights: primary 0.986, two-ring Holland 0.004, no ring 0.010. The alternatives cannot represent the moat and secondary maximum and fit
  Δχ² ≈ 9–11 worse.
- Buoy-implied wind–pressure relation (buoy + structure only; 1-min equivalent = 0.885 × gradient wind + 8 kt):
  160 kt ↔ 883 hPa · 151 kt ↔ 893 hPa · 895 hPa ↔ 149 kt · 884 hPa ↔ 159 kt.
- Final constrained fit at the median: peak gradient wind 169 kt (150 kt surface azimuthal mean), RMW 25.6 km, 17:04Z reading 25.0 km from the centre.

## What changed in version 10

1. **Robust reading errors.** The likelihood is now Student-t (ν = 4) instead of Gaussian. A reading that disagrees with a symmetric eyewall is
   down-weighted, not deleted. This mainly affects the 18:04Z reading (913.3 hPa at ~29 km), which pulled the Gaussian fit toward stronger winds
   than the satellites measured. The Gaussian check gives 881.
2. **Radius of maximum wind at gradient level.** Boundary-layer inflow places the surface wind maximum inside the gradient-level maximum.
   The surface SAR value (26.2 km at 17:33Z, interpolated) is tilted outward ~5%, giving 27.5 ± 1.6 km. The data still pull the fitted radius to
   ~25.6 km, so this change is worth about +1 hPa.
3. **Figures** show fits made with the peak-wind constraint and robust errors, the same likelihood as the Monte Carlo. Panel 2b marks the final fit.
4. **Monte Carlo** saves each trial as it finishes and resumes after an interruption.

**Decided against**, after testing:
- Power-law eye exponent 1.43: it reproduces the summary value but gives a 4% smaller eye pressure drop than the SAR measures; 1.37 does not.
- Centring the SAR wind level between RCM-3 and Sentinel-1D: the buoy pressure gradients and the wind consensus both sit at the RCM-3 level or above.

## Leave-one-out (`analysis/loo.py`; primary model, robust errors, peak-wind constraint)

| Case | Pc (hPa) | Fitted peak, 1-min equivalent |
|---|---|---|
| All readings | 883 | 158 kt |
| Without 18:04Z | 889 | 154 kt (misfit Δχ² −7.2) |
| Without 17:04Z | 887 | 155 kt |
| Without any other single reading | 882–884 | 158–160 kt |
| 17:04Z/18:04Z raised by 2 / 4 hPa (barometer low bias) | 884 / 885 | 158 / 157 kt |

## How far the data can be pushed (17:04Z reading + measured SAR winds, no profile model)

| Assumptions, increasingly adverse | Drop inside the buoy | Central pressure at most |
|---|---|---|
| 21:15Z structure, log-layer conversion | 25.9 hPa | 883.5 |
| 09:20Z structure (wider, weaker eyewall) | 15.5 | 893.9 |
| …and surface winds treated as gradient winds (friction ignored) | 12.1 | 897.3 |
| …and centre 2 km closer to the buoy | 8.9 | 900.5 |
| …and the Sentinel-1D wind level, eyewall tilted outward | 5.2 | 904.2 |

Reaching JTWC's 895 hPa requires several of these adverse choices at once. The data argue against each one:
- the 21:15Z pass shows a tighter, stronger eyewall than at 09:20Z;
- 10-m winds are always weaker than gradient winds;
- the Sentinel-1D level sits ~18% below JTWC's own intensity and below what the buoy's pressure gradients require.

## Buoy vs SAR pressure rise (`analysis/gapcheck.py`; gradient-level RMW 27.5 km)

Measured rise divided by the rise predicted from the 17:33Z SAR winds:

| Pair | Radii (km) | Flat factor 0.85 | Log-layer α(r) |
|---|---|---|---|
| 16:04 → 15:00 | 45 → 74 | 1.00 | 0.82 |
| 19:04 → 20:04 | 47 → 69 | 1.02 | 0.84 |
| 17:04 → 15:00 | 26 → 74 | 1.16 | 1.06 |
| 17:04 → 16:04 | 26 → 45 | 1.26 | 1.24 |
| 18:04 → 20:04 | 31 → 69 | 1.48 | 1.30 |
| 18:04 → 19:04 | 31 → 47 | 1.83 | 1.69 |

- Beyond 45 km the log-layer conversion overshoots by 16–18%. It is too aggressive beyond about twice the RMW (to recalibrate in v11).
- Inside 45 km the buoy wants stronger winds than the SAR shows, most strongly for pairs involving the 18:04Z reading.

## SAR passes (NOAA/STAR level-2, 500 m)

| Pass | RMW (km) | Az.-mean surface max (kt) | I | v(1.4 RMW)/max | Secondary max | Centre vs IR fix (km) |
|---|---|---|---|---|---|---|
| Sentinel-1D 20 Oct 09:09Z (not yet in the priors) | 28.25 | 112 | 0.364 | 0.78 | 43.8 km, 0.83 | +7.4 E, −8.4 N |
| RCM-3 20 Oct 09:20Z | 27.75 | 135 | 0.337 | 0.74 | 45.8 km, 0.81 | +7.7 E, −8.1 N |
| RCM-3 20 Oct 21:15Z | 25.75 | 146 | 0.376 | 0.72 | 43.3 km, 0.77 | +6.8 E, −9.3 N |
| Sentinel-1D 20 Oct 21:20Z | swath misses the eyewall | — | — | — | — | — |
| RCM-3 21 Oct 09:29Z | 27.25 | 134 | 0.391 | 0.83 | none | — |
| RCM-3 21 Oct 21:23Z | 29.75 | 99 | 0.489 | 0.90 | none | — |

**Cross-sensor calibration.** Sentinel-1D vs RCM-3 at the same storm-relative positions:

| Region | Ratio |
|---|---|
| Eye | 0.99 |
| Eyewall (22–30 km, 09Z) | 0.835 |
| Moat and secondary maximum | 0.86–0.91 |
| Outer, 09Z | 0.89 ± 0.03 |
| Outer, 21:20Z | 0.877 ± 0.022 |

Version 10 uses ±6% SAR calibration. The 09Z eyewall comparison (`data/sar/crosscal_0909.json`) supports ±8%, which is queued for v11.

## Queued for version 11

- Sentinel-1D 09:09Z as a second 09Z structure measurement.
- Four surface fixes for the centre offset.
- SAR calibration ±8%.
- Recalibrate the log-layer conversion beyond 2 × RMW against the buoy's outer readings.
- Lower the 830 hPa search floor.
- Add a bound panel to Figure 2.
- Corrections from the external code audit of v9.

## Contents, running, method

Unchanged from v9 except as listed above.

Directories:
- `data/`: inputs, IR fixes, `sar/` per-pass products and cross-calibration
- `analysis/`: `core.py`, `logwind.py`, `scan.py`, `mc.py`, `mc4.py`, `analyze.py`, `sarcheck.py`, `gapcheck.py`, `loo.py`, `cfits.py`, figures
- `preprocessing/`: level-2 SAR scripts and earlier image-based steps
- `results/`
- `figures/`
- `archive/`: v6–v9 packages

To reproduce the numbers and figures from saved results (~1 min):

`python3 analysis/analyze.py && python3 analysis/cfits.py && python3 analysis/fig1.py && python3 analysis/fig2.py`

Full rerun: `./run_all.sh`. The Monte Carlo takes ~1 h 50 min on 2 cores and resumes if interrupted.

## Version history

1. Single Holland fit, IR centre only: unconstrained (~850–905).
2. Two-ring Holland plus SAR/ARCHER/MW constraints: 887 (875–901).
3. Multistart search plus JTWC-track check: 885 (872–896).
4. Tide background and two model families: 877 (864–890); superseded.
5. Synthetic smear correction, three-feature model: 889 (875–900).
6. Radially varying air density, ρ = p/(R_d·T_v), proposed by Evan: 892 (879–902).
7. RCM-3 21:15Z level-2 SAR: 880 (872–889).
8. Level-2 SAR at 09:20Z, time interpolation, Sentinel-1D cross-calibration, leave-one-out: 878 (870–887).
9. Log-layer 10-m to gradient conversion α(r), proposed by Evan; 6600-trial Monte Carlo: 879 (871–887).
10. **Current:** robust (Student-t) reading errors; gradient-level RMW 27.5 ± 1.6 km; figures show constrained fits; 7100 trials: **884 (876–892)**.
