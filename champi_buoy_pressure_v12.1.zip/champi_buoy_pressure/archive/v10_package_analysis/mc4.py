# Monte Carlo job list (7100 trials). Each finished trial is appended to mc10.jsonl immediately, and a restart skips trials already done,
# so a run interrupted by a time limit resumes where it stopped. When all trials are present, mc10.json is written.
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, time
HERE=RES
import mc
from multiprocessing import Pool
def jobs_all():
    S=mc.SRC; jobs=[]
    for src in S:
        for i in range(100): jobs.append(('C','irf',(src,),2_000_000+10_000*S.index(src)+i,True))     # one source at a time (budget)
    for i in range(2000): jobs.append(('C','irf',S,3_000_000+i,True))                                 # all sources, with peak-wind constraint
    SO=tuple(x for x in S if x!='intensity')
    for i in range(1000): jobs.append(('C','irf',SO,4_000_000+i,False))                               # buoy + satellite structure only
    for i in range(500): jobs.append(('C','bt',S,5_000_000+i,True))                                   # JTWC best-track positions
    for i in range(500): jobs.append(('C','ir',S,6_000_000+i,True))                                   # smoothed IR track
    for fam in ('A','B'):
        for i in range(500): jobs.append((fam,'irf',S,7_000_000+i+100_000*(fam=='B'),True))
    for i in range(500): jobs.append(('C','irf',S,8_000_000+i,True,'ramp'))                          # log-ramp density
    for i in range(500): jobs.append(('C','irf',S,9_000_000+i,True,'thermo',0.0))                    # Gaussian reading errors (previous error model)
    return jobs
def key(j): return (j[0],j[1],tuple(j[2]),int(j[3]))
if __name__=='__main__':
    JL=os.path.join(HERE,'mc10.jsonl'); jobs=jobs_all(); done=set()
    if os.path.exists(JL):
        for line in open(JL):
            try: d=json.loads(line); done.add((d['fam'],d['track'],tuple(d['sources']),d['seed']))
            except Exception: pass
    todo=[j for j in jobs if key(j) not in done]; print('%d done, %d to run'%(len(done),len(todo)),flush=True)
    t0=time.time()
    with Pool(2) as pool, open(JL,'a') as fo:
        for k,d in enumerate(pool.imap_unordered(mc.trial,todo,chunksize=2)):
            fo.write(json.dumps(d)+'\n'); fo.flush()
            if k%500==0: print('%d/%d %.0f s'%(k,len(todo),time.time()-t0),flush=True)
    res=[json.loads(l) for l in open(JL)]
    if len({(d['fam'],d['track'],tuple(d['sources']),d['seed']) for d in res})>=len(jobs):
        json.dump(res,open(os.path.join(HERE,'mc10.json'),'w')); print('ALL DONE %.0f s (%d trials)'%(time.time()-t0,len(res)))
