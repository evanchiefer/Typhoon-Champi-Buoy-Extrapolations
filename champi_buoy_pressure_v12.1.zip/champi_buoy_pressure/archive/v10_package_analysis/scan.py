# Profile likelihood over central pressure: multistart least squares at each Pc, plus continuation sweeps (up and down the grid).
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, json, time, numpy as np
from multiprocessing import Pool

from core import *
CFG={'C_irf':dict(family='C',track='irf'),'C_ir':dict(family='C',track='ir'),'C_bt':dict(family='C',track='bt'),
     'A_irf':dict(family='A',track='irf'),'B_irf':dict(family='B',track='irf')}
GRID=np.arange(840,910.1,2.0)
def job(a):
    name,Pc=a; c=dict(CFG[name]); fam=c.pop('family'); tr=c.pop('track')
    best,costs,unpack=solve(fam,Pc,tr,n_rand=32,seed=int(Pc)*7+len(name),**c)
    d=summarize(fam,best,unpack,Pc,tr); d.update(name=name,n_starts=int(len(costs)),n_at_best=int((costs<best.cost+0.05).sum())); return d
def sweep(name,rows):
    c=dict(CFG[name]); fam=c.pop('family'); tr=c.pop('track'); byP={r['Pc']:r for r in rows}
    for order in (GRID,GRID[::-1]):
        prev=None
        for Pc in order:
            if prev is not None:
                res,unpack,lb,ub=make_res(fam,Pc,tr,**c)
                s=least_squares(res,np.clip(prev,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
                if 2*s.cost<byP[Pc]['chi2']-1e-6:
                    d=summarize(fam,s,unpack,Pc,tr); d.update(name=name,n_starts=byP[Pc]['n_starts'],n_at_best=0,improved_by_sweep=True); byP[Pc]=d
            prev=np.array(byP[Pc]['x'])
    return [byP[p] for p in GRID]
if __name__=='__main__':
    names=sys.argv[1].split(','); out=sys.argv[2]; t0=time.time()
    jobs=[(n,float(p)) for n in names for p in GRID]
    with Pool(2) as pool: rows=pool.map(job,jobs,chunksize=2)
    print('multistart done %.0f s'%(time.time()-t0),flush=True)
    final=[]
    for n in names:
        final+=sweep(n,[r for r in rows if r['name']==n]); print(n,'sweep done %.0f s'%(time.time()-t0),flush=True)
    json.dump(final,open(out,'w')); print('ALL DONE %.0f s'%(time.time()-t0))
