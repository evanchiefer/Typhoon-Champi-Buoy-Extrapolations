# Radius-dependent 10-m to gradient-level wind factor alpha(r) = V10 / Vgradient from a log-layer boundary-layer model:
#   alpha(r) = [ln(10/z0) / ln(z_s/z0)] * beta(r),  z_s = 0.1 h(r) (surface-layer top; the mixed layer above it is near-uniform)
#   h(r): boundary-layer depth, shallow at the eyewall (h_ew) and deepening outward to h_out over Lh (in RMW units)
#   beta(r): boundary-layer wind / gradient wind; supergradient at the eyewall (b_ew) relaxing to sub-gradient outside (b_out) over Lb
#   Inside the RMW alpha is held at its RMW value. z0 from drag saturation at extreme winds (Cd(10 m) ~ 0.002-0.003 -> z0 ~ 1-4 mm).
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import os, json, numpy as np
HERE=RES
DEF=dict(z0=0.002,h_ew=500.0,h_out=1100.0,Lh=1.2,b_ew=1.05,b_out=0.94,Lb=0.6)
def draw(rng):
    return dict(z0=10**rng.uniform(np.log10(0.001),np.log10(0.004)),h_ew=rng.uniform(350,650),h_out=rng.uniform(800,1500),
                Lh=rng.uniform(0.5,2.0),b_ew=rng.uniform(1.00,1.10),b_out=rng.uniform(0.88,1.00),Lb=rng.uniform(0.3,1.0))
def alpha_x(x,p):
    """alpha at normalized radius x = r/RMW"""
    d=np.maximum(np.asarray(x,float)-1.0,0.0)
    h=p['h_out']-(p['h_out']-p['h_ew'])*np.exp(-d/p['Lh']); zs=0.1*h
    beta=p['b_out']+(p['b_ew']-p['b_out'])*np.exp(-d/p['Lb'])
    return np.log(10.0/p['z0'])/np.log(zs/p['z0'])*beta
# SAR surface shape at 17:33Z: RCM-3 level-2 09:20Z and 21:15Z azimuthal means in normalized coordinates, interpolated in time
SD=os.path.join(DATA,'sar')
def _norm(key):
    d=np.load(os.path.join(SD,key+'_prof.npz')); s=json.load(open(os.path.join(SD,key+'_struct.json'))); return d['rc']/s['Rm'], d['v']*1.94384/s['Vm_kt']
XG=np.linspace(0.005,4.0,1600)
_x1,_s1=_norm('R3_20_0920'); _x2,_s2=_norm('R3_20_2115'); S1=np.interp(XG,_x1,_s1); S2=np.interp(XG,_x2,_s2)
W2115=0.689
def sfc_shape(w=W2115): return (1-w)*S1+w*S2
def grad_metrics(p,w=W2115):
    """gradient-level shape ratios implied by the SAR surface shape and alpha(r): v14, v20, v30, secondary maximum (radius in RMW, strength)"""
    s=sfc_shape(w); g=s/alpha_x(XG,p)*alpha_x(1.0,p); g1=np.interp(1.0,XG,g)
    v=lambda x: float(np.interp(x,XG,g)/g1)
    m=(XG>1.45)&(XG<2.2); j=np.argmax(np.where(m,g,-1))
    return dict(v14=v(1.4),v20=v(2.0),v30=v(3.0),vsec=float(g[j]/g1),x2=float(XG[j]),alpha_rm=float(alpha_x(1.0,p)),alpha_14=float(alpha_x(1.4,p)),alpha_20=float(alpha_x(2.0,p)),alpha_30=float(alpha_x(3.0,p)))
if __name__=='__main__':
    rng=np.random.default_rng(7); M=[]
    for k in range(20000):
        p=draw(rng); w=np.clip(rng.normal(W2115,0.10),0,1); M.append(grad_metrics(p,w))
    keys=M[0].keys(); A={k:np.array([m[k] for m in M]) for k in keys}
    s0=sfc_shape(); g=lambda x: float(np.interp(x,XG,s0)/np.interp(1.0,XG,s0))
    print('surface (SAR) ratios at 17:33Z: v14 %.3f v20 %.3f v30 %.3f'%(g(1.4),g(2.0),g(3.0)))
    for k in keys: print('%-9s mean %.3f sd %.3f  (5-95%%: %.3f-%.3f)'%(k,A[k].mean(),A[k].std(),*np.percentile(A[k],[5,95])))
    print('default params:',grad_metrics(DEF))
    json.dump({k:[float(A[k].mean()),float(A[k].std())] for k in keys},open(os.path.join(HERE,'logwind_priors.json'),'w'),indent=1)
