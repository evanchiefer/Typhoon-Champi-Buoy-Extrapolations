# Build data/inputs.json from the spreadsheet (buoy record, 6-hourly JTWC best-track positions, JTWC pressures).
import sys, os, json, openpyxl
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); DATA=os.path.join(ROOT,'data')
wb=openpyxl.load_workbook(os.path.join(DATA,'champi_revised.xlsx'),data_only=True)
rows=[r for r in wb.worksheets[0].iter_rows(min_row=2,values_only=True) if r[0] is not None]
h=lambda t:(t.day-20)*24+t.hour+t.minute/60            # hours after 00Z 20 Oct 2026
buoy=[[h(r[0]),float(r[4]),float(r[5]),float(r[6])] for r in rows]
bt=[[h(r[0]),float(r[1]),float(r[2]),float(r[3])] for r in rows if r[1] is not None]
jt=[[h(r[0]),float(r[7])] for r in rows if r[7] is not None]
out=os.path.join(DATA,'inputs.json') if len(sys.argv)<2 else sys.argv[1]
json.dump(dict(buoy=buoy,bt=bt,jtwc_p=jt),open(out,'w')); print('wrote',out,len(buoy),'buoy rows,',len(bt),'track points')
