# How much of the buoy-vs-SAR gap does the log-layer conversion close?  For each pair of near-core buoy readings, compare the measured pressure
# rise with the rise predicted by the 17:33Z SAR wind profile in gradient balance: (a) flat surface factor 0.85, (b) log-layer alpha(r).
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, numpy as np
HERE=RES
from core import P,TRACKS,dist,FCOR,RD
import logwind as LW
sh=LW.sfc_shape(); Vm=143.0*0.514444; Rm=27.5   # gradient-level RMW (surface 26.2 km tilted outward)
r=dist('irf',*TRACKS['irf'][2])
def rise(r1,r2,alpha_fn):
    rr=np.linspace(min(r1,r2),max(r1,r2),400); x=rr/Rm; v=np.interp(x,LW.XG,sh)*Vm/alpha_fn(x); rho=930*100/(RD*305.0)
    return np.trapezoid(rho*(v**2/(rr*1e3)+FCOR*v),rr*1e3)/100
pairs=[('17:04 -> 16:04',17,16),('18:04 -> 19:04',18,19),('17:04 -> 15:00',17,15),('18:04 -> 20:04',18,20),('16:04 -> 15:00',16,15),('19:04 -> 20:04',19,20)]
print('pair              radii (km)    buoy rise   SAR flat 0.85   ratio    SAR log alpha(r)   ratio')
out=[]
for lab,i,j in pairs:
    m=P[j]-P[i]; a=rise(r[i],r[j],lambda x:0.85+0*x); b=rise(r[i],r[j],lambda x:LW.alpha_x(x,LW.DEF))
    out.append((lab,float(r[i]),float(r[j]),float(m),float(a),float(b)))
    print('%-16s %5.1f-%5.1f     %5.1f        %5.1f        %.2f        %5.1f           %.2f'%(lab,r[i],r[j],m,a,m/a,b,m/b))
# equivalent wind-speed factor: measured/predicted rise ~ (V_true/V_SAR)^2
fa=np.array([o[3]/o[4] for o in out]); fb=np.array([o[3]/o[5] for o in out])
print('implied wind factor (sqrt of rise ratio): flat %.2f-%.2f (mean %.2f) | log %.2f-%.2f (mean %.2f)'%(np.sqrt(fa.min()),np.sqrt(fa.max()),np.sqrt(fa).mean(),np.sqrt(fb.min()),np.sqrt(fb.max()),np.sqrt(fb).mean()))
json.dump(out,open(os.path.join(HERE,'gapcheck.json'),'w'),indent=1)
