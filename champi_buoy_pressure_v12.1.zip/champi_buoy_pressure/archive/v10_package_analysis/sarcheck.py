# Independent check: central pressure from the buoy's eyewall readings plus the SAR wind profile integrated inward in gradient balance.
# No storm-profile model and no wind consensus are used.  The 17:33Z profile is interpolated in time between the RCM-3 level-2 passes
# at 09:20Z and 21:15Z (in normalized radius r/RMW and normalized speed v/Vmax), then rescaled to the 17:33Z RMW and peak wind.
#   Pc = P_buoy(r_b) - int_0^{r_b} rho(r) [Vg(r)^2/r + f Vg(r)] dr ,  Vg = V_SAR / alpha(r)  (log-layer conversion, logwind.py)
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, numpy as np
HERE=RES
from core import t,lat,lon,P,TRACKS,dist,FCOR,RD
import logwind as LW
SD=os.path.join(DATA,'sar')
def norm(key):
    d=np.load(os.path.join(SD,key+'_prof.npz')); s=json.load(open(os.path.join(SD,key+'_struct.json')))
    return d['rc']/s['Rm'], d['v']*1.94384/s['Vm_kt'], d['v2']*1.94384**2/s['Vm_kt']**2
x1,s1,q1=norm('R3_20_0920'); x2,s2,q2=norm('R3_20_2115')
xg=np.linspace(0.005,3.0,1200); S1=np.interp(xg,x1,s1); S2=np.interp(xg,x2,s2); Q1=np.interp(xg,x1,q1); Q2=np.interp(xg,x2,q2)
KTMS=0.514444; rng=np.random.default_rng(11); N=20000; out={17:[],18:[]}
for k in range(N):
    w=np.clip(rng.normal(0.689,0.10),0,1)        # time weight of the 21:15Z shape (linear in time), +- interpolation uncertainty
    sh=(1-w)*S1+w*S2; q=(1-w)*Q1+w*Q2
    pbl=LW.draw(rng)                              # boundary-layer parameters for the 10-m -> gradient-level conversion alpha(r)
    Vm=143.5*rng.normal(1,0.06)+rng.normal(0,3.0) # RCM-3 azimuthal-mean surface max at 17:33Z (kt): SAR calibration +-6%, time +-3 kt
    Rm17=rng.normal(27.5,1.6); off=TRACKS['irf'][2]+rng.normal(0,2.0,2)
    dTc=rng.uniform(0.5,4.5); bias=rng.normal(0,0.5); re_kt=rng.choice([47,55])
    xe=xg[np.argmax(sh*Vm>=re_kt)]
    r=dist('irf',*off)
    for idx in (17,18):
        rb=r[idx]+rng.normal(0,1.5)               # eyewall non-circularity
        xx=np.linspace(xe,rb/Rm17,500); rr=xx*Rm17
        al=LW.alpha_x(xx,pbl); vg=np.interp(xx,xg,sh)*Vm*KTMS/al; vq=np.interp(xx,xg,q)*(Vm*KTMS/al)**2
        ve=np.interp(xe,xg,sh)*Vm*KTMS/LW.alpha_x(xe,pbl)
        p=np.full_like(rr,P[idx]+bias)
        for it in range(2):
            Tv=305.0+dTc*np.exp(-(rr/(0.8*Rm17))**2); rho=p*100/(RD*Tv)
            dp=(rho*(vq/(rr*1e3)+FCOR*vg))*1e3
            cum=np.concatenate([[0],np.cumsum((dp[1:]+dp[:-1])/2*np.diff(rr))])
            p=(P[idx]+bias)-(cum[-1]-cum)/100
        out[idx].append(P[idx]+bias-cum[-1]/100-rho[0]*ve**2/2/100)
res={}
for key in (17,18):
    a=np.array(out[key]); qq=np.percentile(a,[2.5,16,50,84,97.5]); res[key]=qq.tolist()
    print('from the %02d:04 reading (P=%.1f): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(key,P[key],qq[2],qq[1],qq[3],qq[0],qq[4]))
both=np.concatenate([out[17],out[18]]); qq=np.percentile(both,[2.5,16,50,84,97.5]); res['both']=qq.tolist()
print('pooled: median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(qq[2],qq[1],qq[3],qq[0],qq[4]))
json.dump(res,open(os.path.join(HERE,'sarcheck.json'),'w'))
