# Figure 1: observations and storm structure
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os; 
from common import *
import logwind as LW
HERE=RES
F=json.load(open(os.path.join(HERE,'final.json')))               # medians and ranges written by the analysis step
PCm,PClo,PChi=F['median'],F['lo68'],F['hi68']
SCN=os.path.join(HERE,'scan_main.json')
CF=os.path.join(HERE,'fits_constrained.json')   # constrained fits (peak-wind constraint, robust errors), as in the Monte Carlo
RA=rows_of(CF,'A_con'); RB=rows_of(CF,'C_con'); RB2=rows_of(CF,'B_con'); RBb=rows_of(SCN,'C_bt'); RBs=rows_of(SCN,'C_ir')
bm=nearest(RB,PCm); am=nearest(RA,PCm)
SP={k:np.load(os.path.join(DATA,'sar',k+'_prof.npz')) for k in ('R3_20_0920','R3_20_2115','R3_21_0929')}; C2=json.load(open(os.path.join(DATA,'sar','R3_20_2115_struct.json')))
fig,ax=plt.subplots(2,3,figsize=(21,13)); (A1,A2,A3),(B1,B2,B3)=ax
tt=np.linspace(0,37,3000); la_i=np.interp(tt,t,lat); lo_i=np.interp(tt,t,lon)
# (a) full record
D,bg,_=model_eval('C',bm,'irf',tt,la_i,lo_i)
A1.plot(tt,bg,color=GRN,lw=1.6,ls='--',label='background: environment + tide + trend')
A1.plot(tt,bg-D,color=BLU,lw=2.2,label='fitted model (wind profile with secondary ring, centre ≈%.0f hPa)'%PCm)
A1.plot(t,P,'o',ms=6.5,color=INK,mec=SURF,mew=1.2,label='drifting-buoy pressure (hourly)',zorder=5)
A1.set_xlim(0,37); A1.set_ylim(870,1015); A1.set_xticks(range(0,38,6)); A1.set_xticklabels(['00Z\n20 Oct','06Z','12Z','18Z','00Z\n21 Oct','06Z','12Z'])
A1.set_ylabel('sea-level pressure (hPa)'); A1.set_title('a   Full buoy record and fit',loc='left',fontweight='bold')
A1.legend(loc='lower left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (b) zoom on pass
tz=np.linspace(13,22,2000); la_z=np.interp(tz,t,lat); lo_z=np.interp(tz,t,lon)
for Pc,c,lab in ((PClo,LBL,'68% low'),(PCm,BLU,'median'),(PChi,DBL,'68% high')):
    r_=nearest(RB,Pc); D,bg,_=model_eval('C',r_,'irf',tz,la_z,lo_z); A2.plot(tz,bg-D,color=c,lw=2.2,label='centre ≈%.0f hPa (%s)'%(Pc,lab))
m=(t>=13)&(t<=22); A2.plot(t[m],P[m],'o',ms=8,color=INK,mec=SURF,mew=1.4,label='buoy',zorder=5)
A2.annotate('909.4 hPa, 17:04Z',(17.07,909.4),(14.2,925),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
r_=nearest(RB,PCm); D,bg,_=model_eval('C',r_,'irf',tz,la_z,lo_z); j=np.argmin(bg-D)
A2.annotate('likely buoy low ~%.0f hPa\nat %02d:%02dZ (between readings)'%((bg-D)[j],int(tz[j]),round(tz[j]%1*60)),(tz[j],(bg-D)[j]),(18.9,903),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
A2.set_xlim(13,22); A2.set_ylim(885,990); A2.set_xlabel('20 October, UTC hour'); A2.set_ylabel('sea-level pressure (hPa)')
A2.set_title('b   The eyewall pass',loc='left',fontweight='bold'); A2.legend(loc='upper center',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
# (c) map
fa,fo=TRACKS['irf'][:2]; th2=np.linspace(11,23,500); k=111*np.cos(np.radians(17.4)); sx,sy=bm['off']
fx=json.load(open(os.path.join(DATA,'ir_eye_fixes.json'))); hh=np.array(sorted(int(q) for q in fx))
A3.plot(fo(th2),fa(th2),color=GRY,lw=1.2)
A3.plot([fx[str(h)]['lon'] for h in hh],[fx[str(h)]['lat'] for h in hh],'o',ms=6,color=SURF,mec=INK2,mew=1.3,label='IR eye track (hourly fixes)')
A3.plot(fo(th2)+sx/k,fa(th2)+sy/111,color=INK,lw=2.2,ls='--',label='surface centre (IR eye fixes + fitted offset)')
A3.plot(np.polyval(BTLON,th2),np.polyval(BTLAT,th2),color=ORA,lw=1.4,ls='-.',label='JTWC best-track positions (smoothed)')
bt=np.array(INP['bt']); mm=(bt[:,0]>=11)&(bt[:,0]<=23); A3.plot(bt[mm,2],bt[mm,1],'*',ms=15,color=ORA,mec=SURF)
A3.plot(131.719,17.335,'^',ms=11,color=GRN,mec=SURF,label='ATMS 165/183 GHz eye, 17:01Z')
A3.plot(C2['clon'],C2['clat'],'s',ms=10,color=BLU,mec=SURF,label='RCM-3 SAR surface centre, 21:15Z')
tc=TC; cla=fa(tc)+sy/111; clo=fo(tc)+sx/k; th_=np.linspace(0,2*np.pi,200)
A3.plot(clo+bm['rmw']*np.sin(th_)/k,cla+bm['rmw']*np.cos(th_)/111,color=BLU,lw=1.6,ls=':')
A3.plot(clo+14*np.sin(th_)/k,cla+14*np.cos(th_)/111,color=INK2,lw=1.0)
A3.plot(clo,cla,'+',ms=14,mew=2.2,color=INK)
A3.text(132.22,17.88,'at 17:33Z:\nmax-wind radius %.0f km (dotted)\ncalm eye ~14 km (solid)'%bm['rmw'],fontsize=10.5,color=INK2,va='top',ha='right')
A3.plot(lon,lat,'-',color=INK,lw=1.3,label='buoy drift'); A3.plot(lon[17],lat[17],'v',ms=12,color=RED,mec=SURF,label='buoy at 17:04Z (909.4 hPa)')
A3.set_xlim(130.72,132.25); A3.set_ylim(16.95,17.9); A3.set_aspect(1/np.cos(np.radians(17.4)))
A3.set_xlabel('longitude (°E)'); A3.set_ylabel('latitude (°N)'); A3.set_title('c   Centre positions and the buoy pass',loc='left',fontweight='bold')
A3.legend(loc='upper center',bbox_to_anchor=(0.5,-0.14),ncol=2,fontsize=9.6,frameon=False)
# (d) distance vs time
_,_,r=model_eval('C',bm,'irf',tz,la_z,lo_z); _,_,rbt=model_eval('C',nearest(RBb,PCm),'bt',tz,la_z,lo_z); _,_,rsm=model_eval('C',nearest(RBs,PCm),'ir',tz,la_z,lo_z)
B1.axhspan(0,14,color=GRID,lw=0); B1.text(13.2,7,'calm eye (SAR 21:15Z: winds < 47 kt)',fontsize=10.5,color=INK2,va='center')
B1.axhspan(bm['rmw']-1.2,bm['rmw']+1.2,color=LBL,alpha=0.45,lw=0); B1.text(19.75,bm['rmw']-1,'max-wind radius\n%.0f ± 1.2 km'%bm['rmw'],fontsize=10.5,color=INK2,va='center')
B1.plot(tz,r,color=INK,lw=2.4,label='IR eye fixes + SAR/ATMS surface offset'); B1.plot(tz,rbt,color=ORA,lw=1.8,ls='--',label='JTWC best-track positions')
B1.plot(tz,rsm,color=GRY,lw=1.6,ls=':',label='smoothed IR track (previous analysis)')
_,_,rp=model_eval('C',bm,'irf',t[m],lat[m],lon[m]); B1.plot(t[m],rp,'o',ms=6.5,color=INK,mec=SURF)
j=np.argmin(r); B1.annotate('closest approach %.0f km at %02d:%02dZ'%(r[j],int(tz[j]),round(tz[j]%1*60)),(tz[j],r[j]),(13.3,60),fontsize=11,arrowprops=dict(arrowstyle='-',color=INK2))
B1.set_xlim(13,22); B1.set_ylim(0,130); B1.set_xlabel('20 October, UTC hour'); B1.set_ylabel('buoy distance from centre (km)')
B1.set_title('d   Where the buoy was relative to the eyewall',loc='left',fontweight='bold'); B1.legend(loc='upper right',frameon=False)
# (e) radial pressure profile (storm part only: buoy minus fitted background)
rr=np.linspace(0.3,250,2000)
B2.axvspan(0,r.min(),color=GRID,lw=0)
for Pc,c in ((PClo,LBL),(PCm,BLU),(PChi,DBL)):
    r_=nearest(RB,Pc); rise,_,_,_=radial('C',r_,'irf',rr); B2.plot(rr,r_['Pc']+rise,color=c,lw=2.2); B2.text(1.0,r_['Pc']+1.2,'%.0f'%Pc,color=c if c!=LBL else '#3d7fc4',fontsize=11,fontweight='bold')
ra_=nearest(RA,PCm); rise,_,_,_=radial('A',ra_,'irf',rr); B2.plot(rr,ra_['Pc']+rise,color=ORA,lw=1.4,ls='--',label='alternative: two-ring Holland (same centre pressure)')
rb_=nearest(RB2,PCm); rise,_,_,_=radial('B',rb_,'irf',rr); B2.plot(rr,rb_['Pc']+rise,color=GRN,lw=1.4,ls=':',label='alternative: no secondary ring (same centre pressure)')
D,bg,rb=model_eval('C',bm,'irf',t,lat,lon); Pst=P-(bg-background(bm['bg'],np.array([TC]),np.array([LST_C]))[0])   # remove tide/trend relative to 17:33Z
bf=t<TC; B2.plot(rb[bf],Pst[bf],'o',ms=7,color=INK,mec=SURF,label='buoy, storm approaching'); B2.plot(rb[~bf],Pst[~bf],'s',ms=7,color=SURF,mec=INK,mew=1.4,label='buoy, storm departing')
B2.text(1.5,1004,'never sampled\n(inside %.0f km)'%r.min(),fontsize=10.5,color=INK2,va='top')
B2.set_xlim(0,250); B2.set_ylim(858,1010); B2.set_xlabel('distance from centre (km)'); B2.set_ylabel('pressure, tide and trend removed (hPa)')
B2.set_title('e   Radial pressure profile at 17:33Z',loc='left',fontweight='bold'); B2.legend(loc='lower right',frameon=False)
# (f) wind structure
B3.plot(SP['R3_21_0929']['rc'],SP['R3_21_0929']['v']*1.94384,color=GRY,lw=1.3,label='SAR surface wind 21 Oct 09:29Z (after replacement)')
B3.plot(SP['R3_20_0920']['rc'],SP['R3_20_0920']['v']*1.94384,color=GRN,lw=1.8,label='SAR surface wind 20 Oct 09:20Z')
B3.plot(SP['R3_20_2115']['rc'],SP['R3_20_2115']['v']*1.94384,color=INK,lw=2.2,label='SAR surface wind 20 Oct 21:15Z')
_,V,_,_=radial('C',bm,'irf',rr); B3.plot(rr,V,color=BLU,lw=2.6,label='fitted wind above the boundary layer, 17:33Z')
B3.plot(rr,V*LW.alpha_x(rr/bm['rmw'],LW.DEF),color=BLU,lw=1.4,ls=':',label='same × log-layer factor α(r) (10-m equivalent)')
B3.axvspan(0,14,color=GRID,lw=0); B3.axvline(r.min(),color=RED,lw=1.4,ls='--'); B3.text(r.min()+1,8,'buoy closest\napproach',fontsize=10.5)
B3.set_xlim(0,100); B3.set_ylim(0,265); B3.set_xlabel('distance from centre (km)'); B3.set_ylabel('wind speed (kt)')
B3.set_title('f   Wind structure: SAR azimuthal means, fit 17:33Z',loc='left',fontweight='bold'); B3.legend(loc='upper right',fontsize=9.6,frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95)
fig.suptitle('Typhoon Champi (29W), 20 October 2026 — drifting-buoy eyewall pass: observations and storm structure',x=0.01,y=0.995,ha='left',fontsize=17,fontweight='bold')
fig.text(0.01,0.968,'Buoy pressures fitted with a storm wind profile in gradient balance (radially varying air density) plus atmospheric background (tides, trend). SAR 10-m winds converted\nto gradient level with a log-layer factor α(r) (0.885 at the RMW, ~0.77 at 2 RMW). Centre: hourly Himawari-9 IR eye fixes, offset to the surface by RCM-3 SAR (09:20Z, 21:15Z) and ATMS (17:01Z).',fontsize=12,color=INK2,va='top')
fig.tight_layout(rect=(0,0,1,0.935)); fig.savefig(os.path.join(FIGS,'fig1_observations.png'),dpi=170)
print('saved')
