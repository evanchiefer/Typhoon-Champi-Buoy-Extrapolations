# Figure 2: central pressure and its uncertainty
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os; 
from common import *
from summ import curve, like, q, G
HERE=RES
F=json.load(open(os.path.join(HERE,'final.json'))); MC=json.load(open(os.path.join(HERE,'mc10.json')))
main=json.load(open(os.path.join(HERE,'scan_main.json')))
fig=plt.figure(figsize=(23,15)); gs=fig.add_gridspec(2,3,width_ratios=[1,1,1.05],height_ratios=[1,1.12],hspace=0.34,wspace=0.42,top=0.84)
A1=fig.add_subplot(gs[0,0]); A2=fig.add_subplot(gs[0,1]); A3=fig.add_subplot(gs[0,2]); gb=gs[1,:].subgridspec(1,3,width_ratios=[1,0.58,1.75],wspace=0.0); B1=fig.add_subplot(gb[0,0]); B2=fig.add_subplot(gb[0,2])
JT=F['jtwc_1733']; R=F['runs']
NM={'C':'Wind-profile model with secondary ring (gradient balance)','A':'Pressure-profile model (two-ring Holland)','B':'Wind-profile model, no secondary ring'}
# (a) profile likelihood
for nm,c,ls,lw,lab in (('C_irf',DBL,'-',2.8,'primary: wind profile + secondary ring'),('C_bt',DBL,'--',1.6,'  same, JTWC best-track positions'),('C_ir',GRY,':',1.8,'  same, smoothed IR track (previous)'),
                       ('A_irf',ORA,'-',1.4,'alternative: two-ring Holland'),('B_irf',GRN,'-',1.4,'alternative: no secondary ring')):
    p,cc,_=curve(main,nm); A1.plot(p,cc-cc.min(),color=c,ls=ls,lw=lw,label=lab)
for lv,tx in ((1,'68%'),(3.84,'95%')): A1.axhline(lv,color=INK2,lw=0.9,ls=':'); A1.text(841,lv+0.15,tx,fontsize=10.5,color=INK2)
A1.axvline(JT,color=RED,lw=1.4,ls='--'); A1.text(JT+0.8,0.15,'JTWC\n%.0f hPa'%JT,fontsize=10.5,color=RED,va='bottom',ha='left')
A1.set_xlim(840,910); A1.set_ylim(0,10); A1.set_xlabel('central pressure at 17:33Z (hPa)'); A1.set_ylabel('misfit above best fit (Δχ²)')
A1.set_title('a   Fit quality vs central pressure\n     (buoy + satellite structure, no intensity input)',loc='left',fontweight='bold')
A1.legend(loc='upper center',bbox_to_anchor=(0.42,1.0),frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95,fontsize=9.6)
# (b) wind-pressure relation implied by the buoy
for nm,c,lab in (('C_irf',DBL,'primary model'),('A_irf',ORA,'alternative: two-ring Holland'),('B_irf',GRN,'alternative: no secondary ring')):
    _,_,d=curve(main,nm); pc=np.array([r['Pc'] for r in d]); vg=np.array([r['vg'] for r in d])
    vg=np.array([np.median(vg[max(0,i-2):i+3]) for i in range(len(vg))])
    if nm=='C_irf': A2.fill_betweenx(pc,0.837*vg+8,0.934*vg+8,color=c,alpha=0.12,lw=0)
    A2.plot(0.885*vg+8,pc,color=c,lw=2.8 if nm=='C_irf' else 1.4,label=lab)
CON=[r for r in json.load(open(os.path.join(HERE,'fits_constrained.json'))) if r['name']=='C_con' and r['tag']=='median'][0]
A2.plot(0.885*CON['vg']+8,CON['Pc'],'o',ms=12,color=BLU,mec=INK,mew=1.2,zorder=7,label='final fit (with peak-wind constraint)')
A2.axvspan(144,158,color=GRY,alpha=0.12,lw=0,label='peak-wind constraint 151 ± 7 kt')
pts=[('JTWC best track 18Z',160,895,RED,'*',16),('JTWC best track 12Z',155,902,RED,'*',12),('D-MINT ATMS 17:02Z',147,906,INK2,'D',8),('D-MINT ATMS 16:41Z',150,907,INK2,'D',8)]
for lab,v,p_,c,mk,ms in pts: A2.plot(v,p_,mk,ms=ms,color=c,mec=INK,mew=0.8,label=lab,zorder=6)
for lab,v in (('AiDT 17:30Z',145),('ADT 17:30Z',137),('SAR 17:33Z',151.5)): A2.axvline(v,color=INK2 if 'SAR' not in lab else INK,lw=1,ls=':' if 'SAR' not in lab else '--'); A2.text(v-0.6,875,lab,rotation=90,fontsize=9.5,color=INK2,ha='right',va='top')
A2.set_xlim(120,200); A2.set_ylim(912,840); A2.set_xlabel('equivalent peak 1-min surface wind (kt)'); A2.set_ylabel('central pressure (hPa)')
A2.set_title('b   Wind–pressure relation implied by the buoy\n     (band: log-layer surface factor 0.84–0.93)',loc='left',fontweight='bold')
A2.legend(loc='upper left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95,fontsize=9.0)
# (c) Monte Carlo
pick=lambda fam,tr,vg,dm='thermo',nu=4.0: np.array([d['Pc'] for d in MC if d['fam']==fam and len(d['sources'])>1 and d['track']==tr and d['use_vg']==vg and d.get('dens','thermo')==dm and d.get('nu',4.0)==nu])
wi=pick('C','irf',True); so=pick('C','irf',False); bt=pick('C','bt',True); sm=pick('C','ir',True); ramp=pick('C','irf',True,'ramp'); altA=pick('A','irf',True); altB=pick('B','irf',True); GAU=pick('C','irf',True,'thermo',0.0)
bins=np.arange(830,914,2)
A3.hist(wi,bins=bins,density=True,color=LBL,edgecolor=SURF,lw=0.8,label='primary model: structure + peak wind (%d trials)'%len(wi))
A3.hist(so,bins=bins,density=True,histtype='step',color=GRY,lw=2,label='buoy + satellite structure only (%d; %d at the 830 hPa search limit)'%(len(so),int((so<830.5).sum())))
A3.hist(bt,bins=bins,density=True,histtype='step',color=ORA,lw=2,label='check: JTWC best-track positions (%d)'%len(bt))
pq=[F['lo95'],F['lo68'],F['median'],F['hi68'],F['hi95']]; ymax=A3.get_ylim()[1]
A3.axvspan(pq[1],pq[3],color=BLU,alpha=0.10,lw=0); A3.axvline(pq[2],color=DBL,lw=2.4)
A3.text(pq[2],ymax*1.03,'combined median %.0f hPa\n68%%: %.0f–%.0f   95%%: %.0f–%.0f\n(three profile models, weighted by fit)'%(pq[2],pq[1],pq[3],pq[0],pq[4]),ha='center',va='bottom',fontsize=12,fontweight='bold',color=DBL,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=2))
A3.axvline(JT,color=RED,lw=1.6,ls='--'); A3.text(JT+1.0,ymax*0.97,'JTWC %.0f hPa'%JT,fontsize=10.5,color=RED,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=1.5))
A3.set_xlim(830,914); A3.set_ylim(0,ymax*1.75); A3.set_xlabel('central pressure at 17:33Z (hPa)'); A3.set_ylabel('probability density (per hPa)')
A3.set_title('c   Monte Carlo over all uncertain inputs',loc='left',fontweight='bold'); A3.legend(loc='upper left',frameon=False,fontsize=9.5)
# (d) budget
lab={'shape':'inner-eye wind shape','decay':'wind decay outside eyewall (SAR)','ring':'secondary wind maximum (SAR)','alpha':'10-m to gradient conversion (log layer)','Rm':'radius of max wind (±1.6 km)','center':'centre position (±2 km)',
     'noise':'reading scatter','bias':'barometer calibration','Pn':'environmental pressure','intensity':'peak surface wind (±7 kt, incl. SAR calibration)','family':'profile-shape choice (3 models)','density':'air density profile (warm eye, cool eyewall)'}
Bd=F['budget']; items=sorted(Bd.items(),key=lambda kv:kv[1]); y=np.arange(len(items))
B1.barh(y,[v for _,v in items],color=[ORA if k=='family' else BLU for k,_ in items],height=0.62)
for yy,(k,v) in zip(y,items): B1.text(v+0.12,yy,'%.1f'%v,va='center',fontsize=11)
B1.set_yticks(y); B1.set_yticklabels([lab[k] for k,_ in items]); B1.grid(axis='y',visible=False)
B1.axvline(F['total_sd'],color=DBL,lw=1.6,ls='--'); B1.text(F['total_sd']+0.12,-0.6,'combined ±%.1f hPa (1σ)'%F['total_sd'],fontsize=11,color=DBL)
B1.set_xlim(0,max(max(v for _,v in items),F['total_sd'])*1.3); B1.set_xlabel('contribution to uncertainty (hPa, 1σ)'); B1.set_title('d   Uncertainty budget',loc='left',fontweight='bold')
# (e) comparison
sq=R['sar_check']['q']
est=[('This work: combined estimate',F['median'],F['lo68'],F['hi68'],F['lo95'],F['hi95'],BLU),
     ('This work: primary model alone',*np.percentile(wi,[50,16,84,2.5,97.5]),BLU),
     ('This work: structure only*',*np.percentile(so,[50,16,84,2.5,97.5]),GRY),
     ('Check: SAR winds integrated inward\n   from the buoy (no profile model)',sq[2],sq[1],sq[3],sq[0],sq[4],GRN),
     ('Check: JTWC best-track positions',*np.percentile(bt,[50,16,84,2.5,97.5]),ORA),
     ('Check: smoothed IR track (previous analysis)',*np.percentile(sm,[50,16,84,2.5,97.5]),GRY),
     ('Check: log-ramp density profile',*np.percentile(ramp,[50,16,84,2.5,97.5]),GRN),
     ('Sensitivity: two-ring Holland profile',*np.percentile(altA,[50,16,84,2.5,97.5]),GRY),
     ('Sensitivity: no secondary ring',*np.percentile(altB,[50,16,84,2.5,97.5]),GRY),
     ('Check: Gaussian errors (v9 error model)',*np.percentile(GAU,[50,16,84,2.5,97.5]),GRY),
     ('Previous version (v9)',878.7,870.9,887.0,863.4,894.5,GRY),
     ('JTWC best track (interp. 17:33Z)',JT,None,None,None,None,RED),('D-PRINT (16:30–17:30Z)',903,902,904,None,None,INK2),
     ('ATMS (SATCON plot, ~17Z)',903,None,None,None,None,INK2),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,None,None,INK2),('SATCON (~17Z)',910,None,None,None,None,INK2)]
n=len(est); NOURS=11
for i,(nm,v,l1,h1,l2,h2,col) in enumerate(est):
    yy=n-1-i; ours=i<NOURS
    if l2 is not None: B2.plot([l2,h2],[yy,yy],color=col,lw=3,alpha=0.4,solid_capstyle='round')
    if l1 is not None: B2.plot([l1,h1],[yy,yy],color=col,lw=9 if ours else 4,alpha=0.45,solid_capstyle='round')
    B2.plot(v,yy,'o',ms=11 if ours else 8,color=col,mec=SURF,mew=1.5)
    txt=('%.0f  (68%%: %.0f–%.0f, 95%%: %.0f–%.0f)'%(v,l1,h1,l2,h2)) if ours else ('%.0f'%v if l1 is None else '%g–%g'%(l1,h1))
    B2.text(v if ours else v+1.0,yy+0.3,txt,fontsize=11,ha='center' if ours else 'left')
bm_=nearest(rows_of(os.path.join(HERE,'scan_main.json'),'C_irf'),F['median'])
B2.axvline(909.4,color=RED,lw=1.3,ls=':'); B2.text(910.0,n-1.3,'buoy reading\n909.4 hPa,\n~%.0f km from\ncentre'%bm_['rmin'],fontsize=10.5,va='top')
B2.set_yticks(range(n)); B2.set_yticklabels([e[0] for e in est][::-1],fontsize=11.2); B2.set_xlim(830,925); B2.set_ylim(-0.7,n-0.2); B2.grid(axis='y',visible=False)
B2.text(830.5,-0.62,'* lower tail truncated at the 830 hPa search limit',fontsize=10,color=INK2); B2.set_xlabel('central pressure near 17Z, 20 Oct (hPa)'); B2.set_title('e   Comparison with operational and satellite estimates   (thick bar 68%, thin bar 95%)',loc='left',fontweight='bold')
fig.suptitle('Typhoon Champi (29W) — central pressure at 17:33Z, 20 October 2026, from the drifting-buoy eyewall pass',x=0.01,y=1.0,ha='left',fontsize=17,fontweight='bold')
fig.text(0.01,0.958,'Primary model: wind profile with eye, eyewall decay and secondary wind ring, in gradient balance; two alternative profile shapes as sensitivity tests.\nRobust (Student-t) reading errors; multistart least squares (48 starts per value plus continuation); Monte Carlo over all uncertain inputs. Air density varies with radius, ρ = p/(R_d·T_v).\nEye shape, eyewall radius, secondary maximum and surface-centre offset from RCM-3 SAR 500-m winds (09:20Z, 21:15Z, interpolated to 17:33Z); 10-m winds converted to gradient level\nwith a log-layer factor α(r); SAR wind calibration ±6% (Sentinel-1D vs RCM-3).\nModels combined by fit quality. JTWC and satellite pressures used for comparison only.',fontsize=12,color=INK2,va='top')
fig.savefig(os.path.join(FIGS,'fig2_central_pressure.png'),dpi=165,bbox_inches='tight'); print('saved')
