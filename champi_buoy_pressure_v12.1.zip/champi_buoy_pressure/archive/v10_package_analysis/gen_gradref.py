# Reference pressure gradient at each buoy reading (sets the position term of the observation error), from a primary-model fit
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, json, numpy as np

from core import *
pri=dict(PRI); pri['Vg']=VG_PRIOR
best,costs,unpack=solve('C',884.0,'irf',n_rand=24,seed=5,pri=pri)
Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm=unpack(best.x)
r=dist('irf',sx,sy); e=0.25
g1,h1=gh(r+e); g0,h0=gh(np.maximum(r-e,0.01)); dPdr=-((g1*Vm**2+h1*Vm)-(g0*Vm**2+h0*Vm))/100/(2*e)
json.dump(dict(dPdr=[float(v) for v in dPdr],r=[float(v) for v in r],source='C_irf fit at 884 hPa'),open(os.path.join(DATA,'grad_ref.json'),'w'))
for i in range(14,22): print('%5.2fh r=%5.1f dP/dr=%.2f hPa/km'%(t[i],r[i],dPdr[i]))
