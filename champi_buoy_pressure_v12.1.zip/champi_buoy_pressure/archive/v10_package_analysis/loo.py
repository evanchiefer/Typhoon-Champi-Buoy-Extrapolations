# Leave-one-out diagnostic: refit the primary model (with the peak-wind constraint, central pressure free) with each near-core
# buoy reading removed in turn, and with the 17:04Z/18:04Z eyewall readings raised by a possible wind-induced barometer low bias.
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, numpy as np
from multiprocessing import Pool
HERE=RES
from core import *
SC=json.load(open(os.path.join(HERE,'scan_main.json'))); b=min([r for r in SC if r['name']=='C_irf'],key=lambda r:r['chi2'])
def fit(args):
    label,drop,shift=args
    pri=dict(PRI); pri['Vg']=VG_PRIOR; s=sig_obs().copy(); data=P.copy()
    for i in drop: s[i]=1e4
    for i,dv in shift: data[i]=data[i]+dv
    _,_,lb,ub=make_res('C',880.0,'irf',pri=pri); lb=np.r_[830.0,lb]; ub=np.r_[912.0,ub]
    def res(q): return make_res('C',q[0],'irf',pri=pri,data=data,sig=s)[0](q[1:])
    best=None
    for pc0 in (860.,875.,890.,900.):
        for k,x0 in enumerate([np.array(b['x'])]+starts('C','irf',3,int(pc0),lb[1:],ub[1:])[:6:2]):
            try: r=least_squares(res,np.clip(np.r_[pc0,x0],lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=5000)
            except Exception: continue
            if best is None or r.cost<best.cost: best=r
    _,unpack,_,_=make_res('C',best.x[0],'irf',pri=pri,data=data,sig=s); d=summarize('C',type('B',(),{'x':best.x[1:],'cost':best.cost})(),unpack,best.x[0],'irf')
    return label,float(best.x[0]),d['vg'],d['rmin'],2*best.cost
if __name__=='__main__':
    names={15:'15:00',16:'16:04',17:'17:04',18:'18:04',19:'19:04',20:'20:04'}
    jobs=[('all readings',(),())]+[('without %s'%names[i],(i,),()) for i in names]
    jobs+=[('17:04 and 18:04 raised 2 hPa (barometer low bias)',(),((17,2.0),(18,2.0))),('17:04 and 18:04 raised 4 hPa',(),((17,4.0),(18,4.0)))]
    with Pool(2) as pool: out=pool.map(fit,jobs)
    for lab,pc,vg,rmin,c2 in out: print('%-52s Pc %.1f  gradient Vmax %.0f kt (1-min equiv. %.0f)  chi2 %.1f'%(lab,pc,vg,ALPHA_RM[0]*vg+8,c2))
    json.dump(out,open(os.path.join(HERE,'loo.json'),'w'),indent=1)
