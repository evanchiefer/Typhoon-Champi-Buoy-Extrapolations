# Monte Carlo: each trial redraws the uncertain inputs and refits with the central pressure free.
# Sources: reading noise, barometer bias, centre offset, RMW, eye shape, eyewall decay (SAR measurement), secondary maximum (SAR measurement),
# surface-to-gradient conversion (log-layer alpha(r): one draw sets v(1.4Rm), v(2Rm), secondary maximum and the peak-wind constraint together),
# environmental pressure, peak surface wind, density profile.
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, time, numpy as np
from multiprocessing import Pool
HERE=RES
from core import *
import logwind as LW
SCAN=json.load(open(os.path.join(HERE,'scan_main.json')))
def best_of(name):
    rows=[r for r in SCAN if r['name']==name]; return min(rows,key=lambda r:r['chi2'])
BEST={k:best_of(k) for k in ('A_irf','B_irf','C_irf','C_ir','C_bt')}
SRC=('noise','bias','center','Rm','shape','decay','ring','alpha','Pn','intensity','density')
GM0=LW.grad_metrics(LW.DEF)                      # gradient-level ratios at the default boundary-layer parameters
def trial(args):
    fam,track,sources,seed,use_vg=args[:5]; dmode=args[5] if len(args)>5 else 'thermo'; nu=args[6] if len(args)>6 else ROBUST_NU; rng=np.random.default_rng(seed)
    pri=dict(PRI)
    off0,soff=TRACKS[track][2].copy(),TRACKS[track][3]; data=P.copy(); s=sig_obs()
    if 'noise' in sources: data=data+rng.normal(0,s)
    if 'bias' in sources: data=data+rng.normal(0,0.5)                 # drifter barometer accuracy (~+-1 hPa at 2 sigma)
    if 'center' in sources: off0=off0+rng.normal(0,soff,2)
    if 'Rm' in sources: pri['Rm']=(rng.normal(*PRI['Rm']),PRI['Rm'][1])
    if 'shape' in sources:
        z=rng.normal(); pri['n']=(PRI['n'][0]+z*PRI['n'][1],PRI['n'][1]); pri['I']=(PRI['I'][0]-z*PRI['I'][1],PRI['I'][1])   # same draw: high n == low I
    # centres of the outer-structure priors and of the peak-wind constraint: one boundary-layer draw sets them coherently
    c=dict(v14=PRI['v14'][0],v20=PRI['v20'][0],vsec=PRI['vsec'][0],R2=PRI['R2'][0]); arm=ALPHA_RM[0]
    if 'alpha' in sources:
        gm=LW.grad_metrics(LW.draw(rng),np.clip(rng.normal(LW.W2115,0.10),0,1))
        for k in ('v14','v20','vsec'): c[k]+=gm[k]-GM0[k]
        c['R2']=PRI['R2'][0]*gm['x2']/GM0['x2']; arm=gm['alpha_rm']
    if 'decay' in sources: c['v14']+=rng.normal(0,SIG_MEAS['v14']); c['v20']+=rng.normal(0,SIG_MEAS['v20'])
    if 'ring' in sources: c['vsec']+=rng.normal(0,SIG_MEAS['vsec']); c['R2']+=rng.normal(0,SIG_MEAS['R2'])
    for k in c: pri[k]=(c[k],PRI[k][1])
    if use_vg:
        vs=VSFC[0]+(rng.normal(0,VSFC[1]) if 'intensity' in sources else 0.0)
        pri['Vg']=(vs/arm,VG_PRIOR[1])
    if 'Pn' in sources: pri['Pn']=(rng.normal(*PRI['Pn']),PRI['Pn'][1])
    pri['dens']=dict(DENS,mode=dmode)
    if 'density' in sources:      # warm-eye anomaly, rain-cooled eyewall, environmental Tv, anomaly width; ramp shape for the ramp check
        pri['dens'].update(dTc=rng.uniform(0.5,4.5),dTw=rng.uniform(0.0,2.5),Tv_env=rng.normal(305.0,1.5),rwf=rng.uniform(0.5,1.2),
                           r0f=rng.uniform(0.5,1.5),Rout=rng.uniform(200,600))
    pri['off']=off0
    b=BEST['%s_%s'%(fam,track)]; x0=np.r_[b['Pc'],b['x']]
    def res(q): return make_res(fam,q[0],track,pri=pri,data=data,sig=s,nu=nu)[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track,pri=pri); lb=np.r_[830.0,lb]; ub=np.r_[912.0,ub]
    st=[x0]+[np.r_[pc,b['x']] for pc in (b['Pc']-12,b['Pc']+12)]
    for q in starts(fam,track,4,seed%100000,lb[1:],ub[1:])[::5][:3]: st.append(np.r_[b['Pc']+rng.normal(0,8),q])
    best=None
    for q0 in st:
        try: r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=6000)
        except Exception: continue
        if best is None or r.cost<best.cost: best=r
    return dict(fam=fam,track=track,sources=list(sources),seed=int(seed),use_vg=bool(use_vg),dens=dmode,nu=float(nu),Pc=float(best.x[0]),chi2=float(2*best.cost))
