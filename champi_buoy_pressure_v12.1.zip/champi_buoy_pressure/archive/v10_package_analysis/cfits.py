# Constrained fits for the figures: primary model at the combined 68% low / median / 68% high central pressures, and the two alternative
# profiles at the median, all with the peak-wind constraint and robust reading errors (the same likelihood as the Monte Carlo).
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, os, json, numpy as np
from multiprocessing import Pool
HERE=RES
from core import *
F=json.load(open(os.path.join(HERE,'final.json')))
def job(a):
    fam,Pc,tag=a; pri=dict(PRI); pri['Vg']=VG_PRIOR
    best,costs,unpack=solve(fam,Pc,'irf',n_rand=24,seed=int(Pc*10)%1000,pri=pri)
    d=summarize(fam,best,unpack,Pc,'irf'); d.update(name=fam+'_con',tag=tag); return d
if __name__=='__main__':
    jobs=[('C',F['lo68'],'lo68'),('C',F['median'],'median'),('C',F['hi68'],'hi68'),('A',F['median'],'median'),('B',F['median'],'median')]
    with Pool(2) as pool: out=pool.map(job,jobs)
    for d in out: print('%s %s Pc %.1f: peak %.0f kt gradient, RMW %.1f, closest reading %.1f km'%(d['name'],d['tag'],d['Pc'],d['vg'],d['rmw'],d['rmin']))
    json.dump(out,open(os.path.join(HERE,'fits_constrained.json'),'w'))
