# Sensitivity: surface-to-gradient wind factor varying with radius (about 0.88 at the eyewall, 0.83 at 1.4 x RMW), which raises the
# gradient-level wind ratio v(1.4Rm)/Vm from the surface value 0.78 to about 0.83. Primary model, all uncertainty sources.
import sys, os, json, time
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); RES=os.path.join(ROOT,'results')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import mc
from multiprocessing import Pool
mc.PRI['v14']=(0.83,0.06)
def run(args):
    d=mc.trial(args); d['tag']='v14_gradient'; return d
if __name__=='__main__':
    jobs=[('C','irf',mc.SRC,970_000+i,True) for i in range(150)]
    t0=time.time()
    with Pool(2) as pool: res=pool.map(run,jobs,chunksize=2)
    json.dump(res,open(os.path.join(RES,'mc6_alpha.json'),'w')); print('ALL DONE %.0f s'%(time.time()-t0))
