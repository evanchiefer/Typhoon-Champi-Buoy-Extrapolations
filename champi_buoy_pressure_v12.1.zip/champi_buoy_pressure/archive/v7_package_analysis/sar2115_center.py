# Surface centre of Champi in the RCM-3 21:15Z level-2 SAR winds (500 m grid)
import numpy as np, json
from scipy.ndimage import gaussian_filter
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=os.path.join(ROOT,'data','sar_2115z')+os.sep
d=np.load(D+'sar2115_l2.npz'); W=d['W'].copy(); lon=d['lon']; lat=d['lat']
W[W<=0]=np.nan
Wf=np.where(np.isfinite(W),W,0); M=np.isfinite(W).astype(float)
Ws=gaussian_filter(Wf,3)/np.maximum(gaussian_filter(M,3),1e-6)   # ~1.5 km smoothing
lon0,lat0=130.818,17.707
KX=111.32*np.cos(np.radians(lat0)); KY=110.57
X=(lon-lon0)*KX; Y=(lat-lat0)*KY
def rmw_points(cx,cy,nsec=72,rmin=12,rmax=38,dr=0.5):
    r=np.hypot(X-cx,Y-cy); th=np.arctan2(Y-cy,X-cx)
    sel=(r<rmax+2)
    rs=r[sel]; ts=th[sel]; ws=Ws[sel]
    sec=((ts+np.pi)/(2*np.pi)*nsec).astype(int)%nsec
    rb=np.arange(rmin,rmax+dr,dr); pts=[];vm=[]
    for k in range(nsec):
        mk=sec==k
        idx=np.digitize(rs[mk],rb)-1
        prof=np.array([np.nanmean(ws[mk][idx==j]) if np.any(idx==j) else np.nan for j in range(len(rb)-1)])
        if np.all(~np.isfinite(prof)): continue
        j=np.nanargmax(prof); rr=0.5*(rb[j]+rb[j+1]); a=(k+0.5)/nsec*2*np.pi-np.pi
        pts.append((cx+rr*np.cos(a),cy+rr*np.sin(a),rr)); vm.append(prof[j])
    return np.array(pts),np.array(vm)
def fit_circle(p):
    A=np.c_[2*p[:,0],2*p[:,1],np.ones(len(p))]; b=p[:,0]**2+p[:,1]**2
    s,*_=np.linalg.lstsq(A,b,rcond=None); cx,cy=s[0],s[1]; R=np.sqrt(s[2]+cx**2+cy**2); return cx,cy,R
cx,cy=0.0,0.0
for it in range(8):
    p,vm=rmw_points(cx,cy)
    # robust: drop points >2.5 MAD from circle
    ncx,ncy,R=fit_circle(p)
    res=np.hypot(p[:,0]-ncx,p[:,1]-ncy)-R; mad=np.median(np.abs(res-np.median(res)))*1.4826
    keep=np.abs(res)<2.5*max(mad,0.5)
    ncx,ncy,R=fit_circle(p[keep])
    print(f'iter {it}: centre ({ncx:+.2f},{ncy:+.2f}) km  R={R:.2f} km  ring scatter={np.std(res[keep]):.2f} km  kept {keep.sum()}/{len(p)}')
    if np.hypot(ncx-cx,ncy-cy)<0.05: cx,cy=ncx,ncy; break
    cx,cy=ncx,ncy
# ellipse fit to the RMW ring (algebraic)
p,vm=rmw_points(cx,cy); xx=p[:,0]-cx; yy=p[:,1]-cy
A=np.c_[xx**2,xx*yy,yy**2,xx,yy]; s,*_=np.linalg.lstsq(A,np.ones(len(xx)),rcond=None)
a,b,c=s[0],s[1],s[2]; ev=np.linalg.eigvalsh(np.array([[a,b/2],[b/2,c]])); ax=1/np.sqrt(ev)
print('RMW-ring ellipse semi-axes ~',ax, 'axis ratio',ax.max()/ax.min())
# eye centroid method: area with Ws below threshold inside 22 km
r=np.hypot(X-cx,Y-cy)
for thr in [30,35,40]:
    m=(Ws<thr)&(r<22)
    print(f'eye centroid (Ws<{thr} m/s): ({X[m].mean():+.2f},{Y[m].mean():+.2f}) km, area-equiv radius {np.sqrt(m.sum()*0.25/np.pi):.1f} km')
# minimum of heavily smoothed field
Wss=gaussian_filter(Wf,8)/np.maximum(gaussian_filter(M,8),1e-6); m=r<15; i=np.argmin(np.where(m,Wss,1e9)); print('smoothed min at',X.flat[i],Y.flat[i])
clon=lon0+cx/KX; clat=lat0+cy/KY
print(f'SAR surface centre (RMW-ring circle fit): {clon:.4f}E {clat:.4f}N ; offset from STAR fix ({cx:+.2f} E, {cy:+.2f} N) km')
json.dump(dict(lon=clon,lat=clat,dx_from_star_km=cx,dy_from_star_km=cy,ring_R_km=R,ellipse_axes_km=list(ax),time='2026-10-20T21:15:26Z'),open(D+'center2115.json','w'),indent=1)
