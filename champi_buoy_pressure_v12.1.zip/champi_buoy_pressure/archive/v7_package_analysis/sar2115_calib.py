# Buoy-vs-SAR calibration with the 21:15Z level-2 winds, using the new centre track (hourly IR fixes + surface offset)
import numpy as np, json
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); B=ROOT+os.sep
INP=json.load(open(B+'data/inputs.json')); b=np.array(INP['buoy']); t,la,lo,P=b.T[:4]
fx=json.load(open(B+'data/ir_eye_fixes.json')); th=np.array(sorted(int(k) for k in fx))
fla=np.array([fx[str(h)]['lat'] for h in th]); flo=np.array([fx[str(h)]['lon'] for h in th])
def ctr(tq,off=(6.53,-10.03)):
    cla=np.interp(tq,th,fla); clo=np.interp(tq,th,flo); kx=111.0*np.cos(np.radians(cla)); return clo+off[0]/kx, cla+off[1]/111.0
def radius(i,off=(6.53,-10.03)):
    clo,cla=ctr(t[i],off); kx=111.0*np.cos(np.radians((la[i]+cla)/2)); return np.hypot((lo[i]-clo)*kx,(la[i]-cla)*111.0)
idx={'14:00':14,'15:00':15,'16:04':16,'17:04':17,'18:04':18,'19:04':19,'20:04':20,'21:04':21,'22:04':22}
for k,i in idx.items(): print(f'{k}: r={radius(i):5.1f} km P={P[i]:.1f}')
pr=np.load(B+'data/sar_2115z/prof2115.npz'); rc=pr['rc']; v=pr['vmean']; v2=pr['v2mean']   # m/s and (m/s)^2
f=2*7.292e-5*np.sin(np.radians(17.6)); RD=287.05
def rise(r1,r2,alpha,Tv=305.0,pb=930.0):
    rr=np.linspace(min(r1,r2),max(r1,r2),400); vv=np.interp(rr,rc,v)/alpha; vq=np.interp(rr,rc,v2)/alpha**2
    rho=pb*100/(RD*Tv); return np.trapezoid(rho*(vq/(rr*1e3)+f*vv),rr*1e3)/100
pairs=[('in, approach','17:04','16:04'),('in, depart','18:04','19:04'),('wide, approach','17:04','15:00'),('wide, depart','18:04','20:04')]
print('\npair             r1    r2   buoy rise  SAR rise(a=1)  implied alpha (=Vsfc/Vgrad)')
al=[]
for lab,a,bb in pairs:
    i1,i2=idx[a],idx[bb]; r1,r2=radius(i1),radius(i2); meas=P[i2]-P[i1]; s1=rise(r1,r2,1.0,pb=0.5*(P[i1]+P[i2]))
    # solve alpha: rise ~ c2/alpha^2 + c1/alpha
    from scipy.optimize import brentq
    a_=brentq(lambda A: rise(r1,r2,A,pb=0.5*(P[i1]+P[i2]))-meas,0.3,2.0); al.append(a_)
    print(f'{lab:15s} {r1:5.1f} {r2:5.1f}   {meas:6.1f}      {s1:6.1f}        {a_:.3f}')
print('mean implied alpha %.3f (sd %.3f)'%(np.mean(al),np.std(al)))
# SAR eye integral from the 21:15 profile (solid-body core inside the 47-kt radius), scaled by each alpha
KT=0.514444
vk=pr['vmean']*1.94384; i=int(np.argmax(vk[:60])); Rm=rc[i]; je=int(np.argmax(vk>=47))
def eye_drop(rb,alpha,pc=890.0,Tv=307.0):
    rr=np.linspace(rc[je],rb,400); vv=np.interp(rr,rc,v)/alpha; vq=np.interp(rr,rc,v2)/alpha**2; rho=pc*100/(RD*Tv)
    core=rho*(v[je]/alpha)**2/2
    return (core+np.trapezoid(rho*(vq/(rr*1e3)+f*vv),rr*1e3))/100
print('\nSAR Rm %.1f km; eye drop centre->r for alpha in implied range:'%Rm)
for rb in (24,26,28,30):
    print('  r=%d km: '%rb+'  '.join('a=%.2f: %.1f hPa'%(A,eye_drop(rb,A)) for A in (0.80,0.85,0.90,np.mean(al))))
