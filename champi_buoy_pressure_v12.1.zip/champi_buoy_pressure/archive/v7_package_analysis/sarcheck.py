# Independent check: central pressure from the buoy's eyewall readings plus the RCM-3 21:15Z wind profile integrated inward
# in gradient balance.  No storm-profile model and no wind consensus are used.
#   Pc = P_buoy(r_b) - int_0^{r_b} rho(r) [Vg(r)^2/r + f Vg(r)] dr ,  Vg = V_SAR(r * Rm_SAR/Rm_1733) * k_t / alpha
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, json, numpy as np

from core import t,lat,lon,P,TRACKS,dist,FCOR,RD,TC
pr=np.load(os.path.join(DATA,'sar_2115z','prof2115.npz'))
rc=pr['rc']; v=pr['vmean']; v2=pr['v2mean']; KT=1.94384
i=int(np.argmax(v[:60])); RmS=rc[i]; je=int(np.argmax(v*KT>=47))
rng=np.random.default_rng(11); N=20000; out={17:[],18:[]}
for k in range(N):
    alpha=rng.normal(0.85,0.05)            # 10-m / gradient-level wind in the eyewall
    kt=rng.normal(1.02,0.03)               # 17:33Z vs 21:15Z wind strength (slow weakening after 18Z per JTWC; SAR 3.7 h later)
    off=TRACKS['irf'][2]+rng.normal(0,2.0,2)
    Rm17=rng.normal(26.3,1.5)              # eyewall radius at 17:33Z (shape stretched from SAR Rm 25.8 km)
    dTc=rng.uniform(0.5,4.5); bias=rng.normal(0,0.5); re_kt=rng.choice([47,55])
    jj=int(np.argmax(v*KT>=re_kt))
    r=dist('irf',*off)
    for idx,key in ((17,17),(18,18)):
        rb=r[idx]+rng.normal(0,1.5)   # sector-to-sector eyewall radius scatter (SAR 21:15Z, +-1.5 km)
        x=np.linspace(rc[jj]*Rm17/RmS,rb,500); xs=x*RmS/Rm17
        vg=np.interp(xs,rc,v)*kt/alpha; vq=np.interp(xs,rc,v2)*(kt/alpha)**2
        ve=v[jj]*kt/alpha
        # density from the pressure itself (iterate once), warm eye core
        p=np.full_like(x,P[idx]+bias)
        for it in range(2):
            Tv=305.0+dTc*np.exp(-(x/(0.8*Rm17))**2)
            rho=p*100/(RD*Tv)
            dp=(rho*(vq/(x*1e3)+FCOR*vg))*1e3          # Pa per km
            cum=np.concatenate([[0],np.cumsum((dp[1:]+dp[:-1])/2*np.diff(x))])
            p=(P[idx]+bias)-(cum[-1]-cum)/100
        core=rho[0]*ve**2/2/100                        # solid-body core inside the eye edge
        out[key].append(P[idx]+bias-cum[-1]/100-core)
res={}
for key in (17,18):
    a=np.array(out[key]); q=np.percentile(a,[2.5,16,50,84,97.5]); res[key]=q.tolist()
    print('from the %02d:04 reading (P=%.1f): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(key,P[key],q[2],q[1],q[3],q[0],q[4]))
both=np.concatenate([out[17],out[18]]); q=np.percentile(both,[2.5,16,50,84,97.5]); res['both']=q.tolist()
print('pooled: median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f'%(q[2],q[1],q[3],q[0],q[4]))
json.dump(res,open(os.path.join(RES,'sarcheck.json'),'w'))
