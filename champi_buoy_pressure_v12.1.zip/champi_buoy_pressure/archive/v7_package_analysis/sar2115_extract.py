# Read the RCM-3 21:15Z level-2 SAR wind file (NetCDF-3, readable with SciPy) and save the fields used by the sar2115_* scripts.
# Place the original file in data/raw/ first (not included in this package: RCM3_SHUB_2026_10_20_21_15_26_..._MERGED01_wind_level2.nc).
import os, glob, numpy as np
from scipy.io import netcdf_file
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fn=glob.glob(os.path.join(ROOT,'data','raw','*21_15_26*wind_level2*.nc'))[0]
f=netcdf_file(fn,'r',mmap=False); g=lambda k: f.variables[k].data.astype(float)
W=g('sar_wind'); W[W<-900]=np.nan
np.savez_compressed(os.path.join(ROOT,'data','sar_2115z','sar2115_l2.npz'),W=W,lon=g('longitude'),lat=g('latitude'),inc=g('incid'),sig=g('sigma'))
print('saved', W.shape)
