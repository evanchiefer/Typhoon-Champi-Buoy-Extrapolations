
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, json, time

import mc
from multiprocessing import Pool
if __name__=='__main__':
    S=mc.SRC; jobs=[]
    for src in S:
        for i in range(40): jobs.append(('C','irf',(src,),10_000*S.index(src)+i,True))     # one source at a time (budget)
    for i in range(500): jobs.append(('C','irf',S,900_000+i,True))                         # all sources, with peak-wind constraint
    SO=tuple(x for x in S if x!='intensity')
    for i in range(250): jobs.append(('C','irf',SO,800_000+i,False))                       # buoy + satellite structure only
    for i in range(250): jobs.append(('C','bt',S,950_000+i,True))                          # JTWC best-track positions
    for i in range(250): jobs.append(('C','ir',S,940_000+i,True))                          # smoothed IR track (previous analysis)
    for fam in ('A','B'):
        for i in range(200): jobs.append((fam,'irf',S,700_000+i+1000*(fam=='B'),True))
    for i in range(250): jobs.append(('C','irf',S,960_000+i,True,'ramp'))                 # log-ramp density
    t0=time.time(); res=[]
    with Pool(2) as pool:
        for j,d in enumerate(pool.imap_unordered(mc.trial,jobs,chunksize=2)):
            res.append(d)
            if j%250==0: print('%d/%d %.0f s'%(j,len(jobs),time.time()-t0),flush=True)
    json.dump(res,open(os.path.join(RES,'mc6.json'),'w')); print('ALL DONE %.0f s'%(time.time()-t0))
