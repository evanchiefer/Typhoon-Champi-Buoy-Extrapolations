# How much does a centre error inflate the measured eye-shape integral for this real eyewall?
import numpy as np, json
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=os.path.join(ROOT,'data','sar_2115z')+os.sep
d=np.load(D+'sar2115_l2.npz'); W=d['W'].copy(); lon=d['lon']; lat=d['lat']; W[W<=0]=np.nan
c=json.load(open(D+'center2115.json')); KT=0.514444
KX=111.32*np.cos(np.radians(c['lat'])); KY=110.57
X0=(lon-c['lon'])*KX; Y0=(lat-c['lat'])*KY
rb=np.arange(0,80.01,0.5); rc=0.5*(rb[1:]+rb[:-1]); ok=np.isfinite(W)
def prof(dx,dy):
    r=np.hypot(X0-dx,Y0-dy)[ok]; i=np.digitize(r,rb)-1; n=len(rc); m=(i>=0)&(i<n)
    return np.bincount(i[m],W[ok][m],n)/np.maximum(np.bincount(i[m],None,n),1)/KT
def I47(vk):
    i=int(np.argmax(vk[:120])); Rm=rc[i]; vm=vk[i]; je=int(np.argmax(vk>=47)); x=rc[:i+1]/Rm; vv=vk[:i+1]/vm; m=x>=rc[je]/Rm
    return (vk[je]/vm)**2/2+np.trapezoid(vv[m]**2/x[m],x[m]), vm, Rm
I0,v0,R0=I47(prof(0,0)); print(f'refined centre: I={I0:.3f} Vm={v0:.0f} Rm={R0:.1f}')
for e in (1,2,3,4):
    res=[I47(prof(e*np.cos(a),e*np.sin(a))) for a in np.linspace(0,2*np.pi,8,endpoint=False)]
    I=np.array([q[0] for q in res]); V=np.array([q[1] for q in res])
    print(f'centre error {e} km: I {I.mean():.3f} (x{I.mean()/I0:.2f}), Vm {V.mean():.0f} kt')
dx,dy=-c['dx_from_star_km'],-c['dy_from_star_km']; I,V,R=I47(prof(dx,dy)); print(f'about STAR fix: I={I:.3f} (x{I/I0:.2f}) Vm={V:.0f} Rm={R:.1f}')
