# Monte Carlo: each trial redraws the uncertain inputs (measurement noise, barometer bias, centre position,
# eyewall radius, inner-eye shape, eyewall wind decay, environmental pressure) and the profile family, refits with Pc free.
import os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(ROOT,'data'); RES=os.path.join(ROOT,'results'); FIGS=os.path.join(ROOT,'figures')
sys.path.insert(0,os.path.join(ROOT,'analysis'))
import sys, json, time, numpy as np
from multiprocessing import Pool

from core import *
SCAN=json.load(open(os.path.join(RES,'scan_main.json')))
def best_of(name):
    rows=[r for r in SCAN if r['name']==name]; return min(rows,key=lambda r:r['chi2'])
BEST={k:best_of(k) for k in ('A_irf','B_irf','C_irf','C_ir','C_bt')}
SRC=('noise','bias','center','Rm','shape','decay','ring','Pn','intensity','density')
def trial(args):
    fam,track,sources,seed,use_vg=args[:5]; dmode=args[5] if len(args)>5 else 'thermo'; rng=np.random.default_rng(seed)
    pri=dict(PRI)
    if use_vg: pri['Vg']=VG_PRIOR
    off0,soff=TRACKS[track][2].copy(),TRACKS[track][3]; data=P.copy(); s=sig_obs()
    if 'noise' in sources: data=data+rng.normal(0,s)
    if 'bias' in sources: data=data+rng.normal(0,0.5)                 # drifter barometer accuracy (~+-1 hPa at 2 sigma)
    if 'center' in sources: off0=off0+rng.normal(0,soff,2)
    if 'Rm' in sources: pri['Rm']=(rng.normal(*PRI['Rm']),PRI['Rm'][1])
    if 'shape' in sources:
        z=rng.normal(); pri['n']=(PRI['n'][0]+z*PRI['n'][1],PRI['n'][1]); pri['I']=(PRI['I'][0]-z*PRI['I'][1],PRI['I'][1])   # same draw: high n == low I
    if 'decay' in sources: pri['v14']=(rng.normal(*PRI['v14']),PRI['v14'][1])
    if 'ring' in sources: pri['R2']=(rng.normal(*PRI['R2']),PRI['R2'][1]); pri['vsec']=(rng.normal(*PRI['vsec']),PRI['vsec'][1])   # secondary wind maximum radius and strength
    if 'Pn' in sources: pri['Pn']=(rng.normal(*PRI['Pn']),PRI['Pn'][1])
    if use_vg and 'intensity' in sources: pri['Vg']=(rng.normal(*VG_PRIOR),VG_PRIOR[1])
    pri['dens']=dict(DENS,mode=dmode)
    if 'density' in sources:      # warm-eye anomaly, rain-cooled eyewall, environmental Tv, anomaly width; ramp shape for the ramp check
        pri['dens'].update(dTc=rng.uniform(0.5,4.5),dTw=rng.uniform(0.0,2.5),Tv_env=rng.normal(305.0,1.5),rwf=rng.uniform(0.5,1.2),
                           r0f=rng.uniform(0.5,1.5),Rout=rng.uniform(200,600))
    pri['off']=off0
    b=BEST['%s_%s'%(fam,track)]; x0=np.r_[b['Pc'],b['x']]
    def res(q): return make_res(fam,q[0],track,pri=pri,data=data,sig=s)[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track,pri=pri); lb=np.r_[830.0,lb]; ub=np.r_[912.0,ub]
    st=[x0]+[np.r_[pc,b['x']] for pc in (b['Pc']-12,b['Pc']+12)]
    for q in starts(fam,track,4,seed%100000,lb[1:],ub[1:])[::5][:3]: st.append(np.r_[b['Pc']+rng.normal(0,8),q])
    best=None
    for q0 in st:
        try: r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=6000)
        except Exception: continue
        if best is None or r.cost<best.cost: best=r
    return dict(fam=fam,track=track,sources=list(sources),seed=int(seed),use_vg=bool(use_vg),dens=dmode,Pc=float(best.x[0]),chi2=float(2*best.cost))
if __name__=='__main__':
    out=sys.argv[1]; jobs=[]; k=0
    for src in SRC:                                  # one source at a time, both families (with intensity constraint)
        for fam in ('A','B'):
            for i in range(80): jobs.append((fam,'ir',(src,),10_000*SRC.index(src)+1000*(fam=='B')+i,True))
    for i in range(800): jobs.append(('A' if i%2==0 else 'B','ir',SRC,900_000+i,True))      # all sources, with intensity constraint
    for i in range(600): jobs.append(('A' if i%2==0 else 'B','ir',SRC[:-1],800_000+i,False))# all sources, buoy + satellite structure only
    for i in range(400): jobs.append(('A' if i%2==0 else 'B','bt',SRC,950_000+i,True))      # JTWC best-track positions check
    t0=time.time(); res=[]
    with Pool(2) as pool:
        for j,d in enumerate(pool.imap_unordered(trial,jobs,chunksize=4)):
            res.append(d)
            if j%200==0: print('%d/%d %.0f s'%(j,len(jobs),time.time()-t0),flush=True)
    json.dump(res,open(out,'w')); print('ALL DONE %.0f s'%(time.time()-t0))
