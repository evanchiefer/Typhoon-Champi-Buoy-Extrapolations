# Azimuthal-mean and per-sector wind profiles, RCM-3 21:15Z, about the refined surface centre
import numpy as np, json
from scipy.ndimage import gaussian_filter
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=os.path.join(ROOT,'data','sar_2115z')+os.sep
d=np.load(D+'sar2115_l2.npz'); W=d['W'].copy(); lon=d['lon']; lat=d['lat']
W[W<=0]=np.nan
c=json.load(open(D+'center2115.json'))
KX=111.32*np.cos(np.radians(c['lat'])); KY=110.57
X=(lon-c['lon'])*KX; Y=(lat-c['lat'])*KY
r=np.hypot(X,Y); th=np.degrees(np.arctan2(X,Y))%360   # azimuth from north, clockwise
dr=1.0; rb=np.arange(0,301,dr); rc=0.5*(rb[1:]+rb[:-1])
ok=np.isfinite(W)
idx=np.digitize(r[ok],rb)-1; w=W[ok]; t=th[ok]
nb=len(rc)
def binmean(v,i,n):
    s=np.bincount(i[(i>=0)&(i<n)],v[(i>=0)&(i<n)],n); k=np.bincount(i[(i>=0)&(i<n)],None,n); return s/np.maximum(k,1),k
vmean,cnt=binmean(w,idx,nb); v2mean,_=binmean(w**2,idx,nb)
# azimuthal coverage per bin (fraction of 10-deg sectors with data)
cov=np.zeros(nb)
sec=(t//10).astype(int)
for j in range(nb):
    m=idx==j
    cov[j]=len(np.unique(sec[m]))/36 if m.any() else 0
# 8 sectors (45 deg) and quadrants
quad={}
for name,(a0,a1) in dict(NE=(0,90),SE=(90,180),SW=(180,270),NW=(270,360)).items():
    m=(t>=a0)&(t<a1); vq,kq=binmean(w[m],idx[m],nb); quad[name]=vq
kt=1.94384
im=np.argmax(vmean[:60]); print(f'azimuthal-mean max {vmean[im]:.1f} m/s = {vmean[im]*kt:.0f} kt at r={rc[im]:.1f} km')
print(' r(km)  mean(kt)  sqrt<v2>(kt)  cov   NE  SE  SW  NW')
for j in list(range(0,60,1))+list(range(60,300,10)):
    print(f'{rc[j]:6.1f} {vmean[j]*kt:7.1f} {np.sqrt(v2mean[j])*kt:9.1f} {cov[j]:5.2f}  '+'  '.join(f'{quad[q][j]*kt:4.0f}' for q in ['NE','SE','SW','NW']))
np.savez(D+'prof2115.npz',rc=rc,vmean=vmean,v2mean=v2mean,cov=cov,cnt=cnt,**{'q_'+k:v for k,v in quad.items()})
