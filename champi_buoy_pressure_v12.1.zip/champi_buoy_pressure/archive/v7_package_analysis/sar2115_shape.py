# Eye shape from the RCM-3 21:15Z level-2 winds: validation against the STAR product, shape integral I, per-sector composite
import numpy as np, json
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=os.path.join(ROOT,'data','sar_2115z')+os.sep
d=np.load(D+'sar2115_l2.npz'); W=d['W'].copy(); lon=d['lon']; lat=d['lat']; W[W<=0]=np.nan
c=json.load(open(D+'center2115.json')); KT=0.514444; NMI=1.852
def coords(clon,clat):
    KX=111.32*np.cos(np.radians(clat)); KY=110.57
    X=(lon-clon)*KX; Y=(lat-clat)*KY; return np.hypot(X,Y), np.degrees(np.arctan2(X,Y))%360
def azmean(r,w,rb):
    ok=np.isfinite(w); i=np.digitize(r[ok],rb)-1; n=len(rb)-1; m=(i>=0)&(i<n)
    return np.bincount(i[m],w[ok][m],n)/np.maximum(np.bincount(i[m],None,n),1)
# 1) validation: STAR centre, 1-nmi bins
r,t=coords(130.818,17.707); rb=np.arange(0,60.1,1.0)*NMI; v=azmean(r,W,rb)/KT
j=np.argmax(v); print(f'STAR centre, 1-nmi bins: mean max {v[j]:.0f} kt at {0.5*(rb[j]+rb[j+1])/NMI:.1f} nmi   (STAR plot: 137 kt mean at 15 nmi)')
r,t=coords(c['lon'],c['lat']); v=azmean(r,W,rb)/KT; j=np.argmax(v)
print(f'refined centre, 1-nmi bins: mean max {v[j]:.0f} kt at {0.5*(rb[j]+rb[j+1])/NMI:.1f} nmi')
# 2) shape integral with the same recipe as the 09Z analysis (shape.py)
def I_recipe(rr,vk,re_kt,w=0.0,Vt=6.0):
    vms=vk*KT; vs=np.sqrt(np.maximum(vms**2-w*Vt**2,0)); i=int(np.argmax(vs[:80])); Rm=rr[i]
    je=int(np.argmax(vk>=re_kt)); re=rr[je]; x=rr[:i+1]/Rm; vv=vs[:i+1]/vs[i]
    core=(vs[je]/vs[i])**2/2; m=x>=re/Rm; return core+np.trapezoid(vv[m]**2/x[m],x[m]), Rm, vs[i]/KT, re
dr=0.5; rb=np.arange(0,80.01,dr); rc=0.5*(rb[1:]+rb[:-1])
vk=azmean(r,W,rb)/KT
out={}
for w in (0.0,0.5,1.0):
    for re_kt in (40,47,55):
        I,Rm,Vm,re=I_recipe(rc,vk,re_kt,w); out[(w,re_kt)]=I
        print(f'azimuthal mean, motion wt {w:.1f}, eye edge {re_kt} kt (r_e={re:4.1f} km): Rm {Rm:.2f} km Vm {Vm:.0f} kt  I={I:.3f}  n_eff={1/(2*I):.2f}')
# raw integral including the SAR eye winds all the way in (no solid-body core)
i=np.argmax(vk[:120]); x=rc[:i+1]/rc[i]; vv=vk[:i+1]/vk[i]
print(f'raw I incl. eye winds down to r=0.25 km: {np.trapezoid(vv**2/x,x):.3f}; from r=2 km: {np.trapezoid((vv**2/x)[x>=2/rc[i]],x[x>=2/rc[i]]):.3f}')
# 3) per-sector: each 10-deg sector's own profile, own Rm & Vm -> I_k ; and ring-aligned composite
nsec=36; Ik=[];Rk=[];Vk=[];prof=[]
xg=np.linspace(0.02,1.6,80)
for k in range(nsec):
    m=(t>=k*10)&(t<(k+1)*10)
    vs=azmean(r[m],W[m],rb)/KT
    from scipy.ndimage import uniform_filter1d
    vs_s=uniform_filter1d(vs,3)
    i=int(np.argmax(vs_s[30:120]))+30; Rm=rc[i]; Vm=vs_s[i]
    try:
        I,_,_,_=I_recipe(rc,vs_s,47)
    except Exception: continue
    Ik.append(I); Rk.append(Rm); Vk.append(Vm); prof.append(np.interp(xg*Rm,rc,vs_s)/Vm)
Ik=np.array(Ik);Rk=np.array(Rk);Vk=np.array(Vk);prof=np.array(prof)
print(f'per-sector (36): Rm {Rk.mean():.1f}±{Rk.std():.1f} km (range {Rk.min():.1f}-{Rk.max():.1f}); Vm {Vk.mean():.0f}±{Vk.std():.0f} kt; I {Ik.mean():.3f}±{Ik.std():.3f} -> n_eff {1/(2*Ik.mean()):.2f}')
comp=prof.mean(0)
x=xg[xg<=1.0]; vv=comp[xg<=1.0]/comp[xg<=1.0].max()
je=np.argmax(vv>=47/146); Ic=vv[je]**2/2+np.trapezoid(vv[je:]**2/x[je:],x[je:])
print(f'ring-aligned composite (each sector scaled by own Rm,Vm): I={Ic:.3f} n_eff={1/(2*Ic):.2f}')
for xx in (0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.2,1.4,1.6):
    print(f'   r/Rm={xx:.1f}: composite v/vm={np.interp(xx,xg,comp):.3f}   az-mean v/vm={np.interp(xx*rc[np.argmax(vk[:120])],rc,vk)/vk[:120].max():.3f}')
json.dump(dict(I_azmean={f'{k[0]}_{k[1]}':v for k,v in out.items()},I_sector_mean=float(Ik.mean()),I_sector_sd=float(Ik.std()),I_composite=float(Ic),
  Rm_sector=list(map(float,Rk)),Vm_sector=list(map(float,Vk)),comp_x=list(map(float,xg)),comp_v=list(map(float,comp))),open(D+'shape2115.json','w'),indent=0)
