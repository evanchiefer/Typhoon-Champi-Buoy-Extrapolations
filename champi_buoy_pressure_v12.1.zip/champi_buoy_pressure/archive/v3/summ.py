import json, numpy as np, sys
def load(fn): return json.load(open(fn))
def curve(rows,name):
    d=sorted([r for r in rows if r['name']==name],key=lambda r:r['Pc']); return np.array([r['Pc'] for r in d]),np.array([r['chi2'] for r in d]),d
G=np.arange(840,910.001,0.1)
def like(rows,name):
    p,c,_=curve(rows,name); L=np.exp(-0.5*np.interp(G,p,c-c.min())); return L/L.sum()
def q(L,ps=(0.025,0.16,0.5,0.84,0.975)): c=np.cumsum(L); return [float(G[min(np.searchsorted(c,x),len(G)-1)]) for x in ps]
if __name__=='__main__':
    for fn in sys.argv[1:]:
        rows=load(fn)
        for name in sorted(set(r['name'] for r in rows)):
            p,c,d=curve(rows,name); i=int(c.argmin()); b=d[i]; L=like(rows,name); qq=q(L)
            bumps=int(((c[1:-1]>c[:-2]+0.1)&(c[1:-1]>c[2:]+0.1)).sum()); imp=sum(1 for r in d if r.get('improved_by_sweep'))
            print('%-14s best %.0f (chi2 %.2f) | median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | edge? %s | bumps %d | sweep-improved %d | at best: RMW %.1f eye %.1f Vg %.0f kt off(%+.1f,%+.1f) rmin %.1f S2 %.2f'%(
                name,b['Pc'],b['chi2'],qq[2],qq[1],qq[3],qq[0],qq[4],'LOW' if i==0 else ('HIGH' if i==len(c)-1 else 'no'),bumps,imp,b['rmw'],b['eye'],b['vg'],*b['off'],b['rmin'],np.hypot(*b['bg'][4:6])))
