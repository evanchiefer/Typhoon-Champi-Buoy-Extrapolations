import json, numpy as np
MC=json.load(open('mc.json')); INP=json.load(open('inputs.json'))
jh=np.array([x[0] for x in INP['jtwc_p']]); jp=np.array([x[1] for x in INP['jtwc_p']]); JT=float(np.interp(17.55,jh,jp))
def rsd(v): p=np.percentile(v,[16,84]); return float((p[1]-p[0])/2)
def sel(**k): return np.array([d['Pc'] for d in MC if all((d[a]==b if a!='multi' else (len(d['sources'])>1)==b) for a,b in k.items())])
budget={}
print('one-source-at-a-time (with intensity constraint), 1-sigma half-width (hPa):')
for src in ('noise','bias','center','Rm','shape','decay','Pn','intensity'):
    s=[rsd(np.array([d['Pc'] for d in MC if d['sources']==[src] and d['fam']==f])) for f in ('A','B')]
    budget[src]=float(np.mean(s)); print('  %-9s A %.2f  B %.2f'%(src,*s))
out={}
for key,kw in (('with_intensity',dict(multi=True,track='ir',use_vg=True)),('structure_only',dict(multi=True,track='ir',use_vg=False)),('bt_check',dict(multi=True,track='bt',use_vg=True))):
    v=sel(**kw); pq=np.percentile(v,[2.5,16,50,84,97.5]); fa=sel(fam='A',**kw); fb=sel(fam='B',**kw)
    out[key]=dict(n=int(len(v)),q=[float(x) for x in pq],sd=rsd(v),p_below_jtwc=float((v<JT).mean()),medA=float(np.median(fa)),medB=float(np.median(fb)),at_bound=int((v<830.5).sum()))
    print('%-15s n=%d median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | P(<JTWC %.1f)=%.3f | A %.1f B %.1f | at lower bound %d'%(key,len(v),pq[2],pq[1],pq[3],pq[0],pq[4],JT,(v<JT).mean(),np.median(fa),np.median(fb),out[key]['at_bound']))
budget['family']=float(abs(out['with_intensity']['medA']-out['with_intensity']['medB'])/2)
quad=float(np.sqrt(sum(v**2 for v in budget.values())))
print('budget',{k:round(v,2) for k,v in budget.items()},'quadrature %.2f vs MC total %.2f'%(quad,out['with_intensity']['sd']))
w=out['with_intensity']
json.dump(dict(median=w['q'][2],lo68=w['q'][1],hi68=w['q'][3],lo95=w['q'][0],hi95=w['q'][4],total_sd=w['sd'],jtwc_1733=JT,budget=budget,runs=out),open('final.json','w'),indent=1)
