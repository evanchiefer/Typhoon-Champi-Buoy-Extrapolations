# Refined model: storm pressure profile + atmospheric background (env. pressure, synoptic trend, S1 and S2 tides).
# Two independent profile families:
#   A: two-ring Holland (1980) pressure profile
#   B: wind profile (inner power law, outer dual exponential, Willoughby-type) integrated through gradient-wind balance
# Pc = background at 17:33Z minus total storm deficit (the actual MSLP at the centre, including the tide).
import numpy as np, json
from scipy.optimize import least_squares
from scipy.stats import qmc
BASE='/tmp/claude-0/-home-claude/aff9a93d-a48d-5fdf-9b61-0f18a743f164/scratchpad/ty/'
INP=json.load(open(BASE+'v3/inputs.json'))
B_=np.array(INP['buoy']); t,lat,lon,P=B_[:,0],B_[:,1],B_[:,2],B_[:,3]
TC=17.55                                   # time of closest approach (17:33Z) at which Pc is reported
LST=t+lon/15.0                             # local solar time (h)
RHO=1.15; FCOR=2*7.292e-5*np.sin(np.radians(17.3)); KT=1/0.5144
# ---- centre tracks ----
fx=json.load(open(BASE+'fixes.json')); th=np.array(sorted(int(k) for k in fx))
IRLAT=np.polyfit(th,[fx[str(h)]['lat'] for h in th],2); IRLON=np.polyfit(th,[fx[str(h)]['lon'] for h in th],2)
BT=np.array(INP['bt']); BTLAT=np.polyfit(BT[:,0],BT[:,1],3); BTLON=np.polyfit(BT[:,0],BT[:,2],3)
TRACKS={'ir':(IRLAT,IRLON,np.array([6.0,-10.2]),4.0),   # IR eye track + offset prior from SAR (09Z) and ATMS (17:01Z) surface centres
        'bt':(BTLAT,BTLON,np.array([0.0,0.0]),6.0)}     # JTWC best-track positions, no offset assumed (+-6 km covers 0.1 deg rounding)
def dist(track,sx,sy,tq=t,la=lat,lo=lon):
    pa,po=TRACKS[track][:2]; cla=np.polyval(pa,tq); clo=np.polyval(po,tq)
    kx=111.0*np.cos(np.radians((la+cla)/2)); return np.hypot((lo-clo)*kx-sx,(la-cla)*111.0-sy)
# ---- background ----
def background(bg,tq=t,lst=LST):
    Pn,b1,c1,s1,c2,s2=bg; w=2*np.pi/24
    return Pn+b1*(tq-TC)+c1*np.cos(w*lst)+s1*np.sin(w*lst)+c2*np.cos(2*w*lst)+s2*np.sin(2*w*lst)
LST_C=TC+131.55/15.0
# ---- family A: two-ring Holland ----
def defA(r,parts):
    return sum(dP*(1-np.exp(-(R/np.maximum(r,0.05))**Bh)) for dP,R,Bh in parts)   # deficit relative to background
def vgA(r,parts):
    g=0*r
    for dP,R,Bh in parts: x=(R/r)**Bh; g=g+dP*100*Bh*x*np.exp(-x)
    rm=r*1e3; return np.sqrt(g/RHO+(FCOR*rm/2)**2)-FCOR*rm/2
# ---- family B: wind profile + gradient balance ----
RG=np.concatenate([np.linspace(0,1,1),np.geomspace(1e-3,1,1)])  # placeholder
def windB(r,Vm,Rm,n,A,X1,X2):
    r=np.asarray(r,float); v=np.where(r<Rm,(np.maximum(r,0)/Rm)**n,(1-A)*np.exp(-(r-Rm)/X1)+A*np.exp(-(r-Rm)/X2)); return Vm*v
def defB_unit(Rm,n,A,X1,X2):
    # returns functions g(r)=rho*int_r^inf v^2/r' dr', h(r)=rho*f*int_r^inf v dr'  (per unit Vm^2 and Vm), Pa, r in km
    ro=Rm+np.concatenate([[0],np.geomspace(0.05,4000,700)])
    vo=(1-A)*np.exp(-(ro-Rm)/X1)+A*np.exp(-(ro-Rm)/X2)
    a=vo**2/ro; b=vo
    ca=np.concatenate([[0],np.cumsum((a[1:]+a[:-1])/2*np.diff(ro))]); cb=np.concatenate([[0],np.cumsum((b[1:]+b[:-1])/2*np.diff(ro))])
    Ga=ca[-1]-ca; Gb=(cb[-1]-cb)*1e3             # int_r^inf (km-> m for the f*v term; v^2/r term is scale-free)
    g_Rm=RHO*Ga[0]; h_Rm=RHO*FCOR*Gb[0]
    def gh(r):
        r=np.asarray(r,float); out_g=np.empty_like(r); out_h=np.empty_like(r); o=r>=Rm
        out_g[o]=RHO*np.interp(r[o],ro,Ga); out_h[o]=RHO*FCOR*np.interp(r[o],ro,Gb)
        x=np.maximum(r[~o],0)/Rm
        out_g[~o]=g_Rm+RHO*(1-x**(2*n))/(2*n); out_h[~o]=h_Rm+RHO*FCOR*Rm*1e3*(1-x**(n+1))/(n+1)
        return out_g,out_h
    return gh
def vm_from_deficit(D,g0,h0):     # solve g0*Vm^2 + h0*Vm = D (Pa)
    return (-h0+np.sqrt(h0**2+4*g0*D))/(2*g0)
# ---- priors (centre, sd) ----
VG_PRIOR=(167.0,16.0)   # wind consensus 150+-10 kt (1-min) -> azimuthal-mean max (-8 kt) / 0.85 surface reduction
PRI=dict(Rm=(27.0,3.0), n=(1.47,0.33), I=(0.345,0.078), Pn=(1009.5,2.0), v14=(0.84,0.07))
SIG0=0.5; SIGPOS=1.0
_ref=json.load(open(BASE+'v3/grad_ref.json')) if __import__('os').path.exists(BASE+'v3/grad_ref.json') else None
def sig_obs(sigpos=None):
    sp=SIGPOS if sigpos is None else sigpos
    g=np.array(_ref['dPdr']) if _ref else np.zeros_like(P)
    return np.sqrt(SIG0**2+(g*sp)**2)
# ---- residual builders ----
def make_res(family,Pc,track='ir',pri=None,data=None,shape_prior=True,tide=True,sig=None,decay_prior=True):
    pri=dict(PRI if pri is None else pri); Pd=P if data is None else data; s=sig_obs() if sig is None else sig
    off0,soff=TRACKS[track][2],TRACKS[track][3]
    if 'off' in pri: off0=pri['off']
    def bgp(q): return q if tide else np.r_[q[:2],0,0,0,0]
    if family=='A':
        def unpack(q):
            fr,R1,B1,R2,B2,sx,sy=q[:7]; bg=bgp(q[7:13]); Dtot=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            return [(Dtot*fr,R1,B1),(Dtot*(1-fr),R2,B2)],sx,sy,bg,Dtot
        def res(q):
            parts,sx,sy,bg,Dtot=unpack(q)
            if Dtot<=5: return np.full(len(Pd)+7,1e3)
            r=dist(track,sx,sy); e=(background(bg)-defA(r,parts)-Pd)/s
            rr=np.linspace(2,150,500); vg=vgA(rr,parts); i=vg.argmax(); rm=rr[i]
            pen=[(sx-off0[0])/soff,(sy-off0[1])/soff,(rm-pri['Rm'][0])/pri['Rm'][1],(bg[0]-pri['Pn'][0])/pri['Pn'][1]]
            if shape_prior:
                E=Dtot-defA(np.array([rm]),parts)[0]; I=E*100/(RHO*vg[i]**2); pen.append((I-pri['I'][0])/pri['I'][1])
            else: pen.append(0.0)
            if decay_prior: pen.append((np.interp(1.4*rm,rr,vg)/vg[i]-pri['v14'][0])/pri['v14'][1])
            else: pen.append(0.0)
            pen.append(((vg[i]*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0)
            return np.r_[e,pen]
        lb=[0.05,8,0.8,40,0.5,-40,-40,1000,-1,-3,-3,-3,-3]; ub=[0.97,70,4.5,500,3,40,40,1020,1,3,3,3,3]
    else:
        def unpack(q):
            Rm,n,A,X1,X2,sx,sy=q[:7]; bg=bgp(q[7:13]); Dtot=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            gh=defB_unit(Rm,n,A,X1,X2); g0,h0=gh(np.array([0.0])); Vm=vm_from_deficit(Dtot*100,g0[0],h0[0])
            return Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm
        def res(q):
            Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(q)
            if Dtot<=5: return np.full(len(Pd)+7,1e3)
            r=dist(track,sx,sy); g,h=gh(r); D=(g*Vm**2+h*Vm)/100
            e=(background(bg)-D-Pd)/s
            pen=[(sx-off0[0])/soff,(sy-off0[1])/soff,(Rm-pri['Rm'][0])/pri['Rm'][1],(bg[0]-pri['Pn'][0])/pri['Pn'][1],
                 ((n-pri['n'][0])/pri['n'][1]) if shape_prior else 0.0,
                 (((1-A)*np.exp(-0.4*Rm/X1)+A*np.exp(-0.4*Rm/X2)-pri['v14'][0])/pri['v14'][1]) if decay_prior else 0.0,
                 ((Vm*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0]
            return np.r_[e,pen]
        lb=[10,0.4,0.0,3,40,-40,-40,1000,-1,-3,-3,-3,-3]; ub=[60,4.0,1.0,150,1500,40,40,1020,1,3,3,3,3]
    return res,unpack,np.array(lb,float),np.array(ub,float)
def starts(family,track,n_rand,seed,lb,ub):
    off0=TRACKS[track][2]
    if family=='A': base=[[fr,R1,B1,R2,1.45,*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0] for fr in (0.6,0.75) for R1 in (25,30) for B1 in (1.8,2.8) for R2 in (110,150)]
    else: base=[[Rm,n,A,X1,X2,*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0] for Rm in (25,29) for n in (1.2,1.8) for A in (0.3,0.6) for X1,X2 in ((15,200),(40,400))]
    u=qmc.LatinHypercube(d=13,seed=seed).random(n_rand); rnd=lb+u*(ub-lb)
    rnd[:,5]=off0[0]+(u[:,5]-0.5)*20; rnd[:,6]=off0[1]+(u[:,6]-0.5)*20; rnd[:,7]=1009.5+(u[:,7]-0.5)*6
    rnd[:,8:]=(u[:,8:]-0.5)*np.array([0.2,2,2,2,2])
    if family=='A': rnd[:,3]=np.exp(np.log(40)+u[:,3]*np.log(500/40))
    else: rnd[:,4]=np.exp(np.log(40)+u[:,4]*np.log(1500/40)); rnd[:,3]=np.exp(np.log(3)+u[:,3]*np.log(150/3))
    return [np.array(b,float) for b in base]+list(rnd)
def solve(family,Pc,track='ir',n_rand=40,seed=0,extra=(),**kw):
    res,unpack,lb,ub=make_res(family,Pc,track,**kw)
    best=None; costs=[]
    for s0 in list(extra)+starts(family,track,n_rand,seed,lb,ub):
        try: s=least_squares(res,np.clip(s0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
        except Exception: continue
        costs.append(s.cost)
        if best is None or s.cost<best.cost: best=s
    return best,np.array(costs),unpack
def summarize(family,best,unpack,Pc,track='ir'):
    if family=='A':
        parts,sx,sy,bg,Dtot=unpack(best.x); rr=np.linspace(2,150,1500); vg=vgA(rr,parts); i=vg.argmax(); rm=rr[i]
        E=Dtot-defA(np.array([rm]),parts)[0]; vmax=vg[i]
    else:
        Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(best.x); rm=Rm; vmax=Vm; g,h=gh(np.array([Rm])); E=Dtot-(g[0]*Vm**2+h[0]*Vm)/100
    r=dist(track,sx,sy); return dict(Pc=float(Pc),chi2=float(2*best.cost),rmw=float(rm),vg=float(vmax*KT),eye=float(E),off=[float(sx),float(sy)],
                                     bg=[float(v) for v in bg],rmin=float(r.min()),x=[float(v) for v in best.x])
