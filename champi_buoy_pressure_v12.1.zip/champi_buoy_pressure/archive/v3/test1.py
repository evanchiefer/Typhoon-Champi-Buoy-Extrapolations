import sys, time, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/aff9a93d-a48d-5fdf-9b61-0f18a743f164/scratchpad/ty/v3')
from core import *
for fam in ('A','B'):
    for Pc in (865,875,885,895):
        t0=time.time(); best,costs,unpack=solve(fam,Pc,n_rand=24,seed=int(Pc))
        s=summarize(fam,best,unpack,Pc)
        print('%s Pc %d: chi2 %.1f (N=38 + priors) | RMW %.1f eye %.1f Vg %.0f kt | off(%+.1f,%+.1f) rmin %.1f | Pn %.1f trend %+.3f S1 %.2f S2 %.2f | %d starts, %.0f s'%(
            fam,Pc,s['chi2'],s['rmw'],s['eye'],s['vg'],*s['off'],s['rmin'],s['bg'][0],s['bg'][1],np.hypot(*s['bg'][2:4]),np.hypot(*s['bg'][4:6]),len(costs),time.time()-t0))
