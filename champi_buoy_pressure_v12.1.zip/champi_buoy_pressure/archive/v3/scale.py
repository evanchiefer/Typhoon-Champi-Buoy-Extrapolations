# Calibrate the SAR eye pressure drop against the buoy, using radii where both exist.
import numpy as np, json
exec(open('fig3.py').read().split('fig,ax=')[0])          # brings in MAIN fits, dist2, plat/plon, data
S=json.load(open('sar/sar_profiles.json')); rho=1.15; KT=0.5144; Vt=7.0
def sar_rise(name,r1,r2,mode='raw'):
    d=S[name]; r=np.array(d['r'])*1e3; v=np.array(d['v'])*KT
    if mode=='mr': v=np.sqrt(np.maximum(v**2-Vt**2,0))
    f=2*7.292e-5*np.sin(np.radians(16.7)); m=(r>=r1*1e3)&(r<=r2*1e3)
    return np.trapezoid(rho*(v[m]**2/r[m]+f*v[m]),r[m])/100
def sar_eye(name,mode):
    d=S[name]; r=np.array(d['r'])*1e3; v=np.array(d['v'])*KT; i=np.nanargmax(v)
    if mode=='mr': v=np.sqrt(np.maximum(v**2-Vt**2,0))
    f=2*7.292e-5*np.sin(np.radians(16.7))
    return np.trapezoid(rho*(v[:i+1]**2/r[:i+1]+f*v[:i+1]),r[:i+1])/100, r[i]/1e3
# buoy distances from the fitted surface center (best fit), readings near the core
r_=at(MAIN,'E0',885); pp,sx,sy=parts_of(r_); rb=dist2(t,lat,lon,(sx,sy),plat,plon)
idx=[15,16,17,18,19,20]   # 15:00 .. 20:04
for i in idx: print('  %s  r=%5.1f km  P=%.1f'%(['15:00','16:04','17:04','18:04','19:04','20:04'][idx.index(i)],rb[i],P[i]))
pairs=[('in, approach',17,16),('in, depart',18,19),('wide, approach',17,15),('wide, depart',18,20)]
rows=[]
for name in S:
    for mode in ('raw','mr'):
        E,rm=sar_eye(name,mode)
        for lab,i1,i2 in pairs:
            meas=P[i2]-P[i1]; sar=sar_rise(name,rb[i1],rb[i2],mode); k=meas/sar
            rows.append((name,mode,lab,meas,sar,k,E,k*E,rm))
print('\npass          mode  radii            buoy rise  SAR rise   k     SAR eye drop  scaled eye drop')
for r in rows: print('%-13s %-4s %-15s  %6.1f    %6.1f   %.2f     %5.1f        %5.1f   (SAR RMW %.0f km)'%r)
ks=np.array([r[5] for r in rows]); Es=np.array([r[7] for r in rows])
print('\nscaled eye drop over all variants: mean %.1f, sd %.1f, range %.1f-%.1f hPa'%(Es.mean(),Es.std(),Es.min(),Es.max()))
for name in S:
    e=np.array([r[7] for r in rows if r[0]==name]); print('  %s: mean %.1f sd %.1f'%(name,e.mean(),e.std()))
json.dump(dict(rows=rows),open('v3/scale.json','w'))
# sounder cross-check: warm-core growth 09:15Z -> 17:00Z and implied k with SRF
a04,a17=np.array([7.18,8.13,8.09]),np.array([9.16,10.49,10.55])
f_lin=a17/(a04+(a17-a04)*(9.25-4.48)/(17.0-4.48))
print('\nsounder warm-core growth 09:15->17:00 (ch7-9, linear in time): %s'%np.round(f_lin,3))
for srf in (0.80,0.85,0.90):
    print('  expected k = f/SRF^2 with SRF %.2f: %.2f (if SAR speeds unbiased)'%(srf,f_lin.mean()/srf**2))
