import sys, json, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/aff9a93d-a48d-5fdf-9b61-0f18a743f164/scratchpad/ty/v3')
import core
from core import *
import mc
def fit(fam,label,track='ir',pri_upd=None,sigpos=None,**kw):
    pri=dict(PRI); pri['Vg']=VG_PRIOR
    if pri_upd: pri.update(pri_upd)
    s=sig_obs(sigpos)
    b=mc.BEST['%s_%s'%(fam,track)]
    def res(q): return make_res(fam,q[0],track,pri=pri,sig=s,**kw)[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track); lb=np.r_[830.0,lb]; ub=np.r_[912.0,ub]
    best=None
    for pc0 in (850,865,880,895):
        q0=np.r_[pc0,b['x']]
        r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=6000)
        if best is None or r.cost<best.cost: best=r
    return best.x[0]
cases=[('baseline (with wind consensus)',{}),('no tide / trend in background',dict(tide=False)),('no eyewall-decay constraint',dict(decay_prior=False)),
       ('position error 0.5 km',dict(sigpos=0.5)),('position error 2.0 km',dict(sigpos=2.0)),('max-wind radius prior 27 ± 2 km',dict(pri_upd={'Rm':(27,2)})),
       ('max-wind radius prior 25 ± 3 km',dict(pri_upd={'Rm':(25,3)})),('max-wind radius prior 29 ± 3 km',dict(pri_upd={'Rm':(29,3)})),
       ('environmental pressure 1008 ± 1',dict(pri_upd={'Pn':(1008,1)})),('environmental pressure 1011 ± 1',dict(pri_upd={'Pn':(1011,1)})),
       ('wind consensus 140 ± 10 kt',dict(pri_upd={'Vg':((140-8)/0.85,16)})),('wind consensus 160 ± 10 kt',dict(pri_upd={'Vg':((160-8)/0.85,16)})),
       ('JTWC best-track positions',dict(track='bt'))]
out=[]
for lab,kw in cases:
    a=fit('A',lab,**kw); b=fit('B',lab,**kw); out.append((lab,a,b)); print('%-36s A %.1f  B %.1f  mean %.1f'%(lab,a,b,(a+b)/2),flush=True)
json.dump(out,open('robust.json','w'))
