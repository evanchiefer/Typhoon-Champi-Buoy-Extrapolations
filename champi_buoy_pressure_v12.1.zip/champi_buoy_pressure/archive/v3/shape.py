# Normalized eye shape from SAR: I = integral_0^1 v^2/x dx  (v=V/Vm, x=r/Rm); eye drop = rho*Vm^2*I (+ small Coriolis term)
import numpy as np, json
S=json.load(open('sar/sar_profiles.json')); KT=0.5144; Vt=7.0
res={}
for name,d in S.items():
    r=np.array(d['r']); v=np.array(d['v'])*KT; i=int(np.nanargmax(v)); Rm=r[i]; Vm=v[i]
    for w in (0.5,1.0):
        vs=np.sqrt(np.maximum(v**2-w*Vt**2,0))
        for re_kt in (40,47,55):        # calm-eye edge: inside it, replace SAR floor by solid-body rotation
            je=int(np.argmax(v*1/KT>=re_kt)); re=r[je]; Ve=vs[je]
            x=r[:i+1]/Rm; vv=vs[:i+1]/vs[i]
            core=(Ve/vs[i])**2/2                                  # solid body inside r_e: integral = v_e^2/2
            m=x>=re/Rm; wall=np.trapezoid(vv[m]**2/x[m],x[m])
            I=core+wall
            res[(name,w,re_kt)]=(Rm,Vm/KT,re,I,1/(2*I))
            print('%-13s motion wt %.1f  eye edge %d kt (r_e=%4.1f km)  Rm %2.0f km  Vm %3.0f kt | core %.3f wall %.3f  I=%.3f  -> n_eff %.2f'%(name,w,re_kt,re,Rm,Vm/KT,core,wall,I,1/(2*I)))
I=np.array([v[3] for v in res.values()]); n=1/(2*I)
print('\nI over all variants: mean %.3f sd %.3f (range %.3f-%.3f) | n_eff mean %.2f sd %.2f'%(I.mean(),I.std(),I.min(),I.max(),n.mean(),n.std()))
# raw integral including the SAR eye floor, for comparison
for name,d in S.items():
    r=np.array(d['r']); v=np.array(d['v'])*KT; i=int(np.nanargmax(v)); x=r[:i+1]/r[i]; vv=v[:i+1]/v[i]
    print('  %s raw (with eye floor) I = %.3f'%(name,np.trapezoid(vv[1:]**2/x[1:],x[1:])))
json.dump(dict(I_mean=float(I.mean()),I_sd=float(I.std())),open('v3/shape.json','w'))
