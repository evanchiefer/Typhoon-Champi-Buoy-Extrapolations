# Figure 2: central pressure and its uncertainty
import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/aff9a93d-a48d-5fdf-9b61-0f18a743f164/scratchpad/ty/v3')
from common import *
from summ import curve, like, q, G
F=json.load(open(BASE+'v3/final.json')); MC=json.load(open(BASE+'v3/mc.json'))
main=json.load(open(BASE+'v3/scan_main.json'))
fig=plt.figure(figsize=(23,14)); gs=fig.add_gridspec(2,3,width_ratios=[1,1,1.05],hspace=0.34,wspace=0.42)
A1=fig.add_subplot(gs[0,0]); A2=fig.add_subplot(gs[0,1]); A3=fig.add_subplot(gs[0,2]); gb=gs[1,:].subgridspec(1,3,width_ratios=[1,0.55,1.75],wspace=0.0); B1=fig.add_subplot(gb[0,0]); B2=fig.add_subplot(gb[0,2])
JT=F['jtwc_1733']; R=F['runs']
# (a) profile likelihood
for nm,c,ls,lab in (('A_ir',ORA,'-',NAME['A']),('B_ir',BLU,'-',NAME['B']),('A_bt',ORA,'--','  same, JTWC best-track positions'),('B_bt',BLU,'--','  same, JTWC best-track positions')):
    p,cc,_=curve(main,nm); A1.plot(p,cc-cc.min(),color=c,ls=ls,lw=2.4 if ls=='-' else 1.6,label=lab)
for lv,tx in ((1,'68%'),(3.84,'95%')): A1.axhline(lv,color=INK2,lw=0.9,ls=':'); A1.text(841,lv+0.15,tx,fontsize=10.5,color=INK2)
A1.axvline(JT,color=RED,lw=1.4,ls='--'); A1.text(JT-0.8,5.2,'JTWC\n%.0f hPa'%JT,fontsize=10.5,color=RED,va='top',ha='right')
A1.set_xlim(840,910); A1.set_ylim(0,10); A1.set_xlabel('central pressure at 17:33Z (hPa)'); A1.set_ylabel('misfit above best fit (Δχ²)')
A1.set_title('a   Fit quality vs central pressure\n     (buoy + satellite structure, no intensity input)',loc='left',fontweight='bold')
A1.legend(loc='upper center',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95,fontsize=9.8)
# (b) wind-pressure relation implied by the buoy
for nm,c,lab in (('A_ir',ORA,NAME['A']),('B_ir',BLU,NAME['B'])):
    _,_,d=curve(main,nm); pc=np.array([r['Pc'] for r in d]); vg=np.array([r['vg'] for r in d])
    vg=np.array([np.median(vg[max(0,i-2):i+3]) for i in range(len(vg))])
    A2.fill_betweenx(pc,0.80*vg+3,0.90*vg+13,color=c,alpha=0.10,lw=0); A2.plot(0.85*vg+8,pc,color=c,lw=2.6,label=lab)
A2.axvspan(140,160,color=GRY,alpha=0.12,lw=0,label='wind consensus 150 ± 10 kt')
pts=[('JTWC best track 18Z',160,895,RED,'*',16),('JTWC best track 12Z',155,902,RED,'*',12),('D-MINT ATMS 17:02Z',147,906,INK2,'D',8),('D-MINT ATMS 16:41Z',150,907,INK2,'D',8)]
for lab,v,p_,c,mk,ms in pts: A2.plot(v,p_,mk,ms=ms,color=c,mec=INK,mew=0.8,label=lab,zorder=6)
for lab,v in (('AiDT 17:30Z',145),('ADT 17:30Z',137)): A2.axvline(v,color=INK2,lw=1,ls=':'); A2.text(v-0.6,910,lab,rotation=90,fontsize=9.5,color=INK2,ha='right',va='bottom')
A2.set_xlim(120,190); A2.set_ylim(912,840); A2.set_xlabel('equivalent peak 1-min surface wind (kt)'); A2.set_ylabel('central pressure (hPa)')
A2.set_title('b   Wind–pressure relation implied by the buoy\n     (band: surface reduction 0.80–0.90)',loc='left',fontweight='bold')
A2.legend(loc='upper left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.95,fontsize=9.3)
# (c) Monte Carlo
wi=np.array([d['Pc'] for d in MC if len(d['sources'])>1 and d['track']=='ir' and d['use_vg']]); so=np.array([d['Pc'] for d in MC if len(d['sources'])>1 and d['track']=='ir' and not d['use_vg']])
bt=np.array([d['Pc'] for d in MC if len(d['sources'])>1 and d['track']=='bt'])
bins=np.arange(830,914,2)
A3.hist(wi,bins=bins,density=True,color=LBL,edgecolor=SURF,lw=0.8,label='buoy + satellite structure + wind consensus (%d trials)'%len(wi))
A3.hist(so,bins=bins,density=True,histtype='step',color=GRY,lw=2,label='buoy + satellite structure only (%d; %d at the 830 hPa search limit)'%(len(so),int((so<830.5).sum())))
A3.hist(bt,bins=bins,density=True,histtype='step',color=ORA,lw=2,label='check: JTWC best-track positions (%d)'%len(bt))
pq=np.percentile(wi,[2.5,16,50,84,97.5]); ymax=A3.get_ylim()[1]
A3.axvspan(pq[1],pq[3],color=BLU,alpha=0.10,lw=0); A3.axvline(pq[2],color=DBL,lw=2.4)
A3.text(pq[2],ymax*1.03,'median %.0f hPa\n68%%: %.0f–%.0f   95%%: %.0f–%.0f'%(pq[2],pq[1],pq[3],pq[0],pq[4]),ha='center',va='bottom',fontsize=12,fontweight='bold',color=DBL,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=2))
A3.axvline(JT,color=RED,lw=1.6,ls='--'); A3.text(JT+0.8,ymax*0.62,'JTWC\n%.0f hPa'%JT,fontsize=10.5,color=RED)
A3.set_xlim(830,914); A3.set_ylim(0,ymax*1.45); A3.set_xlabel('central pressure at 17:33Z (hPa)'); A3.set_ylabel('probability density (per hPa)')
A3.set_title('c   Monte Carlo over all uncertain inputs',loc='left',fontweight='bold'); A3.legend(loc='upper left',frameon=False,fontsize=9.5)
# (d) budget
lab={'shape':'inner-eye wind shape','decay':'wind decay outside eyewall','Rm':'radius of max wind (±3 km)','center':'centre position',
     'noise':'reading scatter','bias':'barometer calibration','Pn':'environmental pressure','intensity':'peak-wind consensus (±10 kt)','family':'profile model (A vs B)'}
Bd=F['budget']; items=sorted(Bd.items(),key=lambda kv:kv[1]); y=np.arange(len(items))
B1.barh(y,[v for _,v in items],color=[ORA if k=='family' else BLU for k,_ in items],height=0.62)
for yy,(k,v) in zip(y,items): B1.text(v+0.12,yy,'%.1f'%v,va='center',fontsize=11)
B1.set_yticks(y); B1.set_yticklabels([lab[k] for k,_ in items]); B1.grid(axis='y',visible=False)
B1.axvline(F['total_sd'],color=DBL,lw=1.6,ls='--'); B1.text(F['total_sd']+0.12,-0.55,'combined ±%.1f hPa (1σ)'%F['total_sd'],fontsize=11,color=DBL)
B1.set_xlim(0,max(max(v for _,v in items),F['total_sd'])*1.3); B1.set_xlabel('contribution to uncertainty (hPa, 1σ)'); B1.set_title('d   Uncertainty budget',loc='left',fontweight='bold')
# (e) comparison
est=[('This work: structure + wind consensus',*np.percentile(wi,[50,16,84,2.5,97.5]),BLU),
     ('This work: structure only*',*np.percentile(so,[50,16,84,2.5,97.5]),GRY),
     ('This work: JTWC-position check',*np.percentile(bt,[50,16,84,2.5,97.5]),ORA),
     ('JTWC best track (interp. 17:33Z)',JT,None,None,None,None,RED),('D-PRINT (16:30–17:30Z)',903,902,904,None,None,INK2),
     ('ATMS (SATCON plot, ~17Z)',903,None,None,None,None,INK2),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,None,None,INK2),('SATCON (~17Z)',910,None,None,None,None,INK2)]
n=len(est)
for i,(nm,v,l1,h1,l2,h2,col) in enumerate(est):
    yy=n-1-i; ours=i<3
    if l2 is not None: B2.plot([l2,h2],[yy,yy],color=col,lw=3,alpha=0.4,solid_capstyle='round')
    if l1 is not None: B2.plot([l1,h1],[yy,yy],color=col,lw=9 if ours else 4,alpha=0.45,solid_capstyle='round')
    B2.plot(v,yy,'o',ms=11 if ours else 8,color=col,mec=SURF,mew=1.5)
    txt=('%.0f  (68%%: %.0f–%.0f, 95%%: %.0f–%.0f)'%(v,l1,h1,l2,h2)) if ours else ('%.0f'%v if l1 is None else '%g–%g'%(l1,h1))
    B2.text(v if ours else v+1.0,yy+0.3,txt,fontsize=11,ha='center' if ours else 'left')
B2.axvline(909.4,color=RED,lw=1.3,ls=':'); B2.text(910.0,n-1.3,'buoy reading\n909.4 hPa,\n~28 km from\ncentre',fontsize=10.5,va='top')
B2.set_yticks(range(n)); B2.set_yticklabels([e[0] for e in est][::-1],fontsize=11.5); B2.set_xlim(830,925); B2.set_ylim(-0.7,n-0.2); B2.grid(axis='y',visible=False)
B2.text(830.5,-0.62,'* lower tail truncated at the 830 hPa search limit',fontsize=10,color=INK2); B2.set_xlabel('central pressure near 17Z, 20 Oct (hPa)'); B2.set_title('e   Comparison with operational and satellite estimates   (thick bar 68%, thin bar 95%)',loc='left',fontweight='bold')
fig.suptitle('Typhoon Champi (29W) — central pressure at 17:33Z, 20 October 2026, from the drifting-buoy eyewall pass',x=0.01,y=0.995,ha='left',fontsize=17,fontweight='bold')
fig.text(0.01,0.963,'Multistart least-squares fits of two independent profile models (64 starts per value plus continuation), Monte Carlo over all uncertain inputs. JTWC and satellite pressures are used for comparison only.',fontsize=12,color=INK2)
fig.savefig(BASE+'v3/fig2_central_pressure.png',dpi=165,bbox_inches='tight'); print('saved')
