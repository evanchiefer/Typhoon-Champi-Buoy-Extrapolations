import sys, json, numpy as np
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from core import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'; SURF='#fcfcfb'
BLU='#2a78d6'; DBL='#0f3f7a'; LBL='#8bb8ea'; ORA='#eb6834'; GRN='#1baf7a'; RED='#d0312d'; GRY='#9a9893'
plt.rcParams.update({'font.size':12,'axes.titlesize':13.5,'axes.labelsize':12.5,'legend.fontsize':10.5,'xtick.labelsize':11,'ytick.labelsize':11,
    'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.facecolor':SURF,'figure.facecolor':SURF,
    'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
NAME={'A':'Pressure-profile model (two-ring Holland)','B':'Wind-profile model, no outer ring','C':'Wind-profile model with outer ring (gradient balance)'}
def rows_of(fn,name): 
    d=[r for r in json.load(open(fn)) if r['name']==name]; return sorted(d,key=lambda r:r['Pc'])
def nearest(rows,Pc): return min(rows,key=lambda r:abs(r['Pc']-Pc))
def model_eval(fam,row,track,tq,la,lo):
    """storm deficit (hPa) and background at arbitrary times/positions for a fitted row"""
    x=np.array(row['x']); Pc=row['Pc']
    _,unpack,_,_=make_res(fam,Pc,track)
    if fam=='A':
        parts,sx,sy,bg,Dtot=unpack(x); r=dist(track,sx,sy,tq,la,lo); D=defA(r,parts)
    elif fam=='B':
        Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(x); r=dist(track,sx,sy,tq,la,lo); g,h=gh(r); D=(g*Vm**2+h*Vm)/100
    else:
        Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm=unpack(x); r=dist(track,sx,sy,tq,la,lo); g,h=gh(r); D=(g*Vm**2+h*Vm)/100
    return D,background(bg,tq,tq+lo/15.0),r
def radial(fam,row,track,rr):
    x=np.array(row['x']); Pc=row['Pc']; _,unpack,_,_=make_res(fam,Pc,track)
    if fam=='A':
        parts,sx,sy,bg,Dtot=unpack(x); D=defA(rr,parts); V=vgA_rho(rr,parts,Pc,Dtot,DENS,parts[0][1])*KT
    elif fam=='B':
        Rm,n,A,X1,X2,sx,sy,bg,Dtot,gh,Vm=unpack(x); g,h=gh(rr); D=(g*Vm**2+h*Vm)/100; V=windB(rr,Vm,Rm,n,A,X1,X2)*KT
    else:
        Rm,n,A,X1,X2,a,R2,W2,sx,sy,bg,Dtot,gh,Vm=unpack(x); g,h=gh(rr); D=(g*Vm**2+h*Vm)/100; V=Vm*shapeC(rr,Rm,n,A,X1,X2,a,R2,W2)*KT
    return Dtot-D, V, (sx,sy), bg    # pressure rise above centre (hPa), gradient-level wind (kt)
