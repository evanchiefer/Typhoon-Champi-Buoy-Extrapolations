import sys, json, time
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import mc
from core import RES
from multiprocessing import Pool
if __name__=='__main__':
    S=mc.SRC; jobs=[]
    for src in S:
        for i in range(40): jobs.append(('C','ir',(src,),10_000*S.index(src)+i,True))
    for i in range(500): jobs.append(('C','ir',S,900_000+i,True))          # all sources, wind consensus
    SO=tuple(x for x in S if x!='intensity')
    for i in range(250): jobs.append(('C','ir',SO,800_000+i,False))       # structure only
    for i in range(250): jobs.append(('C','bt',S,950_000+i,True))          # JTWC best-track positions

    for fam in ('A','B'):
        for i in range(200): jobs.append((fam,'ir',S,700_000+i+1000*(fam=='B'),True))
    for i in range(250): jobs.append(('C','ir',S,960_000+i,True,'ramp'))   # log-ramp density check
    t0=time.time(); res=[]
    with Pool(2) as pool:
        for j,d in enumerate(pool.imap_unordered(mc.trial,jobs,chunksize=2)):
            res.append(d)
            if j%250==0: print('%d/%d %.0f s'%(j,len(jobs),time.time()-t0),flush=True)
    json.dump(res,open(os.path.join(RES,'mc5.json'),'w')); print('ALL DONE %.0f s'%(time.time()-t0))
