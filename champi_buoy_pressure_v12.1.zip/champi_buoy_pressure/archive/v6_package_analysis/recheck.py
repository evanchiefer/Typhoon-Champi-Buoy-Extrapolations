# Re-solve every primary-model trial that ended below 860 hPa with a much broader multistart; keep whichever fit is better.
import sys, json, numpy as np
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import mc
from core import *
from multiprocessing import Pool
def rebuild(d):
    fam,track,sources,seed,use_vg=d['fam'],d['track'],tuple(d['sources']),d['seed'],d['use_vg']
    rng=np.random.default_rng(seed); pri=dict(PRI)
    if use_vg: pri['Vg']=VG_PRIOR
    off0,soff=TRACKS[track][2].copy(),TRACKS[track][3]; data=P.copy(); s=sig_obs()
    # replay the exact random draws of mc.trial (same order)
    if 'noise' in sources: data=data+rng.normal(0,s)
    if 'bias' in sources: data=data+rng.normal(0,0.5)
    if 'center' in sources: off0=off0+rng.normal(0,soff,2)
    if 'Rm' in sources: pri['Rm']=(rng.normal(*PRI['Rm']),PRI['Rm'][1])
    if 'shape' in sources:
        z=rng.normal(); pri['n']=(PRI['n'][0]+z*PRI['n'][1],PRI['n'][1]); pri['I']=(PRI['I'][0]-z*PRI['I'][1],PRI['I'][1])
    if 'decay' in sources: pri['v14']=(rng.normal(*PRI['v14']),PRI['v14'][1])
    if 'Pn' in sources: pri['Pn']=(rng.normal(*PRI['Pn']),PRI['Pn'][1])
    if use_vg and 'intensity' in sources: pri['Vg']=(rng.normal(*VG_PRIOR),VG_PRIOR[1])
    pri['dens']=dict(DENS,mode=d.get('dens','thermo'))
    if 'density' in sources:
        pri['dens'].update(dTc=rng.uniform(0.5,4.5),dTw=rng.uniform(0.0,2.5),Tv_env=rng.normal(305.0,1.5),rwf=rng.uniform(0.5,1.2),r0f=rng.uniform(0.5,1.5),Rout=rng.uniform(200,600))
    pri['off']=off0; return fam,track,pri,data,s
def resolve(d):
    fam,track,pri,data,s=rebuild(d)
    def res(q): return make_res(fam,q[0],track,pri=pri,data=data,sig=s)[0](q[1:])
    _,_,lb,ub=make_res(fam,880.0,track,pri=pri); lb=np.r_[830.0,lb]; ub=np.r_[912.0,ub]
    rows=[r for r in mc.SCAN if r['name']=='%s_%s'%(fam,track)]
    st=[np.r_[r['Pc'],r['x']] for r in rows[::2]]                     # warm starts from every other profile-scan solution (840..910)
    best=None; cand=[]
    for q0 in st:
        try: r=least_squares(res,np.clip(q0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=6000)
        except Exception: continue
        cand.append((2*r.cost,r.x[0]))
        if best is None or r.cost<best.cost: best=r
    return dict(seed=d['seed'],old_Pc=d['Pc'],old_chi2=d['chi2'],new_Pc=float(best.x[0]),new_chi2=float(2*best.cost),
                prior_n=pri['n'][0],prior_Vg=pri['Vg'][0] if 'Vg' in pri else None,prior_Rm=pri['Rm'][0])
if __name__=='__main__':
    MC=json.load(open(os.path.join(RES,'mc5.json')))
    low=[d for d in MC if d['fam']=='C' and len(d['sources'])>1 and d['Pc']<860]
    print('trials below 860:',len(low),flush=True)
    with Pool(2) as pool: out=pool.map(resolve,low)
    for o in sorted(out,key=lambda o:o['old_Pc']):
        print('seed %6d: was %.1f (chi2 %.1f) -> now %.1f (chi2 %.1f) | drawn priors: n %.2f  Vg %s  Rm %.1f'%(o['seed'],o['old_Pc'],o['old_chi2'],o['new_Pc'],o['new_chi2'],o['prior_n'],'%.0f'%o['prior_Vg'] if o['prior_Vg'] else '-',o['prior_Rm']))
    json.dump(out,open(os.path.join(RES,'recheck.json'),'w'))
