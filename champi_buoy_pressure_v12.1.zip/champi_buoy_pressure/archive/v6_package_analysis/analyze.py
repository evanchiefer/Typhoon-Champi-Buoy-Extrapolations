import sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from core import DATA, RES
import json, numpy as np
MC=json.load(open(os.path.join(RES,'mc5.json'))); INP=json.load(open(os.path.join(DATA,'inputs.json'))); SC=json.load(open(os.path.join(RES,'scan_main.json')))
jh=np.array([x[0] for x in INP['jtwc_p']]); jp=np.array([x[1] for x in INP['jtwc_p']]); JT=float(np.interp(17.55,jh,jp))
def rsd(v): p=np.percentile(v,[16,84]); return float((p[1]-p[0])/2)
multi=lambda d: len(d['sources'])>1
def sel(fam,track,vg,dens='thermo'):
    return np.array([d['Pc'] for d in MC if d['fam']==fam and d['track']==track and multi(d) and d['use_vg']==vg and d.get('dens','thermo')==dens])
budget={}
for src in ('noise','bias','center','Rm','shape','decay','Pn','intensity','density'):
    v=np.array([d['Pc'] for d in MC if d['fam']=='C' and d['sources']==[src]]); budget[src]=rsd(v); print('  %-9s %.2f (n=%d)'%(src,budget[src],len(v)))
runs={}
for key,(fam,tr,vg,dm) in {'with_intensity':('C','ir',True,'thermo'),'structure_only':('C','ir',False,'thermo'),'bt_check':('C','bt',True,'thermo'),
                           'ramp_check':('C','ir',True,'ramp'),'alt_A':('A','ir',True,'thermo'),'alt_B':('B','ir',True,'thermo')}.items():
    v=sel(fam,tr,vg,dm); pq=np.percentile(v,[2.5,16,50,84,97.5])
    runs[key]=dict(n=int(len(v)),q=[float(x) for x in pq],sd=rsd(v),p_below_jtwc=float((v<JT).mean()),at_bound=int((v<830.5).sum()))
    print('%-15s n=%d median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | P(<%.1f)=%.3f | at bound %d'%(key,len(v),pq[2],pq[1],pq[3],pq[0],pq[4],JT,(v<JT).mean(),runs[key]['at_bound']))
best={nm:min([r for r in SC if r['name']==nm],key=lambda r:r['chi2']) for nm in ('A_ir','B_ir','C_ir')}
for nm,b in best.items(): print('  %s best chi2 %.2f at %.0f hPa'%(nm,b['chi2'],b['Pc']))
w={k:float(np.exp(-0.5*(best[k+'_ir']['chi2']-best['C_ir']['chi2']))) for k in ('A','B','C')}; ws=sum(w.values()); w={k:v/ws for k,v in w.items()}
meds={'A':runs['alt_A']['q'][2],'B':runs['alt_B']['q'][2],'C':runs['with_intensity']['q'][2]}
mbar=sum(w[k]*meds[k] for k in w); budget['family']=float(np.sqrt(sum(w[k]*(meds[k]-mbar)**2 for k in w)))
print('  model weights',{k:round(v,3) for k,v in w.items()},'| structural sd %.2f'%budget['family'])
S={'A':sel('A','ir',True),'B':sel('B','ir',True),'C':sel('C','ir',True)}
def wq(wt,ps=(2.5,16,50,84,97.5)):
    v=np.concatenate([S[k] for k in 'ABC']); ww=np.concatenate([np.full(len(S[k]),wt[k]/len(S[k])) for k in 'ABC'])
    o=np.argsort(v); c=np.cumsum(ww[o]); c/=c[-1]; return [float(np.interp(p/100,c,v[o])) for p in ps], float(ww[v<JT].sum()/ww.sum())
for lab,wt in (('fit-quality weights',w),('equal weights',dict(A=1/3,B=1/3,C=1/3)),('primary model only',dict(A=0,B=0,C=1))):
    qq,pb=wq(wt); print('%-20s median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | P(below JTWC) %.2f'%(lab,qq[2],qq[1],qq[3],qq[0],qq[4],pb))
qq,pb=wq(w)
final=dict(median=qq[2],lo68=qq[1],hi68=qq[3],lo95=qq[0],hi95=qq[4],p_below_jtwc=pb,total_sd=(qq[3]-qq[1])/2,jtwc_1733=JT,budget=budget,runs=runs,weights=w)
json.dump(final,open(os.path.join(RES,'final.json'),'w'),indent=1)
print('FINAL (mixture): median %.1f | 68%% %.1f-%.1f | 95%% %.1f-%.1f | 1-sigma %.1f'%(qq[2],qq[1],qq[3],qq[0],qq[4],final['total_sd']))
