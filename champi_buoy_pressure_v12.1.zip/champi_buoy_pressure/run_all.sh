#!/usr/bin/env bash
# Full reproduction of the v12.1 analysis (v12 plus the follow-up checks). Python 3 with numpy, scipy, matplotlib (openpyxl only for step 0).
# Runtime on 2 CPU cores: preparation ~10 min, best fits / diagnostics / scan ~1.5 h, Monte Carlo ~17 h (resumable), centre checks ~35 min, checks and figures ~10 min.
# PY can point at another interpreter: PY=/path/to/python ./run_all.sh
set -e
PY=${PY:-python3}
cd "$(dirname "$0")"
# 0. buoy record and JTWC table from the spreadsheet (optional: model/inputs.json is shipped)
# $PY data_source/build_inputs.py
cd model
# 1. SAR (optional: the per-pass products in sar/ are shipped). Needs the NOAA/STAR level-2 files (names + sha256 in sar/sar_files.json):
# $PY sar/extract_all.py /path/to/star_files && for k in S1D_20_0909 R3_20_0920 R3_20_2115 R3_21_0929 R3_21_2123; do $PY sar/structure.py $k <lon> <lat>; done
# $PY sar/crosscal09.py && $PY sar/crosscal.py ir_eye_fixes.json
$PY sar/endpoint.py                       # structure at 17:33Z (09Z endpoint: Sentinel-1D shape 0.75 + RCM-3 0.25; 21:15Z) -> sar/structure_1733.json
$PY logwind.py                            # log-layer conversion (alpha at the RMW and the log-layer case), Franklin check -> logwind_priors.json
$PY track_gp.py                           # centre track model from the IR and SAR/ATMS fixes (v11 form, drift 1 km) -> track_gp.json
$PY track_hier.py                         # v12: track models over the IR-surface drift amplitude and its posterior -> track_variants.npz, track_hier.json
$PY gen_gradref.py                        # reference pressure gradients for the position term of the reading errors -> grad_ref.json
# 2. fits
$PY cbest.py                              # best fit per configuration (Monte Carlo starting points) -> cbest.json
$PY ladder12.py 2 > ladder12.log          # what each v12 change does, best fits -> ladder12.json
$PY weights12.py 2 > weights12.log        # best fits, buoy-conservation diagnostics, leave-one-out, weights -> weights12.json, rescale.json
$PY scan12.py T_gp,U_gp,A_gp,T_bt,T_gp_novg scan_v12.json 2 > scan12.log   # profile likelihood for Figure 2
# 3. Monte Carlo (resumable: rerun the same command after an interruption)
$PY mc12.py 2
# 4. checks, combination, figures
for v in interp nat2115 nat09; do $PY sarcheck.py $v; done
$PY gapcheck.py && $PY bounds.py
$PY analyze12.py > analyze12.log
$PY cfits12.py > cfits12.log
$PY centre12.py > centre12.log && $PY centre_map.py 2 > centre_map.log && $PY centre_compare.py > centre_compare.log && $PY centretrials12.py > centretrials12.log   # centre checks (Figure 3)
$PY irls_check.py > irls_check.log && $PY wander_offset_check.py > wander_offset_check.log   # v12.1 checks (reading-error gradients; wander and offset bounds)
$PY fig1.py && $PY fig2.py && $PY fig3_centre.py
$PY make_readme12.py && cp README.md ../README.md
