# Figure 2: central pressure and its uncertainty (v12)
import sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
HERE=os.path.dirname(os.path.abspath(__file__))
F=json.load(open(os.path.join(HERE,'final12.json'))); SC=json.load(open(os.path.join(HERE,'scan_v12.json')))
BD=json.load(open(os.path.join(HERE,'bounds.json'))); SCK=json.load(open(os.path.join(HERE,'sarcheck.json')))
MC=json.load(open(os.path.join(HERE,'mc12.json')))
_c={d['seed']:d for d in MC if d['tag']=='conv10' and d['fam']=='T'}      # headline ring model: better of the 4- and 10-start fits (as analyze12.py)
MC=[(dict(_c[d['seed']],tag='head') if (d['tag']=='head' and d['fam']=='T' and d['seed'] in _c and _c[d['seed']]['chi2']<d['chi2']-1e-9) else d) for d in MC]
H=F['headline']; HQ=H['q']; CS=F['cases']
def curve(name):
    d=sorted([r for r in SC if r['name']==name],key=lambda r:r['Pc']); return np.array([r['Pc'] for r in d]),np.array([r['chi2'] for r in d]),d
fig=plt.figure(figsize=(23,21)); gs=fig.add_gridspec(3,3,width_ratios=[1,1,1.05],height_ratios=[1,1.35,0.42],hspace=0.56,wspace=0.42,top=0.9,bottom=0.05)
A1=fig.add_subplot(gs[0,0]); A2=fig.add_subplot(gs[0,1]); A3=fig.add_subplot(gs[0,2]); gb=gs[1,:].subgridspec(1,3,width_ratios=[1,0.62,1.75],wspace=0.0)
B1=fig.add_subplot(gb[0,0]); B2=fig.add_subplot(gb[0,2]); C1=fig.add_subplot(gs[2,1:])
JT=F['jtwc_1733']; w=H['weights']
# (a) profile likelihood, the Monte Carlo likelihood (peak-wind constraint, Student-t errors)
for nm,c,ls,lw,lab in (('T_gp',DBL,'-',2.8,'ring model: SAR eye shape + secondary ring (weight %.2f)'%w['T']),('T_bt',DBL,'--',1.6,'  same, JTWC best-track positions'),
                       ('U_gp',GRN,'-',1.5,'SAR eye shape, no secondary ring (weight %.2f)'%w['U']),('A_gp',ORA,'-',1.5,'two-ring Holland (weight %.2f)'%w['A']),
                       ('T_gp_novg',GRY,':',1.8,'ring model without the peak-wind constraint')):
    p,cc,_=curve(nm); A1.plot(p,cc-cc.min(),color=c,ls=ls,lw=lw,label=lab)
for lv,tx in ((1,'68%'),(3.84,'95%')): A1.axhline(lv,color=INK2,lw=0.9,ls=':'); A1.text(839,lv+0.15,tx,fontsize=10.5,color=INK2)
A1.axvline(JT,color=RED,lw=1.4,ls='--'); A1.text(JT+0.8,0.15,'JTWC\n%.0f hPa'%JT,fontsize=10.5,color=RED,va='bottom',ha='left')
A1.set_xlim(838,911); A1.set_ylim(0,10); A1.set_xlabel('central pressure at 17:33Z (hPa)'); A1.set_ylabel('misfit above each model\'s best fit (Δχ²)')
A1.set_title('a   Fit quality vs central pressure\n     (each curve relative to its own best fit)',loc='left',fontweight='bold')
A1.legend(loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=1,frameon=False,fontsize=9.6)
# (b) wind-pressure relation implied by the buoy (structure-only scan: no intensity input)
for nm,c,lab,lw in (('T_gp_novg',DBL,'buoy + satellite structure, no wind input (band: α 0.84–0.93, +4–20 kt)',2.8),('T_gp',BLU,'with the peak-wind constraint',1.6)):
    _,_,d=curve(nm); pc=np.array([r['Pc'] for r in d]); vg=np.array([r['vg'] for r in d]); vg=np.array([np.median(vg[max(0,i-1):i+2]) for i in range(len(vg))])
    if nm=='T_gp_novg': A2.fill_betweenx(pc,0.837*vg+4,0.934*vg+20,color=c,alpha=0.12,lw=0)
    A2.plot(0.885*vg+10,pc,color=c,lw=lw,label=lab)
CON=[r for r in json.load(open(os.path.join(HERE,'fits_constrained.json'))) if r['name']=='T_con_gp' and r['tag']=='median'][0]
A2.plot(0.885*CON['vg']+10,CON['Pc'],'o',ms=12,color=BLU,mec=INK,mew=1.2,zorder=7,label='final fit (median)')
A2.axvspan(144,158,color=GRY,alpha=0.12,lw=0,label='peak-wind constraint 151 ± 7 kt')
pts=[('JTWC best track 18Z',160,895,RED,'*',16),('JTWC best track 12Z',155,902,RED,'*',12),('D-MINT ATMS 17:02Z',147,906,INK2,'D',8),('D-MINT ATMS 16:41Z',150,907,INK2,'D',8)]
for lab,v,p_,c,mk,ms in pts: A2.plot(v,p_,mk,ms=ms,color=c,mec=INK,mew=0.8,label=lab,zorder=6)
vv=np.linspace(120,200,100); A2.plot(vv,1010-(vv/6.7)**(1/0.644),color=INK2,lw=1.0,ls='--',label='Atkinson–Holliday 1977 (context only)')
A2.set_xlim(120,200); A2.set_ylim(912,840); A2.set_xlabel('equivalent peak 1-min surface wind (kt)'); A2.set_ylabel('central pressure (hPa)')
A2.set_title('b   Wind–pressure relation implied by the buoy\n     (1-min ≈ 0.885 × gradient + 10 kt)',loc='left',fontweight='bold')
A2.legend(loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=2,frameon=False,fontsize=9.4)
# (c) Monte Carlo
pick=lambda tg,f=None: np.array([d['Pc'] for d in MC if d['tag']==tg and (f is None or d['fam']==f)])
def pool(tg,wt):
    v=[pick(tg,f) for f in 'TUA']; return np.concatenate(v),np.concatenate([np.full(len(x),wt[f]/max(1,len(x))) for x,f in zip(v,'TUA')])
allv,allw=pool('head',w); wi=pick('head','T'); so=pick('v11chk_structure_only','T'); o4,o4w=pool('S24_flat4km_irf',w); fr,frw=pool('a20_free',CS['a20_free']['weights'])
bins=np.arange(838,914,2)
A3.hist(allv,bins=bins,weights=allw,density=True,color=LBL,edgecolor=SURF,lw=0.8,label='combined: three models weighted (%d trials)'%len(allv))
A3.hist(wi,bins=bins,density=True,histtype='step',color=DBL,lw=1.8,label='ring model alone (%d)'%len(wi))
A3.hist(fr,bins=bins,weights=frw,density=True,histtype='step',color=GRN,lw=2,label='sensitivity: no constraint at 2× radius (%d)'%len(fr))
A3.hist(so,bins=bins,density=True,histtype='step',color=GRY,lw=2,label='ring model, structure only (%d)'%len(so))
A3.hist(o4,bins=bins,weights=o4w,density=True,histtype='step',color=PUR,lw=2,ls='--',label='check: flat ±4 km centre error (%d)'%len(o4))
pq=HQ; ymax=A3.get_ylim()[1]
A3.axvspan(pq[1],pq[3],color=BLU,alpha=0.10,lw=0); A3.axvline(pq[2],color=DBL,lw=2.4)
A3.text(pq[2],ymax*1.03,'combined median %.0f hPa\n68%%: %.0f–%.0f   95%%: %.0f–%.0f\n(three profile models, weighted by fit to buoy + SAR)'%(pq[2],pq[1],pq[3],pq[0],pq[4]),ha='center',va='bottom',fontsize=12,fontweight='bold',color=DBL,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=2))
A3.axvline(JT,color=RED,lw=1.6,ls='--'); A3.text(JT+1.0,ymax*0.62,'JTWC %.0f hPa'%JT,fontsize=10.5,color=RED,bbox=dict(fc=SURF,ec='none',alpha=0.9,pad=1.5))
A3.set_xlim(838,914); A3.set_ylim(0,ymax*1.75); A3.set_xlabel('central pressure at 17:33Z (hPa)'); A3.set_ylabel('probability density (per hPa)')
A3.set_title('c   Monte Carlo over all uncertain inputs',loc='left',fontweight='bold'); A3.legend(loc='upper left',frameon=True,facecolor=SURF,edgecolor=GRID,framealpha=0.97,fontsize=9.3)
# (d) budget
lab={'shape':'inner-eye wind shape','decay':'wind ratios at 1.4× and 2× radius (SAR)','ring':'secondary wind maximum (SAR)','alpha':'10-m to gradient conversion at the RMW','alpha20':'conversion at 2× radius (α20)',
     'Rm':'radius of max wind (incl. tilt)','center':'centre position (track, drift, wander)','ellipse':'oval eyewall (size, orientation)','noise':'reading scatter',
     'bias':'barometer calibration','Pn':'environmental pressure','intensity':'peak surface wind (±8 kt, incl. SAR calibration)','family':'profile-shape choice (3 models)',
     'density':'air density profile (warm eye, cool eyewall)'}
Bd=F['budget']; items=sorted(Bd.items(),key=lambda kv:kv[1]); y=np.arange(len(items)); TS=H['half68']
B1.barh(y,[v for _,v in items],color=[ORA if k=='family' else BLU for k,_ in items],height=0.62)
for yy,(k,v) in zip(y,items): B1.text(v+0.12,yy,'%.1f'%v,va='center',fontsize=11)
B1.set_yticks(y); B1.set_yticklabels([lab[k] for k,_ in items]); B1.grid(axis='y',visible=False)
B1.axvline(TS,color=DBL,lw=1.6,ls='--'); B1.text(TS+0.12,-0.6,'combined ±%.1f hPa (1σ)'%TS,fontsize=11,color=DBL)
B1.set_xlim(0,max(max(v for _,v in items),TS)*1.3); B1.set_xlabel('contribution to uncertainty (hPa, 1σ)'); B1.set_title('d   Uncertainty budget (weighted over the three models)',loc='left',fontweight='bold')
# (e) comparison
qr=lambda tg: (CS[tg]['q'][2],CS[tg]['q'][1],CS[tg]['q'][3],CS[tg]['q'][0],CS[tg]['q'][4])
pm=lambda tg,f: (CS[tg]['per_model'][f]['q'][2],CS[tg]['per_model'][f]['q'][1],CS[tg]['per_model'][f]['q'][3],CS[tg]['per_model'][f]['q'][0],CS[tg]['per_model'][f]['q'][4])
aw=lambda k: (F['alt_weights'][k]['q'][2],F['alt_weights'][k]['q'][1],F['alt_weights'][k]['q'][3],F['alt_weights'][k]['q'][0],F['alt_weights'][k]['q'][4])
sq=SCK['interp']['both']
est=[('This work: combined estimate',*HQ[2:3],HQ[1],HQ[3],HQ[0],HQ[4],BLU),
     ('Ring model alone',*pm('head','T'),BLU),('No-ring model alone',*pm('head','U'),BLU),('Two-ring Holland alone',*pm('head','A'),BLU),
     ('Sensitivity: no constraint at 2× radius',*qr('a20_free'),GRN),('Sensitivity: α20 flat 0.77–0.91',*qr('a20_flat'),GRN),('Sensitivity: α20 log-layer 0.77 ± 0.03',*qr('a20_loglayer'),GRN),
     ('Sensitivity: buoy only (no SAR outer terms)',*qr('S27_buoy_only'),GRN),
     ('Ring model, no wind input',*pm('v11chk_structure_only','T'),GRY),
     ('Check: SAR winds integrated inward',sq[2],sq[1],sq[3],sq[0],sq[4],GRN),
     ('Sensitivity: 21:15Z structure only',*qr('S25_2115_only'),GRN),('Sensitivity: 09Z structure only',*qr('S26_09Z_only'),GRN),
     ('Centre: drift fixed at 3 km',*qr('S5_drift_fixed3'),PUR),('Centre: no wander',*qr('S7_no_wander'),PUR),('Centre: STAR 09:09Z centre',*qr('S23_star_centre'),PUR),
     ('Centre: STAR centres, all three passes',*qr('S23c_star_all'),PUR),('Check: flat ±4 km centre error',*qr('S24_flat4km_irf'),PUR),('Check: JTWC best-track positions',*qr('v11chk_bt'),ORA),
     ('Weights: buoy leave-one-out (v11 method)',*aw('pbma_buoy'),GRY),('Weights: BIC',*aw('BIC_eff'),GRY),('Weights: equal',*aw('equal'),GRY),
     ('Previous version (v11)',888.9,880.3,893.9,871.5,899.3,GRY),('Previous version (v10)',884.1,875.8,892.1,867.2,899.1,GRY),
     ('JTWC best track (interp. 17:33Z)',JT,None,None,None,None,RED),('D-PRINT (16:30–17:30Z)',903,902,904,None,None,INK2),
     ('ATMS (SATCON plot, ~17Z)',903,None,None,None,None,INK2),('D-MINT ATMS (16:41, 17:02Z)',906.5,906,907,None,None,INK2),('SATCON (~17Z)',910,None,None,None,None,INK2)]
CON=[r for r in json.load(open(os.path.join(HERE,'fits_constrained.json'))) if r['name']=='T_con_gp' and r['tag']=='median'][0]
n=len(est); NOURS=23
for i,(nm,v,l1,h1,l2,h2,col) in enumerate(est):
    yy=n-1-i; ours=i<NOURS
    if l2 is not None: B2.plot([l2,h2],[yy,yy],color=col,lw=3,alpha=0.4,solid_capstyle='round')
    if l1 is not None: B2.plot([l1,h1],[yy,yy],color=col,lw=9 if ours else 4,alpha=0.45,solid_capstyle='round')
    B2.plot(v,yy,'o',ms=11 if ours else 8,color=col,mec=SURF,mew=1.5)
    txt=('%.0f  (68%%: %.0f–%.0f, 95%%: %.0f–%.0f)'%(v,l1,h1,l2,h2)) if ours else ('%.0f'%v if l1 is None else '%g–%g'%(l1,h1))
    B2.text(v if ours else v+1.0,yy+0.3,txt,fontsize=10.6,ha='center' if ours else 'left')
B2.axvline(909.4,color=RED,lw=1.3,ls=':'); B2.text(910.0,n-1.3,'buoy reading\n909.4 hPa,\n~%.0f km from\ncentre'%CON['r17'],fontsize=10.5,va='top')
B2.set_yticks(range(n)); B2.set_yticklabels([e[0] for e in est][::-1],fontsize=10.8); B2.set_xlim(845,925); B2.set_ylim(-0.7,n-0.2); B2.grid(axis='y',visible=False)
B2.set_xlabel('central pressure near 17Z, 20 Oct (hPa)'); B2.set_title('e   Comparison with sensitivity cases, checks and operational/satellite estimates   (thick bar 68%, thin bar 95%)',loc='left',fontweight='bold')
# (f) how far the data can be pushed
rows=BD['rows']; yb=np.arange(len(rows))[::-1]
for yy,(lab_,d,pc) in zip(yb,rows):
    C1.barh(yy,pc-BD['p_buoy'],left=BD['p_buoy'],color=BLU if pc<JT else ORA,alpha=0.55,height=0.6)
    C1.text(pc-0.4,yy,'%.1f hPa'%pc,ha='left',va='center',fontsize=11.5,fontweight='bold')
C1.set_yticks(yb); C1.set_yticklabels([r_[0] for r_ in rows],fontsize=11); C1.grid(axis='y',visible=False)
C1.axvline(JT,color=RED,lw=1.6,ls='--'); C1.text(JT-0.3,-0.75,'JTWC %.0f'%JT,color=RED,fontsize=11,va='center')
C1.set_xlim(BD['p_buoy'],870); C1.set_ylim(-1.0,len(rows)-0.4)
C1.set_xlabel('highest central pressure consistent with the 17:04Z reading (909.4 hPa at %.0f km effective distance)\nand the measured SAR winds (hPa)'%BD['r_buoy'])
C1.set_title('f   How far the data can be pushed: increasingly adverse assumptions, no profile model',loc='left',fontweight='bold')
fig.suptitle('Typhoon Champi (29W) — central pressure at 17:33Z, 20 October 2026, from the drifting-buoy eyewall pass',x=0.01,y=1.0,ha='left',fontsize=17,fontweight='bold')
fig.text(0.01,0.975,'Three storm profiles in gradient balance (SAR-measured eye shape with the secondary wind ring; the same without the ring; a two-ring Holland profile), weighted by how well each fits\n'
         'the buoy readings and the SAR structure together (AIC with effective parameter counts). One 10-m-to-gradient conversion profile (0.885 at the max-wind radius; α20 at twice the radius\n'
         'fitted, prior 0.80 ± 0.05) feeds all SAR wind ratios. Student-t reading errors; centre from a track model of the IR and SAR/ATMS fixes with its IR-to-surface drift drawn from its posterior.\n'
         'Storm structure from 500-m SAR winds (09Z and 21:15Z, interpolated to 17:33Z). Sensitivity cases use the same seeds. JTWC and satellite pressures used for comparison only.',fontsize=12,color=INK2,va='top')
fig.text(0.01,-0.005,'Sources: SAR winds NOAA/NESDIS/STAR (RCM imagery © Government of Canada 2026; contains modified Copernicus Sentinel data); best track JTWC (provisional working best track); D-PRINT, D-MINT, SATCON, ADT/AiDT: UW-Madison CIMSS; Atkinson & Holliday (1977). Full references in README.',fontsize=10.5,color=INK2)
fig.savefig(os.path.join(HERE,'fig2_central_pressure.png'),dpi=150,bbox_inches='tight'); print('saved')
