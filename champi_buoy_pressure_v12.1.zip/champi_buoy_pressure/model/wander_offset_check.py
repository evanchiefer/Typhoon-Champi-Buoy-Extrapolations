# Checks against two of the other group's v12.1 changes [B9, B10]: how large the fitted centre wander is against its prior and its +-12 km bound,
# and how large the fitted constant offsets get in the cases that fit one (bound +-40 km around the prior centre; their old bound was 15 km).
# Reads mc12.json and track_variants.npz; writes wander_offset_check.json.
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import core as C
from core import NW, NBASE
MC=json.load(open(os.path.join(HERE,'mc12.json'))); H=C._tv()['hier']; C.set_track(int(H['i_median']))
out=dict(wander_bound_km=12.0,offset_bound_km=40.0,prior_sd_per_axis_km=[float(x) for x in np.sqrt(np.diag(C.CWIN))])
cv={d['seed']:d for d in MC if d['tag']=='conv10' and d['fam']=='T'}
for f in 'TUA':
    D=[d for d in MC if d['tag']=='head' and d['fam']==f]
    if f=='T': D=[(cv[d['seed']] if d['seed'] in cv and cv[d['seed']]['chi2']<d['chi2']-1e-9 else d) for d in D]
    W=np.abs(np.array([d['fit']['x'][-2*NW:] for d in D]))
    out['wander_'+f]=dict(n=len(D),median_abs=float(np.median(W)),p95_abs=float(np.percentile(W,95)),max_abs=float(W.max()),
                          trial_rms_median=float(np.median(np.sqrt((W**2).mean(1)))),n_trials_within_0p5km_of_bound=int((W>11.5).any(1).sum()))
nb=NBASE['T']
for tg in ('S24_flat4km_irf','v11chk_bt','v11chk_v10_geometry'):
    D=[d for d in MC if d['tag']==tg and d['fam']=='T']; O=np.abs(np.array([d['fit']['x'][1+nb-8:1+nb-6] for d in D]))
    out['offset_'+tg]=dict(n=len(D),max_abs_km=float(O.max()),n_over_15km=int((O>15).any(1).sum()))
json.dump(out,open(os.path.join(HERE,'wander_offset_check.json'),'w'),indent=1); print(json.dumps(out,indent=1))
