# Fitted storm centre at 17:33Z in every ring-model trial of the headline and the centre-related cases, as km east / north of the smoothed
# IR eye track at 17:33Z (posterior-median track model). Headline ring-model trials use the better of the 4- and 10-start fits, as in
# analyze12.py. Writes centretrials12.json (per case: centres, mean, sd, correlation, median Pc).
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc, core as C, track_gp as TG
TQ=17.55; CASES={'head':'headline','S23_star_centre':'STAR 09:09Z centre','S23b_star_both':'STAR 09:09Z and 21:15Z centres','S23c_star_all':'STAR centres, all three SAR passes','S24_flat4km_irf':'flat ±4 km centre error (v10 track)','v11chk_bt':'JTWC best-track positions',
                 'S5_drift_fixed3':'IR-surface drift fixed at 3 km','S7_no_wander':'no centre wander'}
H=json.load(open(os.path.join(HERE,'track_hier.json'))); G=TG.TrackGP(so=H['median_flat']); IR=G.mean([TQ],surface=False)[0]
lat0,lon0=TG.LAT0,TG.LON0; KX,KY=TG.KX,TG.KY
def to_frame(la,lo): return float((lo-lon0)*KX-IR[0]),float((la-lat0)*KY-IR[1])
def centre(d):
    j=dict(mc.DEF); j.update({k:d[k] for k in ('fam','track','wander','ell','a20case','track_model') if k in d}); j['seed']=d['seed']
    tk=d['inputs'].get('track_key')
    if j['track']=='gp': C.set_track(tk if tk in ('v11','star','star2','star3') else int(tk))
    pri=C.get_pri(d['variant'] if 'variant' in d else 'interp',j['a20case']); pri=dict(pri,wander=j['wander'],ell=j['ell'])
    res,unpack,_,_=C.make_res(d['fam'],d['Pc'],j['track'],pri=pri); u=unpack(np.array(d['fit']['x'][1:]))
    sx,sy=res.shift(u,np.array([TQ])); fa,fo=C.TRACKS[j['track']][:2]; cla=float(fa(np.array([TQ]))[0]); clo=float(fo(np.array([TQ]))[0])
    sx=float(np.atleast_1d(sx)[0]); sy=float(np.atleast_1d(sy)[0]); la=cla+sy/111.0; lo=clo+sx/(111.0*np.cos(np.radians(la)))
    return to_frame(la,lo)
if __name__=='__main__':
    MC=json.load(open(os.path.join(HERE,'mc12.json'))); cv={d['seed']:d for d in MC if d['tag']=='conv10' and d['fam']=='T'}
    out={}
    for tg,lab in CASES.items():
        D=[d for d in MC if d['tag']==tg and d['fam']=='T']
        if tg=='head': D=[(dict(cv[d['seed']],tag='head') if d['seed'] in cv and cv[d['seed']]['chi2']<d['chi2']-1e-9 else d) for d in D]
        P=np.array([centre(d) for d in D]); pc=np.array([d['Pc'] for d in D])
        out[tg]=dict(label=lab,n=len(D),E=P[:,0].tolist(),N=P[:,1].tolist(),mean=[float(P[:,0].mean()),float(P[:,1].mean())],sd=[float(P[:,0].std()),float(P[:,1].std())],
                     corr=float(np.corrcoef(P[:,0],P[:,1])[0,1]),Pc_median=float(np.median(pc)))
        o=out[tg]; print('%-18s n %4d  centre E %+.2f ± %.2f  N %+.2f ± %.2f km (r %+.2f)  ring-model Pc median %.1f'%(tg,o['n'],o['mean'][0],o['sd'][0],o['mean'][1],o['sd'][1],o['corr'],o['Pc_median']))
    out['ir_track_1733']=[float(IR[0]),float(IR[1])]
    json.dump(out,open(os.path.join(HERE,'centretrials12.json'),'w'))
