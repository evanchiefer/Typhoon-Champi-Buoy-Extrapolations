# Champi buoy analysis, v12 core (v11 paths kept: a20case=None, set_track('v11')): storm pressure profile + atmospheric background (environmental pressure, trend, S1/S2 tides) fitted to
# the drifting-buoy pressures. Profile families (gradient-wind balance with radially varying air density, except A):
#   A: two-ring Holland (1980) pressure profile
#   B: wind profile: power-law eye, dual-exponential decay outside the RMW (no secondary ring)
#   C: as B plus a Gaussian secondary wind ring (primary)
#   T: as C with the eye taken from the SAR-measured eye shape (table, raised to a power s) instead of a power law
#   U: as T without the secondary ring
# Geometry (v11):
#   'gp' track: surface centre from track_gp.py (hourly IR eye fixes + SAR/ATMS surface fixes, time-correlated wander); at each buoy reading
#            within 13-22Z the centre may move within the track's posterior covariance (parameters delta, whitened prior).
#   elliptical eyewall: RMW(theta) = RMW * (1 + e cos 2(theta - theta0)) from the SAR sector RMWs; the profile is evaluated at
#            r_eff = r / (1 + e(r) cos 2(theta - theta0)), e(r) = e0 inside 40 km, tapering outward.
#   'irf' (v10 primary: hourly fixes, linear, fixed offset +-2 km) and 'bt' (JTWC positions) kept as checks.
# Pc = background at 17:33Z minus the total storm deficit.
import os, json, numpy as np
from scipy.optimize import least_squares
from scipy.stats import qmc
HERE=os.path.dirname(os.path.abspath(__file__))
BASE=os.environ.get('CHAMPI_BASE',os.path.dirname(HERE))+os.sep
INP=json.load(open(os.path.join(HERE,'inputs.json')))
B_=np.array(INP['buoy']); t,lat,lon,P=B_[:,0],B_[:,1],B_[:,2],B_[:,3]
NB=len(t)
TC=17.55                                   # time of closest approach (17:33Z) at which Pc is reported
LST=t+lon/15.0                             # local solar time (h)
RHO=1.15; FCOR=2*7.292e-5*np.sin(np.radians(17.3)); KT=1/0.5144
# ---------------- centre tracks ----------------
fx=json.load(open(os.path.join(HERE,'ir_eye_fixes.json'))); th=np.array(sorted(int(k) for k in fx))
FLAT=np.array([fx[str(h)]['lat'] for h in th]); FLON=np.array([fx[str(h)]['lon'] for h in th])
IRLAT=np.polyfit(th,FLAT,2); IRLON=np.polyfit(th,FLON,2)
BT=np.array(INP['bt']); BTLAT=np.polyfit(BT[:,0],BT[:,1],3); BTLON=np.polyfit(BT[:,0],BT[:,2],3)
def _fixes(tq,c):   # v10 'irf': hourly IR eye fixes, linear between fixes; quadratic trend outside 07Z-00Z
    tq=np.asarray(tq,float); inside=(tq>=th[0])&(tq<=th[-1])
    v=np.interp(tq,th,FLAT if c=='lat' else FLON); q=np.polyval(IRLAT if c=='lat' else IRLON,tq)
    lo_=np.polyval(IRLAT if c=='lat' else IRLON,th[0]); hi_=np.polyval(IRLAT if c=='lat' else IRLON,th[-1])
    e0=(FLAT if c=='lat' else FLON)[0]-lo_; e1=(FLAT if c=='lat' else FLON)[-1]-hi_
    return np.where(inside,v,np.where(tq<th[0],q+e0,q+e1))
GPJ=json.load(open(os.path.join(HERE,'track_gp.json')))
GT=np.array(GPJ['grid_t']); GLA=np.array(GPJ['grid_lat']); GLO=np.array(GPJ['grid_lon']); GW=np.array(GPJ['grid_w'])
WIN=np.array(GPJ['win']); NW=len(WIN); CWIN=np.array(GPJ['cov_win']); LWIN=np.linalg.cholesky(CWIN+1e-9*np.eye(NW)); LWINI=np.linalg.inv(LWIN)
SD_GP=np.array(GPJ['sd_readings'])
# v12: track models over the IR-to-surface drift amplitude SO (track_hier.py). set_track() switches the module-level track arrays;
# each Monte Carlo trial selects one track model (no interpolation between them).
_TV={}
def _tv():
    if not _TV:
        f=os.path.join(HERE,'track_variants.npz'); _TV.update(dict(np.load(f)) if os.path.exists(f) else {})
        h=os.path.join(HERE,'track_hier.json'); _TV['hier']=json.load(open(h)) if os.path.exists(h) else None
    return _TV
_V11TRACK=(GLA,GLO,GW,CWIN,SD_GP); TRACK_NOW=['v11']
def set_track(key):
    """key: 'v11' (track_gp.json, SO = 1 km), an index into the SO grid of track_variants.npz, 'star' (STAR 09:09Z centre), 'star2' (STAR 09:09Z and 21:15Z centres) or 'star3' (all three STAR centres)"""
    global GLA,GLO,GW,CWIN,LWIN,LWINI,SD_GP
    if key==TRACK_NOW[0]: return
    if key=='v11': GLA,GLO,GW,CWIN,SD_GP=_V11TRACK
    else:
        V=_tv(); sel=(lambda a: V[key+'_'+a]) if key in ('star','star2','star3') else (lambda a: V[a][int(key)])
        GLA,GLO,GW,CWIN,SD_GP=sel('grid_lat'),sel('grid_lon'),sel('grid_w'),sel('cov_win'),sel('sd_readings')
    LWIN=np.linalg.cholesky(CWIN+1e-9*np.eye(NW)); LWINI=np.linalg.inv(LWIN); TRACK_NOW[0]=key
def so_index(so):
    g=np.array(_tv()['so']); return int(np.argmin(np.abs(g-so)))
TRACKS={'gp':(lambda tq:np.interp(tq,GT,GLA),lambda tq:np.interp(tq,GT,GLO),np.zeros(2),0.05),       # primary: offset is inside the track
        'irf':(lambda tq:_fixes(tq,'lat'),lambda tq:_fixes(tq,'lon'),np.array([7.13,-9.17]),2.0),     # v10 primary (check)
        'bt':(lambda tq:np.polyval(BTLAT,tq),lambda tq:np.polyval(BTLON,tq),np.array([0.0,0.0]),6.0)}  # JTWC best-track positions (check)
def has_wander(track,pri): return track=='gp' and pri.get('wander',True)
def wander_at(tq,dlt):
    """centre wander (km E, km N) at arbitrary times from its values at the window readings (GP kriging weights)"""
    if dlt is None: return 0.0,0.0
    W=np.array([np.interp(tq,GT,GW[:,k]) for k in range(NW)]).T.reshape(np.size(tq),NW); return W@dlt[:,0],W@dlt[:,1]
def troch_at(tq,tr):
    """sub-hourly trochoidal wobble between hourly fixes: circular wobble minus its linear interpolation between the whole hours"""
    if tr is None: return 0.0,0.0
    A,T,ph=tr; tq=np.asarray(tq,float); h0=np.floor(tq); f=tq-h0
    W=lambda s: (A*np.cos(2*np.pi*s/T+ph),A*np.sin(2*np.pi*s/T+ph))
    w0=W(h0); w1=W(h0+1); wt=W(tq); return wt[0]-(w0[0]+f*(w1[0]-w0[0])), wt[1]-(w0[1]+f*(w1[1]-w0[1]))
def geom(track,sx,sy,tq=t,la=lat,lo=lon):
    """buoy minus centre (km E, km N)"""
    fa,fo=TRACKS[track][:2]; cla=fa(tq); clo=fo(tq); kx=111.0*np.cos(np.radians((la+cla)/2))
    return (lo-clo)*kx-sx,(la-cla)*111.0-sy
def dist(track,sx,sy,tq=t,la=lat,lo=lon):
    dx,dy=geom(track,sx,sy,tq,la,lo); return np.hypot(dx,dy)
def r_eff(dx,dy,e0,th0):
    r=np.hypot(dx,dy); bear=np.arctan2(dx,dy); e=e0*np.exp(-np.maximum(r-40.0,0.0)/27.0)
    return r/(1.0+e*np.cos(2*(bear-np.radians(th0)))), r
# ---------------- background ----------------
def background(bg,tq=t,lst=LST):
    Pn,b1,c1,s1,c2,s2=bg; w=2*np.pi/24
    return Pn+b1*(tq-TC)+c1*np.cos(w*lst)+s1*np.sin(w*lst)+c2*np.cos(2*w*lst)+s2*np.sin(2*w*lst)
LST_C=TC+131.55/15.0
# ---------------- family A: two-ring Holland ----------------
def defA(r,parts):
    return sum(dP*(1-np.exp(-(R/np.maximum(r,0.05))**Bh)) for dP,R,Bh in parts)
RD=287.05
DENS=dict(mode='thermo',Tv_env=305.0,dTc=2.5,dTw=1.0,rwf=0.8,r0f=1.0,Rout=400.0)
def Tv_of_r(r,Rm,d):
    return d['Tv_env']+d['dTc']*np.exp(-(np.asarray(r)/(d['rwf']*Rm))**2)-d['dTw']*np.exp(-((np.asarray(r)-Rm)/12.0)**2)
def rho_profile(r,p_hPa,Rm,d,Pc,Pn):
    r=np.asarray(r,float)
    if d['mode']=='const': return np.full_like(r,RHO)
    if d['mode']=='thermo': return p_hPa*100/(RD*Tv_of_r(r,Rm,d))
    rc=Pc*100/(RD*(d['Tv_env']+d['dTc'])); re=Pn*100/(RD*d['Tv_env']); r0=d['r0f']*Rm
    return rc+(re-rc)*np.log1p(np.minimum(r,d['Rout'])/r0)/np.log1p(d['Rout']/r0)
def vgA_rho(r,parts,Pc,Dtot,d,Rm):
    r=np.asarray(r,float); g=0*r
    for dP,R,Bh in parts: x=(R/r)**Bh; g=g+dP*100*Bh*x*np.exp(-x)
    rho=rho_profile(r,Pc+Dtot-defA(r,parts),Rm,d,Pc,Pc+Dtot)
    rm=r*1e3; return np.sqrt(g/rho+(FCOR*rm/2)**2)-FCOR*rm/2
# ---------------- families B / C / T: wind profile + gradient balance ----------------
XE=np.linspace(0,1,401)
def shapeC(r,Rm,n,A,X1,X2,a,R2,W2,tab=None):
    r=np.asarray(r,float); x=np.maximum(r,0)/Rm
    inner=(np.interp(x,XE,tab)**n) if tab is not None else x**n
    v1=np.where(r<Rm,inner,(1-A)*np.exp(-(r-Rm)/X1)+A*np.exp(-(r-Rm)/X2))
    return v1+a*np.exp(-((r-R2)/W2)**2)
def vm_from_deficit(D,g0,h0): return (-h0+np.sqrt(h0**2+4*g0*D))/(2*g0)
def wind_deficit(Rm,n,A,X1,X2,a,R2,W2,Dtot,Pc,d,iters=3,tab=None):
    # gradient-wind balance with rho(r): D(r) = int_r^inf rho (V^2/r' + f V) dr'; Vm fixed so that D(0) = Dtot
    rr=np.concatenate([Rm*np.geomspace(1e-4,1,320)[:-1],Rm+np.concatenate([[0],np.geomspace(0.05,4000,800)])])
    v=shapeC(rr,Rm,n,A,X1,X2,a,R2,W2,tab); rho=np.full_like(rr,RHO); Bc=Pc+Dtot
    for it in range(1 if d['mode']=='const' else iters):
        fa=rho*v**2/rr; fb=rho*v
        ca=np.concatenate([[0],np.cumsum((fa[1:]+fa[:-1])/2*np.diff(rr))]); cb=np.concatenate([[0],np.cumsum((fb[1:]+fb[:-1])/2*np.diff(rr))])
        Ga=ca[-1]-ca; Gb=FCOR*(cb[-1]-cb)*1e3
        Vm=vm_from_deficit(Dtot*100,Ga[0],Gb[0])
        if d['mode']!='const': rho=rho_profile(rr,Bc-(Ga*Vm**2+Gb*Vm)/100,Rm,d,Pc,Bc)
    def gh(r):
        r=np.asarray(r,float); return np.interp(r,rr,Ga,left=Ga[0]), np.interp(r,rr,Gb,left=Gb[0])
    return gh,Vm
# ---------------- priors at 17:33Z (sar/endpoint.py + logwind.py) ----------------
ST=json.load(open(os.path.join(HERE,'sar','structure_1733.json'))); LWP=json.load(open(os.path.join(HERE,'logwind_priors.json')))
import logwind as LW
W_OF={'interp':(LW.W2115,0.10),'nat2115':(1.0,0.0),'nat09':(0.0,0.0)}     # 21:15Z weight and its spread, per structure variant
SIG_MEAS=dict(v14=0.03,v20=0.03,vsec=0.035,R2=3.0)
TILT=(1.00,1.10)                 # gradient-level RMW = k x surface RMW, k ~ U(1.00, 1.10) (boundary-layer inflow; Stern & Nolan 2009)
RMS_SFC=1.2                      # surface RMW uncertainty (km)
CONSENSUS=(142.0,10.0)           # wind consensus 150 +- 10 kt 1-min, -8 kt for the azimuthal mean (kt)
SAR_CAL=0.08                     # SAR wind calibration +-8% (Sentinel-1D vs RCM-3 at the eyewall: 0.83)
ELL=dict(interp=(0.042,0.015,187.0,20.0),nat2115=(0.048,0.015,192.0,20.0),nat09=(0.035,0.015,175.0,20.0))   # e0, sd, axis bearing, sd
def _tab_I(tab,s): return float(np.trapezoid(tab[1:]**(2*s)/XE[1:],XE[1:]))
def make_pri(variant='interp',a20case=None):
    s=ST[variant]; g=LWP[variant]; tab=np.array(s['eye'])
    Rs=s['Rm']; km=np.mean(TILT); ksd=(TILT[1]-TILT[0])/np.sqrt(12)
    I=s['I47']; n=1/(2*I)
    hrs=0.0 if variant=='interp' else s['hours_from_nearest_pass']; tsd=3.0 if variant=='interp' else 0.94*hrs
    sar=(s['Vm_rcm'],float(np.hypot(tsd,SAR_CAL*s['Vm_rcm']))); wa=1/sar[1]**2; wb=1/CONSENSUS[1]**2
    vs=((sar[0]*wa+CONSENSUS[0]*wb)/(wa+wb),float(1/np.sqrt(wa+wb)))
    arm=tuple(g['alpha_rm']); vg=(vs[0]/arm[0],float(np.hypot(vs[1]/arm[0],vs[0]/arm[0]*arm[1]/arm[0])))
    dI=(_tab_I(tab,1.01)-_tab_I(tab,0.99))/0.02; e=ELL[variant]
    out=dict(variant=variant,Rm=(Rs*km,float(np.hypot(km*RMS_SFC,Rs*ksd))),Rm_sfc=(Rs,RMS_SFC),n=(n,n*0.03/I),I=(I,0.03),
                s=(1.0,abs(0.03/dI)),tab=tab,R2=(s['R2'],3.0),Pn=(1009.5,2.0),
                v14=(g['v14'][0],float(np.hypot(g['v14'][1],SIG_MEAS['v14']))),v20=(g['v20'][0],float(np.hypot(g['v20'][1],SIG_MEAS['v20']))),
                vsec=(g['vsec'][0],float(np.hypot(g['vsec'][1],SIG_MEAS['vsec']))),x2=tuple(g['x2']),alpha_rm=arm,VSFC=vs,VG=vg,
                e0=(e[0],e[1]),th0=(e[2],e[3]),dens=DENS)
    if a20case is None: return out
    # v12: outer-conversion profile (logwind.alpha_two). The SAR terms become surface-ratio residuals:
    #   (model gradient ratio x alpha(x)/alpha_rm - measured surface ratio) / sd, sd = SAR measurement (0.03; 0.035 secondary maximum)
    #   combined with the spread from the 21:15Z interpolation weight. alpha20 is a fitted parameter with its prior; alpha_rm is drawn per trial.
    w0,wsd=W_OF[variant]; c=LW.A20CASE[a20case]; arm=out['alpha_rm'][0]; a20c=c[1] if c[0]=='norm' else 0.5*(c[1]+c[2])
    x2=LW.x2_two(w0,arm,a20c); r0=LW.sfc_ratios(w0,x2)
    if wsd>0:
        ws=np.clip(np.random.default_rng(5).normal(w0,wsd,3000),0,1); Rr=np.array([[LW.sfc_ratios(w,x2)[k] for k in ('s14','s20','ssec')] for w in ws]); wv=Rr.std(0)
    else: wv=np.zeros(3)
    out.update(a20mode=a20case,a20=c,a20c=a20c,arm_val=arm,w0=w0,wsd=wsd,x2=x2,sfc=dict(s14=r0['s14'],s20=r0['s20'],ssec=r0['ssec']),
               sdm=dict(v14=float(np.hypot(0.03,wv[0])),v20=float(np.hypot(0.03,wv[1])),vsec=float(np.hypot(0.035,wv[2]))),
               R2=(x2*Rs*km,3.0),a14_ll=float(LW.alpha_x(1.4,LW.DEF)),ax2_ll=float(LW.alpha_x(x2,LW.DEF)))
    return out
PRIS={v:make_pri(v) for v in ('interp','nat2115','nat09')}
_P12={}
def get_pri(variant='interp',a20case=None):
    if a20case is None: return PRIS[variant]
    k=(variant,a20case)
    if k not in _P12: _P12[k]=make_pri(variant,a20case)
    return _P12[k]
PRI=PRIS['interp']; VSFC=PRI['VSFC']; ALPHA_RM=PRI['alpha_rm']; VG_PRIOR=PRI['VG']
# ---------------- observation error ----------------
SIG0=0.5; SIGPOS=1.0     # position term: eyewall non-circularity left after the elliptical (wavenumber-2) term: SAR sector-RMW residual sd 0.8-1.0 km
_ref=json.load(open(os.path.join(HERE,'grad_ref.json'))) if os.path.exists(os.path.join(HERE,'grad_ref.json')) else None
def sig_obs(sigpos=None,track='gp'):
    sp=SIGPOS if sigpos is None else sigpos
    g=np.array(_ref['dPdr']) if _ref else np.zeros_like(P)
    v=SIG0**2+(g*sp)**2
    if track=='gp':                                  # track uncertainty outside the wander window enters as extra error
        out=np.ones(NB,bool); out[WIN]=False; v=v+np.where(out,(g*SD_GP)**2,0.0)
    return np.sqrt(v)
# Reading errors: Student-t with nu = 4. The Gaussian sd sigma is used as the t scale (so the t sd is sigma*sqrt(nu/(nu-2)) = 1.41 sigma);
# 'tscale' rescales it (tscale = sqrt((nu-2)/nu) = 0.71 gives a t with sd sigma). nu = 0: Gaussian errors.
ROBUST_NU=4.0
def robust(e,nu):
    return e if not nu else np.sign(e)*np.sqrt((nu+1)*np.log1p(e**2/nu))
def angdiff(a,b): return (a-b+90.0)%180.0-90.0      # axis bearings (period 180 deg)
NBASE=dict(A=13,B=13,U=13,C=16,T=16)
def make_res(family,Pc,track='gp',pri=None,data=None,sig=None,nu=None,shape_prior=True,decay_prior=True,tscale=1.0):
    nu=ROBUST_NU if nu is None else nu
    pri=dict(PRI if pri is None else pri); Pd=P if data is None else data; s=(sig_obs(track=track) if sig is None else sig)*tscale
    off0,soff=TRACKS[track][2],TRACKS[track][3]
    if 'off' in pri: off0=pri['off']
    if 'soff' in pri: soff=pri['soff']
    wand=has_wander(track,pri); nb=NBASE[family]; a2=pri.get('a20mode'); na=1 if a2 else 0; nx=nb+2+na+(2*NW if wand else 0)
    sar_on=not pri.get('buoyonly',False)
    d0=np.asarray(pri.get('dlt0',np.zeros((NW,2))))
    ell=pri.get('ell',True); troch=pri.get('troch',None); tab=pri['tab'] if family in 'TU' else None
    dd=pri.get('dens',DENS); cache={}
    def prof(Rm,n,A,X1,X2,a,R2,W2,Dtot):
        key=(Rm,n,A,X1,X2,a,R2,W2,Dtot)
        if key not in cache:
            if len(cache)>8: cache.clear()
            cache[key]=wind_deficit(Rm,n,A,X1,X2,a,R2,W2,Dtot,Pc,dd,tab=tab)
        return cache[key]
    def unpack(q):
        q=np.asarray(q,float); u=dict(family=family,Pc=Pc,track=track)
        if family=='A':
            fr,R1,B1,R2h,B2,sx,sy=q[:7]; bg=q[7:13]; u['Dtot']=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            u.update(parts=[(u['Dtot']*fr,R1,B1),(u['Dtot']*(1-fr),R2h,B2)],Rm=R1)
        else:
            if family in 'BU': Rm,n,A,X1,X2,sx,sy=q[:7]; a,R2,W2=0.0,120.0,30.0; bg=q[7:13]
            else: Rm,n,A,X1,X2,a,R2,W2,sx,sy=q[:10]; bg=q[10:16]
            u.update(Rm=Rm,n=n,A=A,X1=X1,X2=X2,a=a,R2=R2,W2=W2); u['Dtot']=background(bg,np.array([TC]),np.array([LST_C]))[0]-Pc
            gh,Vm=prof(Rm,n,A,X1,X2,a,R2,W2,u['Dtot']) if u['Dtot']>5 else (None,np.nan); u.update(gh=gh,Vm=Vm)
        u.update(sx=sx,sy=sy,bg=np.array(bg),e0=q[nb],th0=q[nb+1]); u['a20']=q[nb+2] if a2 else None
        u['dlt']=q[nb+2+na:].reshape(2,NW).T if wand else None
        return u
    def deficit(u,r):
        if u['family']=='A': return defA(r,u['parts'])
        g,h=u['gh'](r); return (g*u['Vm']**2+h*u['Vm'])/100
    def shift(u,tq):
        sx,sy=u['sx'],u['sy']
        if u['dlt'] is not None:
            if tq is t: dx=np.zeros(NB); dy=np.zeros(NB); dx[WIN]=u['dlt'][:,0]; dy[WIN]=u['dlt'][:,1]
            else: dx,dy=wander_at(tq,u['dlt'])
            sx=sx+dx; sy=sy+dy
        ax,ay=troch_at(tq,troch); return sx+ax,sy+ay
    def pressure(u,tq=t,la=lat,lo=lon,lst=None):
        sx,sy=shift(u,tq); dx,dy=geom(track,sx,sy,tq,la,lo); re,r=r_eff(dx,dy,u['e0'],u['th0'])
        return background(u['bg'],tq,tq+lo/15.0 if lst is None else lst)-deficit(u,re), r, re
    def conv(u):
        """v12: alpha at 1.4 RMW, 2 RMW and the secondary-maximum radius over alpha_rm"""
        arm=pri['arm_val']; a20=u['a20']
        if a2=='independent': return pri['a14_ll']/arm, a20/arm, pri['ax2_ll']/arm
        return LW.alpha_two(1.4,arm,a20)/arm, a20/arm, LW.alpha_two(pri['x2'],arm,a20)/arm
    def sarterm(model,key,fac,on=True):
        if not (on and sar_on): return 0.0
        if a2: return (model*fac-pri['sfc']['s'+key[1:]])/pri['sdm'][key]
        return (model-pri[key][0])/pri[key][1]
    def res(q):
        u=unpack(q); npen=nx-nb+(10 if family in 'CT' else 8)
        f14,f20,fsec=conv(u) if a2 else (1.0,1.0,1.0)
        if u['Dtot']<=5: return np.full(NB+npen,1e3)
        Pm,_,_=pressure(u); e=robust((Pm-Pd)/s,nu)
        pen=[(u['sx']-off0[0])/soff,(u['sy']-off0[1])/soff,(u['bg'][0]-pri['Pn'][0])/pri['Pn'][1]]
        if family=='A':
            parts=u['parts']; rr=np.linspace(2,150,500); vg=vgA_rho(rr,parts,Pc,u['Dtot'],dd,parts[0][1]); i=vg.argmax(); rm=rr[i]
            pen.append((rm-pri['Rm'][0])/pri['Rm'][1])
            if shape_prior: ri=np.geomspace(0.05,rm,250); vi=vgA_rho(ri,parts,Pc,u['Dtot'],dd,parts[0][1]); I=np.trapezoid((vi/vg[i])**2/ri,ri); pen.append((I-pri['I'][0])/pri['I'][1])
            else: pen.append(0.0)
            pen.append(sarterm(np.interp(1.4*rm,rr,vg)/vg[i],'v14',f14,decay_prior))
            pen.append(((vg[i]*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0)
            pen.append(sarterm(np.interp(2.0*rm,rr,vg)/vg[i],'v20',f20,decay_prior and a2!='free'))
        else:
            Rm,n,A,X1,X2,a,R2,W2=(u[k] for k in ('Rm','n','A','X1','X2','a','R2','W2'))
            vR=shapeC(np.array([Rm,1.4*Rm,2.0*Rm]),Rm,n,A,X1,X2,a,R2,W2,tab)
            pen.append((Rm-pri['Rm'][0])/pri['Rm'][1])
            sp_=pri['s'] if family in 'TU' else pri['n']; pen.append(((n-sp_[0])/sp_[1]) if shape_prior else 0.0)
            pen.append(sarterm(vR[1]/vR[0],'v14',f14,decay_prior))
            pen.append(((u['Vm']*vR[0]*KT-pri['Vg'][0])/pri['Vg'][1]) if 'Vg' in pri else 0.0)
            pen.append(sarterm(vR[2]/vR[0],'v20',f20,decay_prior and a2!='free'))
            if family in 'CT':
                pen.append((R2-pri['R2'][0])/pri['R2'][1] if sar_on else 0.0)
                pen.append(sarterm(shapeC(Rm*np.linspace(1.2,3.0,60),Rm,n,A,X1,X2,a,R2,W2,tab).max()/vR[0],'vsec',fsec))
        pen+=[(u['e0']-pri['e0'][0])/pri['e0'][1] if ell else u['e0']/1e-3,angdiff(u['th0'],pri['th0'][0])/pri['th0'][1]]      # ell off: e0 pinned at 0
        if a2: pen.append((u['a20']-pri['a20c'])/pri['a20'][2] if pri['a20'][0]=='norm' else 0.0)                         # flat: bounds only
        if u['dlt'] is not None: pen+=list((LWINI@(u['dlt'][:,0]-d0[:,0])))+list((LWINI@(u['dlt'][:,1]-d0[:,1])))
        return np.r_[e,pen]
    if family=='A': lb=[0.05,8,0.8,40,0.5]; ub=[0.97,70,4.5,500,3]
    elif family in 'BU': lb=[10,0.3 if family=='U' else 0.4,0.0,3,40]; ub=[60,3.0 if family=='U' else 4.0,1.0,150,1500]
    else: lb=[10,0.3 if family=='T' else 0.8,0.0,3,40,0.0,30,4]; ub=[60,3.0 if family=='T' else 5.0,1.0,150,1500,0.9,120,40]
    lb+=[off0[0]-40,off0[1]-40,1000,-1,-3,-3,-3,-3]; ub+=[off0[0]+40,off0[1]+40,1020,1,3,3,3,3]
    lb+=[0.0,pri['th0'][0]-90]; ub+=[0.15,pri['th0'][0]+90]
    if a2: c=pri['a20']; lb+=[0.5 if c[0]=='norm' else c[1]]; ub+=[1.1 if c[0]=='norm' else c[2]]
    if wand: lb+=[-12.0]*(2*NW); ub+=[12.0]*(2*NW)
    res.pressure=pressure; res.deficit=deficit; res.shift=shift
    return res,unpack,np.array(lb,float),np.array(ub,float)
def base_x(family,track,pri=None):
    """a neutral starting vector for the non-profile parameters (offset, background, ellipse, wander)"""
    pri=PRI if pri is None else pri; off0=pri.get('off',TRACKS[track][2])
    x=[*off0,1009.5,-0.05,0.2,0.2,-0.5,-1.0,pri['e0'][0] if pri.get('ell',True) else 1e-4,pri['th0'][0]]
    if pri.get('a20mode'): x+=[pri['a20c']]
    if has_wander(track,pri): x+=list(np.zeros(2*NW))
    return x
def starts(family,track,n_rand,seed,lb,ub,pri=None):
    bx=base_x(family,track,pri); nb=NBASE[family]; core=[]
    if family in 'CT':
        n0=(1.0,) if family=='T' else (1.2,1.7)
        core=[[Rm,n,0.4,X1,X2,a,R2,W2] for Rm in (24.5,28) for n in n0 for X1,X2 in ((15,250),(40,500)) for a,R2,W2 in ((0.08,42,7),(0.2,48,14))]
        u=qmc.LatinHypercube(d=8,seed=seed).random(n_rand)
        rnd=np.c_[22+u[:,0]*9,(0.8+u[:,1]*0.4) if family=='T' else (0.9+u[:,1]*1.6),u[:,2],np.exp(np.log(3)+u[:,3]*np.log(50)),np.exp(np.log(40)+u[:,4]*np.log(1500/40)),u[:,5]*0.4,34+u[:,6]*22,4+u[:,7]*22]
    elif family=='A':
        core=[[fr,R1,B1,R2,1.45] for fr in (0.6,0.75) for R1 in (25,30) for B1 in (1.8,2.8) for R2 in (110,150)]
        u=qmc.LatinHypercube(d=5,seed=seed).random(n_rand); rnd=lb[:5]+u*(ub[:5]-lb[:5]); rnd[:,3]=np.exp(np.log(40)+u[:,3]*np.log(500/40))
    else:
        core=[[Rm,n,A,X1,X2] for Rm in (25,29) for n in ((1.0,) if family=='U' else (1.2,1.8)) for A in (0.3,0.6) for X1,X2 in ((15,200),(40,400))]
        u=qmc.LatinHypercube(d=5,seed=seed).random(n_rand); rnd=lb[:5]+u*(ub[:5]-lb[:5]); rnd[:,4]=np.exp(np.log(40)+u[:,4]*np.log(1500/40)); rnd[:,3]=np.exp(np.log(3)+u[:,3]*np.log(50))
        if family=='U': rnd[:,1]=0.8+u[:,1]*0.4
    out=[np.r_[c,bx] for c in core]+[np.r_[c,bx] for c in rnd]
    return [np.clip(o,lb+1e-6,ub-1e-6) for o in out]
def solve(family,Pc,track='gp',n_rand=40,seed=0,extra=(),**kw):
    res,unpack,lb,ub=make_res(family,Pc,track,**kw)
    best=None; costs=[]
    for s0 in list(extra)+starts(family,track,n_rand,seed,lb,ub,kw.get('pri')):
        try: s=least_squares(res,np.clip(s0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
        except Exception: continue
        costs.append(s.cost)
        if best is None or s.cost<best.cost: best=s
    return best,np.array(costs),unpack
def closest(res,u,t0=16.0,t1=19.0):
    tq=np.linspace(t0,t1,1801); la=np.interp(tq,t,lat); lo=np.interp(tq,t,lon); _,r,re=res.pressure(u,tq,la,lo); i=int(np.argmin(r)); return float(r[i]),float(tq[i]),float(re[i])
def summarize(family,best,unpack,Pc,track='gp',res=None,pri=None):
    u=unpack(best.x)
    if res is None: res,_,_,_=make_res(family,Pc,track,pri=pri)
    if family=='A':
        rr=np.linspace(2,150,1500); vg=vgA_rho(rr,u['parts'],Pc,u['Dtot'],DENS,u['parts'][0][1]); i=vg.argmax(); rm=rr[i]; vmax=vg[i]
        E=u['Dtot']-defA(np.array([rm]),u['parts'])[0]
    else:
        tab=(pri or PRI)['tab'] if family in 'TU' else None
        rm=u['Rm']; vmax=u['Vm']*shapeC(np.array([rm]),rm,u['n'],u['A'],u['X1'],u['X2'],u['a'],u['R2'],u['W2'],tab)[0]
        g,h=u['gh'](np.array([rm])); E=u['Dtot']-(g[0]*u['Vm']**2+h[0]*u['Vm'])/100
    Pm,r,re=res.pressure(u); rc,tcl,rec=closest(res,u)
    return dict(Pc=float(Pc),chi2=float(2*best.cost),rmw=float(rm),vg=float(vmax*KT),eye=float(E),off=[float(u['sx']),float(u['sy'])],bg=[float(v) for v in u['bg']],
                e0=float(u['e0']),th0=float(u['th0']),r17=float(r[17]),r18=float(r[18]),re17=float(re[17]),re18=float(re[18]),rmin=float(min(r[17],r[18])),
                rclose=rc,tclose=tcl,resid=[float(v) for v in (P-Pm)],x=[float(v) for v in best.x],
                dlt=(u['dlt'].tolist() if u['dlt'] is not None else None))
