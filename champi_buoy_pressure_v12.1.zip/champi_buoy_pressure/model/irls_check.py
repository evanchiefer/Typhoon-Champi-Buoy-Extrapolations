# Check of the reading-error position term against the gradient of the v12 fit (the other group's "IRLS" proposal).
# The headline uses fixed reference gradients (grad_ref.json, from a v11 fit at 886 hPa). Here, on the unperturbed headline ring-model
# configuration: (a) gradients refreshed from the v12 best fit and iterated to convergence, fixed across Pc;
# (b) gradients recomputed from each Pc's own fit, iterated (no log-det term); (c) as (b) with the Gaussian log-det term added.
import sys, os, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import mc, core as C
from core import make_res, least_squares, geom, r_eff, SIG0, SIGPOS, NB, WIN
S=[r for r in json.load(open(os.path.join(HERE,'scan_v12.json'))) if r['name']=='T_gp']
GRID=np.arange(868,899.1,3.0); X0={r['Pc']:np.array(r['x']) for r in S}
j=dict(mc.DEF,fam='T'); pri,data,s_old=mc.build(j,None)
def fit(Pc,s,x0):
    res,unpack,lb,ub=make_res('T',Pc,'gp',pri=pri,sig=s)
    r=least_squares(res,np.clip(x0,lb+1e-6,ub-1e-6),bounds=(lb,ub),x_scale='jac',max_nfev=4000)
    return r,res,unpack
def grad(Pc,r,res,unpack):
    u=unpack(r.x); sx,sy=res.shift(u,C.t); dx,dy=geom('gp',sx,sy); re,_=r_eff(dx,dy,u['e0'],u['th0']); e=0.25
    return -(res.deficit(u,re+e)-res.deficit(u,np.maximum(re-e,0.01)))/(2*e)
def sig_from(g):
    v=SIG0**2+(g*SIGPOS)**2; out=np.ones(NB,bool); out[WIN]=False
    return np.sqrt(v+np.where(out,(g*C.SD_GP)**2,0.0))
def vertex(P,c):
    i=int(np.argmin(c)); i=min(max(i,1),len(P)-2); a,b,cc=np.polyfit(P[i-1:i+2],c[i-1:i+2],2); return -b/(2*a)
g_ref=np.array(C._ref['dPdr']); out={}
# (a) global refresh
s=s_old; hist=[]
for it in range(4):
    rows=[fit(Pc,s,X0[Pc]) for Pc in GRID]; c=np.array([2*r.cost for r,_,_ in rows]); pm=vertex(GRID,c); hist.append(round(float(pm),2))
    k=int(np.argmin(np.abs(GRID-pm))); r,res,un=rows[k]; g=grad(GRID[k],r,res,un); s=sig_from(g)
    if it==0: g_v12=g
    if len(hist)>1 and abs(hist[-1]-hist[-2])<0.1: break
out['a_global_refresh']=dict(MAP_by_iteration=hist,chi2=[float(x) for x in c])
print('(a) MAP by iteration',hist,flush=True)
# (b),(c) per-Pc gradients
cb=[]; cc=[]
for Pc in GRID:
    s=s_old; x0=X0[Pc]
    for it in range(6):
        r,res,un=fit(Pc,s,x0); g=grad(Pc,r,res,un); s_new=sig_from(g); x0=r.x
        if np.max(np.abs(s_new-s))<1e-3: break
        s=s_new
    cb.append(2*r.cost); cc.append(2*r.cost+2*np.sum(np.log(s)))
cb=np.array(cb); cc=np.array(cc)
out['b_perPc_nologdet']=dict(MAP=float(vertex(GRID,cb))); out['c_perPc_logdet']=dict(MAP=float(vertex(GRID,cc)))
out['MAP_fixed_ref']=float(vertex(np.array([r['Pc'] for r in S]),np.array([r['chi2'] for r in S])))
idx=[i for i in range(NB) if abs(C.t[i]-17.55)<3]
out['gradients']=dict(t=[float(C.t[i]) for i in idx],ref_v11=[float(g_ref[i]) for i in idx],v12=[float(g_v12[i]) for i in idx])
json.dump(out,open(os.path.join(HERE,'irls_check.json'),'w'),indent=1); print(json.dumps(out,indent=1))
